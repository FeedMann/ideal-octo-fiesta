local M = COD1MV

CreateClientConVar( "cod1mv_codkeys", "0", true, true, "1 = Call of Duty keys: Alt sprint, Shift melee, Q/E lean, F use, Ctrl prone, C crouch" )
CreateClientConVar( "cod1mv_bob", "1", true, false, "1 = Call of Duty view and weapon bob" )
CreateClientConVar( "cod1mv_hud", "1", true, false, "1 = Call of Duty stance icon" )

local held = {}
for _, n in ipairs( { "leanleft", "leanright" } ) do
	concommand.Add( "+cod1mv_" .. n, function() held[ n ] = true end )
	concommand.Add( "-cod1mv_" .. n, function() held[ n ] = false end )
end
concommand.Add( "cod1mv_goprone", function() held.pronePulse = true end )
concommand.Add( "cod1mv_gocrouch", function() held.crouchPulse = true end )

local REMAP = { [ "+menu" ] = true, [ "+use" ] = true, [ "impulse 100" ] = true, [ "+duck" ] = true, [ "+menu_context" ] = true }

local function keysOn()
	return GetConVar( "cod1mv_codkeys" ):GetBool() and M.Active( LocalPlayer() ) and not vgui.CursorVisible()
end

local function bindDown( bind )
	local key = input.LookupBinding( bind )
	local code = key and input.GetKeyCode( key )
	return code and code > 0 and input.IsKeyDown( code )
end

hook.Add( "PlayerBindPress", "COD1MV", function( ply, bind, pressed )
	if pressed and REMAP[ bind ] and keysOn() then return true end
end )

local proneYaw
hook.Add( "CreateMove", "COD1MV", function( cmd )
	local ply = LocalPlayer()
	local on = keysOn()
	local state = {
		leanleft = held.leanleft or ( on and bindDown( "+menu" ) ),
		leanright = held.leanright or ( on and bindDown( "+use" ) ),
		prone = on and bindDown( "+duck" ),
		crouch = on and bindDown( "+menu_context" ),
		use = on and bindDown( "impulse 100" ),
	}
	local b = cmd:GetButtons()
	if state.leanleft then b = bit.bor( b, IN_WEAPON1 ) end
	if state.leanright then b = bit.bor( b, IN_WEAPON2 ) end
	if state.prone or held.pronePulse then b = bit.bor( b, IN_GRENADE1 ) end
	if state.crouch or held.crouchPulse then b = bit.bor( b, IN_GRENADE2 ) end
	if on then
		b = bit.band( b, bit.bnot( bit.bor( IN_USE, IN_DUCK ) ) )
		if state.use then b = bit.bor( b, IN_USE ) end
		if bit.band( b, IN_WALK ) ~= 0 then
			b = bit.bor( bit.band( b, bit.bnot( IN_WALK ) ), IN_ALT2 )
			local f, s = cmd:GetForwardMove(), cmd:GetSideMove()
			if f ~= 0 then cmd:SetForwardMove( f > 0 and 10000 or -10000 ) end
			if s ~= 0 then cmd:SetSideMove( s > 0 and 10000 or -10000 ) end
		end
	end
	if cmd:CommandNumber() ~= 0 then held.pronePulse, held.crouchPulse = nil, nil end
	cmd:SetButtons( b )

	if M.Active( ply ) and M.Stance( ply ) == M.PRONE then
		local ang = cmd:GetViewAngles()
		proneYaw = proneYaw or ang.y
		local d = math.AngleDifference( ang.y, proneYaw )
		local turn = M.PRONE_TURN * FrameTime()
		proneYaw = proneYaw + math.Clamp( d, -turn, turn )
		d = math.AngleDifference( ang.y, proneYaw )
		if math.abs( d ) > M.PRONE_YAWCAP then
			ang.y = proneYaw + M.PRONE_YAWCAP * ( d > 0 and 1 or -1 )
			cmd:SetViewAngles( ang )
		end
	else
		proneYaw = nil
	end
end )

local bob = { cycle = 0, speed = 0, sway = Angle(), lastAng = nil, sprint = 0, prone = 0, wpos = { 0, 0, 0 }, wrot = { 0, 0, 0 } }
local POS, ROT = { "F", "R", "U" }, { "P", "Y", "R" }

local function vertical( stance, cycle, speed, max )
	local amp = math.min( M.BOB[ stance ] * speed, max )
	return ( math.sin( cycle * 4 + math.pi / 2 ) * 0.2 + math.sin( cycle * 2 ) ) * amp * 0.75
end

local function horizontal( stance, cycle, speed, max )
	return math.sin( cycle ) * math.min( M.BOB[ stance ] * speed, max )
end

hook.Add( "Think", "COD1MV", function()
	local ply = LocalPlayer()
	if not IsValid( ply ) or not M.Active( ply ) then bob.cycle, bob.speed = 0, 0 return end
	local dt = FrameTime()
	local speed = ply:OnGround() and ply:GetVelocity():Length2D() or 0
	bob.speed = speed
	if speed < 5 then bob.cycle = 0 return end
	local old = bob.cycle
	bob.cycle = old + M.StrideRate( ply, speed ) * dt * 2 * math.pi
	if math.floor( bob.cycle / math.pi ) ~= math.floor( old / math.pi ) and GetConVar( "cod1mv_footsteps" ):GetBool() then
		local kind = M.StepKind( ply, speed )
		local surf = M.Surface( ply )
		local function play( alias )
			local silent = M.Silent[ alias ]
			if not ( silent and math.random() < silent ) then ply:EmitSound( "COD1MV." .. alias ) end
		end
		play( "step_" .. kind .. "_" .. surf )
		if kind ~= "prone" then play( "gear_rattle_" .. kind ) end
	end
	bob.cycle = bob.cycle % ( 4 * math.pi )
end )

local lastView
hook.Add( "CalcView", "COD1MV", function( ply, origin, angles, fov, znear, zfar )
	lastView = nil
	if ply ~= LocalPlayer() or not M.Active( ply ) or ply:ShouldDrawLocalPlayer() or ply:GetViewEntity() ~= ply then return end
	local view = GAMEMODE:CalcView( ply, origin, angles, fov, znear, zfar )
	if not view then return end
	local ang = view.angles
	local stance = M.Stance( ply )
	local off = M.LeanOffset( ply, ang.y )
	view.origin = view.origin - ply:GetCurrentViewOffset() + Vector( 0, 0, M.EyeHeight( ply ) ) + off
	if GetConVar( "cod1mv_bob" ):GetBool() and bob.speed >= 5 then
		view.origin = view.origin + Vector( 0, 0, vertical( stance, bob.cycle, bob.speed, M.BOB_MAX ) )
			+ ang:Right() * horizontal( stance, bob.cycle, bob.speed, M.BOB_MAX )
	end
	lastView = { origin = view.origin, angles = view.angles }
	return view
end )

hook.Add( "CalcViewModelView", "COD1MV", function( wep, vm, oldPos, oldAng, pos, ang )
	local ply = LocalPlayer()
	if not lastView or not M.Active( ply ) then return end
	local p, a = Vector( lastView.origin ), Angle( lastView.angles )
	if wep.GetViewModelPosition then p, a = wep:GetViewModelPosition( p, a ) end
	local d = wep.Def and wep:Def() or {}
	local dt = FrameTime()
	local ads = wep.ADSFraction and wep:ADSFraction() or 0

	if GetConVar( "cod1mv_bob" ):GetBool() and bob.speed >= 5 then
		local stance = M.Stance( ply )
		local s = bob.speed * M.WBOB
		local c1 = bob.cycle + M.WBOB_LAG * math.pi + 2 * math.pi
		local k = 1 - ads
		local pitch = -vertical( stance, c1, s, M.WBOB_MAX ) * k
		local yaw = -horizontal( stance, c1, s, M.WBOB_MAX ) * k
		local rollAmp = math.min( M.BOB[ stance ] * M.WBOB_ROLL * s, M.WBOB_MAX )
		local roll = math.min( math.sin( c1 - 0.471239 ) * rollAmp, 0 ) * k
		a:RotateAroundAxis( a:Right(), pitch )
		a:RotateAroundAxis( a:Up(), yaw )
		a:RotateAroundAxis( a:Forward(), roll )
	end

	local va = lastView.angles
	if bob.lastAng then
		local dp, dy = math.AngleDifference( va.p, bob.lastAng.p ), math.AngleDifference( va.y, bob.lastAng.y )
		local max = ads > 0.5 and ( d.adsSwayMaxAngle or 30 ) or ( d.swayMaxAngle or 30 )
		local speed = ads > 0.5 and ( d.adsSwayLerpSpeed or 6 ) or ( d.swayLerpSpeed or 6 )
		bob.sway.p = math.Clamp( bob.sway.p + dp, -max, max )
		bob.sway.y = math.Clamp( bob.sway.y + dy, -max, max )
		local f = math.Clamp( dt * speed, 0, 1 )
		bob.sway.p = Lerp( f, bob.sway.p, 0 )
		bob.sway.y = Lerp( f, bob.sway.y, 0 )
	end
	bob.lastAng = Angle( va.p, va.y, 0 )
	local ps, ys = d.swayPitchScale or 0.1, d.swayYawScale or 0.1
	local hs, vs = d.swayHorizScale or 0.1, d.swayVertScale or 0.1
	a:RotateAroundAxis( a:Right(), -bob.sway.p * ps )
	a:RotateAroundAxis( a:Up(), bob.sway.y * ys )
	p = p - a:Right() * bob.sway.y * hs + a:Up() * bob.sway.p * vs

	local wm = wep.CoDKey and M.WeaponMove and M.WeaponMove[ wep.CoDKey ]
	if wm then
		local stance = M.Stance( ply )
		local pre = stance == M.PRONE and "prone" or stance == M.CROUCH and "ducked" or "stand"
		local spd = ply:OnGround() and ply:GetVelocity():Length2D() or 0
		local function frac( min )
			min = min or 0
			if spd <= min then return 0 end
			return math.Clamp( ( spd - min ) / ( M.RUN - min ), 0, 1 )
		end
		local fm, fr, k = frac( wm[ pre .. "MoveMinSpeed" ] ), frac( wm[ pre .. "RotMinSpeed" ] ), 1 - ads
		local prone = stance == M.PRONE
		local mr = math.Clamp( dt * ( ( prone and wm.posProneMoveRate or wm.posMoveRate ) or 10 ), 0, 1 )
		local rr = math.Clamp( dt * ( ( prone and wm.posProneRotRate or wm.posRotRate ) or 10 ), 0, 1 )
		for i, ax in ipairs( POS ) do
			local t = ( ( wm[ pre .. "Ofs" .. ax ] or 0 ) + fm * ( wm[ pre .. "Move" .. ax ] or 0 ) ) * k
			bob.wpos[ i ] = bob.wpos[ i ] + ( t - bob.wpos[ i ] ) * mr
		end
		for i, ax in ipairs( ROT ) do
			local t = fr * ( wm[ pre .. "Rot" .. ax ] or 0 ) * k
			bob.wrot[ i ] = bob.wrot[ i ] + ( t - bob.wrot[ i ] ) * rr
		end
		a:RotateAroundAxis( a:Right(), -bob.wrot[ 1 ] )
		a:RotateAroundAxis( a:Up(), bob.wrot[ 2 ] )
		a:RotateAroundAxis( a:Forward(), bob.wrot[ 3 ] )
		p = p + a:Forward() * bob.wpos[ 1 ] + a:Right() * bob.wpos[ 2 ] + a:Up() * bob.wpos[ 3 ]
	end

	bob.sprint = math.Approach( bob.sprint, M.Sprinting( ply ) and 1 or 0, dt * 5 )
	bob.prone = math.Approach( bob.prone, M.Stance( ply ) == M.PRONE and 1 or 0, dt / M.TO_PRONE )
	local lean = M.LeanEase( M.Lean( ply ) )
	if lean ~= 0 then p = p + a:Right() * lean * Lerp( ads, M.LEAN_GUN, M.LEAN_GUN_ADS ) end

	local sp, pr = bob.sprint, ( wm and 0 or bob.prone ) * ( 1 - ads )
	if sp > 0 or pr > 0 then
		a:RotateAroundAxis( a:Right(), -( d.sprintRotP or 0 ) * sp )
		a:RotateAroundAxis( a:Up(), ( d.sprintRotY or 0 ) * sp )
		a:RotateAroundAxis( a:Forward(), ( d.sprintRotR or 0 ) * sp )
		local f = ( d.sprintMoveF or -14 ) * sp + ( d.proneOfsF or -2 ) * pr
		local r = ( d.sprintMoveR or -10 ) * sp + ( d.proneOfsR or 1.5 ) * pr
		local u = ( d.sprintMoveU or -14 ) * sp + ( d.proneOfsU or 0.8 ) * pr
		p = p + a:Forward() * f + a:Right() * r + a:Up() * u
	end
	return p, a
end )

local ICON, MAN = {}, {}
for _, n in ipairs( { "stand", "crouch", "prone", "sprint" } ) do
	ICON[ n ] = Material( "cod1mv/hud/stance_" .. n )
	MAN[ n ] = Material( "cod1mv/hud/stance_" .. n .. "_man" )
end
local FLASH = Material( "cod1mv/hud/stance_flash" )

hook.Add( "HUDPaint", "COD1MV", function()
	local ply = LocalPlayer()
	if not M.Active( ply ) or not GetConVar( "cod1mv_hud" ):GetBool() or not GetConVar( "cl_drawhud" ):GetBool() then return end
	local sx, sy = ScrW() / 640, ScrH() / 480
	local x, y, w, h = 100 * sx, 434.375 * sy, 40 * sy, 40 * sy
	local stance = M.Stance( ply )
	local name = M.Sprinting( ply ) and "sprint" or stance == M.PRONE and "prone" or stance == M.CROUCH and "crouch" or "stand"
	local flash = math.Clamp( 1 - ( CurTime() - ply:GetNW2Float( "c1mvBlocked", 0 ) ) / 0.5, 0, 1 )
	surface.SetDrawColor( 255, 255 - 255 * flash, 255 - 255 * flash, 255 )
	surface.SetMaterial( flash > 0 and FLASH or ICON[ name ] )
	surface.DrawTexturedRect( x, y, w, h )
	if flash > 0 then
		surface.SetMaterial( ICON[ name ] )
		surface.DrawTexturedRect( x, y, w, h )
	end
	local stamina = M.Stamina( ply )
	surface.SetMaterial( MAN[ name ] )
	surface.SetDrawColor( 255, 255, 255, 70 )
	surface.DrawTexturedRect( x, y, w, h )
	if stamina > 0 then
		local top = 1 - stamina
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRectUV( x, y + h * top, w, h * stamina, 0, top, 1, 1 )
	end
end )

--the gun bobs so you dont have to
