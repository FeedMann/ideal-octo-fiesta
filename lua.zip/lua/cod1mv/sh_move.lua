local M = COD1MV

M.STAND, M.CROUCH, M.PRONE = 0, 1, 2
M.RUN = 190
M.SCALE = { [ 0 ] = 1, [ 1 ] = 0.65, [ 2 ] = 0.15 }
M.BACK, M.STRAFE, M.ADS = 0.7, 0.8, 0.6
M.VIEW = { [ 0 ] = 60, [ 1 ] = 40, [ 2 ] = 11 }
M.HULL = { [ 0 ] = 70, [ 1 ] = 50, [ 2 ] = 30 }
M.TO_PRONE = 0.4
M.JUMP = 216
M.SPRINT, M.SPRINT_TIME, M.SPRINT_RECHARGE, M.SPRINT_PAUSE, M.SPRINT_MIN = 1.6, 1.5, 3, 1, 0.25
M.EYE_HIGH, M.EYE_LOW = 100, 72.5
M.LEAN_DIST, M.LEAN_ROLL, M.LEAN_OUT, M.LEAN_IN = 20, 16, 0.35, 0.28
M.LEAN_MAX = { [ 0 ] = 1, [ 1 ] = 0.5, [ 2 ] = 0.25 }
M.LEAN_GUN, M.LEAN_GUN_ADS = 2, 0.8
M.BOB = { [ 0 ] = 0.008, [ 1 ] = 0.015, [ 2 ] = 0.03 }
M.BOB_MAX = 8
M.WBOB, M.WBOB_MAX, M.WBOB_LAG, M.WBOB_ROLL = 0.16, 10, 0.25, 1.5
M.STRIDE = { [ 0 ] = 1.45 / 190, [ 1 ] = 1.25 / 123, [ 2 ] = 0.9 / 28 }
M.PRONE_YAWCAP, M.PRONE_TURN = 85, 45

local IN_PRONE, IN_CROUCH, IN_LEAN_L, IN_LEAN_R = IN_GRENADE1, IN_GRENADE2, IN_WEAPON1, IN_WEAPON2
local FLAGS = bit.bor( FCVAR_ARCHIVE, FCVAR_REPLICATED )
local MINS = Vector( -16, -16, 0 )
local TOOLS = { weapon_physgun = true, gmod_tool = true, gmod_camera = true }

CreateConVar( "cod1mv_enable", "1", FLAGS, "1 = Call of Duty movement for players" )
CreateConVar( "cod1mv_codonly", "0", FLAGS, "1 = only while holding a Call of Duty weapon" )
CreateConVar( "cod1mv_footsteps", "1", FLAGS, "1 = Call of Duty footstep, landing and gear sounds" )

function M.Active( ply )
	if not GetConVar( "cod1mv_enable" ):GetBool() or not IsValid( ply ) or not ply:Alive() or ply:InVehicle() then return false end
	if ply:GetMoveType() ~= MOVETYPE_WALK then return false end
	local wep = ply:GetActiveWeapon()
	if IsValid( wep ) and TOOLS[ wep:GetClass() ] then return false end
	if GetConVar( "cod1mv_codonly" ):GetBool() and not ( IsValid( wep ) and wep.CoDKey ) then return false end
	return true
end

function M.Stance( ply ) return ply:GetNW2Int( "c1mvStance", 0 ) end
function M.Sprinting( ply ) return ply:GetNW2Bool( "c1mvSprint", false ) end
function M.Stamina( ply ) return ply:GetNW2Float( "c1mvStamina", 1 ) end
function M.Lean( ply ) return ply:GetNW2Float( "c1mvLean", 0 ) end
function M.LeanEase( f ) return ( 2 - math.abs( f ) ) * f end

function M.EyeHeight( ply )
	local h, to = ply:GetNW2Float( "c1mvEyeFrom", M.VIEW[ 0 ] ), M.VIEW[ M.Stance( ply ) ]
	local t = CurTime() - ply:GetNW2Float( "c1mvStanceT", 0 )
	local mid = M.VIEW[ 1 ]
	for _ = 1, 3 do
		if t <= 0 or h == to then break end
		local up = to > h
		local stop, rate
		if up then
			stop, rate = h < mid and math.min( mid, to ) or to, h < mid and M.EYE_LOW or M.EYE_HIGH
		else
			stop, rate = h > mid and math.max( mid, to ) or to, h > mid and M.EYE_HIGH or M.EYE_LOW
		end
		local need = math.abs( stop - h ) / rate
		if t >= need then
			h, t = stop, t - need
		else
			h, t = h + ( up and 1 or -1 ) * rate * t, 0
		end
	end
	return h
end

function M.ProneSettling( ply )
	return M.Stance( ply ) == M.PRONE and CurTime() - ply:GetNW2Float( "c1mvStanceT", 0 ) < M.TO_PRONE
end

function M.Crawling( ply )
	return M.Stance( ply ) == M.PRONE and ply:GetVelocity():Length2D() > 15
end

function M.FireBlocked( ply )
	return CurTime() - ply:GetNW2Float( "c1mvSprintEnd", 0 ) < 0.2 or M.ProneSettling( ply ) or M.Crawling( ply )
end

local function setHulls( ply, stance )
	if ply.c1mvHull == stance then return end
	ply.c1mvHull = stance
	if stance == nil then
		ply:SetHull( MINS, Vector( 16, 16, 72 ) )
		ply:SetHullDuck( MINS, Vector( 16, 16, 36 ) )
		ply:SetViewOffset( Vector( 0, 0, 64 ) )
		ply:SetViewOffsetDucked( Vector( 0, 0, 28 ) )
		ply:SetJumpPower( 200 )
		return
	end
	local low = stance == M.PRONE and M.PRONE or M.CROUCH
	ply:SetHull( MINS, Vector( 16, 16, M.HULL[ 0 ] ) )
	ply:SetHullDuck( MINS, Vector( 16, 16, M.HULL[ low ] ) )
	ply:SetViewOffset( Vector( 0, 0, M.VIEW[ 0 ] ) )
	ply:SetViewOffsetDucked( Vector( 0, 0, M.VIEW[ low ] ) )
	ply:SetJumpPower( M.JUMP )
end

local function roomFor( ply, stance )
	local pos = ply:GetPos()
	return not util.TraceHull( { start = pos + Vector( 0, 0, 2 ), endpos = pos + Vector( 0, 0, 2 ),
		mins = MINS, maxs = Vector( 16, 16, M.HULL[ stance ] - 2 ), filter = ply, mask = MASK_PLAYERSOLID } ).Hit
end

function M.Surface( ply )
	if ply:WaterLevel() >= 1 then return "water" end
	local pos = ply:GetPos()
	local tr = util.TraceHull( { start = pos + Vector( 0, 0, 8 ), endpos = pos - Vector( 0, 0, 24 ), mins = Vector( -8, -8, 0 ), maxs = Vector( 8, 8, 4 ),
		filter = ply, mask = MASK_PLAYERSOLID } )
	if not tr.Hit then return "concrete" end
	local prop = util.GetSurfacePropName( tr.SurfaceProps ) or ""
	for key, surf in pairs( M.PROPS ) do
		if string.find( prop, key, 1, true ) then return surf end
	end
	return M.MATS[ tr.MatType ] or "concrete"
end

M.PROPS = { gravel = "gravel", mud = "mud", carpet = "carpet", brick = "brick", rock = "rock", ice = "ice", paper = "paper",
	plaster = "plaster", asphalt = "asphault", sand = "sand", snow = "snow", grass = "grass", cloth = "cloth", foliage = "foliage" }
M.MATS = { [ MAT_CONCRETE ] = "concrete", [ MAT_DIRT ] = "dirt", [ MAT_GRASS ] = "grass", [ MAT_WOOD ] = "wood", [ MAT_METAL ] = "metal",
	[ MAT_SAND ] = "sand", [ MAT_SNOW ] = "snow", [ MAT_GLASS ] = "glass", [ MAT_TILE ] = "brick", [ MAT_FOLIAGE ] = "foliage",
	[ MAT_GRATE ] = "metal", [ MAT_VENT ] = "metal", [ MAT_COMPUTER ] = "metal", [ MAT_SLOSH ] = "mud", [ MAT_FLESH ] = "flesh",
	[ MAT_PLASTIC ] = "carpet", [ MAT_ANTLION ] = "flesh", [ MAT_ALIENFLESH ] = "flesh", [ MAT_BLOODYFLESH ] = "flesh" }

function M.Sound( ply, alias )
	local silent = M.Silent[ alias ]
	if silent and math.random() < silent then return end
	if SERVER then
		local sp = game.SinglePlayer()
		if not sp then SuppressHostEvents( ply ) end
		ply:EmitSound( "COD1MV." .. alias )
		if not sp then SuppressHostEvents( NULL ) end
	elseif ply ~= LocalPlayer() or IsFirstTimePredicted() then
		ply:EmitSound( "COD1MV." .. alias )
	end
end

function M.StepKind( ply, speed )
	local stance = M.Stance( ply )
	if stance == M.PRONE then return "prone" end
	if M.Sprinting( ply ) then return "sprint" end
	if stance == M.CROUCH or speed < 120 then return "walk" end
	return "run"
end

function M.Step( ply, speed )
	if not GetConVar( "cod1mv_footsteps" ):GetBool() then return end
	local kind = M.StepKind( ply, speed )
	M.Sound( ply, "step_" .. kind .. "_" .. M.Surface( ply ) )
	if kind ~= "prone" then M.Sound( ply, "gear_rattle_" .. kind ) end
end

function M.StrideRate( ply, speed )
	return speed * M.STRIDE[ M.Stance( ply ) ] * ( M.Sprinting( ply ) and 1.15 or 1 )
end

hook.Add( "SetupMove", "COD1MV", function( ply, mv, cmd )
	if not M.Active( ply ) then
		setHulls( ply, nil )
		if M.Stance( ply ) ~= M.STAND then ply:SetNW2Int( "c1mvStance", M.STAND ) end
		if M.Sprinting( ply ) then ply:SetNW2Bool( "c1mvSprint", false ) end
		if M.Lean( ply ) ~= 0 then ply:SetNW2Float( "c1mvLean", 0 ) end
		if ply.c1mvEye then
			ply.c1mvEye = nil
			ply:SetCurrentViewOffset( ply:Crouching() and ply:GetViewOffsetDucked() or ply:GetViewOffset() )
		end
		return
	end
	ply.c1mvEye = true
	local now, dt = CurTime(), FrameTime()
	local stance = M.Stance( ply )
	local keys = ply:GetInfoNum( "cod1mv_codkeys", 0 ) ~= 0

	local want = stance
	local fresh = SERVER or IsFirstTimePredicted()
	if mv:KeyPressed( IN_PRONE ) then want = stance == M.PRONE and M.CROUCH or M.PRONE end
	if mv:KeyPressed( IN_CROUCH ) then want = stance == M.CROUCH and M.STAND or M.CROUCH end
	if not keys and stance ~= M.PRONE and want ~= M.PRONE then want = mv:KeyDown( IN_DUCK ) and M.CROUCH or M.STAND end
	if mv:KeyPressed( IN_JUMP ) and stance > M.STAND then want = stance - 1 end
	if stance > M.STAND then mv:SetButtons( bit.band( mv:GetButtons(), bit.bnot( IN_JUMP ) ) ) end
	if want == M.PRONE and not ply:OnGround() then want = stance end
	if want < stance and not roomFor( ply, want ) then
		want = stance
		ply:SetNW2Float( "c1mvBlocked", now )
	end
	if not fresh then want = stance end
	if want ~= stance then
		ply:SetNW2Float( "c1mvEyeFrom", M.EyeHeight( ply ) )
		ply:SetNW2Float( "c1mvStanceT", now )
		ply:SetNW2Int( "c1mvStance", want )
		stance = want
	end
	setHulls( ply, stance )
	if stance > M.STAND then mv:SetButtons( bit.bor( mv:GetButtons(), IN_DUCK ) )
	elseif keys then mv:SetButtons( bit.band( mv:GetButtons(), bit.bnot( IN_DUCK ) ) ) end

	local wep = ply:GetActiveWeapon()
	local ads = IsValid( wep ) and wep.GetADS and wep:GetADS()
	local reloading = IsValid( wep ) and wep.GetReloadState and wep:GetReloadState() ~= 0
	local stamina = M.Stamina( ply )
	local sprinting = M.Sprinting( ply )
	local sprintKey = keys and ( mv:KeyDown( IN_WALK ) or mv:KeyDown( IN_ALT2 ) ) or not keys and mv:KeyDown( IN_SPEED )
	local moving = mv:GetForwardSpeed() ~= 0 or mv:GetSideSpeed() ~= 0
	if sprintKey and stamina > 0 and stance == M.STAND and moving and not ads and not reloading and not ply.c1mvWantFire
		and ( sprinting or ( stamina > M.SPRINT_MIN and ply:OnGround() ) ) then
		sprinting = true
	else
		sprinting = false
	end
	if sprinting then
		stamina = math.max( stamina - dt / M.SPRINT_TIME, 0 )
		if stamina <= 0 then sprinting = false end
		ply:SetNW2Float( "c1mvSprintEnd", now )
	elseif not sprintKey and now - ply:GetNW2Float( "c1mvSprintEnd", 0 ) >= M.SPRINT_PAUSE then
		stamina = math.min( stamina + dt / M.SPRINT_RECHARGE, 1 )
	end
	if sprinting ~= M.Sprinting( ply ) then ply:SetNW2Bool( "c1mvSprint", sprinting ) end
	ply:SetNW2Float( "c1mvStamina", stamina )

	local scale = IsValid( wep ) and wep.Def and wep:Def() and wep:Def().moveSpeedScale or 1
	local speed = M.RUN * scale * M.SCALE[ stance ]
	if sprinting then speed = speed * M.SPRINT elseif ads then speed = speed * M.ADS end
	local fwd, side = mv:GetForwardSpeed(), mv:GetSideSpeed()
	if fwd < 0 then speed = speed * M.BACK elseif fwd == 0 and side ~= 0 then speed = speed * M.STRAFE end
	if M.ProneSettling( ply ) then speed = 0 end
	mv:SetMaxClientSpeed( speed )
	mv:SetMaxSpeed( speed )

	local lean = M.Lean( ply )
	local target = 0
	local leanMax = M.LEAN_MAX[ stance ]
	if not sprinting and not M.ProneSettling( ply ) then
		if mv:KeyDown( IN_LEAN_L ) then target = target - 1 end
		if mv:KeyDown( IN_LEAN_R ) then target = target + 1 end
	end
	if target ~= 0 then
		local eye = ply:GetPos() + Vector( 0, 0, M.EyeHeight( ply ) )
		local right = Angle( 0, mv:GetAngles().y, 0 ):Right() * target
		local tr = util.TraceHull( { start = eye, endpos = eye + right * ( M.LEAN_DIST + 8 ), mins = Vector( -6, -6, -6 ), maxs = Vector( 6, 6, 6 ),
			filter = ply, mask = MASK_PLAYERSOLID } )
		target = target * leanMax * math.Clamp( ( tr.Fraction * ( M.LEAN_DIST + 8 ) - 8 ) / M.LEAN_DIST, 0, 1 )
	end
	local out = target ~= 0 and target * lean >= 0 and math.abs( target ) > math.abs( lean )
	local step = dt / ( out and M.LEAN_OUT or M.LEAN_IN ) * leanMax
	lean = lean + math.Clamp( target - lean, -step, step )
	if lean ~= M.Lean( ply ) then ply:SetNW2Float( "c1mvLean", lean ) end

	if mv:KeyPressed( IN_SPEED ) and keys and not sprinting and not M.ProneSettling( ply ) then M.Melee( ply, wep ) end
end )

function M.LeanOffset( ply, yaw )
	local f = M.LeanEase( M.Lean( ply ) )
	if f == 0 then return vector_origin, 0 end
	local roll = f * M.LEAN_ROLL
	local r, d = math.rad( math.abs( roll ) ), f * M.LEAN_DIST
	return Angle( 0, yaw, 0 ):Right() * d * math.cos( r ) - Vector( 0, 0, math.abs( d ) * math.sin( r ) ), roll
end

function M.Melee( ply, wep )
	if IsValid( wep ) and wep.Melee then
		wep:Melee()
		return
	end
	if CurTime() < ( ply.c1mvNextBash or 0 ) then return end
	ply.c1mvNextBash = CurTime() + 0.65
	ply:SetAnimation( PLAYER_ATTACK1 )
	if COD1 and COD1.PlayerMeleeAnim then COD1.PlayerMeleeAnim( ply ) end
	ply:ViewPunch( Angle( 4, -6, 0 ) )
	if SERVER then ply:EmitSound( "COD1MV.melee_swing_large" ) end
	if CLIENT then return end
	timer.Simple( 0.15, function()
		if not IsValid( ply ) or not ply:Alive() then return end
		ply:LagCompensation( true )
		local tr = util.TraceHull( { start = ply:GetShootPos(), endpos = ply:GetShootPos() + ply:GetAimVector() * 64,
			mins = Vector( -8, -8, -8 ), maxs = Vector( 8, 8, 8 ), filter = ply, mask = MASK_SHOT_HULL } )
		ply:LagCompensation( false )
		if not tr.Hit then return end
		ply:EmitSound( "COD1MV.melee_hit" )
		if IsValid( tr.Entity ) then
			local dmg = DamageInfo()
			dmg:SetAttacker( ply )
			dmg:SetInflictor( ply )
			dmg:SetDamage( 75 )
			dmg:SetDamageType( DMG_CLUB )
			dmg:SetDamageForce( ply:GetAimVector() * 4000 )
			dmg:SetDamagePosition( tr.HitPos )
			tr.Entity:TakeDamageInfo( dmg )
		end
	end )
end

hook.Add( "StartCommand", "COD1MV", function( ply, cmd )
	ply.c1mvWantFire = cmd:KeyDown( IN_ATTACK ) or nil
	if M.Active( ply ) and M.FireBlocked( ply ) then
		cmd:RemoveKey( IN_ATTACK )
		cmd:RemoveKey( IN_ATTACK2 )
	end
end )

hook.Add( "FinishMove", "COD1MV_Eye", function( ply, mv )
	if not M.Active( ply ) then return end
	local off = M.LeanOffset( ply, mv:GetAngles().y )
	ply:SetCurrentViewOffset( Vector( off.x, off.y, M.EyeHeight( ply ) + off.z ) )
end )

hook.Add( "PlayerFootstep", "COD1MV", function( ply )
	if M.Active( ply ) and GetConVar( "cod1mv_footsteps" ):GetBool() then return true end
end )

hook.Add( "OnPlayerHitGround", "COD1MV", function( ply, water, floater, speed )
	if not M.Active( ply ) or not GetConVar( "cod1mv_footsteps" ):GetBool() then return end
	M.Sound( ply, "land_" .. M.Surface( ply ) )
	if speed > 580 then M.Sound( ply, "land_damage" ) end
end )

if SERVER then
	hook.Add( "FinishMove", "COD1MV", function( ply, mv )
		if not M.Active( ply ) or game.SinglePlayer() then return end
		local speed = ply:OnGround() and mv:GetVelocity():Length2D() or 0
		if speed < 5 then ply.c1mvCycle = 0 return end
		local old = ply.c1mvCycle or 0
		local cycle = old + M.StrideRate( ply, speed ) * FrameTime() * 2 * math.pi
		ply.c1mvCycle = cycle % ( 4 * math.pi )
		if math.floor( cycle / math.pi ) ~= math.floor( old / math.pi ) then M.Step( ply, speed ) end
	end )
end

hook.Add( "CalcMainActivity", "COD1MV", function( ply, vel )
	if not M.Active( ply ) or M.Stance( ply ) ~= M.PRONE or COD1 and COD1.IsCoDPlayer and COD1.IsCoDPlayer( ply ) then return end
	local wep = ply:GetActiveWeapon()
	local hold = IsValid( wep ) and wep:GetHoldType() or "normal"
	local seq = ply:LookupSequence( "swimming_" .. ( hold == "pistol" and "pistol" or hold == "smg" and "smg1" or hold == "normal" and "all" or "ar2" ) )
	if seq < 0 then seq = ply:LookupSequence( "swimming_all" ) end
	if seq < 0 then return end
	return ACT_MP_SWIM, seq
end )

hook.Add( "UpdateAnimation", "COD1MV", function( ply, vel )
	if not M.Active( ply ) or M.Stance( ply ) ~= M.PRONE or COD1 and COD1.IsCoDPlayer and COD1.IsCoDPlayer( ply ) then return end
	ply:SetPlaybackRate( math.Clamp( vel:Length2D() / 30, 0, 1 ) )
	return true
end )

--if you can sprint for more than a second and a half you are not a real soldier
