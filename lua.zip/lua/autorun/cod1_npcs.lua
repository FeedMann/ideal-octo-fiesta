AddCSLuaFile()

COD1 = COD1 or {}

local SHARED = {
	"cod1/sound_data.lua", "cod1/uo_sound_data.lua", "cod1/weapon_data.lua", "cod1/uo_weapon_data.lua", "cod1/extra_data.lua", "cod1/motion_data.lua",
	"cod1/vehicle_data.lua", "cod1/turret_data.lua", "cod1/mg_data.lua", "cod1/treat_data.lua", "cod1/rescue_data.lua", "cod1/efx_data.lua",
	"cod1/sh_config.lua", "cod1/sh_weapons.lua", "cod1/player_anim_data.lua", "cod1/sh_playermodels.lua", "cod1/sh_variants.lua", "cod1/sh_tanks.lua", "cod1/sh_efx.lua",
}
local CLIENT_ONLY = {
	"cod1/font_data.lua", "cod1/cl_efx.lua", "cod1/cl_hud.lua", "cod1/cl_music.lua", "cod1/cl_menu.lua", "cod1/cl_credits.lua", "cod1/cl_maps.lua",
	"cod1/cl_notice.lua", "cod1/cl_props.lua",
}
local SERVER_ONLY = {
	"cod1/corner_data.lua", "cod1/flag_data.lua", "cod1/nodes.lua", "cod1/sv_hooks.lua",
}

for _, f in ipairs( SHARED ) do
	AddCSLuaFile( f )
	include( f )
end
for _, f in ipairs( CLIENT_ONLY ) do
	if SERVER then AddCSLuaFile( f ) else include( f ) end
end
if SERVER then
	for _, f in ipairs( SERVER_ONLY ) do include( f ) end
	AddCSLuaFile( "cod1/credits_set.lua" )
	AddCSLuaFile( "cod1/cine_data.lua" )
	AddCSLuaFile( "cod1/credits_script.lua" )
end

--if this file breaks everything breaks, dont touch
