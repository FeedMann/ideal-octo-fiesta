AddCSLuaFile()

COD1MV = COD1MV or {}

for _, f in ipairs( { "cod1mv/sound_data.lua", "cod1mv/sh_move.lua" } ) do
	AddCSLuaFile( f )
	include( f )
end
if SERVER then
	AddCSLuaFile( "cod1mv/cl_move.lua" )
	AddCSLuaFile( "cod1mv/weapon_move.lua" )
else
	include( "cod1mv/weapon_move.lua" )
	include( "cod1mv/cl_move.lua" )
end

--legs.exe
