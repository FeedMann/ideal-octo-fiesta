local C = {
	shade = Color( 0, 0, 0, 200 ),
	frame = Color( 120, 108, 64 ),
	bar = Color( 74, 72, 38, 235 ),
	title = Color( 232, 220, 170 ),
	text = Color( 205, 202, 190 ),
	dim = Color( 140, 136, 118 ),
	hover = Color( 255, 196, 90 ),
}

--Pls actually read this

local TITLE = "READ THIS SOLDIER!"
local SUBTITLE = "Call of Duty 1 & United Offensive Npc's / Weapon's For Garry's Mod."
local TEXT = {
	"Listen up, private! This mod is still being worked on, so the soldiers can act a bit dumb at times. They might get stuck on a wall, walk the wrong way or freeze up for a second. I'm fixing these as I find them.",
	"Please report any bugs you find, like AI problems (they keep running into same wall on one map) or a gun model that looks broken. Thank you!",
	"You'll find all the settings in the spawn menu under Utilities > Call of Duty 1. The soldiers need a navmesh to get around, so build one there if your map doesn't have it.",
}
local COOKIE = "M"

local MAT = {
	back = Material( "cod1/notice/backdrop" ),
	soldier = Material( "cod1/notice/soldier" ),
	logo = Material( "cod1/notice/logo" ),
}
local pages = {}
for i, path in ipairs( COD1.Font.pages ) do pages[ i - 1 ] = Material( path ) end
local glyphs = COD1.Font.glyphs

local function width( s, use )
	local w = 0
	for i = 1, #s do
		local gl = glyphs[ string.byte( s, i ) ]
		if gl then w = w + gl[ 6 ] * use end
	end
	return w
end

local function text( s, x, y, use, col, a, center )
	if center then x = x - width( s, use ) / 2 end
	for pass = 1, 2 do
		local cx = x
		for i = 1, #s do
			local gl = glyphs[ string.byte( s, i ) ]
			if gl then
				if gl[ 2 ] > 0 then
					local o = pass == 1 and math.max( 1, use * 1.6 ) or 0
					surface.SetMaterial( pages[ gl[ 1 ] ] )
					if pass == 1 then surface.SetDrawColor( 0, 0, 0, a * 0.8 ) else surface.SetDrawColor( col.r, col.g, col.b, a ) end
					surface.DrawTexturedRectUV( cx + gl[ 5 ] * use + o, y - gl[ 4 ] * use + o, gl[ 2 ] * use, gl[ 3 ] * use, gl[ 7 ], gl[ 8 ], gl[ 9 ], gl[ 10 ] )
				end
				cx = cx + gl[ 6 ] * use
			end
		end
	end
end

local function wrap( s, use, maxW )
	local out, line = {}, ""
	for word in string.gmatch( s, "%S+" ) do
		local try = line == "" and word or line .. " " .. word
		if line ~= "" and width( try, use ) > maxW then
			out[ #out + 1 ] = line
			line = word
		else
			line = try
		end
	end
	if line ~= "" then out[ #out + 1 ] = line end
	return out
end

local open

function COD1.ShowNotice()
	if IsValid( open ) then open:Remove() end
	local k = math.Clamp( ScrH() / 1080, 0.65, 1.5 )
	local W = math.min( 1060 * k, ScrW() - 40 )
	local pad = 34 * k
	local soldierH = 600 * k
	local soldierW = soldierH * 512 / 628
	local textW = W - soldierW - pad * 0.5
	local bodyUse, titleUse = 0.62 * k, 0.8 * k
	local lineH = 24 * bodyUse * 1.55
	local lines, nLines = {}, 0
	for _, p in ipairs( TEXT ) do
		lines[ #lines + 1 ] = wrap( p, bodyUse, textW )
		nLines = nLines + #lines[ #lines ]
	end
	local logoW = math.min( 440 * k, textW )
	local logoH = logoW * 243 / 1024
	local barH = 34 * k
	local bw, bh = 170 * k, 40 * k
	local H = math.max( 450 * k, pad + logoH + 10 * k + barH + 22 * k + ( nLines + #TEXT * 0.45 ) * lineH + 16 * k + bh + pad )
	local x0, y0 = ( ScrW() - W ) / 2, ( ScrH() - H ) / 2 + 60 * k
	local barY = y0 + pad + logoH + 10 * k
	local t0 = RealTime()
	if IsValid( COD1.NoticeMusic ) then COD1.NoticeMusic:Stop() end
	sound.PlayFile( "sound/cod1/music/training_datestamp.mp3", "noplay noblock", function( ch )
		if not IsValid( ch ) then return end
		if not IsValid( open ) then ch:Stop() return end
		COD1.NoticeMusic = ch
		ch:SetVolume( 0.7 )
		ch:Play()
	end )

	local back = vgui.Create( "EditablePanel" )
	open = back
	back:SetSize( ScrW(), ScrH() )
	back:MakePopup()
	back:SetKeyboardInputEnabled( false )
	back:SetAlpha( 0 )
	back:AlphaTo( 255, 0.3 )
	back.Paint = function( _, pw, ph )
		surface.SetDrawColor( C.shade )
		surface.DrawRect( 0, 0, pw, ph )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( MAT.back )
		surface.DrawTexturedRectUV( x0, y0, W, H, 0, 0, 1, 1 )
		surface.SetDrawColor( C.frame )
		surface.DrawOutlinedRect( x0, y0, W, H, 2 )

		surface.SetMaterial( MAT.logo )
		surface.SetDrawColor( 0, 0, 0, 200 )
		surface.DrawTexturedRectUV( x0 + pad + 3 * k, y0 + pad + 4 * k, logoW, logoH, 0, 0, 1, 243 / 256 )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.DrawTexturedRectUV( x0 + pad, y0 + pad, logoW, logoH, 0, 0, 1, 243 / 256 )

		surface.SetDrawColor( C.bar )
		surface.DrawRect( x0 + pad, barY, textW, barH )
		surface.SetDrawColor( C.frame )
		surface.DrawRect( x0 + pad, barY + barH, textW, 1 )
		text( TITLE, x0 + pad + 12 * k, barY + barH * 0.78, titleUse, C.title, 255 )

		local y = barY + barH + 22 * k + lineH * 0.7
		for _, l in ipairs( lines ) do
			for _, s in ipairs( l ) do
				text( s, x0 + pad, y, bodyUse, C.text, 255 )
				y = y + lineH
			end
			y = y + lineH * 0.45
		end
		text( SUBTITLE, x0 + pad, y0 + H - pad * 0.55, bodyUse * 0.78, C.dim, 255 )

		local rise = math.min( ( RealTime() - t0 ) / 0.45, 1 )
		local ease = 1 - ( 1 - rise ) ^ 3
		surface.SetMaterial( MAT.soldier )
		surface.SetDrawColor( 255, 255, 255, 255 * ease )
		surface.DrawTexturedRectUV( x0 + W - soldierW + 10 * k + ( 1 - ease ) * 60 * k, y0 + H - soldierH, soldierW, soldierH, 0, 0, 1, 628 / 1024 )
	end

	local ok = vgui.Create( "DButton", back )
	ok:SetSize( bw, bh )
	ok:SetPos( x0 + pad + textW - bw, y0 + H - pad - bh - 12 * k )
	ok:SetText( "" )
	ok.Paint = function( s, w, h )
		local hot = s:IsHovered()
		surface.SetDrawColor( hot and Color( 96, 92, 46, 245 ) or C.bar )
		surface.DrawRect( 0, 0, w, h )
		surface.SetDrawColor( C.frame )
		surface.DrawOutlinedRect( 0, 0, w, h )
		text( "GOT IT", w / 2, h * 0.76, titleUse, hot and C.hover or C.title, 255, true )
	end
	ok.OnCursorEntered = function() surface.PlaySound( "ui/buttonrollover.wav" ) end
	ok.DoClick = function()
		cookie.Set( COOKIE, "1" )
		surface.PlaySound( "ui/buttonclickrelease.wav" )
		surface.PlaySound( "cod1/voiceovers/mp/us/resp/us_resp_yessir.wav" )
		local ch = COD1.NoticeMusic
		if IsValid( ch ) then
			local v0, tEnd = ch:GetVolume(), RealTime() + 1.2
			hook.Add( "Think", "COD1NoticeFade", function()
				if not IsValid( ch ) then hook.Remove( "Think", "COD1NoticeFade" ) return end
				local f = ( tEnd - RealTime() ) / 1.2
				if f <= 0 then ch:Stop() hook.Remove( "Think", "COD1NoticeFade" ) return end
				ch:SetVolume( v0 * f )
			end )
		end
		back:AlphaTo( 0, 0.2, 0, function() if IsValid( back ) then back:Remove() end end )
	end
end

hook.Add( "InitPostEntity", "COD1Notice", function()
	if cookie.GetString( COOKIE, "" ) == "1" then return end
	timer.Simple( 3, function()
		if cookie.GetString( COOKIE, "" ) ~= "1" then COD1.ShowNotice() end
	end )
end )

concommand.Add( "cod1_notice", function() COD1.ShowNotice() end )

--IS THAT YOU JOHN WAAAYNE? IS THIS MEEEEEEEEE?
