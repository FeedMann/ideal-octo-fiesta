util.AddNetworkString( "cod1_hint" )

function COD1.Hint( ply, text, dur )
	if not IsValid( ply ) or not ply:IsPlayer() then return end
	net.Start( "cod1_hint" )
	net.WriteString( text )
	net.WriteFloat( dur or 3 )
	net.Send( ply )
end

function COD1.ArtilleryStrike( pos, attacker, count, spread, delay )
	for i = 1, count do
		timer.Simple( ( delay or 0 ) + i * math.Rand( 0.8, 1.6 ), function()
			local p = pos + Vector( math.Rand( -spread, spread ), math.Rand( -spread, spread ), 0 )
			local down = util.TraceLine( { start = p + Vector( 0, 0, 256 ), endpos = p - Vector( 0, 0, 512 ), mask = MASK_SOLID_BRUSHONLY } )
			if down.Hit and not down.StartSolid then p = down.HitPos end
			sound.Play( "COD1.ShellIncoming", p, 120 )
			timer.Simple( 0.9, function()
				local tr = util.TraceLine( { start = p + Vector( 0, 0, 64 ), endpos = p - Vector( 0, 0, 64 ), mask = MASK_SOLID_BRUSHONLY } )
				COD1.FX( COD1.ExplosionFX( "artillery", tr, false ), tr.Hit and tr.HitPos or p, Vector( 0, 0, 1 ) )
				sound.Play( "COD1.ShellExplode", p, 150 )
				util.ScreenShake( p, 12, 150, 1.2, 1400 )
				util.Decal( "Scorch", p + Vector( 0, 0, 16 ), p - Vector( 0, 0, 32 ) )
				local who = IsValid( attacker ) and attacker or game.GetWorld()
				util.BlastDamage( who, who, p + Vector( 0, 0, 12 ), 360, 220 )
			end )
		end )
	end
end

local ARTY_VOICE = { us = "us", uswinter = "us", british = "uk", british_air = "uk", russian = "ru", whermact = "ge", waffen = "ge", fallschirmjager = "ge" }

local function artyLine( line )
	local hands = COD1.HandSets[ COD1.HandSet() + 1 ]
	return "cod1/voiceovers/mp/arty/" .. ( ARTY_VOICE[ hands ] or "us" ) .. "_" .. line .. ".mp3"
end

function COD1.CallArtillery( ply )
	if not IsValid( ply ) or not ply:Alive() or not GetConVar( "cod1_artillery" ):GetBool() then return end
	local now = CurTime()
	local ready = ply:GetNW2Float( "COD1ArtyReady", 0 )
	if now < ready then
		if now >= ( ply.COD1ArtyNag or 0 ) then
			ply.COD1ArtyNag = now + 2.5
			ply:EmitSound( artyLine( "noarty" ), 75, 100, 1, CHAN_VOICE )
			COD1.Hint( ply, "Artillery not ready yet (" .. math.ceil( ready - now ) .. "s)", 2 )
		end
		return
	end
	local eye = ply:EyePos()
	local tr = util.TraceLine( { start = eye, endpos = eye + ply:GetAimVector() * 15000, filter = ply, mask = MASK_SHOT } )
	if not tr.Hit or tr.HitSky then
		COD1.Hint( ply, "Can't see where to put it", 2 )
		return
	end
	if tr.HitPos:Distance( ply:GetPos() ) < 650 then
		COD1.Hint( ply, "Too close, you'd hit yourself", 2 )
		return
	end
	local target = tr.HitPos
	local cooldown = math.max( GetConVar( "cod1_artillery_cooldown" ):GetFloat(), 5 )
	ply:SetNW2Float( "COD1ArtyReady", now + cooldown )
	ply:EmitSound( artyLine( "fire_mission" ), 80, 100, 1, CHAN_VOICE )
	COD1.Hint( ply, "Fire mission called in", 3 )
	if COD1.NoteGunfire then COD1.NoteGunfire( target ) end
	COD1.ArtilleryStrike( target, ply, math.random( 6, 8 ), 280, 3 )
	timer.Simple( 4, function()
		for s in pairs( COD1.Soldiers or {} ) do
			if IsValid( s ) and not s.Dead and s:GetPos():DistToSqr( target ) < 800 * 800 then
				s.ShakenUntil = CurTime() + 6
				s.Suppressed = math.max( s.Suppressed or 0, CurTime() + 3 )
			end
		end
	end )
	timer.Create( "COD1ArtyReady" .. ply:EntIndex(), cooldown, 1, function()
		if IsValid( ply ) and ply:Alive() and GetConVar( "cod1_artillery" ):GetBool() then
			ply:EmitSound( artyLine( "arty_gtg" ), 75, 100, 1, CHAN_VOICE )
			COD1.Hint( ply, "Artillery ready", 2 )
		end
	end )
end

hook.Add( "EntityFireBullets", "COD1Hearing", function( shooter, data )
	local soldiers = COD1.Soldiers
	if not soldiers or not next( soldiers ) or not IsValid( shooter ) then return end
	local src, dir = data.Src, data.Dir
	if not src or not dir then return end
	local gun = shooter.IsCOD1Soldier and shooter.Weapon or shooter.GetActiveWeapon and shooter:GetActiveWeapon()
	local hear = ( istable( gun ) and gun.quiet or IsValid( gun ) and gun.Quiet ) and 450 or 3000
	for s in pairs( soldiers ) do
		if IsValid( s ) and s ~= shooter and not s.Dead then
			local to = s:WorldSpaceCenter() - src
			if to:LengthSqr() < hear * hear then s:HearShot( shooter, src, dir ) end
			if s:IsHostileTo( shooter ) then
				local along = to:Dot( dir )
				if along > 0 and along < 4000 and ( to - dir * along ):LengthSqr() < 70 * 70 then
					s:OnSuppressed( shooter )
				end
			end
		end
	end
	if shooter:IsPlayer() then
		for s in pairs( soldiers ) do
			if IsValid( s ) and not s.Dead and s:IsHostileTo( shooter ) and s:GetPos():DistToSqr( src ) < 2500 * 2500 then
				shooter:SetNW2Float( "COD1Battle", CurTime() )
				break
			end
		end
	end
end )

local lastBoom = 0
hook.Add( "EntityTakeDamage", "COD1HearExplosions", function( target, dmg )
	if not dmg:IsExplosionDamage() or CurTime() - lastBoom < 0.2 then return end
	lastBoom = CurTime()
	local pos = dmg:GetDamagePosition()
	if pos == vector_origin then pos = target:GetPos() end
	for s in pairs( COD1.Soldiers or {} ) do
		if IsValid( s ) and not s.Dead and s:GetPos():DistToSqr( pos ) < 2500 * 2500 then
			s:HearExplosion( pos, dmg:GetAttacker() )
		end
	end
end )

local function allowed( ply, super )
	if not IsValid( ply ) or game.SinglePlayer() then return true end
	return super and ply:IsSuperAdmin() or ply:IsAdmin()
end

concommand.Add( "cod1_nav_generate", function( ply )
	if not allowed( ply, true ) or navmesh.IsGenerating() then return end
	if IsValid( ply ) then navmesh.AddWalkableSeed( ply:GetPos(), Vector( 0, 0, 1 ) ) end
	PrintMessage( HUD_PRINTTALK, "[CoD1] Building the navmesh. The game will hang for a while, and the map may reload when it's done." )
	timer.Simple( 0.5, function() navmesh.BeginGeneration() end )
end )

local nextPraise = 0
hook.Add( "OnNPCKilled", "COD1QuickChat", function( victim, attacker )
	if not IsValid( attacker ) or CurTime() < nextPraise then return end
	if attacker.IsCOD1Soldier and not attacker.Dead then
		if math.random() < 0.2 and attacker:Quick( "enemy_down" ) then nextPraise = CurTime() + 4 end
		return
	end
	if not attacker:IsPlayer() or math.random() > 0.4 then return end
	local best, bestDist = nil, 800 * 800
	for s in pairs( COD1.Soldiers ) do
		if IsValid( s ) and not s.Dead and not s:EnemySide() and not s:IsHostileTo( attacker ) then
			local d = s:GetPos():DistToSqr( attacker:GetPos() )
			if d < bestDist and s:LineOfSight( s:EyePosition(), attacker ) then best, bestDist = s, d end
		end
	end
	if best and best:Quick( "great_shot" ) then nextPraise = CurTime() + 5 end
end )

local TEST_MOVES = { "mantle_low", "mantle_high", "jump_down_low", "jump_down_high", "dodge_left", "dodge_right" }
concommand.Add( "cod1_test_moves", function( ply, cmd, args )
	if not IsValid( ply ) or not allowed( ply ) then return end
	local moves = TEST_MOVES
	if args[ 1 ] and args[ 1 ] ~= "all" then
		if not table.HasValue( TEST_MOVES, args[ 1 ] ) then
			ply:ChatPrint( "[CoD1] Moves: all, " .. table.concat( TEST_MOVES, ", " ) )
			return
		end
		moves = { args[ 1 ] }
	end
	local tr = ply:GetEyeTrace()
	local npc = IsValid( tr.Entity ) and tr.Entity.IsCOD1Soldier and not tr.Entity.Dead and tr.Entity
	if not npc then
		local pos = tr.HitPos
		if pos:Distance( ply:GetPos() ) > 600 or tr.HitNormal.z < 0.7 then
			pos = ply:GetPos() + Angle( 0, ply:EyeAngles().y, 0 ):Forward() * 220
		end
		npc = ents.Create( "npc_cod1_airborne" )
		if not IsValid( npc ) then return end
		npc:SetPos( pos + Vector( 0, 0, 4 ) )
		npc:Spawn()
		npc:Activate()
		undo.Create( "CoD1 test soldier" )
		undo.AddEntity( npc )
		undo.SetPlayer( ply )
		undo.Finish()
	end
	npc.TestYaw = ply:EyeAngles().y + 90
	npc.TestHome = nil
	npc.TestQueue = table.Copy( moves )
end, function( cmd ) local t = { cmd .. " all" } for _, m in ipairs( TEST_MOVES ) do t[ #t + 1 ] = cmd .. " " .. m end return t end )

function COD1.SpawnSoldier( variant, pos, ang, kv, ply )
	local v = COD1.Variants[ variant ]
	if not v then return end
	local npc = ents.Create( v.team == "axis" and "npc_cod1_german" or "npc_cod1_airborne" )
	if not IsValid( npc ) then return end
	npc:SetKeyValue( "cod1_variant", variant )
	npc:SetKeyValue( "cod1_weapon", "random" )
	for k, val in pairs( kv or {} ) do npc:SetKeyValue( k, val ) end
	npc:SetPos( pos )
	npc:SetAngles( ang or angle_zero )
	npc:Spawn()
	npc:Activate()
	if IsValid( ply ) then
		undo.Create( "CoD1 Soldier" ) undo.AddEntity( npc ) undo.SetPlayer( ply ) undo.Finish()
		ply:AddCleanup( "npcs", npc )
	end
	return npc
end

concommand.Add( "cod1_paradrop", function( ply, cmd, args )
	if not allowed( ply ) then return end
	local count = math.Clamp( tonumber( args[ 1 ] ) or 6, 1, 16 )
	local variant = COD1.Variants[ args[ 2 ] or "" ] and args[ 2 ] or "airborne_summer"
	local tr = IsValid( ply ) and ply:GetEyeTrace()
	local center = tr and tr.HitPos or vector_origin
	local fwd = IsValid( ply ) and Angle( 0, ply:EyeAngles().y, 0 ):Forward() or Vector( 1, 0, 0 )
	local side = fwd:Angle():Right()
	sound.Play( "COD1.C47Flyby", center + Vector( 0, 0, 1200 ), 150, 100, 1 )
	for i = 1, count do
		timer.Simple( 0.7 + ( i - 1 ) * 0.6, function()
			local pos = center + side * ( ( i - ( count + 1 ) / 2 ) * 170 ) + VectorRand() * 30
			local ground = util.TraceLine( { start = pos + Vector( 0, 0, 200 ), endpos = pos - Vector( 0, 0, 2000 ), mask = MASK_SOLID_BRUSHONLY } )
			if not ground.Hit then return end
			COD1.SpawnSoldier( variant, ground.HitPos, Angle( 0, fwd:Angle().y + 180 + math.random( -40, 40 ), 0 ), { cod1_parachute = "1" }, ply )
		end )
	end
end )

local function spotNear( center, dist, ang )
	local p = center + Angle( 0, ang, 0 ):Forward() * dist
	local tr = util.TraceLine( { start = p + Vector( 0, 0, 80 ), endpos = p - Vector( 0, 0, 300 ), mask = MASK_PLAYERSOLID } )
	if not tr.Hit or tr.StartSolid or tr.HitNormal.z < 0.7 then return end
	local free = not util.TraceHull( { start = tr.HitPos + Vector( 0, 0, 4 ), endpos = tr.HitPos + Vector( 0, 0, 4 ),
		mins = Vector( -16, -16, 0 ), maxs = Vector( 16, 16, 72 ), mask = MASK_PLAYERSOLID } ).Hit
	return free and tr.HitPos
end

concommand.Add( "cod1_stalingrad", function( ply )
	if not IsValid( ply ) or not allowed( ply ) then return end
	local tr = ply:GetEyeTrace()
	local center = tr.HitPos
	if center:Distance( ply:GetPos() ) > 1500 then center = ply:GetPos() + Angle( 0, ply:EyeAngles().y, 0 ):Forward() * 300 end
	local yaw = ply:EyeAngles().y
	local winter = math.random() < 0.5
	local mega = spotNear( center, 0, 0 ) or center
	COD1.SpawnSoldier( "russian_megaphone", mega, Angle( 0, yaw + 180, 0 ), nil, ply )
	local flag = spotNear( center, 120, yaw )
	if flag then COD1.SpawnSoldier( "russian_flag", flag, Angle( 0, yaw, 0 ), nil, ply ) end
	local placed = 0
	for i = 0, 15 do
		if placed >= 8 then break end
		local p = spotNear( center, 140 + ( i % 3 ) * 70, yaw + ( i - 7 ) * 22 )
		if p then
			placed = placed + 1
			local variant = winter and "russian_winter" or "russian"
			if placed % 3 == 0 then variant = variant .. "_conscript" end
			COD1.SpawnSoldier( variant, p, Angle( 0, yaw, 0 ), nil, ply )
		end
	end
	local com = spotNear( center, 90, yaw + 150 )
	if com then COD1.SpawnSoldier( "russian_commissar", com, Angle( 0, yaw, 0 ), nil, ply ) end
end )

--server hooks, boring but important
