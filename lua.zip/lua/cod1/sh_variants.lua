local US_HELMET_PROPS = { [ 0 ] = { "models/cod1/props/helmet.mdl", "helmet" }, [ 1 ] = { "models/cod1/props/helmet_net.mdl", "helmet" },
	[ 2 ] = { "models/cod1/props/helmet_scrim.mdl", "helmet" }, [ 4 ] = { "models/cod1/props/helmet_winter.mdl", "head" } }
local US_WEAPONS = { "thompson", "garand", "carbine", "bar" }
local US_RANDOM = { "garand", "garand", "garand", "garand", "thompson", "thompson", "thompson", "carbine", "carbine", "bar" }
local US_BELTS = { thompson = 0, garand = 1, carbine = 2, bar = 3 }
local GER_WEAPONS = { "kar98", "mp40", "mp44", "fg42" }
local GER_WEAPONS_OFF = { "kar98", "mp40", "mp44", "fg42", "luger" }
local GER_RANDOM = { "kar98", "kar98", "kar98", "kar98", "kar98", "mp40", "mp40", "mp40", "mp44", "mp44" }

COD1.Variants = {
	airborne_summer = {
		team = "allies", voice = "american", voices = 7, model = "models/cod1/american/airborne.mdl",
		bodies = 6, heads = 5, skins = 15, helmets = { 0, 1, 2 }, blankHelmet = 3, helmetProps = US_HELMET_PROPS,
		loads = 3, fronts = 3, weapons = US_WEAPONS, random = US_RANDOM, belts = US_BELTS, ammoBelt = 4,
		bandolier = { garand = 0.5 }, bandolierLoads = { 1, 2 },
	},
	airborne_winter = {
		team = "allies", voice = "american", voices = 7, model = "models/cod1/american/airborne_winter.mdl",
		bodies = 1, heads = 5, skins = 15, helmets = { 0, 1, 2, 4 }, blankHelmet = 3, helmetProps = US_HELMET_PROPS,
		loads = 3, fronts = 3, weapons = US_WEAPONS, random = US_RANDOM, belts = US_BELTS, ammoBelt = 4,
		bandolier = { garand = 0.5 }, bandolierLoads = { 1, 2 },
		officer = { body = 1, weapon = "thompson", rank = "Lt." },
	},
	german_wehrmacht = {
		team = "axis", voice = "german", voices = 3, model = "models/cod1/german/wehrmacht.mdl",
		bodies = 4, heads = 2, skins = 10, helmets = { 0, 0, 1 }, blankHelmet = 3,
		helmetProps = { [ 0 ] = { "models/cod1/props/ger_helmet.mdl", "head" }, [ 1 ] = { "models/cod1/props/ger_helmet2.mdl", "head" },
			[ 2 ] = { "models/cod1/props/ger_officer_cap.mdl", "head" } },
		loads = 5, weapons = GER_WEAPONS_OFF, random = GER_RANDOM, belts = { kar98 = 0, mp40 = 1, mp44 = 2, fg42 = 0 },
		officer = { body = 4, helmet = 2, belt = 4, weapon = "mp40", weapons = { "mp40", "luger" }, rank = "Ltn." },
	},
	german_waffenss = {
		team = "axis", voice = "german", voices = 3, model = "models/cod1/german/waffen_ss.mdl",
		bodies = 3, heads = 2, skins = 10, helmets = { 0, 0, 0, 1 }, blankHelmet = 3,
		helmetProps = { [ 0 ] = { "models/cod1/props/ger_helmet_waffen.mdl", "helmet" }, [ 1 ] = { "models/cod1/props/ger_helmet2.mdl", "head" },
			[ 2 ] = { "models/cod1/props/ger_officer_cap.mdl", "head" } },
		loads = 3, weapons = GER_WEAPONS_OFF, random = { "kar98", "kar98", "kar98", "mp40", "mp40", "mp40", "mp44", "mp44", "mp44" },
		belts = { kar98 = 0, mp40 = 1, mp44 = 2, fg42 = 0 },
		officer = { body = 3, helmet = 2, belt = 4, weapon = "mp40", weapons = { "mp40", "luger" }, rank = "Ltn." },
	},
	german_fallschirm = {
		team = "axis", voice = "german", voices = 3, model = "models/cod1/german/fallschirmjager.mdl",
		bodies = 2, heads = 2, skins = 10, helmets = { 0, 1, 2 }, blankHelmet = 3,
		helmetProps = { [ 0 ] = { "models/cod1/props/ger_helmet_fj_blk.mdl", "head" }, [ 1 ] = { "models/cod1/props/ger_helmet_fj_grn.mdl", "head" },
			[ 2 ] = { "models/cod1/props/ger_helmet_fj_camo.mdl", "head" } },
		loads = 3, weapons = GER_WEAPONS, random = { "kar98", "kar98", "kar98", "mp40", "mp40", "mp44", "mp44", "fg42", "fg42", "fg42" },
		belts = { kar98 = 0, mp40 = 1, mp44 = 2, fg42 = 2 }, bandolier = { kar98 = 0.6, fg42 = 0.5 }, bandolierBelt = 3,
	},
	german_winter = {
		team = "axis", voice = "german", voices = 3, model = "models/cod1/german/winter.mdl",
		bodies = 2, heads = 2, skins = 10, helmets = { 0, 0, 1, 2 }, blankHelmet = 3,
		helmetProps = { [ 0 ] = { "models/cod1/props/ger_helmet_winter.mdl", "head" }, [ 1 ] = { "models/cod1/props/ger_helmet2.mdl", "head" },
			[ 2 ] = { "models/cod1/props/ger_helmet.mdl", "head" } },
		loads = 3, weapons = GER_WEAPONS, random = GER_RANDOM, belts = { kar98 = 0, mp40 = 1, mp44 = 2, fg42 = 0 },
	},
}

local BRIT_PROPS = { [ 0 ] = { "models/cod1/props/brit_beret_red.mdl", "head" }, [ 1 ] = { "models/cod1/props/brit_helmet_para.mdl", "head" },
	[ 2 ] = { "models/cod1/props/brit_beret_green.mdl", "head" } }
local BRIT_LOAD = { [ 0 ] = 0, [ 1 ] = 1, [ 2 ] = 2, [ 3 ] = 2, [ 4 ] = 3 }
local BRIT = { team = "allies", voice = "british", voices = 6, model = "models/cod1/british/paratroopers.mdl", heads = 5, skins = 10,
	blankHelmet = 3, helmetProps = BRIT_PROPS, loads = 1, weapons = { "enfield", "sten", "bren", "thompson" },
	random = { "enfield", "enfield", "enfield", "enfield", "sten", "sten", "sten", "bren" }, belts = {},
	names = COD1.BritishSurnames, extra = function( ent, body ) ent:SetGroup( "load", BRIT_LOAD[ body ] or 0 ) end }
COD1.Variants.british_para = table.Merge( table.Copy( BRIT ), { bodyList = { 0 }, helmets = { 0, 0, 1 } } )
COD1.Variants.british_medic = table.Merge( table.Copy( BRIT ), { bodyList = { 0 }, helmets = { 0, 1 }, medic = true,
	materials = { brit_uparm_l = "models/cod1/british/medic/medic_uparm", helment = "models/cod1/british/medic/medic_helmet" } } )
COD1.Variants.british_medic.random = { "enfield" }
COD1.Variants.british_commando = table.Merge( table.Copy( BRIT ), { bodyList = { 1, 2 }, helmets = { 2 } } )
COD1.Variants.british_winter = table.Merge( table.Copy( BRIT ), { bodyList = { 3 }, helmets = { 2 } } )
COD1.Variants.british_price = table.Merge( table.Copy( BRIT ), { bodyList = { 4 }, headList = { 5 }, helmets = { 0 },
	random = { "thompson" }, voice = "price", voices = 1, fixedName = "Capt. Price" } )

local SOV_PROPS = { [ 0 ] = { "models/cod1/props/sov_helmet.mdl", "helmet" }, [ 1 ] = { "models/cod1/props/sov_sidecap.mdl", "head" },
	[ 2 ] = { "models/cod1/props/sov_officercap.mdl", "head" } }
local function sovExtra( ent, body, w, officer )
	local ocoat = ent.VariantData.ocoat[ body ]
	ent:SetGroup( "load", officer and 2 or ( ocoat and 0 or 1 ) )
	ent:SetGroup( "pack", ( ocoat and not officer and math.random() < 0.6 ) and 0 or 1 )
	ent:SetGroup( "belt", officer and math.random( 4, 5 ) or ( ocoat and 0 or 2 ) + ( w == "ppsh" and 1 or 0 ) )
end
local SOV = { team = "allies", voice = "russian", voices = 6, heads = 5, skins = 10,
	helmets = { 0, 0, 0, 1 }, blankHelmet = 3, helmetProps = SOV_PROPS, loads = 1, weapons = { "mosin", "ppsh" },
	random = { "mosin", "mosin", "mosin", "ppsh", "ppsh" }, belts = {}, names = COD1.RussianSurnames, extra = sovExtra,
	flagGroup = 2, blankWeapon = 3 }
COD1.Variants.russian = table.Merge( table.Copy( SOV ), { model = "models/cod1/russian/army.mdl", bodyList = { 0, 1, 2, 3 },
	ocoat = { [ 0 ] = true, [ 1 ] = true, [ 4 ] = true, [ 5 ] = true },
	officer = { bodyList = { 4, 5 }, helmet = 2, weapon = "ppsh", rank = "Lt." } } )
COD1.Variants.russian_winter = table.Merge( table.Copy( SOV ), { model = "models/cod1/russian/winter.mdl", bodyList = { 0, 1 },
	ocoat = { [ 0 ] = true, [ 2 ] = true, [ 3 ] = true },
	officer = { bodyList = { 2, 3 }, helmet = 2, weapon = "ppsh", rank = "Lt." } } )

COD1.Variants.russian_conscript = table.Merge( table.Copy( COD1.Variants.russian ), { unarmed = true, random = { "mosin" } } )
COD1.Variants.russian_conscript.officer = nil
COD1.Variants.russian_winter_conscript = table.Merge( table.Copy( COD1.Variants.russian_winter ), { unarmed = true, random = { "mosin" } } )
COD1.Variants.russian_winter_conscript.officer = nil

local SOV_MEDIC_COAT = { [ 2 ] = true, [ 3 ] = true }
local function sovMedic( ent, body, w )
	local coat = SOV_MEDIC_COAT[ body ]
	ent:SetGroup( "load", coat and 0 or 1 )
	ent:SetGroup( "belt", ( coat and 0 or 2 ) + ( w == "ppsh" and 1 or 0 ) )
end
local function sovMedicVariant( bodies, helmets )
	return { team = "allies", voice = "russian", voices = 6, model = "models/cod1/russian/medics.mdl", heads = 5, skins = 10,
		bodyList = bodies, helmets = helmets, blankHelmet = 2, helmetProps = { [ 0 ] = SOV_PROPS[ 0 ], [ 1 ] = SOV_PROPS[ 1 ] },
		loads = 1, weapons = { "mosin", "ppsh" }, random = { "mosin", "mosin", "ppsh" }, belts = {}, blankWeapon = 2,
		names = COD1.RussianSurnames, extra = sovMedic, medic = true, roleName = "Sanitar" }
end
COD1.Variants.russian_medic = sovMedicVariant( { 0, 0, 1, 2 }, { 0, 0, 1 } )
COD1.Variants.russian_winter_medic = sovMedicVariant( { 3, 4 }, { 0 } )

local function sovOfficer( t )
	local v = { team = "allies", voice = "russian", voices = 6, model = "models/cod1/russian/officers.mdl", heads = 5, skins = 10,
		helmets = { 0 }, blankHelmet = 1, helmetProps = { [ 0 ] = { "models/cod1/props/sov_officercap.mdl", "head" } },
		loads = 1, weapons = { "luger", "ppsh" }, random = { "luger" }, belts = {}, names = COD1.RussianSurnames,
		flagGroup = 3, blankWeapon = 4 }
	return table.Merge( v, t )
end
COD1.Variants.russian_flag = sovOfficer( { bodyList = { 0 }, role = "flag", rank = "Sgt.", roleName = "Flag Bearer",
	extra = function( ent ) ent:SetGroup( "belt", 2 ) end } )
COD1.Variants.russian_commissar = sovOfficer( { bodyList = { 0, 1 }, role = "commissar", rank = "Commissar", roleName = "Political Officer",
	extra = function( ent ) ent:SetGroup( "belt", 0 ) end } )
COD1.Variants.russian_megaphone = sovOfficer( { bodyList = { 0, 1 }, role = "megaphone", rank = "Commissar", roleName = "Political Officer",
	extra = function( ent ) ent:SetGroup( "belt", 0 ) ent:SetGroup( "weapon", 2 ) ent:SetGroup( "left", math.random( 0, 1 ) ) end } )

local function hero( body, helmet, name, weapons, fixed )
	return { team = "allies", voice = name, voices = 1, model = "models/cod1/american/heroes.mdl",
		bodyList = { body }, headList = { body }, skins = 1, helmets = { helmet }, blankHelmet = 3, helmetProps = US_HELMET_PROPS,
		loads = 1, weapons = { "thompson", "garand" }, random = weapons, belts = {}, fixedName = fixed,
		extra = function( ent ) ent:SetGroup( "load", body ) end }
end
COD1.Variants.hero_foley = hero( 0, 2, "foley", { "thompson" }, "Capt. Foley" )
COD1.Variants.hero_moody = hero( 1, 0, "moody", { "thompson" }, "Sgt. Moody" )
COD1.Variants.hero_elder = hero( 2, 1, "elder", { "thompson", "thompson", "garand" }, "Pvt. Elder" )

local function named( model, weapons, body, helmet, voice, random, groups, props, blank, name )
	return { team = "allies", voice = voice, voices = 1, model = model, bodyList = { body }, headList = { body }, skins = 1,
		helmets = { helmet }, blankHelmet = blank, helmetProps = props, loads = 1, weapons = weapons, random = random, belts = {},
		fixedName = name, extra = function( ent ) for g, i in pairs( groups ) do ent:SetGroup( g, i ) end end }
end
local BH, BHW = "models/cod1/british/heroes.mdl", { "bren", "sten", "mp40" }
local BH_PROPS = { [ 0 ] = { "models/cod1/props/brit_beret_green.mdl", "head" }, [ 1 ] = { "models/cod1/props/brit_helmet_para.mdl", "head" } }
COD1.Variants.hero_waters = named( BH, BHW, 0, 0, "waters", { "bren", "sten" }, { load = 0 }, BH_PROPS, 2, "Sgt. Waters" )
COD1.Variants.hero_ingram = named( BH, BHW, 1, 0, "ingram", { "mp40" }, { load = 2 }, BH_PROPS, 2, "Maj. Ingram" )
COD1.Variants.hero_mills = named( BH, BHW, 2, 1, "mills", { "sten" }, { load = 1 }, BH_PROPS, 2, "Pvt. Mills" )
local RH, RHW = "models/cod1/russian/heroes.mdl", { "ppsh" }
local RH_PROPS = { [ 1 ] = { "models/cod1/props/sov_helmet.mdl", "helmet" } }
COD1.Variants.hero_pavlov = named( RH, RHW, 0, 0, "pavlov", { "ppsh" }, { load = 1, belt = 1, pack = 1 }, RH_PROPS, 2, "Sgt. Pavlov" )
COD1.Variants.hero_kovalenko = named( RH, RHW, 1, 1, "kovalenko", { "ppsh" }, { load = 0, belt = 0, pack = 1 }, RH_PROPS, 2, "Sgt. Kovalenko" )
COD1.Variants.hero_makarov = named( RH, RHW, 2, 1, "makarov", { "ppsh" }, { load = 0, belt = 0, pack = 0 }, RH_PROPS, 2, "Pvt. Makarov" )

local MEDIC = { team = "allies", voice = "american", voices = 7, model = "models/cod1/american/medics.mdl",
	heads = 5, skins = 15, helmets = { 0 }, blankHelmet = 1, loads = 2, fronts = 1, weapons = { "carbine", "colt" },
	random = { "carbine", "colt" }, belts = { carbine = 0, colt = 0 }, medic = true, helmetSide = { [ 0 ] = 1 }, frontCompass = { [ 0 ] = true } }
COD1.Variants.airborne_medic = table.Merge( table.Copy( MEDIC ), { bodyList = { 0 } } )
COD1.Variants.airborne_winter_medic = table.Merge( table.Copy( MEDIC ), { bodyList = { 1 } } )
COD1.Variants.german_medic = { team = "axis", voice = "german", voices = 3, model = "models/cod1/german/wehrmacht.mdl",
	bodies = 4, heads = 2, skins = 10, helmets = { 0 }, blankHelmet = 3,
	helmetProps = { [ 0 ] = { "models/cod1/props/ger_helmet.mdl", "head" } },
	loads = 5, weapons = GER_WEAPONS_OFF, random = { "kar98", "luger" }, belts = { kar98 = 0, mp40 = 1, mp44 = 2, fg42 = 0, luger = 4 },
	blankLoad = { luger = true },
	medic = true, roleName = "Sanitaeter",
	materials = { wehrmacht_tunic = "models/cod1/german/medic/medic_tunic", wehrmacht_uparm = "models/cod1/german/medic/medic_uparm",
		german_helment = "models/cod1/german/medic/medic_helmet" } }
local FJM = "models/cod1/german/fjmedic/"
COD1.Variants.german_fallschirm_medic = { team = "axis", voice = "german", voices = 3, model = "models/cod1/german/fallschirmjager.mdl",
	bodies = 2, heads = 2, skins = 10, helmets = { 0, 1, 2 }, blankHelmet = 3,
	helmetProps = { [ 0 ] = { "models/cod1/props/ger_helmet_fj_blk.mdl", "head" }, [ 1 ] = { "models/cod1/props/ger_helmet_fj_grn.mdl", "head" },
		[ 2 ] = { "models/cod1/props/ger_helmet_fj_camo.mdl", "head" } },
	loads = 3, weapons = GER_WEAPONS_OFF, random = { "kar98", "luger" }, belts = { kar98 = 0, mp40 = 1, mp44 = 2, fg42 = 2, luger = 0 },
	medic = true, roleName = "Sanitaeter",
	looks = {
		{ bodyList = { 0, 1 }, helmets = { 0, 1 }, materials = { fallschirm_tunictop = FJM .. "medic_bib",
			fallschirm_tunictop_grey = FJM .. "medic_bib_grey",
			falshrmhelm_grn = FJM .. "medic_helmet_white_grn", falshrmhelm_blk = FJM .. "medic_helmet_white_blk" } },
		{ bodyList = { 0, 1 }, helmets = { 2 }, materials = { fallschirm_upperarm_l = FJM .. "medic_uparm",
			fallschirm_upperarm_grey_l = FJM .. "medic_uparm_grey" } },
	} }

COD1.Variants.summer = COD1.Variants.airborne_summer
COD1.Variants.winter = COD1.Variants.airborne_winter

local KM = "models/cod1/german/kriegsmarine.mdl"
local KM_PROPS = { [ 0 ] = { "models/cod1/props/ger_kriegsmarine_cap.mdl", "head" },
	[ 1 ] = { "models/cod1/props/ger_kriegsmarine_officer_cap.mdl", "head" } }
COD1.Variants.german_kriegsmarine = { team = "axis", voice = "german", voices = 3, model = KM, bodyList = { 0 }, heads = 2, skins = 10,
	helmets = { 0, 0, 0, 2 }, blankHelmet = 2, helmetProps = KM_PROPS, loads = 1, weapons = GER_WEAPONS_OFF,
	random = { "kar98", "kar98", "kar98", "mp40", "mp40", "mp44" }, belts = {},
	officer = { body = 1, helmet = 1, weapon = "luger", weapons = { "luger", "mp40" }, rank = "Kptlt." } }
local function disguised( head, body, helmet, voice, name, officer )
	return { team = "allies", voice = voice, voices = 1, model = KM, bodyList = { body }, headList = { head }, skins = 1,
		helmets = { helmet }, blankHelmet = 2, helmetProps = KM_PROPS, loads = 1, weapons = GER_WEAPONS_OFF, random = { "mp40" },
		belts = {}, fixedName = name, undercover = true, officerLook = officer, papers = officer }
end
COD1.Variants.price_disguised = disguised( 2, 1, 1, "price", "Capt. Price", true )
COD1.Variants.waters_disguised = disguised( 3, 0, 2, "waters", "Sgt. Waters" )

local function with( base, t )
	local v = table.Copy( base )
	for k, x in pairs( t ) do v[ k ] = x end
	return v
end

local GER_UO = { "kar98", "mp40", "mp44", "fg42", "g43", "mg34", "pschreck", "pfaust", "luger" }
local GER_UO_RANDOM = { "kar98", "kar98", "kar98", "kar98", "g43", "g43", "mp40", "mp40", "mp40", "mp44", "mp44", "mg34" }
local GER_UO_BELTS = { kar98 = 0, mp40 = 1, mp44 = 2, fg42 = 0, g43 = 0, mg34 = 3, pschreck = 0, pfaust = 1, luger = 4, flamer = 4 }
local GER_HELMET = { "models/cod1/props/ger_helmet.mdl", "head" }
local GER_CAP = { "models/cod1/props/ger_officer_cap.mdl", "head" }
local GER_OFFICER = { helmet = 3, belt = 4, weapon = "mp40", weapons = { "mp40", "luger" }, rank = "Ltn.", binoc = true }

COD1.Variants.german_afrika = { team = "axis", voice = "german", voices = 3, model = "models/cod1/german/tropical.mdl",
	bodies = 1, heads = 2, skins = 10, helmets = { 0 }, blankHelmet = 2,
	helmetProps = { [ 0 ] = { "models/cod1/props/ger_helmet_tropical.mdl", "head" }, [ 1 ] = GER_CAP },
	loads = 3, weapons = GER_UO, random = GER_UO_RANDOM, belts = GER_UO_BELTS, bandolier = { kar98 = 0.5, g43 = 0.4 },
	officer = { helmet = 1, belt = 4, weapon = "mp40", weapons = { "mp40", "luger" }, rank = "Ltn." } }

local GER_ASSAULT = { team = "axis", voice = "german", voices = 3, model = "models/cod1/german/assault.mdl", heads = 2, skins = 10,
	blankHelmet = 5, helmetProps = { [ 0 ] = GER_HELMET, [ 1 ] = { "models/cod1/props/ger_helmet_waffen.mdl", "helmet" },
		[ 2 ] = { "models/cod1/props/ger_tank_cap.mdl", "helmet" }, [ 3 ] = GER_CAP },
	loads = 3, weapons = { "kar98", "mp40", "mp44", "fg42", "g43", "mg34", "pschreck", "pfaust", "luger", "flamer", "binoc" },
	random = GER_UO_RANDOM, belts = GER_UO_BELTS, blankLoad = { flamer = true }, flameTank = true, smokes = 0.15 }
COD1.Variants.german_uo = with( GER_ASSAULT, { bodyList = { 0, 1, 2, 3 }, helmets = { 0 }, officer = GER_OFFICER } )
COD1.Variants.german_uo_ss = with( GER_ASSAULT, { bodyList = { 4, 5 }, helmets = { 1 }, officer = with( GER_OFFICER, { helmet = 4 } ) } )
COD1.Variants.german_tankcrew = with( GER_ASSAULT, { bodyList = { 6 }, helmets = { 2 }, random = { "luger", "mp40" },
	roleName = "Panzerbesatzung", tankCrew = true, smokes = 0, extra = function( ent ) ent:SetGroup( "load", 3 ) ent:SetGroup( "belt", 4 ) end } )
COD1.Variants.german_winter_uo = { team = "axis", voice = "german", voices = 3, model = "models/cod1/german/winter_assault.mdl",
	bodies = 2, heads = 2, skins = 10, helmets = { 0, 0, 1, 2 }, blankHelmet = 4,
	helmetProps = { [ 0 ] = { "models/cod1/props/ger_helmet_winter.mdl", "head" }, [ 1 ] = { "models/cod1/props/ger_helmet2.mdl", "head" },
		[ 2 ] = GER_HELMET, [ 3 ] = GER_CAP },
	loads = 3, weapons = GER_UO, random = GER_UO_RANDOM, belts = GER_UO_BELTS, smokes = 0.15,
	officer = { helmet = 3, belt = 4, weapon = "mp40", weapons = { "mp40", "luger" }, rank = "Ltn." } }

COD1.ResistanceNames = {
	"Jacques", "Pierre", "Andre", "Marcel", "Henri", "Lucien", "Gaston", "Rene", "Emile", "Raymond", "Georges", "Maurice",
	"Paul", "Robert", "Louis", "Fernand", "Roger", "Michel", "Julien", "Albert", "Leon", "Victor", "Gilbert", "Etienne",
}
COD1.Variants.resistance = { team = "allies", voice = "resistance", voices = 1, model = "models/cod1/british/resistance.mdl",
	bodies = 6, headList = { 0 }, skins = 1, helmets = { 0 }, loads = 1, belts = {},
	weapons = { "enfield", "sten", "mp40", "kar98", "webley", "stensd" },
	random = { "enfield", "enfield", "sten", "sten", "mp40", "kar98", "kar98", "stensd" }, names = COD1.ResistanceNames, satchels = 1,
	extra = function( ent, body ) ent:SetGroup( "head", body ) end }
COD1.Voices.resistance = { { pain = COD1.Voices.american[ 1 ].pain, death = COD1.Voices.american[ 1 ].death } }

COD1.Variants.british_sas = { team = "allies", voice = "british", voices = 6, model = "models/cod1/british/uo.mdl",
	bodyList = { 0, 1 }, headList = { 0, 1, 2, 3 }, skins = 1, helmets = { 0 }, loads = 1, belts = {},
	weapons = { "stensd", "sten", "enfield", "bren", "thompson", "webley", "bazooka" },
	random = { "stensd", "stensd", "stensd", "sten", "sten", "enfield", "enfield", "bren", "thompson" },
	names = COD1.BritishSurnames, smokes = 0.3, satchels = 1 }
COD1.Variants.hero_ingram_uo = with( COD1.Variants.british_sas, { bodyList = { 2 }, headList = { 4 },
	voice = "ingram_uo", voices = 1, random = { "sten", "stensd" }, fixedName = "Maj. Ingram" } )

local SOV_UO_PROPS = { [ 0 ] = SOV_PROPS[ 0 ], [ 1 ] = SOV_PROPS[ 1 ], [ 2 ] = SOV_PROPS[ 2 ],
	[ 3 ] = { "models/cod1/props/sov_tank_helmet.mdl", "helmet" } }
local SOV_UO_COAT = { [ 0 ] = true, [ 1 ] = true }
local function sovUO( ent, body, w, officer )
	local coat = SOV_UO_COAT[ body ]
	local smg = w == "ppsh" or w == "dp28"
	if body > 2 then
		ent:SetGroup( "load", 2 )
		ent:SetGroup( "belt", 5 )
	else
		ent:SetGroup( "load", coat and 0 or 1 )
		ent:SetGroup( "belt", officer and 4 or ( coat and 0 or 2 ) + ( smg and 1 or 0 ) )
	end
	if body == 3 then
		ent:SetGroup( "pack", 1 )
		ent:SetGroup( "spool", 1 )
	end
end
local SOV_UO = { team = "allies", voice = "russian", voices = 6, model = "models/cod1/russian/uo.mdl", heads = 5, skins = 10,
	helmets = { 0, 0, 0, 1 }, blankHelmet = 4, helmetProps = SOV_UO_PROPS, loads = 1,
	weapons = { "mosin", "ppsh", "svt40", "dp28", "tt33", "binoc" },
	random = { "mosin", "mosin", "mosin", "ppsh", "ppsh", "svt40", "svt40", "dp28" }, belts = {}, names = COD1.RussianSurnames,
	extra = sovUO }
COD1.Variants.russian_uo = with( SOV_UO, { bodyList = { 0, 1, 2 },
	officer = { helmet = 2, weapon = "tt33", weapons = { "tt33", "ppsh" }, rank = "Lt.", binoc = true } } )
COD1.Variants.russian_engineer = with( SOV_UO, { bodyList = { 3 }, helmets = { 0, 1 },
	random = { "ppsh", "mosin" }, roleName = "Sapper", satchels = 3 } )
COD1.Variants.russian_radioman = with( SOV_UO, { bodyList = { 4 }, helmets = { 0 }, random = { "ppsh" },
	roleName = "Radioman", radio = true } )
COD1.Variants.russian_tankcrew = with( SOV_UO, { bodyList = { 5 }, helmets = { 3 }, random = { "tt33", "ppsh" },
	roleName = "Tank Crew", tankCrew = true } )
COD1.Variants.hero_miesha = with( SOV_UO, { bodyList = { 4 }, headList = { 5 }, skins = 1, helmets = { 0 },
	random = { "ppsh" }, voice = "miesha", voices = 1, fixedName = "Miesha", radio = true } )
COD1.Variants.hero_boris = with( SOV_UO, { bodyList = { 1 }, headList = { 4 }, skins = 1, helmets = { 0 },
	random = { "mosin", "ppsh" }, fixedName = "Boris" } )
COD1.Variants.hero_antonov = { team = "allies", voice = "antonov", voices = 1, model = "models/cod1/russian/antonov.mdl",
	bodyList = { 0 }, headList = { 0 }, skins = 1, helmets = { 0 }, blankHelmet = 1,
	helmetProps = { [ 0 ] = SOV_PROPS[ 2 ] }, loads = 1, weapons = { "ppsh", "tt33", "binoc" }, random = { "ppsh" }, belts = {},
	fixedName = "Sgt. Antonov" }

local US_UO_PROPS = { [ 0 ] = US_HELMET_PROPS[ 0 ], [ 2 ] = US_HELMET_PROPS[ 4 ], [ 3 ] = { "models/cod1/props/helmet_moody.mdl", "head" } }
COD1.Variants.airborne_uo = { team = "allies", voice = "american", voices = 7, model = "models/cod1/american/uo.mdl",
	bodyList = { 0 }, heads = 5, skins = 10, helmets = { 0, 2, 2 }, blankHelmet = 1, helmetProps = US_UO_PROPS,
	loads = 3, weapons = { "thompson", "garand", "bazooka", "mg30cal", "colt", "binoc" },
	random = { "garand", "garand", "garand", "garand", "thompson", "thompson", "thompson", "mg30cal" },
	belts = { thompson = 0, garand = 1, bazooka = 2, mg30cal = 2, colt = 3 }, smokes = 0.3,
	officer = { body = 1, helmet = 4, weapon = "thompson", rank = "Lt.", binoc = true } }
COD1.Variants.hero_moody_uo = { team = "allies", voice = "moody_uo", voices = 1, model = "models/cod1/american/uo.mdl",
	bodyList = { 2 }, headList = { 5 }, skins = 1, helmets = { 3 }, blankHelmet = 1, helmetProps = US_UO_PROPS, loads = 1,
	weapons = { "thompson", "garand", "bazooka", "mg30cal", "colt", "binoc" }, random = { "thompson" }, belts = {},
	fixedName = "Sgt. Moody", smokes = 1, extra = function( ent ) ent:SetGroup( "load", 3 ) ent:SetGroup( "belt", 0 ) end }
COD1.Variants.hero_foley_uo = { team = "allies", voice = "foley_uo", voices = 1, model = "models/cod1/american/uo.mdl",
	bodyList = { 1 }, headList = { 6 }, skins = 1, helmets = { 4 }, blankHelmet = 1, helmetProps = US_UO_PROPS, loads = 1,
	weapons = { "thompson", "garand", "bazooka", "mg30cal", "colt", "binoc" }, random = { "thompson" }, belts = {},
	fixedName = "Capt. Foley", smokes = 1, officer = { body = 1, helmet = 4, weapon = "thompson", binoc = true },
	extra = function( ent ) ent:SetGroup( "load", 4 ) ent:SetGroup( "belt", 0 ) end }

COD1.Variants.german_sniper = { team = "axis", voice = "german", voices = 3, model = "models/cod1/german/snipers.mdl",
	bodyList = { 0, 1 }, heads = 2, skins = 10, helmets = { 0 }, blankHelmet = 4,
	helmetProps = { [ 0 ] = { "models/cod1/props/ger_helmet.mdl", "head" }, [ 1 ] = { "models/cod1/props/ger_helmet_waffen.mdl", "helmet" },
		[ 2 ] = { "models/cod1/props/ger_helmet_winter.mdl", "head" }, [ 3 ] = { "models/cod1/props/ger_helmet_fj_camo.mdl", "head" } },
	loads = 2, weapons = { "kar98_sniper" }, random = { "kar98_sniper" }, belts = { kar98_sniper = 0 },
	looks = { { bodyList = { 0, 1 }, helmets = { 0 } }, { bodyList = { 0, 1 }, helmets = { 0 } }, { bodyList = { 2 }, helmets = { 1 } },
		{ bodyList = { 4 }, helmets = { 3 } } },
	extra = function( ent, body ) if body == 4 then ent:SetGroup( "load", 2 ) ent:SetGroup( "belt", 1 ) end end }
COD1.Variants.german_sniper_winter = with( COD1.Variants.german_sniper, { looks = { { bodyList = { 3 }, helmets = { 2, 2, 0 } } } } )

COD1.Variants.russian_sniper = { team = "allies", voice = "russian", voices = 6, model = "models/cod1/russian/snipers.mdl",
	bodyList = { 0, 0, 2 }, headList = { 0, 0, 0, 1, 2, 3, 4, 5 }, skins = 11, helmets = { 0, 0, 1 }, blankHelmet = 2,
	helmetProps = { [ 0 ] = SOV_PROPS[ 0 ], [ 1 ] = SOV_PROPS[ 1 ] }, loads = 1, weapons = { "mosin_sniper" }, random = { "mosin_sniper" },
	belts = {}, names = COD1.RussianSurnames,
	extra = function( ent, body )
		ent:SetGroup( "load", body == 2 and 1 or 0 )
		ent:SetGroup( "belt", body == 2 and 1 or 0 )
		ent:SetSkin( ent:GetBodygroup( ent:FindBodygroupByName( "head" ) ) == 0 and 0 or math.random( 1, 10 ) )
	end }
COD1.Variants.russian_sniper_winter = with( COD1.Variants.russian_sniper, { bodyList = { 1 }, helmets = { 0, 1 } } )

COD1.Variants.airborne_sniper = { team = "allies", voice = "american", voices = 7, model = "models/cod1/american/snipers.mdl",
	bodyList = { 0, 1, 2 }, heads = 5, skins = 15, helmets = { 0, 1, 2 }, blankHelmet = 3, helmetProps = US_HELMET_PROPS,
	loads = 3, weapons = { "springfield" }, random = { "springfield" }, belts = { springfield = 0 } }
COD1.Variants.airborne_sniper_winter = with( COD1.Variants.airborne_sniper, { bodyList = { 3 }, helmets = { 0 } } )

COD1.Variants.hero_waters_winter = named( "models/cod1/british/heroes_winter.mdl", { "bren", "sten" }, 0, 0, "waters", { "bren", "sten" },
	{ load = 0 }, { [ 0 ] = { "models/cod1/props/brit_beret_green.mdl", "head" } }, 1, "Sgt. Waters" )

COD1.Variants.british_raf = { team = "allies", voice = "british", voices = 6, model = "models/cod1/british/raf.mdl",
	bodyList = { 1, 1, 2 }, headList = { 0, 1, 2, 3 }, skins = 1, helmets = { 0 }, loads = 1, belts = {},
	weapons = { "sten", "webley", "enfield" }, random = { "sten", "sten", "webley", "enfield" }, names = COD1.BritishSurnames,
	roleName = "RAF Aircrew" }

local CAT, HEROES = "Call of Duty 1", "Call of Duty 1 & UO: Main Characters"
local US, GER = "npc_cod1_airborne", "npc_cod1_german"
local SECTION = {}
SECTION[ "npc_cod1_airborne" ] = "Americans"
SECTION[ "npc_cod1_airborne_thompson" ] = "Americans"
SECTION[ "npc_cod1_airborne_garand" ] = "Americans"
SECTION[ "npc_cod1_airborne_carbine" ] = "Americans"
SECTION[ "npc_cod1_airborne_bar" ] = "Americans"
SECTION[ "npc_cod1_airborne_para" ] = "Americans"
SECTION[ "npc_cod1_airborne_winter" ] = "Americans"
SECTION[ "npc_cod1_airborne_officer" ] = "Americans"
SECTION[ "npc_cod1_medic" ] = "Americans"
SECTION[ "npc_cod1_medic_winter" ] = "Americans"
SECTION[ "npc_cod1_british_para" ] = "British"
SECTION[ "npc_cod1_british_para_drop" ] = "British"
SECTION[ "npc_cod1_british_medic" ] = "British"
SECTION[ "npc_cod1_british_commando" ] = "British"
SECTION[ "npc_cod1_british_bren" ] = "British"
SECTION[ "npc_cod1_british_winter" ] = "British"
SECTION[ "npc_cod1_russian" ] = "Russians"
SECTION[ "npc_cod1_russian_mosin" ] = "Russians"
SECTION[ "npc_cod1_russian_ppsh" ] = "Russians"
SECTION[ "npc_cod1_russian_winter" ] = "Russians"
SECTION[ "npc_cod1_russian_officer" ] = "Russians"
SECTION[ "npc_cod1_russian_medic" ] = "Russians"
SECTION[ "npc_cod1_russian_medic_winter" ] = "Russians"
SECTION[ "npc_cod1_russian_conscript" ] = "Russians"
SECTION[ "npc_cod1_russian_conscript_winter" ] = "Russians"
SECTION[ "npc_cod1_gunpass" ] = "Russians"
SECTION[ "npc_cod1_gunpass_winter" ] = "Russians"
SECTION[ "npc_cod1_russian_flag" ] = "Russians"
SECTION[ "npc_cod1_russian_commissar" ] = "Russians"
SECTION[ "npc_cod1_russian_megaphone" ] = "Russians"
SECTION[ "npc_cod1_german" ] = "Germans"
SECTION[ "npc_cod1_german_kar98" ] = "Germans"
SECTION[ "npc_cod1_german_mp40" ] = "Germans"
SECTION[ "npc_cod1_german_mp44" ] = "Germans"
SECTION[ "npc_cod1_german_officer" ] = "Germans"
SECTION[ "npc_cod1_german_officer_luger" ] = "Germans"
SECTION[ "npc_cod1_german_medic" ] = "Germans"
SECTION[ "npc_cod1_german_ss" ] = "Germans"
SECTION[ "npc_cod1_german_ss_officer" ] = "Germans"
SECTION[ "npc_cod1_german_ss_officer_luger" ] = "Germans"
SECTION[ "npc_cod1_german_fj" ] = "Germans"
SECTION[ "npc_cod1_german_fg42" ] = "Germans"
SECTION[ "npc_cod1_german_fj_drop" ] = "Germans"
SECTION[ "npc_cod1_german_fj_medic" ] = "Germans"
SECTION[ "npc_cod1_german_winter" ] = "Germans"
SECTION[ "npc_cod1_kriegsmarine" ] = "Germans"
SECTION[ "npc_cod1_kriegsmarine_mp40" ] = "Germans"
SECTION[ "npc_cod1_kriegsmarine_officer" ] = "Germans"
SECTION[ "npc_cod1_german_sniper" ] = "Germans"
SECTION[ "npc_cod1_german_sniper_winter" ] = "Germans"
SECTION[ "npc_cod1_russian_sniper" ] = "Russians"
SECTION[ "npc_cod1_russian_sniper_winter" ] = "Russians"
SECTION[ "npc_cod1_airborne_sniper" ] = "Americans"
SECTION[ "npc_cod1_airborne_sniper_winter" ] = "Americans"
SECTION[ "npc_cod1_foley" ] = "Americans"
SECTION[ "npc_cod1_moody" ] = "Americans"
SECTION[ "npc_cod1_elder" ] = "Americans"
SECTION[ "npc_cod1_price" ] = "British"
SECTION[ "npc_cod1_waters" ] = "British"
SECTION[ "npc_cod1_price_disguised" ] = "British"
SECTION[ "npc_cod1_waters_disguised" ] = "British"
SECTION[ "npc_cod1_ingram" ] = "British"
SECTION[ "npc_cod1_mills" ] = "British"
SECTION[ "npc_cod1_pavlov" ] = "Russians"
SECTION[ "npc_cod1_kovalenko" ] = "Russians"
SECTION[ "npc_cod1_makarov" ] = "Russians"
SECTION[ "npc_cod1_waters_winter" ] = "British"
SECTION[ "npc_cod1_uo_afrika" ] = "Germans"
SECTION[ "npc_cod1_uo_afrika_g43" ] = "Germans"
SECTION[ "npc_cod1_uo_afrika_mg34" ] = "Germans"
SECTION[ "npc_cod1_uo_afrika_pschreck" ] = "Germans"
SECTION[ "npc_cod1_uo_afrika_pfaust" ] = "Germans"
SECTION[ "npc_cod1_uo_afrika_officer" ] = "Germans"
SECTION[ "npc_cod1_uo_german" ] = "Germans"
SECTION[ "npc_cod1_uo_german_g43" ] = "Germans"
SECTION[ "npc_cod1_uo_german_mg34" ] = "Germans"
SECTION[ "npc_cod1_uo_german_pschreck" ] = "Germans"
SECTION[ "npc_cod1_uo_german_pfaust" ] = "Germans"
SECTION[ "npc_cod1_uo_german_flamer" ] = "Germans"
SECTION[ "npc_cod1_uo_german_officer" ] = "Germans"
SECTION[ "npc_cod1_uo_ss" ] = "Germans"
SECTION[ "npc_cod1_uo_ss_flamer" ] = "Germans"
SECTION[ "npc_cod1_uo_ss_officer" ] = "Germans"
SECTION[ "npc_cod1_uo_german_winter" ] = "Germans"
SECTION[ "npc_cod1_uo_german_winter_mg34" ] = "Germans"
SECTION[ "npc_cod1_uo_german_winter_pschreck" ] = "Germans"
SECTION[ "npc_cod1_uo_german_tankcrew" ] = "Germans"
SECTION[ "npc_cod1_uo_airborne" ] = "Americans"
SECTION[ "npc_cod1_uo_airborne_bazooka" ] = "Americans"
SECTION[ "npc_cod1_uo_airborne_30cal" ] = "Americans"
SECTION[ "npc_cod1_uo_airborne_officer" ] = "Americans"
SECTION[ "npc_cod1_uo_sas" ] = "British & Resistance"
SECTION[ "npc_cod1_uo_sas_stensd" ] = "British & Resistance"
SECTION[ "npc_cod1_uo_sas_bazooka" ] = "British & Resistance"
SECTION[ "npc_cod1_uo_resistance" ] = "British & Resistance"
SECTION[ "npc_cod1_uo_resistance_stensd" ] = "British & Resistance"
SECTION[ "npc_cod1_uo_raf" ] = "British & Resistance"
SECTION[ "npc_cod1_uo_russian" ] = "Russians"
SECTION[ "npc_cod1_uo_russian_svt40" ] = "Russians"
SECTION[ "npc_cod1_uo_russian_dp28" ] = "Russians"
SECTION[ "npc_cod1_uo_russian_officer" ] = "Russians"
SECTION[ "npc_cod1_uo_russian_engineer" ] = "Russians"
SECTION[ "npc_cod1_uo_russian_radioman" ] = "Russians"
SECTION[ "npc_cod1_uo_russian_tankcrew" ] = "Russians"
SECTION[ "npc_cod1_uo_foley" ] = "Americans"
SECTION[ "npc_cod1_uo_moody" ] = "Americans"
SECTION[ "npc_cod1_uo_ingram" ] = "British"
SECTION[ "npc_cod1_uo_antonov" ] = "Russians"
SECTION[ "npc_cod1_uo_miesha" ] = "Russians"
SECTION[ "npc_cod1_uo_boris" ] = "Russians"
local function addNPC( key, name, class, kv, cat )
	list.Set( "NPC", key, { Name = name, Class = class, Category = cat or CAT, SubCategory = SECTION[ key ], KeyValues = kv } )
end
local function v( variant, weapon, extra )
	local kv = { cod1_variant = variant, cod1_weapon = weapon or "random" }
	if extra then table.Merge( kv, extra ) end
	return kv
end
local OFFICER, DROP = { cod1_officer = "1" }, { cod1_parachute = "1" }

addNPC( "npc_cod1_airborne", "US Airborne (Random)", US, v( "airborne_summer" ) )
addNPC( "npc_cod1_airborne_thompson", "US Airborne (Thompson)", US, v( "airborne_summer", "thompson" ) )
addNPC( "npc_cod1_airborne_garand", "US Airborne (M1 Garand)", US, v( "airborne_summer", "garand" ) )
addNPC( "npc_cod1_airborne_carbine", "US Airborne (M1 Carbine)", US, v( "airborne_summer", "carbine" ) )
addNPC( "npc_cod1_airborne_bar", "US Airborne (BAR)", US, v( "airborne_summer", "bar" ) )
addNPC( "npc_cod1_airborne_para", "US Airborne (Parachute Drop)", US, v( "airborne_summer", nil, DROP ) )
addNPC( "npc_cod1_airborne_winter", "US Airborne Winter (Random)", US, v( "airborne_winter" ) )
addNPC( "npc_cod1_airborne_officer", "US Airborne Winter Officer", US, v( "airborne_winter", nil, OFFICER ) )
addNPC( "npc_cod1_medic", "US Airborne Medic", US, v( "airborne_medic" ) )
addNPC( "npc_cod1_medic_winter", "US Airborne Medic (Winter)", US, v( "airborne_winter_medic" ) )
addNPC( "npc_cod1_british_para", "British Paratrooper (Random)", US, v( "british_para" ) )
addNPC( "npc_cod1_british_para_drop", "British Paratrooper (Parachute Drop)", US, v( "british_para", nil, DROP ) )
addNPC( "npc_cod1_british_medic", "British Paratrooper Medic", US, v( "british_medic" ) )
addNPC( "npc_cod1_british_commando","British Commando (Random)", US, v( "british_commando" ) )
addNPC( "npc_cod1_british_bren", "British Commando (Bren)", US, v( "british_commando", "bren" ) )
addNPC( "npc_cod1_british_winter", "British Commando Winter", US, v( "british_winter" ) )
addNPC( "npc_cod1_russian", "Russian Soldier (Random)", US, v( "russian" ) )
addNPC( "npc_cod1_russian_mosin", "Russian Soldier (Mosin-Nagant)", US, v( "russian", "mosin" ) )
addNPC( "npc_cod1_russian_ppsh", "Russian Soldier (PPSh)", US, v( "russian", "ppsh" ) )
addNPC( "npc_cod1_russian_winter", "Russian Soldier Winter", US, v( "russian_winter" ) )
addNPC( "npc_cod1_russian_officer", "Russian Officer", US, v( "russian", nil, OFFICER ) )
addNPC( "npc_cod1_russian_medic", "Russian Medic", US, v( "russian_medic" ) )
addNPC( "npc_cod1_russian_medic_winter", "Russian Medic Winter", US, v( "russian_winter_medic" ) )
addNPC( "npc_cod1_russian_conscript", "Russian Conscript (Unarmed)", US, v( "russian_conscript", "mosin" ) )
addNPC( "npc_cod1_russian_conscript_winter", "Russian Conscript Winter (Unarmed)", US, v( "russian_winter_conscript", "mosin" ) )
addNPC( "npc_cod1_gunpass", "Russian Supply Station (Guns & Ammo)", "cod1_gunpass", { cod1_variant = "russian" } )
addNPC( "npc_cod1_gunpass_winter", "Russian Supply Station Winter (Guns & Ammo)", "cod1_gunpass", { cod1_variant = "russian_winter" } )
addNPC( "npc_cod1_russian_flag", "Russian Flag Bearer", US, v( "russian_flag", "luger" ) )
addNPC( "npc_cod1_russian_commissar", "Russian Commissar", US, v( "russian_commissar", "luger" ) )
addNPC( "npc_cod1_russian_megaphone", "Russian Commissar (Megaphone)", US, v( "russian_megaphone", "luger" ) )
addNPC( "npc_cod1_german", "German Wehrmacht (Random)", GER, v( "german_wehrmacht" ) )
addNPC( "npc_cod1_german_kar98", "German Wehrmacht (Kar98k)", GER, v( "german_wehrmacht", "kar98" ) )
addNPC( "npc_cod1_german_mp40", "German Wehrmacht (MP40)", GER, v( "german_wehrmacht", "mp40" ) )
addNPC( "npc_cod1_german_mp44", "German Wehrmacht (MP44)", GER, v( "german_wehrmacht", "mp44" ) )
addNPC( "npc_cod1_german_officer", "German Wehrmacht Officer", GER, v( "german_wehrmacht", nil, OFFICER ) )
addNPC( "npc_cod1_german_officer_luger", "German Wehrmacht Officer (Luger)", GER, v( "german_wehrmacht", "luger", OFFICER ) )
addNPC( "npc_cod1_german_medic", "German Wehrmacht Medic", GER, v( "german_medic" ) )
addNPC( "npc_cod1_german_ss","German Waffen-SS (Random)", GER, v( "german_waffenss" ) )
addNPC( "npc_cod1_german_ss_officer", "German Waffen-SS Officer", GER, v( "german_waffenss", nil, OFFICER ) )
addNPC( "npc_cod1_german_ss_officer_luger", "German Waffen-SS Officer (Luger)", GER, v( "german_waffenss", "luger", OFFICER ) )
addNPC( "npc_cod1_german_fj", "German Fallschirmjäger (Random)", GER, v( "german_fallschirm" ) )
addNPC( "npc_cod1_german_fg42", "German Fallschirmjäger (FG42)", GER, v( "german_fallschirm", "fg42" ) )
addNPC( "npc_cod1_german_fj_drop", "German Fallschirmjäger (Parachute Drop)", GER, v( "german_fallschirm", nil, DROP ) )
addNPC( "npc_cod1_german_fj_medic", "German Fallschirmjäger Medic", GER, v( "german_fallschirm_medic" ) )
addNPC( "npc_cod1_german_winter","German Winter (Random)", GER, v( "german_winter" ) )
addNPC( "npc_cod1_kriegsmarine", "German Kriegsmarine Sailor (Random)", GER, v( "german_kriegsmarine" ) )
addNPC( "npc_cod1_kriegsmarine_mp40", "German Kriegsmarine Sailor (MP40)", GER, v( "german_kriegsmarine", "mp40" ) )
addNPC( "npc_cod1_kriegsmarine_officer", "German Kriegsmarine Officer", GER, v( "german_kriegsmarine", nil, OFFICER ) )
addNPC( "npc_cod1_german_sniper", "German Sniper (Kar98k Scoped)", GER, v( "german_sniper" ) )
addNPC( "npc_cod1_german_sniper_winter", "German Sniper Winter (Kar98k Scoped)", GER, v( "german_sniper_winter" ) )
addNPC( "npc_cod1_russian_sniper", "Russian Sniper (Mosin-Nagant Scoped)", US, v( "russian_sniper" ) )
addNPC( "npc_cod1_russian_sniper_winter", "Russian Sniper Winter (Mosin-Nagant Scoped)", US, v( "russian_sniper_winter" ) )
addNPC( "npc_cod1_airborne_sniper", "US Airborne Sniper (Springfield)", US, v( "airborne_sniper" ) )
addNPC( "npc_cod1_airborne_sniper_winter", "US Airborne Sniper Winter (Springfield)", US, v( "airborne_sniper_winter" ) )
addNPC( "npc_cod1_german_truck", "German Truck (Squad Drop-off)", "cod1_german_truck", {}, "Call of Duty 1: Vehicles" )
list.Set( "NPC", "npc_cod1_mg42_nest", { Name = "German MG42 Nest", Class = "cod1_mg_turret", Category = CAT, SubCategory = "Machine Guns", KeyValues = { cod1_mg = "mg42" }, Rotate = Angle( 0, 180, 0 ) } )
list.Set( "NPC", "npc_cod1_mg42_prone", { Name = "German MG42 (Prone Gunner)", Class = "cod1_mg_turret", Category = CAT, SubCategory = "Machine Guns", KeyValues = { cod1_mg = "mg42_prone" }, Rotate = Angle( 0, 180, 0 ) } )
list.Set( "NPC", "npc_cod1_30cal_nest", { Name = "US .30 cal Nest", Class = "cod1_mg_turret", Category = CAT, SubCategory = "Machine Guns", KeyValues = { cod1_mg = "b30cal" }, Rotate = Angle( 0, 180, 0 ) } )
list.Set( "NPC", "npc_cod1_mg42_free", { Name = "German MG42 (No Sandbags, Windows & Ledges)", Class = "cod1_mg_turret", Category = CAT, SubCategory = "Machine Guns",
	KeyValues = { cod1_mg = "mg42_stand", cod1_free = "1" }, Rotate = Angle( 0, 180, 0 ), NoDrop = true, Offset = 2 } )
list.Set( "NPC", "npc_cod1_30cal_free", { Name = "US .30 cal (No Sandbags, Windows & Ledges)", Class = "cod1_mg_turret", Category = CAT, SubCategory = "Machine Guns",
	KeyValues = { cod1_mg = "b30cal_free", cod1_free = "1" }, Rotate = Angle( 0, 180, 0 ), NoDrop = true, Offset = 2 } )
addNPC( "npc_cod1_foley", "Captain Foley", US, v( "hero_foley", "thompson" ), HEROES )
addNPC( "npc_cod1_moody", "Sergeant Moody", US, v( "hero_moody", "thompson" ), HEROES )
addNPC( "npc_cod1_elder", "Private Elder", US, v( "hero_elder" ), HEROES )
addNPC( "npc_cod1_price", "Captain Price", US, v( "british_price", "thompson" ), HEROES )
addNPC( "npc_cod1_waters", "Sergeant Waters", US, v( "hero_waters" ), HEROES )
addNPC( "npc_cod1_price_disguised", "Captain Price (Kriegsmarine Disguise)", US, v( "price_disguised", "mp40" ), HEROES )
addNPC( "npc_cod1_waters_disguised", "Sergeant Waters (Kriegsmarine Disguise)", US, v( "waters_disguised", "mp40" ), HEROES )
addNPC( "npc_cod1_ingram", "Major Ingram", US, v( "hero_ingram", "mp40" ), HEROES )
addNPC( "npc_cod1_mills", "Private Mills", US, v( "hero_mills", "sten" ), HEROES )
addNPC( "npc_cod1_pavlov", "Sergeant Pavlov", US, v( "hero_pavlov", "ppsh" ), HEROES )
addNPC( "npc_cod1_kovalenko", "Sergeant Kovalenko", US, v( "hero_kovalenko", "ppsh" ), HEROES )
addNPC( "npc_cod1_makarov", "Private Makarov", US, v( "hero_makarov", "ppsh" ), HEROES )
addNPC( "npc_cod1_waters_winter", "Sergeant Waters (Winter)", US, v( "hero_waters_winter" ), HEROES )

local UO = "Call of Duty: United Offensive"
addNPC( "npc_cod1_uo_afrika", "Afrika Korps (Random)", GER, v( "german_afrika" ), UO )
addNPC( "npc_cod1_uo_afrika_g43", "Afrika Korps (Gewehr 43)", GER, v( "german_afrika", "g43" ), UO )
addNPC( "npc_cod1_uo_afrika_mg34", "Afrika Korps (MG34)", GER, v( "german_afrika", "mg34" ), UO )
addNPC( "npc_cod1_uo_afrika_pschreck", "Afrika Korps (Panzerschreck)", GER, v( "german_afrika", "pschreck" ), UO )
addNPC( "npc_cod1_uo_afrika_pfaust", "Afrika Korps (Panzerfaust)", GER, v( "german_afrika", "pfaust" ), UO )
addNPC( "npc_cod1_uo_afrika_officer", "Afrika Korps Officer", GER, v( "german_afrika", nil, OFFICER ), UO )
addNPC( "npc_cod1_uo_german", "German Grenadier (Random)", GER, v( "german_uo" ), UO )
addNPC( "npc_cod1_uo_german_g43", "German Grenadier (Gewehr 43)", GER, v( "german_uo", "g43" ), UO )
addNPC( "npc_cod1_uo_german_mg34", "German Grenadier (MG34)", GER, v( "german_uo", "mg34" ), UO )
addNPC( "npc_cod1_uo_german_pschreck", "German Grenadier (Panzerschreck)", GER, v( "german_uo", "pschreck" ), UO )
addNPC( "npc_cod1_uo_german_pfaust", "German Grenadier (Panzerfaust)", GER, v( "german_uo", "pfaust" ), UO )
addNPC( "npc_cod1_uo_german_flamer", "German Flamethrower", GER, v( "german_uo", "flamer" ), UO )
addNPC( "npc_cod1_uo_german_officer", "German Officer (Binoculars)", GER, v( "german_uo", nil, OFFICER ), UO )
addNPC( "npc_cod1_uo_ss", "Waffen-SS Grenadier (Random)", GER, v( "german_uo_ss" ), UO )
addNPC( "npc_cod1_uo_ss_flamer", "Waffen-SS Flamethrower", GER, v( "german_uo_ss", "flamer" ), UO )
addNPC( "npc_cod1_uo_ss_officer", "Waffen-SS Officer (Binoculars)", GER, v( "german_uo_ss", nil, OFFICER ), UO )
addNPC( "npc_cod1_uo_german_winter", "German Winter Grenadier (Random)", GER, v( "german_winter_uo" ), UO )
addNPC( "npc_cod1_uo_german_winter_mg34", "German Winter Grenadier (MG34)", GER, v( "german_winter_uo", "mg34" ), UO )
addNPC( "npc_cod1_uo_german_winter_pschreck", "German Winter Grenadier (Panzerschreck)", GER, v( "german_winter_uo", "pschreck" ), UO )
addNPC( "npc_cod1_uo_german_tankcrew", "German Panzer Crewman", GER, v( "german_tankcrew" ), UO )
addNPC( "npc_cod1_uo_airborne", "US Airborne Bastogne (Random)", US, v( "airborne_uo" ), UO )
addNPC( "npc_cod1_uo_airborne_bazooka", "US Airborne Bastogne (Bazooka)", US, v( "airborne_uo", "bazooka" ), UO )
addNPC( "npc_cod1_uo_airborne_30cal", "US Airborne Bastogne (.30 cal)", US, v( "airborne_uo", "mg30cal" ), UO )
addNPC( "npc_cod1_uo_airborne_officer", "US Airborne Bastogne Officer (Binoculars)", US, v( "airborne_uo", nil, OFFICER ), UO )
addNPC( "npc_cod1_uo_sas", "British SAS (Random)", US, v( "british_sas" ), UO )
addNPC( "npc_cod1_uo_sas_stensd", "British SAS (Silenced Sten)", US, v( "british_sas", "stensd" ), UO )
addNPC( "npc_cod1_uo_sas_bazooka", "British SAS (Bazooka)", US, v( "british_sas", "bazooka" ), UO )
addNPC( "npc_cod1_uo_resistance", "Resistance Fighter (Random)", US, v( "resistance" ), UO )
addNPC( "npc_cod1_uo_resistance_stensd", "Resistance Fighter (Silenced Sten)", US, v( "resistance", "stensd" ), UO )
addNPC( "npc_cod1_uo_raf", "RAF Bomber Crew (Random)", US, v( "british_raf" ), UO )
addNPC( "npc_cod1_uo_russian", "Russian Soldier 1943 (Random)", US, v( "russian_uo" ), UO )
addNPC( "npc_cod1_uo_russian_svt40", "Russian Soldier 1943 (SVT-40)", US, v( "russian_uo", "svt40" ), UO )
addNPC( "npc_cod1_uo_russian_dp28", "Russian Soldier 1943 (DP-28)", US, v( "russian_uo", "dp28" ), UO )
addNPC( "npc_cod1_uo_russian_officer", "Russian Officer (Binoculars)", US, v( "russian_uo", nil, OFFICER ), UO )
addNPC( "npc_cod1_uo_russian_engineer", "Russian Sapper (Satchel Charges)", US, v( "russian_engineer" ), UO )
addNPC( "npc_cod1_uo_russian_radioman", "Russian Radioman", US, v( "russian_radioman" ), UO )
addNPC( "npc_cod1_uo_russian_tankcrew", "Russian Tank Crewman", US, v( "russian_tankcrew" ), UO )
addNPC( "npc_cod1_uo_foley", "Captain Foley (Bastogne)", US, v( "hero_foley_uo", "thompson", OFFICER ), HEROES )
addNPC( "npc_cod1_uo_moody", "Sergeant Moody (Bastogne)", US, v( "hero_moody_uo", "thompson" ), HEROES )
addNPC( "npc_cod1_uo_ingram", "Major Ingram (Sicily)", US, v( "hero_ingram_uo" ), HEROES )
addNPC( "npc_cod1_uo_antonov", "Sergeant Antonov", US, v( "hero_antonov", "ppsh" ), HEROES )
addNPC( "npc_cod1_uo_miesha", "Miesha", US, v( "hero_miesha", "ppsh" ), HEROES )
addNPC( "npc_cod1_uo_boris", "Boris", US, v( "hero_boris" ), HEROES )

list.Set( "ContentCategoryIcons", CAT, "cod1/ui/star16.png" )
list.Set( "ContentCategoryIcons", HEROES, "cod1/ui/star16_gold.png" )
list.Set( "ContentCategoryIcons", UO, "cod1/ui/uo16.png" )

--is that you john wayne is thiss me?