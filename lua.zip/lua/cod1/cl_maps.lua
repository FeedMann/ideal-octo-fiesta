COD1.MapAmbience = {
	cod1_bocage = { file = "sound/cod1/ambient/amb_brecourt_ext.mp3", volume = 0.7 },
	cod1_stalingrad = { file = "sound/cod1/ambient/amb_stalingrad_docks.mp3", volume = 0.7 },
	cod1_redsquare = { file = "sound/cod1/ambient/amb_berlin_ext.mp3", volume = 0.75 },
	cod1_dawnville = { file = "sound/cod1/ambient/amb_brecourt_ext.mp3", volume = 0.7 },
	cod1_dawnville_night = { file = "sound/cod1/ambient/amb_burnville_ext.mp3", volume = 0.75 },
}

local function stop()
	if IsValid( COD1.AmbienceChannel ) then COD1.AmbienceChannel:Stop() end
	COD1.AmbienceChannel = nil
end

local function volume( a )
	return a.volume * GetConVar( "cod1_ambience_volume" ):GetFloat()
end

function COD1.StartAmbience()
	stop()
	local a = COD1.MapAmbience[ game.GetMap() ]
	if not a or volume( a ) <= 0 then return end
	sound.PlayFile( a.file, "noplay noblock", function( ch )
		if not IsValid( ch ) then return end
		stop()
		ch:EnableLooping( true )
		ch:SetVolume( volume( a ) )
		ch:Play()
		COD1.AmbienceChannel = ch
	end )
end

hook.Add( "InitPostEntity", "COD1MapAmbience", COD1.StartAmbience )

cvars.AddChangeCallback( "cod1_ambience_volume", function()
	local a = COD1.MapAmbience[ game.GetMap() ]
	if not a then return end
	if IsValid( COD1.AmbienceChannel ) and volume( a ) > 0 then
		COD1.AmbienceChannel:SetVolume( volume( a ) )
	else
		COD1.StartAmbience()
	end
end, "COD1MapAmbience" )

COD1.MapFX = {}
COD1.MapFX.cod1_dawnville_night = {
	off = Vector( 320, 16640, 0 ),
	cycle = 300,
	loops = {
		{ "fire/smallbon", Vector( -808, -18216, 115 ), 0.3 },
		{ "fire/tinybon", Vector( -272, -17009, 225 ), 0.3 },
		{ "fire/tinybon", Vector( -353, -17014, 203 ), 0.2 },
		{ "fire/tinybon", Vector( -90, -14757, -22 ), 0.3 },
		{ "fire/tinybon", Vector( -573, -14953, -71 ), 0.3 },
		{ "fire/smallbon", Vector( -686, -17114, 14 ), 0.3 },
		{ "fire/smallbon", Vector( 3071, -15910, 126 ), 0.4 },
		{ "fire/tinybon", Vector( 1596, -15276, -106 ), 0.3 },
		{ "fire/smallbon", Vector( -701, -18361, 128 ), 0.3 },
		{ "fire/smallbon", Vector( -1183, -17403, 15 ), 0.3 },
		{ "fire/smallbon", Vector( 31, -16989, 220 ), 0.3 },
		{ "fire/smallbon", Vector( 2725, -14916, 36 ), 0.3 },
		{ "fire/tinybon", Vector( 2169, -15715, -45 ), 0.3 },
		{ "fire/smallbon", Vector( 959, -14741, -75 ), 0.3 },
		{ "fire/smallbon", Vector( 99, -15281, -56 ), 0.2 },
		{ "smoke/smokecurtain", Vector( 1293, -16833, 274 ), 0.3 },
		{ "smoke/smokecurtain", Vector( -596, -17111, 345 ), 0.3 },
		{ "smoke/firesmoke_col2", Vector( 87, -15284, 75 ), 0.3 },
		{ "smoke/smokecurtain", Vector( 2714, -14921, 114 ), 0.3 },
		{ "smoke/smokecurtain", Vector( 2060, -16287, 68 ), 0.3 },
		{ "smoke/firesmoke_col2", Vector( 400, -15674, 0 ), 0.3 },
		{ "fire/smallbon", Vector( 402, -15698, -72 ), 0.3 },
		{ "smoke/smokecurtain", Vector( 868, -18498, 226 ), 0.3 },
		{ "fire/extreme_butwide2", Vector( 873, -18552, 193 ), 0.2 },
		{ "smoke/firesmoke_col2", Vector( 1556, -16402, 245 ), 0.3 },
		{ "smoke/smokecurtain", Vector( 2454, -17347, 484 ), 0.3 },
		{ "smoke/smokecurtain", Vector( 30, -17001, 286 ), 0.3 },
		{ "smoke/underlitsmoke", Vector( 203, -16781, 200 ), 0.1 },
		{ "smoke/underlitsmoke", Vector( -2766, -16958, 76 ), 0.1 },
		{ "smoke/firesmoke_col1", Vector( -701, -18361, 200 ), 0.2 },
		{ "smoke/underlitsmoke", Vector( -824, -18227, 130 ), 0.1 },
		{ "smoke/underlitsmoke", Vector( -1190, -17381, 86 ), 0.1 },
		{ "smoke/firesmoke_col1", Vector( 1612, -15260, -46 ), 0.2 },
		{ "smoke/firesmoke_col1", Vector( 2165, -15718, -60 ), 0.2 },
		{ "smoke/underlitsmoke", Vector( -570, -14944, -62 ), 0.1 },
		{ "smoke/underlitsmoke", Vector( 961, -14749, -8 ), 0.2 },
		{ "smoke/windowsmoke_col1", Vector( 1323, -17085, 78 ), 0.2 },
		{ "smoke/windowsmoke_col1", Vector( 1186, -17082, 98 ), 0.2 },
		{ "smoke/underlitsmoke", Vector( 147, -16274, 223 ), 0.2 },
		{ "smoke/underlitsmoke", Vector( 101, -16284, 171 ), 0.2 },
		{ "fire/firewallfacade_x", Vector( 2480, -17343, 234 ), 0.4 },
		{ "fire/em_fire1", Vector( 1285, -16939, 22 ), 0.3 },
		{ "fire/em_fire1", Vector( 1307, -16855, 122 ), 0.4 },
		{ "fire/tinybon", Vector( -844, -16967, 212 ), 0.4 },
		{ "fire/smallbon", Vector( 2080, -16289, -29 ), 0.3 },
		{ "fire/em_fire1", Vector( 1570, -16400, -36 ), 0.4 },
		{ "fire/em_fire1", Vector( 1570, -16400, 79 ), 0.3 },
		{ "fire/em_fire1", Vector( -632, -17107, 179 ), 0.3 },
	},
	sounds = {
		{ "medfire", Vector( 443, -15679, -3 ) },
		{ "medfire", Vector( 115, -16278, 137 ) },
		{ "medfire", Vector( 2159, -15706, -63 ) },
		{ "medfire", Vector( 1616, -15265, -78 ) },
		{ "medfire", Vector( 959, -14747, -25 ) },
		{ "medfire", Vector( -91, -14756, -32 ) },
		{ "medfire", Vector( -560, -14943, -48 ) },
		{ "medfire", Vector( 114, -15283, 0 ) },
		{ "bigfire", Vector( 898, -18551, 120 ) },
		{ "bigfire", Vector( -705, -18352, 120 ) },
		{ "bigfire", Vector( -1178, -17390, 65 ) },
		{ "bigfire", Vector( -648, -17097, 131 ) },
		{ "bigfire", Vector( 1581, -16398, -3 ) },
		{ "bigfire", Vector( 1295, -16904, 84 ) },
		{ "bigfire", Vector( 39, -16989, 197 ) },
	},
	guns = {
		{ "atmosphere/antiair_tracers", Vector( 5025, -14265, 227 ), 1, 4, 5.2, 3.4, 3.2, 4.5 },
		{ "atmosphere/antiair_tracers", Vector( 4025, -14265, 227 ), 2, 4, 9.2, 4.4, 1.2, 4.5 },
		{ "atmosphere/antiair_tracers", Vector( -4932, -16709, 300 ), 2, 3, 5.1, 6.4, 2.1, 5.3 },
		{ "atmosphere/antiair_tracers", Vector( 687, -13553, 144 ), 2, 3, 5.1, 6.4, 2.1, 5.3 },
		{ "atmosphere/longrangeflash_altocloud", Vector( -4287, -16109, 137 ), 1, 2, 10, 60, 10, 40 },
		{ "atmosphere/longrangeflash_altocloud", Vector( 2170, -12886, 137 ), 1, 2, 10, 60, 5, 40 },
		{ "atmosphere/longrangeflash_altocloud", Vector( 385, -13049, 377 ), 1, 2, 10, 60, 5, 40 },
		{ "atmosphere/flash2flak", Vector( -1156, -13252, 2694 ), 4, 8, 2.5, 3.6, 5, 20 },
		{ "atmosphere/flash2flak2", Vector( -3470, -13920, 2400 ), 3, 6, 0.2, 1.5, 5, 10 },
		{ "atmosphere/flash2flak2", Vector( 762, -16389, 4543 ), 3, 6, 0.2, 1.5, 5, 20 },
		{ "atmosphere/distant88s", Vector( 5711, -19112, 700 ), 4, 10, 10, 30, 15, 40 },
		{ "atmosphere/distant88s", Vector( 5025, -14529, 900 ), 3, 8, 10, 30, 15, 40 },
		{ "atmosphere/distant88s", Vector( -4105, -14695, 600 ), 3, 8, 10, 30, 15, 40 },
		{ "atmosphere/distant88s", Vector( -3932, -16709, 700 ), 3, 8, 10, 30, 15, 40 },
		{ "atmosphere/lowlevelburst", Vector( -4932, -14709, 3100 ), 3, 8, 1, 3, 1, 4 },
		{ "atmosphere/lowlevelburst", Vector( -2335, -14149, 1394 ), 3, 8, 1, 3, 1, 4 },
		{ "atmosphere/lowlevelburst", Vector( 444, -13344, 741 ), 3, 8, 0.1, 3, 1, 2 },
	},
	shots = {
		{ "atmosphere/shootdrop1", Vector( 5414, -15694, 4591 ), 35 },
		{ "atmosphere/shootdrop1", Vector( 593, -13829, 2644 ), 60 },
		{ "atmosphere/shootdrop1", Vector( -1936, -22324, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -2367, -14847, 2748 ), 90 },
		{ "atmosphere/shootdrop1", Vector( 5382, -15700, 2639 ), 180 },
		{ "atmosphere/c47flyover2d", Vector( 794, -23852, 827 ), 3 },
		{ "atmosphere/c47flyover2d", Vector( -2110, -21943, 447 ), 21 },
		{ "atmosphere/c47flyover2d", Vector( 3851, -19836, 584 ), 31 },
		{ "atmosphere/c47flyover2d", Vector( 5414, -15694, 4591 ), 180 },
		{ "atmosphere/c47flyover2d", Vector( 794, -23852, 827 ), 280 },
		{ "atmosphere/shootdrop1", Vector( -1912, -21092, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -3312, -20564, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -4528, -19932, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -5064, -17492, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -4320, -14636, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -3240, -15356, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -1440, -12236, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 672, -11076, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -88, -12876, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 3192, -12340, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 4512, -13124, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 4312, -14660, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 4968, -16940, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 4368, -17972, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 5008, -19084, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 5728, -21180, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 5064, -23156, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 3328, -25332, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -248, -25652, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -1352, -24532, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 1968, -25580, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -4192, -22388, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( -4328, -13028, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 2464, -10564, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 4968, -11444, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 5920, -13180, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 6616, -17332, 2727 ), 25 },
		{ "atmosphere/shootdrop1", Vector( 6680, -19268, 2727 ), 25 },
	},
}

local FIRE_SOUND = { medfire = 0.5, bigfire = 0.8 }
local FAR = 5000

local function startFX()
	local m = COD1.MapFX[ game.GetMap() ]
	if not m or not COD1.PlayEFX then return end
	local now = CurTime()
	local loops, guns, shots = {}, {}, {}
	for _, l in ipairs( m.loops ) do loops[ #loops + 1 ] = { l[ 1 ], l[ 2 ] + m.off, l[ 3 ], now + math.Rand( 0, l[ 3 ] ) } end
	for _, g in ipairs( m.guns ) do guns[ #guns + 1 ] = { fx = g[ 1 ], pos = g[ 2 ] + m.off, g = g, left = 0, at = now + math.Rand( 0, 3 ) } end
	local cycleStart = now
	for i, s in ipairs( m.shots ) do shots[ i ] = { s[ 1 ], s[ 2 ] + m.off, s[ 3 ], false, math.Rand( 0, 12 ) } end
	for _, s in ipairs( m.sounds ) do
		sound.PlayFile( "sound/cod1/cine/fire_loop.wav", "3d noplay noblock", function( ch )
			if not IsValid( ch ) then return end
			ch:SetPos( s[ 2 ] + m.off )
			ch:Set3DFadeDistance( 150, 1000 )
			ch:SetVolume( FIRE_SOUND[ s[ 1 ] ] or 0.5 )
			ch:EnableLooping( true )
			ch:Play()
			COD1.MapFXSounds = COD1.MapFXSounds or {}
			table.insert( COD1.MapFXSounds, ch )
		end )
	end
	hook.Add( "Think", "COD1MapFX", function()
		local t = CurTime()
		local eye = EyePos()
		for _, l in ipairs( loops ) do
			if t >= l[ 4 ] then
				l[ 4 ] = t + l[ 3 ]
				if eye:DistToSqr( l[ 2 ] ) < FAR * FAR then COD1.PlayEFX( l[ 1 ], l[ 2 ] ) end
			end
		end
		for _, g in ipairs( guns ) do
			if t >= g.at then
				local p = g.g
				if g.left <= 0 then g.left = p[ 3 ] + math.random( 0, math.max( 0, p[ 4 ] - p[ 3 ] - 1 ) ) end
				COD1.PlayEFX( g.fx, g.pos )
				g.left = g.left - 1
				if g.left > 0 then
					g.at = t + p[ 7 ] + math.Rand( 0, p[ 8 ] - p[ 7 ] )
				else
					g.at = t + p[ 5 ] + math.Rand( 0, p[ 6 ] - p[ 5 ] )
				end
			end
		end
		if t - cycleStart >= m.cycle then
			cycleStart = t
			for _, s in ipairs( shots ) do s[ 4 ] = false s[ 5 ] = math.Rand( 0, 12 ) end
		end
		for _, s in ipairs( shots ) do
			if not s[ 4 ] and t - cycleStart >= s[ 3 ] + s[ 5 ] then
				s[ 4 ] = true
				COD1.PlayEFX( s[ 1 ], s[ 2 ] )
				if s[ 1 ] == "atmosphere/c47flyover2d" then
					sound.Play( "cod1/vehicles/c47_flyby0" .. math.random( 1, 2 ) .. ".wav", eye + ( s[ 2 ] - eye ):GetNormalized() * 600, 90, 100, 0.8 )
				end
			end
		end
	end )
end

hook.Add( "InitPostEntity", "COD1MapFX", startFX )

--map stuff, ambience and all that
