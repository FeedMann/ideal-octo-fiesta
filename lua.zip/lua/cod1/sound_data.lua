COD1 = COD1 or {}

sound.Add( { name = "COD1.Fire.thompson", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/thompson/thompson_01.wav" } } )
sound.Add( { name = "COD1.Fire.garand", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/m1garand/m1garand_01.wav" } } )
sound.Add( { name = "COD1.Fire.carbine", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/m1carbine/m1carbine_01.wav" } } )
sound.Add( { name = "COD1.Fire.bar", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/bar/bar_01.wav" } } )
sound.Add( { name = "COD1.GarandPing", channel = CHAN_ITEM, level = 85, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/m1garand/m1garand_ping01.wav" } } )
sound.Add( { name = "COD1.Reload.thompson", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/thompson/thompson_reload.wav" } } )
sound.Add( { name = "COD1.Reload.garand", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/m1garand/m1garand_reload.wav" } } )
sound.Add( { name = "COD1.Reload.carbine", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/m1carbine/m1carbine_reload.wav" } } )
sound.Add( { name = "COD1.Reload.bar", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/bar/bar_reload.wav" } } )
sound.Add( { name = "COD1.GrenadePin", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/grenade/us_grenade_pin.wav" } } )
sound.Add( { name = "COD1.Fire.kar98", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/kar98k/kar98_01.wav" } } )
sound.Add( { name = "COD1.Fire.mp40", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/mp40/mp40_01.wav" } } )
sound.Add( { name = "COD1.Fire.mp44", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/mp44/mp44_01.wav" } } )
sound.Add( { name = "COD1.Fire.fg42", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/fg42/fg42_01_temp.wav" } } )
sound.Add( { name = "COD1.Reload.kar98", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_reload.wav" } } )
sound.Add( { name = "COD1.Reload.mp40", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/mp40/mp40_reload.wav" } } )
sound.Add( { name = "COD1.Reload.mp44", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/mp44/mp44_reload.wav" } } )
sound.Add( { name = "COD1.Reload.fg42", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/fg42/fg42_reload.wav" } } )
sound.Add( { name = "COD1.Rechamber.kar98", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_rechamber.wav" } } )
sound.Add( { name = "COD1.Fire.enfield", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/enfield/enfield_01.wav" } } )
sound.Add( { name = "COD1.Fire.sten", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/sten/sten_01.wav" } } )
sound.Add( { name = "COD1.Fire.bren", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/bren/bren_01.wav" } } )
sound.Add( { name = "COD1.Fire.mosin", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/nagant/nagant_01.wav" } } )
sound.Add( { name = "COD1.Fire.ppsh", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/ppsh/ppsh_01.wav" } } )
sound.Add( { name = "COD1.Reload.enfield", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/null.wav" } } )
sound.Add( { name = "COD1.Reload.sten", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/sten/sten_reload.wav" } } )
sound.Add( { name = "COD1.Reload.bren", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/bren/bren_reload.wav" } } )
sound.Add( { name = "COD1.Reload.mosin", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_reload.wav" } } )
sound.Add( { name = "COD1.Reload.ppsh", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/ppsh/ppsh_reload.wav" } } )
sound.Add( { name = "COD1.Rechamber.enfield", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_rechamber.wav" } } )
sound.Add( { name = "COD1.Rechamber.mosin", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_rechamber.wav" } } )
sound.Add( { name = "COD1.C47Flyby", channel = CHAN_AUTO, level = 150, volume = 1, pitch = { 90, 110 }, sound = { "cod1/vehicles/c47_flyby01.wav", "cod1/vehicles/c47_flyby02.wav", "cod1/vehicles/c47_flyby03.wav", "cod1/vehicles/c47_flyby04.wav" } } )
sound.Add( { name = "COD1.GrenadeThrow", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/grenade/us_grenade_throw.wav" } } )
sound.Add( { name = "COD1.GrenadeBounce", channel = CHAN_BODY, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/grenade/grenade_bounce_stone01.wav", "cod1/weapons/grenade/grenade_bounce_stone02.wav", "cod1/weapons/grenade/grenade_bounce_stone03.wav", "cod1/weapons/grenade/grenade_bounce_stone04.wav", "cod1/weapons/grenade/grenade_bounce_stone05.wav" } } )
sound.Add( { name = "COD1.GrenadeExplode", channel = CHAN_AUTO, level = 140, volume = 1, pitch = { 80, 120 }, sound = { "cod1/explosions/grenade_explo01.wav", "cod1/explosions/grenade_explo02.wav", "cod1/explosions/grenade_explo03.wav" } } )
sound.Add( { name = "COD1.MeleeSwish", channel = CHAN_AUTO, level = 70, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/melee/melee_swing03.wav", "cod1/weapons/melee/melee_swing01.wav" } } )
sound.Add( { name = "COD1.MeleeHit", channel = CHAN_AUTO, level = 75, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/melee/melee_hit01.wav", "cod1/weapons/melee/melee_hit02.wav" } } )
sound.Add( { name = "COD1.Whizby", channel = CHAN_AUTO, level = 70, volume = 1, pitch = { 80, 110 }, sound = { "cod1/whizbys/whizby02.wav", "cod1/whizbys/whizby03.wav", "cod1/whizbys/whizby04.wav", "cod1/whizbys/whizby05.wav", "cod1/whizbys/whizby06.wav", "cod1/whizbys/whizby07.wav", "cod1/whizbys/whizby08.wav", "cod1/whizbys/whizby09.wav", "cod1/whizbys/whizby10.wav", "cod1/whizbys/whizby11.wav", "cod1/whizbys/whizby12.wav", "cod1/whizbys/whizby13.wav", "cod1/whizbys/whizby14.wav", "cod1/whizbys/whizby15.wav", "cod1/whizbys/whizby01.wav", "cod1/null.wav" } } )
sound.Add( { name = "COD1.ImpactFlesh", channel = CHAN_AUTO, level = 75, volume = 1, pitch = { 90, 110 }, sound = { "cod1/weapons/impact/impact_flesh_01.wav", "cod1/weapons/impact/impact_flesh_02.wav", "cod1/weapons/impact/impact_flesh_03.wav", "cod1/weapons/impact/bullet_flesh_mega.wav", "cod1/weapons/impact/bullet_flesh09.wav", "cod1/weapons/impact/impact_flesh_06.wav", "cod1/weapons/impact/bullet_flesh04.wav", "cod1/weapons/impact/bullet_flesh02.wav", "cod1/weapons/impact/impact_flesh_16.wav", "cod1/weapons/impact/impact_flesh_10.wav" } } )
sound.Add( { name = "COD1.ParaLand", channel = CHAN_BODY, level = 80, volume = 1, pitch = { 90, 105 }, sound = { "cod1/misc/para_land_player.wav" } } )
sound.Add( { name = "COD1.Fire.luger", channel = CHAN_WEAPON, level = 130, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/luger/luger_01.wav" } } )
sound.Add( { name = "COD1.Reload.luger", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/luger/luger_reload.wav" } } )
sound.Add( { name = "COD1.Fire.colt", channel = CHAN_WEAPON, level = 130, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/colt/colt45_01.wav" } } )
sound.Add( { name = "COD1.Reload.colt", channel = CHAN_ITEM, level = 70, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/colt/colt45_reload.wav" } } )
sound.Add( { name = "COD1.ImpactFleshSmall", channel = CHAN_AUTO, level = 75, volume = 1, pitch = { 90, 110 }, sound = { "cod1/weapons/impact/impact_flesh_02.wav", "cod1/weapons/impact/impact_flesh_03.wav", "cod1/weapons/impact/bullet_flesh_mega.wav", "cod1/weapons/impact/bullet_flesh09.wav", "cod1/weapons/impact/impact_flesh_06.wav", "cod1/weapons/impact/bullet_flesh04.wav", "cod1/weapons/impact/impact_flesh_01.wav", "cod1/weapons/impact/impact_flesh_10.wav" } } )
sound.Add( { name = "COD1.melee_hit", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/melee/melee_hit01.wav", "cod1/weapons/melee/melee_hit02.wav" } } )
sound.Add( { name = "COD1.melee_swing_large", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/melee/melee_swing03.wav", "cod1/weapons/melee/melee_swing01.wav" } } )
sound.Add( { name = "COD1.weap_bar_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/bar/bar_01.wav" } } )
sound.Add( { name = "COD1.weap_bar_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/bar/bar_reload.wav" } } )
sound.Add( { name = "COD1.weap_bar_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/bar/bar_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_bren_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/bren/bren_01.wav" } } )
sound.Add( { name = "COD1.weap_bren_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/bren/bren_reload.wav" } } )
sound.Add( { name = "COD1.weap_bren_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/bren/bren_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_colt_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/colt/colt45_01.wav" } } )
sound.Add( { name = "COD1.weap_colt_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/colt/colt45_reload.wav" } } )
sound.Add( { name = "COD1.weap_colt_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/colt/colt45_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_enfield_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/enfield/enfield_01.wav" } } )
sound.Add( { name = "COD1.weap_enfield_rechamber", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_rechamber.wav" } } )
sound.Add( { name = "COD1.weap_enfield_reload_end", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/enfield/enfield_reload_end.wav" } } )
sound.Add( { name = "COD1.weap_enfield_reload_loop", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 90, 110 }, sound = { "cod1/weapons/enfield/enfield_reload_loop.wav" } } )
sound.Add( { name = "COD1.weap_enfield_reload_start", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/enfield/enfield_reload_start.wav" } } )
sound.Add( { name = "COD1.weap_fg42_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/fg42/fg42_01_temp.wav" } } )
sound.Add( { name = "COD1.weap_fg42_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/fg42/fg42_reload.wav" } } )
sound.Add( { name = "COD1.weap_fg42_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/fg42/fg42_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_kar98k_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/kar98k/kar98_01.wav" } } )
sound.Add( { name = "COD1.weap_kar98k_rechamber", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_rechamber.wav" } } )
sound.Add( { name = "COD1.weap_kar98k_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_reload.wav" } } )
sound.Add( { name = "COD1.weap_kar98k_sniper_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/kar98k/kar98_sniper.wav" } } )
sound.Add( { name = "COD1.weap_kar98k_sniper_rechamber", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_rechamber.wav" } } )
sound.Add( { name = "COD1.weap_kar98k_sniper_reload_end", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_reload_end.wav" } } )
sound.Add( { name = "COD1.weap_kar98k_sniper_reload_loop", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 90, 110 }, sound = { "cod1/weapons/kar98k/kar98_reload_loop.wav" } } )
sound.Add( { name = "COD1.weap_kar98k_sniper_reload_start", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_reload_start.wav" } } )
sound.Add( { name = "COD1.weap_luger_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/luger/luger_01.wav" } } )
sound.Add( { name = "COD1.weap_luger_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/luger/luger_reload.wav" } } )
sound.Add( { name = "COD1.weap_luger_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/luger/luger_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_m1carbine_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/m1carbine/m1carbine_01.wav" } } )
sound.Add( { name = "COD1.weap_m1carbine_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/m1carbine/m1carbine_reload.wav" } } )
sound.Add( { name = "COD1.weap_m1carbine_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/m1carbine/m1carbine_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_m1garand_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/m1garand/m1garand_01.wav" } } )
sound.Add( { name = "COD1.weap_m1garand_lastshot", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/m1garand/m1garand_ping01.wav" } } )
sound.Add( { name = "COD1.weap_m1garand_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/m1garand/m1garand_reload.wav" } } )
sound.Add( { name = "COD1.weap_mp40_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/mp40/mp40_01.wav" } } )
sound.Add( { name = "COD1.weap_mp40_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/mp40/mp40_reload.wav" } } )
sound.Add( { name = "COD1.weap_mp40_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/mp40/mp40_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_mp44_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/mp44/mp44_01.wav" } } )
sound.Add( { name = "COD1.weap_mp44_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/mp44/mp44_reload.wav" } } )
sound.Add( { name = "COD1.weap_mp44_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/mp44/mp44_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_nagant_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/nagant/nagant_01.wav" } } )
sound.Add( { name = "COD1.weap_nagant_rechamber", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_rechamber.wav" } } )
sound.Add( { name = "COD1.weap_nagant_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_reload.wav" } } )
sound.Add( { name = "COD1.weap_nagant_sniper", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/nagant/nagant_sniper.wav" } } )
sound.Add( { name = "COD1.weap_pickup", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 90, 110 }, sound = { "cod1/misc/pu_weapon01.wav", "cod1/misc/pu_weapon03.wav", "cod1/misc/pu_weapon04.wav" } } )
sound.Add( { name = "COD1.weap_ppsh_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/ppsh/ppsh_01.wav" } } )
sound.Add( { name = "COD1.weap_ppsh_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/ppsh/ppsh_reload.wav" } } )
sound.Add( { name = "COD1.weap_ppsh_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/ppsh/ppsh_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_raise", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 90, 110 }, sound = { "cod1/misc/equip_rifle02.wav", "cod1/misc/pu_weapon01.wav", "cod1/misc/pu_weapon03.wav", "cod1/misc/pu_weapon04.wav" } } )
sound.Add( { name = "COD1.weap_springfield_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/springfield/springfield_01.wav" } } )
sound.Add( { name = "COD1.weap_springfield_rechamber", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_rechamber.wav" } } )
sound.Add( { name = "COD1.weap_springfield_reload_end", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/enfield/enfield_reload_end.wav" } } )
sound.Add( { name = "COD1.weap_springfield_reload_loop", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 90, 110 }, sound = { "cod1/weapons/kar98k/kar98_reload_loop.wav" } } )
sound.Add( { name = "COD1.weap_springfield_reload_start", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/kar98k/kar98_reload_start.wav" } } )
sound.Add( { name = "COD1.weap_sten_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/sten/sten_01.wav" } } )
sound.Add( { name = "COD1.weap_sten_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/sten/sten_reload.wav" } } )
sound.Add( { name = "COD1.weap_sten_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/sten/sten_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_thompson_altswitch", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/alt_fire_switch.wav" } } )
sound.Add( { name = "COD1.weap_thompson_fire", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 90, 105 }, sound = { "cod1/weapons/thompson/thompson_01.wav" } } )
sound.Add( { name = "COD1.weap_thompson_reload", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/thompson/thompson_reload.wav" } } )
sound.Add( { name = "COD1.weap_thompson_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 100, 100 }, sound = { "cod1/weapons/thompson/thompson_reload_not_empty.wav" } } )

COD1.Voices = {
	american = {
		[1] = {
			coverme = { "cod1/voiceovers/generic/allies/am/gr/eldercoverme_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldercoverme_02.wav" },
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/am/gr/elderatwill_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderatwill_02.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/am/gr/eldersighted_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_02.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_03.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_04.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_05.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_06.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_07.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_08.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_09.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_10.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_11.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_12.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_13.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_14.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_15.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/am/gr/elderflankleft_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderflankthem01.wav", "cod1/voiceovers/generic/allies/am/gr/elderleftflank_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderleftflank_02.wav" },
			flankright = { "cod1/voiceovers/generic/allies/am/gr/elderflankright_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderflankright_02.wav", "cod1/voiceovers/generic/allies/am/gr/elderflankthem02.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/am/qf/qf_avoid_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_02.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_04.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_05.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_06.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_07.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_08.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_09.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/am/gr/eldergreetloud_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldergreetloud_02.wav", "cod1/voiceovers/generic/allies/am/gr/eldergreetloud_03.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/am/gr/eldergreetsoft_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldergreetsoft_02.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/am/qf/qf_grenatk_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_grenatk_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/am/qf/qf_grendng_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_grendng_02.wav", "cod1/voiceovers/generic/allies/am/qf/qf_grendng_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_grendng_04.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/gr/elderexert_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_02.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_03.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_04.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_05.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_06.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/gr/eldercharge_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldercharge_02.wav", "cod1/voiceovers/generic/allies/am/gr/eldercharge_03.wav", "cod1/voiceovers/generic/allies/am/gr/eldercharge_04.wav", "cod1/voiceovers/generic/allies/am/gr/eldercharge_05.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/am/gr/eldercoverme_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldercoverme_02.wav", "cod1/voiceovers/generic/allies/am/gr/eldergogogo_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldermovein01.wav", "cod1/voiceovers/generic/allies/am/gr/eldermovein02.wav", "cod1/voiceovers/generic/allies/am/gr/eldermoveit_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldermoveit_02.wav" },
			pain = { "cod1/allied/pain01.wav", "cod1/allied/pain02.wav", "cod1/allied/pain03.wav", "cod1/allied/pain04.wav", "cod1/allied/pain05.wav", "cod1/allied/pain06.wav", "cod1/allied/pain07.wav", "cod1/allied/pain08.wav", "cod1/allied/pain09.wav", "cod1/allied/pain10.wav", "cod1/allied/pain11.wav", "cod1/allied/pain12.wav", "cod1/allied/pain13.wav", "cod1/allied/pain14.wav", "cod1/allied/pain15.wav", "cod1/allied/pain16.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/am/gr/elderstaylow_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderstaylow_02.wav" },
		},
		[2] = {
			coverme = { "cod1/voiceovers/generic/allies/am/mg/mg_combat_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_15.wav" },
			death = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/am/mg/mg_suppfire_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_keepfire_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_keepshoot_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_openfire_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_fire_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_covfire_01.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/am/mg/mg_sighted_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_sighted_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_sighted_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_sighted_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_sighted_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_sighted_06.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/am/mg/mg_combat_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_12.wav" },
			flankright = { "cod1/voiceovers/generic/allies/am/mg/mg_combat_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_13.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/am/mg/mg_avoid_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_08.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/am/mg/mg_greetloud_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_greetloud_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_greetloud_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_greetloud_04.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/am/mg/mg_greetsoft_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_greetsoft_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_greetsoft_01.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_grenatk_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_grenatk_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/am/mg/mg_grendng_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_grendng_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_grendng_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_grendng_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_grendng_05.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/mg/mg_charge_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_charge_02.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/am/mg/mg_combat_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_10.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_11.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_14.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_15.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/am/mg/mg_undsup_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_undsup_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_undsup_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_undsup_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_undsup_05.wav" },
		},
		[3] = {
			coverme = { "cod1/voiceovers/generic/allies/am/gr/eldercoverme_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldercoverme_02.wav" },
			death = { "cod1/voiceovers/generic/allies/am/as/as_exert_01.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_03.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_08.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/am/as/as_supp_01.wav", "cod1/voiceovers/generic/allies/am/as/as_supp_02.wav", "cod1/voiceovers/generic/allies/am/as/as_supp_03.wav", "cod1/voiceovers/generic/allies/am/as/as_supp_04.wav", "cod1/voiceovers/generic/allies/am/as/as_supp_05.wav", "cod1/voiceovers/generic/allies/am/as/as_supp_06.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/am/qf/qf_avoid_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_02.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_04.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_05.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_06.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_07.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_08.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_09.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_02.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_04.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_05.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_06.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_07.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_08.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_02.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_04.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_05.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/am/as/as_grenatk_01.wav", "cod1/voiceovers/generic/allies/am/as/as_grenatk_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/am/as/as_grendng_01.wav", "cod1/voiceovers/generic/allies/am/as/as_grendng_02.wav", "cod1/voiceovers/generic/allies/am/as/as_grendng_03.wav", "cod1/voiceovers/generic/allies/am/as/as_grendng_04.wav", "cod1/voiceovers/generic/allies/am/as/as_grendng_05.wav", "cod1/voiceovers/generic/allies/am/as/as_grendng_06.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/as/as_exert_01.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_06.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_09.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/as/as_exert_02.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_05.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_07.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/am/as/as_supp_02.wav", "cod1/voiceovers/generic/allies/am/as/as_undsup_02.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/as/as_exert_04.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_06.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_08.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_09.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/am/as/as_undsup_01.wav", "cod1/voiceovers/generic/allies/am/as/as_undsup_02.wav", "cod1/voiceovers/generic/allies/am/as/as_undsup_03.wav", "cod1/voiceovers/generic/allies/am/as/as_undsup_04.wav", "cod1/voiceovers/generic/allies/am/as/as_undsup_05.wav" },
		},
		[4] = {
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/am/jp/jp_supp_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_supp_02.wav", "cod1/voiceovers/generic/allies/am/jp/jp_supp_03.wav", "cod1/voiceovers/generic/allies/am/jp/jp_supp_04.wav", "cod1/voiceovers/generic/allies/am/jp/jp_supp_05.wav", "cod1/voiceovers/generic/allies/am/jp/jp_supp_06.wav" },
			enemykilled = { "cod1/voiceovers/generic/allies/am/nj/nj_combat_04.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/am/jp/jp_avoid_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_avoid_02.wav", "cod1/voiceovers/generic/allies/am/jp/jp_avoid_03.wav", "cod1/voiceovers/generic/allies/am/jp/jp_avoid_04.wav", "cod1/voiceovers/generic/allies/am/jp/jp_avoid_05.wav", "cod1/voiceovers/generic/allies/am/jp/jp_avoid_06.wav", "cod1/voiceovers/generic/allies/am/jp/jp_avoid_07.wav", "cod1/voiceovers/generic/allies/am/jp/jp_avoid_08.wav", "cod1/voiceovers/generic/allies/am/jp/jp_avoid_09.wav", "cod1/voiceovers/generic/allies/am/jp/jp_avoid_10.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/am/jp/jp_grenatk_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_grenatk_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/am/jp/jp_grendng_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_grendng_02.wav", "cod1/voiceovers/generic/allies/am/jp/jp_grendng_03.wav", "cod1/voiceovers/generic/allies/am/jp/jp_grendng_04.wav", "cod1/voiceovers/generic/allies/am/jp/jp_grendng_05.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/jp/jp_exert_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_02.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_03.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_04.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_05.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/jp/jp_charge_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_charge_02.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/am/jp/jp_combat_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_combat_02.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/jp/jp_exert_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_02.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_03.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_04.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_05.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/am/jp/jp_undsup_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_undsup_02.wav", "cod1/voiceovers/generic/allies/am/jp/jp_undsup_03a.wav", "cod1/voiceovers/generic/allies/am/jp/jp_undsup_03b.wav", "cod1/voiceovers/generic/allies/am/jp/jp_undsup_04.wav", "cod1/voiceovers/generic/allies/am/jp/jp_undsup_05.wav" },
		},
		[5] = {
			coverme = { "cod1/voiceovers/generic/allies/am/nj/nj_combat_04.wav" },
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/am/nj/nj_supp_01.wav", "cod1/voiceovers/generic/allies/am/nj/nj_supp_02.wav", "cod1/voiceovers/generic/allies/am/nj/nj_supp_03.wav", "cod1/voiceovers/generic/allies/am/nj/nj_supp_04.wav", "cod1/voiceovers/generic/allies/am/nj/nj_supp_05.wav", "cod1/voiceovers/generic/allies/am/nj/nj_supp_06.wav", "cod1/voiceovers/generic/allies/am/nj/nj_supp_07.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/am/nj/nj_combat_03.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_06.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_12.wav" },
			flankright = { "cod1/voiceovers/generic/allies/am/nj/nj_combat_03.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_07.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_13.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/am/mg/mg_avoid_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_avoid_08.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/am/nj/nj_greetloud_01.wav", "cod1/voiceovers/generic/allies/am/nj/nj_greetloud_02.wav", "cod1/voiceovers/generic/allies/am/nj/nj_greetloud_03.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/am/nj/nj_greetsoft_01.wav", "cod1/voiceovers/generic/allies/am/nj/nj_greetsoft_02.wav", "cod1/voiceovers/generic/allies/am/nj/nj_greetsoft_03.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/am/nj/nj_grenatk_01.wav", "cod1/voiceovers/generic/allies/am/nj/nj_grenatk_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/am/nj/nj_grendng_01.wav", "cod1/voiceovers/generic/allies/am/nj/nj_grendng_02.wav", "cod1/voiceovers/generic/allies/am/nj/nj_grendng_03.wav", "cod1/voiceovers/generic/allies/am/nj/nj_grendng_04.wav", "cod1/voiceovers/generic/allies/am/nj/nj_grendng_05.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/mg/mg_charge_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_charge_02.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/am/nj/nj_combat_01.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_02.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_04.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_08.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_09.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_10.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_11.wav", "cod1/voiceovers/generic/allies/am/nj/nj_combat_14.wav" },
			pain = { "cod1/allied/pain01.wav", "cod1/allied/pain02.wav", "cod1/allied/pain03.wav", "cod1/allied/pain04.wav", "cod1/allied/pain05.wav", "cod1/allied/pain06.wav", "cod1/allied/pain07.wav", "cod1/allied/pain08.wav", "cod1/allied/pain09.wav", "cod1/allied/pain10.wav", "cod1/allied/pain11.wav", "cod1/allied/pain12.wav", "cod1/allied/pain13.wav", "cod1/allied/pain14.wav", "cod1/allied/pain15.wav", "cod1/allied/pain16.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/am/nj/nj_undsup_01.wav", "cod1/voiceovers/generic/allies/am/nj/nj_undsup_02.wav", "cod1/voiceovers/generic/allies/am/nj/nj_undsup_03.wav", "cod1/voiceovers/generic/allies/am/nj/nj_undsup_04.wav", "cod1/voiceovers/generic/allies/am/nj/nj_undsup_05.wav" },
		},
		[6] = {
			coverme = { "cod1/voiceovers/generic/allies/am/mg/mg_combat_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_combat_15.wav" },
			death = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/am/gr/elderatwill_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderatwill_02.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/am/qf/qf_sighted_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_sighted_02a.wav", "cod1/voiceovers/generic/allies/am/qf/qf_sighted_02b.wav", "cod1/voiceovers/generic/allies/am/qf/qf_sighted_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_sighted_04.wav", "cod1/voiceovers/generic/allies/am/qf/qf_sighted_05.wav", "cod1/voiceovers/generic/allies/am/qf/qf_sighted_06.wav", "cod1/voiceovers/generic/allies/am/qf/qf_sighted_07a.wav", "cod1/voiceovers/generic/allies/am/qf/qf_sighted_07b.wav", "cod1/voiceovers/generic/allies/am/qf/qf_sighted_08.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/am/gr/elderflankleft_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderflankthem01.wav", "cod1/voiceovers/generic/allies/am/gr/elderleftflank_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderleftflank_02.wav" },
			flankright = { "cod1/voiceovers/generic/allies/am/gr/elderflankright_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderflankright_02.wav", "cod1/voiceovers/generic/allies/am/gr/elderflankthem02.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/am/qf/qf_avoid_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_02.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_04.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_05.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_06.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_07.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_08.wav", "cod1/voiceovers/generic/allies/am/qf/qf_avoid_09.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_02.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_04.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_05.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_06.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_07.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetloud_08.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_02.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_04.wav", "cod1/voiceovers/generic/allies/am/qf/qf_greetsoft_05.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/am/qf/qf_grenatk_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_grenatk_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/am/qf/qf_grendng_01.wav", "cod1/voiceovers/generic/allies/am/qf/qf_grendng_02.wav", "cod1/voiceovers/generic/allies/am/qf/qf_grendng_03.wav", "cod1/voiceovers/generic/allies/am/qf/qf_grendng_04.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/mg/mg_charge_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_charge_02.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/am/gr/eldercoverme_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldercoverme_02.wav", "cod1/voiceovers/generic/allies/am/gr/eldergogogo_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldermovein01.wav", "cod1/voiceovers/generic/allies/am/gr/eldermovein02.wav", "cod1/voiceovers/generic/allies/am/gr/eldermoveit_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldermoveit_02.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/am/gr/elderstaylow_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderstaylow_02.wav" },
		},
		[7] = {
			death = { "cod1/voiceovers/generic/allies/am/ga/ga_exert_02.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_03.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_04.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_05.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_06.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/am/ga/ga_avoid_01.wav", "cod1/voiceovers/generic/allies/am/ga/ga_avoid_02.wav", "cod1/voiceovers/generic/allies/am/ga/ga_avoid_03.wav", "cod1/voiceovers/generic/allies/am/ga/ga_avoid_04.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/ga/ga_exert_01.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_02.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_03.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_04.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_05.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_06.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/ga/ga_charge.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/ga/ga_exert_02.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_03.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_04.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_05.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_06.wav" },
		},
	},
	german = {
		[1] = {
			coverme = { "cod1/voiceovers/generic/axis/a/ba_ger_a_04_coverme.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_10_now.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_12_move.wav" },
			death = { "cod1/voiceovers/generic/axis/a/death_aargh_g_001.wav", "cod1/voiceovers/generic/axis/a/death_aargh_g_003.wav", "cod1/voiceovers/generic/axis/c/german2_line_119.wav", "cod1/voiceovers/generic/axis/c/german2_line_120.wav", "cod1/voiceovers/generic/axis/c/die01.wav", "cod1/voiceovers/generic/axis/c/die02.wav" },
			doingsuppression = { "cod1/voiceovers/generic/axis/a/ds_ger_a_001alt_suppressingfire.wav", "cod1/voiceovers/generic/axis/a/ds_ger_a_002_coveringfire.wav", "cod1/voiceovers/generic/axis/a/ds_ger_a_002alt_coveringfire.wav", "cod1/voiceovers/generic/axis/a/ds_ger_a_003_fire.wav", "cod1/voiceovers/generic/axis/a/ds_ger_a_003alt_fire.wav", "cod1/voiceovers/generic/axis/a/ds_ger_a_004_openfire.wav", "cod1/voiceovers/generic/axis/a/ds_ger_a_004alt_openfire.wav", "cod1/voiceovers/generic/axis/a/ds_ger_a_005_hideyoucowards.wav", "cod1/voiceovers/generic/axis/a/ds_ger_a_005alt_hideyoucowards.wav" },
			enemykilled = { "cod1/voiceovers/generic/axis/a/ek_ger_a_001_gotone.wav", "cod1/voiceovers/generic/axis/a/ek_ger_a_002_onedown.wav", "cod1/voiceovers/generic/axis/a/ek_ger_a_003_killem.wav", "cod1/voiceovers/generic/axis/a/ek_ger_a_004_keepshootinggusto.wav" },
			enemysighted = { "cod1/voiceovers/generic/axis/a/es_ger_a_002alt_amerikaner.wav", "cod1/voiceovers/generic/axis/a/es_ger_a_005alt_theretheyare.wav", "cod1/voiceovers/generic/axis/a/es_ger_a_006alt_itsthem.wav", "cod1/voiceovers/generic/axis/a/es_ger_a_007alt_attack.wav", "cod1/voiceovers/generic/axis/a/es_ger_a_008alt_headsup.wav", "cod1/voiceovers/generic/axis/a/es_ger_a_001_theenemy.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_1alt_dieamerikaner.wav" },
			flankleft = { "cod1/voiceovers/generic/axis/a/ba_ger_a_06_flankleft.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_03_flankthem.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_06alt2_flankleft.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_6alt_flankleft.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_12alt_leftflank.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_13alt2_leftflank.wav" },
			flankright = { "cod1/voiceovers/generic/axis/a/ba_ger_a_07_flankright.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_03_flankthem.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_07alt2_flankright.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_13alt_rightflank.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_14alt2_rightflank.wav" },
			grenadeattack = { "cod1/voiceovers/generic/axis/a/ga_ger_a_001_fireinthehole.wav", "cod1/voiceovers/generic/axis/a/ga_ger_a_002_throwinggrenade.wav" },
			grenadedanger = { "cod1/voiceovers/generic/axis/a/gd_ger_a_001_grenaderun.wav", "cod1/voiceovers/generic/axis/a/gd_ger_a_002_lookgrenade.wav", "cod1/voiceovers/generic/axis/a/gd_ger_a_004_enemygrenade.wav", "cod1/voiceovers/generic/axis/a/gd_ger_a_003alt_getdowngrenade.wav" },
			meleeattack = { "cod1/voiceovers/generic/axis/a/meleeattack_g_001.wav", "cod1/voiceovers/generic/axis/a/meleeattack_g_002.wav", "cod1/voiceovers/generic/axis/a/meleeattack_g_003.wav", "cod1/voiceovers/generic/axis/a/meleeattack_g_005.wav", "cod1/voiceovers/generic/axis/a/meleeattack_g_006.wav", "cod1/voiceovers/generic/axis/a/meleeattack_ger_e_001.wav", "cod1/voiceovers/generic/axis/a/meleeattack_ger_e_002.wav", "cod1/voiceovers/generic/axis/a/meleeattack_ger_e_003.wav", "cod1/voiceovers/generic/axis/a/meleeattack_ger_e_009.wav" },
			meleecharge = { "cod1/voiceovers/generic/axis/a/meleecharg_ger_stirb_b_001.wav", "cod1/voiceovers/generic/axis/a/meleecharg_ger_stirb_b_002.wav", "cod1/voiceovers/generic/axis/a/meleecharge_ger_die_e_002.wav", "cod1/voiceovers/generic/axis/a/meleecharge_ger_die_e_004.wav", "cod1/voiceovers/generic/axis/a/meleecharge_ger_stirb_d_04.wav" },
			misccombat = { "cod1/voiceovers/generic/axis/a/ba_ger_a_006_tactics.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_005_mg42team.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_002_tactics.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_001_letsgoletsgo.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_7alt_defensive.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_4alt_sendbackup.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_3alt_checkweps.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_2alt_tactics.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_1alt_letsgoletsgo.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_004_youstink.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_1alt_takecover.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_2alt_movein.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_4alt_coverme.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_7alt_fireatwill.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_8alt_fireoncommand.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_9alt_now.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_01_takecover.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_02_movein.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_05_fallback.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_08_fireatwill.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_09_fireoncommand.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_10_now.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_11_gogogo.wav", "cod1/voiceovers/generic/axis/a/ba_ger_a_12_move.wav" },
			pain = { "cod1/voiceovers/generic/axis/a/pain_german_e_006.wav", "cod1/voiceovers/generic/axis/a/pain_german_e_007.wav", "cod1/voiceovers/generic/axis/a/pain_german_e_008.wav" },
			undersuppression = { "cod1/voiceovers/generic/axis/a/uns_ger_a_001alt2_pinneddown.wav", "cod1/voiceovers/generic/axis/a/uns_ger_a_001alt_pinneddown.wav", "cod1/voiceovers/generic/axis/a/uns_ger_a_001_pinneddown.wav", "cod1/voiceovers/generic/axis/a/uns_ger_a_002_takecover.wav", "cod1/voiceovers/generic/axis/a/uns_ger_a_003_fallback.wav", "cod1/voiceovers/generic/axis/a/uns_ger_a_004_getdown.wav", "cod1/voiceovers/generic/axis/a/uns_ger_a_005_headdown.wav" },
		},
		[2] = {
			coverme = { "cod1/voiceovers/generic/axis/b/ba_ger_b_004alt2_coverme.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_011alt3_gogogo.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_012alt_move.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_004alt_coverme.wav" },
			death = { "cod1/voiceovers/generic/axis/c/german1_line_119.wav", "cod1/voiceovers/generic/axis/c/german1_line_120.wav", "cod1/voiceovers/generic/axis/c/german2_line_119.wav", "cod1/voiceovers/generic/axis/c/german2_line_120.wav", "cod1/voiceovers/generic/axis/c/die01.wav", "cod1/voiceovers/generic/axis/c/die02.wav" },
			doingsuppression = { "cod1/voiceovers/generic/axis/b/ds_ger_b_003alt2_fire.wav", "cod1/voiceovers/generic/axis/b/ds_ger_b_004alt_openfire.wav", "cod1/voiceovers/generic/axis/b/ds_ger_b_005alt2_hideyoucowards.wav", "cod1/voiceovers/generic/axis/b/ds_ger_b_005alt3_fire.wav", "cod1/voiceovers/generic/axis/b/ds_ger_b_001_suppressingfire.wav", "cod1/voiceovers/generic/axis/b/ds_ger_b_002alt_coveringfire.wav", "cod1/voiceovers/generic/axis/b/ds_ger_b_003alt_fire.wav", "cod1/voiceovers/generic/axis/b/ds_ger_b_005_hideyoucowards.wav", "cod1/voiceovers/generic/axis/b/ds_ger_b_005alt_hideyoucowards.wav" },
			enemykilled = { "cod1/voiceovers/generic/axis/b/ek_ger_b_001_alt_gotone.wav", "cod1/voiceovers/generic/axis/b/ek_ger_b_001_gotone.wav", "cod1/voiceovers/generic/axis/b/ek_ger_b_002_alt_onedown.wav", "cod1/voiceovers/generic/axis/b/ek_ger_b_002_alt3_onedown.wav", "cod1/voiceovers/generic/axis/b/ek_ger_b_002_onedown.wav", "cod1/voiceovers/generic/axis/b/ek_ger_b_003_alt3_killem.wav", "cod1/voiceovers/generic/axis/b/ek_ger_b_003_killem.wav", "cod1/voiceovers/generic/axis/b/ek_ger_b_003a_alt_keepshooting.wav", "cod1/voiceovers/generic/axis/b/ek_ger_b_003a_keepshooting.wav", "cod1/voiceovers/generic/axis/b/ek_ger_b_004a_keepshooting.wav" },
			enemysighted = { "cod1/voiceovers/generic/axis/b/es_ger_b_002 alt_amerikaner.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_002_amerikaner.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_008 alt2_enemysighted.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_006_alt_itsthem.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_005_itsthem.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_006_theenemy.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_001 alt_therestheenemy.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_008_headsup.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_007 alt_attack.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_002alt_dieami.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_002_dieamerikaner.wav" },
			flankleft = { "cod1/voiceovers/generic/axis/b/ba_ger_b_006alt2_flankleft.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_013alts_leftflank.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_006_flankleft.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_013_leftflank.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_013alt_leftflank.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_003alt_flankthem.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_003_flankthem.wav" },
			flankright = { "cod1/voiceovers/generic/axis/b/ba_ger_b_007alt2_flankright.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_007_flankright.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_007alt_flankright.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_014_rightflank.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_014alt_rightflank.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_003alt_flankthem.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_003_flankthem.wav" },
			grenadeattack = { "cod1/voiceovers/generic/axis/b/ga_ger_b_001 alt_fireinthehole.wav", "cod1/voiceovers/generic/axis/b/ga_ger_b_002 alt_throwinggrenade.wav", "cod1/voiceovers/generic/axis/b/ga_ger_b_001_fireinthehole.wav", "cod1/voiceovers/generic/axis/b/ga_ger_b_002_throwinggrenade.wav" },
			grenadedanger = { "cod1/voiceovers/generic/axis/b/gd_ger_b_001 alt_grenaderun.wav", "cod1/voiceovers/generic/axis/b/gd_ger_b_002 alt_lookgrenade.wav", "cod1/voiceovers/generic/axis/b/gd_ger_b_003 alt_getdowngrenade.wav", "cod1/voiceovers/generic/axis/b/gd_ger_b_004 alt_enemygrenade.wav", "cod1/voiceovers/generic/axis/b/gd_ger_b_001_grenaderun.wav", "cod1/voiceovers/generic/axis/b/gd_ger_b_002_lookgrenade.wav", "cod1/voiceovers/generic/axis/b/gd_ger_b_004_enemygrenade.wav" },
			meleeattack = { "cod1/voiceovers/generic/axis/b/meleeattack_ger_d_01.wav", "cod1/voiceovers/generic/axis/b/meleeattack_ger_d_02.wav", "cod1/voiceovers/generic/axis/b/meleeattack_ger_d_04.wav", "cod1/voiceovers/generic/axis/b/meleeattack_ger_b_001.wav", "cod1/voiceovers/generic/axis/b/meleeattack_ger_b_004.wav", "cod1/voiceovers/generic/axis/b/meleeattack_ger_b_006.wav", "cod1/voiceovers/generic/axis/b/meleeattack_ger_b_008.wav" },
			meleecharge = { "cod1/voiceovers/generic/axis/b/meleecharge_ger_stirb_d_04.wav", "cod1/voiceovers/generic/axis/a/meleecharg_ger_stirb_b_002.wav" },
			misccombat = { "cod1/voiceovers/generic/axis/b/ba_ger_b_004alt2_coverme.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_009alt2_fireoncommand.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_011alt2_gogogo.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_011alt3_gogogo.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_012alt2_move.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_001alt_takecover.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_002alt_movein.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_004alt_coverme.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_005_fallback.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_005alt_fallback.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_008_fireatwill.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_008alt_fireatwill.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_009_fireoncommand.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_009alt_fireoncommand.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_012alt_move.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_010alt_now.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_011_gogogo.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_011alt_gogogo.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_012_move.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_001_takecover.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_002_movein.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_004_coverme.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_004alt2_sendbackup.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_003alt_checkweps.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_005alt_mg42team.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_04alt_youguysstink.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_004_youguysstink.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_002_tactics.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_003_checkweps.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_005_mg42team.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_006_tactics.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_007_defensive.wav" },
			pain = { "cod1/voiceovers/generic/axis/b/pain_ger_b_002.wav", "cod1/voiceovers/generic/axis/b/pain_ger_b_003.wav", "cod1/voiceovers/generic/axis/b/pain_ger_b_007.wav", "cod1/voiceovers/generic/axis/b/pain_ger_b_010.wav", "cod1/voiceovers/generic/axis/b/pain_ger_b_013.wav" },
			undersuppression = { "cod1/voiceovers/generic/axis/b/uns_ger_b_001alt2_pinneddown.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_001alt3_pinneddown.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_002alt2_takecover.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_002alt3_takecover.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_003alt2_fallback.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_003alt3_fallback.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_003alt5_fallback.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_004alt_getdown.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_001_pinneddown.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_001alt_pinneddown.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_002_takecover.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_002alt_takecover.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_003_fallback.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_003alt_fallback.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_004_getdown.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_005_headdown.wav", "cod1/voiceovers/generic/axis/b/ga_ger_b_002_throwinggrenade.wav", "cod1/voiceovers/generic/axis/b/uns_ger_b_005alt_headdown.wav" },
		},
		[3] = {
			coverme = { "cod1/voiceovers/generic/axis/b/ba_ger_b_004alt2_coverme.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_011alt3_gogogo.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_012alt_move.wav", "cod1/voiceovers/generic/axis/b/ba_ger_b_004alt_coverme.wav" },
			death = { "cod1/voiceovers/generic/axis/c/german1_line_119.wav", "cod1/voiceovers/generic/axis/c/german1_line_120.wav", "cod1/voiceovers/generic/axis/c/german2_line_119.wav", "cod1/voiceovers/generic/axis/c/german2_line_120.wav", "cod1/voiceovers/generic/axis/c/die01.wav", "cod1/voiceovers/generic/axis/c/die02.wav" },
			doingsuppression = { "cod1/voiceovers/generic/axis/c/german1_line_99.wav", "cod1/voiceovers/generic/axis/c/german1_line_112.wav", "cod1/voiceovers/generic/axis/c/german1_line_113.wav", "cod1/voiceovers/generic/axis/c/german1_line_114.wav", "cod1/voiceovers/generic/axis/c/german1_line_106.wav", "cod1/voiceovers/generic/axis/c/german2_line_91.wav", "cod1/voiceovers/generic/axis/c/german2_line_99.wav", "cod1/voiceovers/generic/axis/c/german2_line_112.wav", "cod1/voiceovers/generic/axis/c/german2_line_106.wav" },
			enemykilled = { "cod1/voiceovers/generic/axis/c/german1_line_94.wav", "cod1/voiceovers/generic/axis/c/german1_line_95.wav", "cod1/voiceovers/generic/axis/c/german2_line_94.wav", "cod1/voiceovers/generic/axis/c/german2_line_95.wav" },
			enemysighted = { "cod1/voiceovers/generic/axis/c/german1_line_103.wav", "cod1/voiceovers/generic/axis/c/german1_line_87.wav", "cod1/voiceovers/generic/axis/c/german1_line_83.wav" },
			flankleft = { "cod1/voiceovers/generic/axis/c/german1_line_92.wav", "cod1/voiceovers/generic/axis/c/german1_line_107.wav", "cod1/voiceovers/generic/axis/c/german2_line_92.wav", "cod1/voiceovers/generic/axis/c/german2_line_107.wav" },
			flankright = { "cod1/voiceovers/generic/axis/c/german1_line_92.wav", "cod1/voiceovers/generic/axis/c/german1_line_108.wav", "cod1/voiceovers/generic/axis/c/german2_line_92.wav", "cod1/voiceovers/generic/axis/c/german2_line_108.wav" },
			grenadeattack = { "cod1/voiceovers/generic/axis/c/german1_line_88.wav", "cod1/voiceovers/generic/axis/c/german1_line_89.wav", "cod1/voiceovers/generic/axis/c/german1_line_116.wav", "cod1/voiceovers/generic/axis/c/german2_line_88.wav", "cod1/voiceovers/generic/axis/c/german2_line_89.wav", "cod1/voiceovers/generic/axis/c/german2_line_116.wav", "cod1/voiceovers/generic/axis/c/fireinhole.wav" },
			grenadedanger = { "cod1/voiceovers/generic/axis/c/german1_line_97.wav", "cod1/voiceovers/generic/axis/c/german1_line_90.wav", "cod1/voiceovers/generic/axis/c/german2_line_97.wav", "cod1/voiceovers/generic/axis/c/german2_line_90.wav" },
			meleeattack = { "cod1/voiceovers/generic/axis/c/pain02.wav", "cod1/voiceovers/generic/axis/c/german1_line_118.wav" },
			meleecharge = { "cod1/voiceovers/generic/axis/c/pain02.wav", "cod1/voiceovers/generic/axis/c/german1_line_112.wav" },
			misccombat = { "cod1/voiceovers/generic/axis/c/german1_line_91.wav", "cod1/voiceovers/generic/axis/c/german1_line_98.wav", "cod1/voiceovers/generic/axis/c/german1_line_101.wav", "cod1/voiceovers/generic/axis/c/german1_line_102.wav", "cod1/voiceovers/generic/axis/c/german1_line_103.wav", "cod1/voiceovers/generic/axis/c/german1_line_104.wav", "cod1/voiceovers/generic/axis/c/german1_line_105.wav", "cod1/voiceovers/generic/axis/c/german2_line_96.wav", "cod1/voiceovers/generic/axis/c/german2_line_98.wav", "cod1/voiceovers/generic/axis/c/german2_line_101.wav", "cod1/voiceovers/generic/axis/c/german2_line_102.wav", "cod1/voiceovers/generic/axis/c/german2_line_103b.wav", "cod1/voiceovers/generic/axis/c/german2_line_109.wav" },
			pain = { "cod1/voiceovers/generic/axis/c/german1_line_117.wav", "cod1/voiceovers/generic/axis/c/german1_line_118.wav", "cod1/voiceovers/generic/axis/c/german2_line_117.wav", "cod1/voiceovers/generic/axis/c/german2_line_118.wav", "cod1/voiceovers/generic/axis/c/pain02.wav" },
			undersuppression = { "cod1/voiceovers/generic/axis/c/german1_line_97.wav", "cod1/voiceovers/generic/axis/c/german1_line_100.wav", "cod1/voiceovers/generic/axis/c/german2_line_100.wav", "cod1/voiceovers/generic/axis/c/shorttaunt.wav" },
		},
	},
	british = {
		[1] = {
			coverme = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_05b.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_05a.wav" },
			death = { "cod1/voiceovers/generic/allies/am/ga/ga_exert_02.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_03.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_04.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_05.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_06.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_supp_01.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_supp_02.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_supp_03.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_supp_04.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_supp_05.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_supp_06.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_sighted_01.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_sighted_02.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_sighted_03.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_sighted_04.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_sighted_05.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_sighted_06.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_sighted_07.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_sighted_08.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_02.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_13.wav" },
			flankright = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_02.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_08.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_14.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_avoid_01.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_avoid_02.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_avoid_03.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_avoid_04.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_avoid_05.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_avoid_06.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_avoid_07.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_greetloud_01.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_greetsoft_01.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_greetsoft_02.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_greetsoft_03.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_grenatk_01.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_grenatk_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_grendng_01.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_grendng_02.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_grendng_03.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_grendng_04.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_grendng_05.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/ga/ga_exert_01.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_02.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_03.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_04.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_05.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_06.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/ga/ga_charge.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_01.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_04.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_07.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_09.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_11.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_12.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_15a.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_combat_15b.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/ga/ga_exert_02.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_03.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_04.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_05.wav", "cod1/voiceovers/generic/allies/am/ga/ga_exert_06.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/br/ga/ga_uk_undsup_01.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_undsup_02.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_undsup_03.wav", "cod1/voiceovers/generic/allies/br/ga/ga_uk_undsup_04.wav" },
		},
		[2] = {
			coverme = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_04.wav" },
			death = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_supp_01.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_supp_02.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_supp_03.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_supp_04.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_supp_05.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_supp_06.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_sighted_01.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_sighted_02.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_sighted_03.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_sighted_04.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_sighted_05.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_sighted_06.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_sighted_07.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_sighted_08.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_sighted_09.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_06.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_12.wav" },
			flankright = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_07.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_13.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_avoid_01.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_avoid_02.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_avoid_03.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_avoid_04.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_avoid_05.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_avoid_06.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_avoid_07.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_greetloud_01.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_greetsoft_01.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_grenatk_01.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_grenatk_02a.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_grenatk_02b.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_grendng_01.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_grendng_02.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_grendng_03.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_grendng_04.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/mg/mg_charge_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_charge_02.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_01.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_02.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_04.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_08.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_10.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_11.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_14.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_15.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_combat_16.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/br/mg/mg_uk_undsup_01.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_undsup_02.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_undsup_03.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_undsup_04.wav", "cod1/voiceovers/generic/allies/br/mg/mg_uk_undsup_05.wav" },
		},
		[3] = {
			coverme = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_04.wav" },
			death = { "cod1/voiceovers/generic/allies/am/as/as_exert_01.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_03.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_08.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/br/as/as_uk_supp_01.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_02.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_03.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_04.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_05.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_06.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_06.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_12.wav" },
			flankright = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_07.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_13.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_02.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_03.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_04.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_05.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/as/as_exert_01.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_06.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_09.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/as/as_exert_02.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_05.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_07.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_01.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_02.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_04.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_08.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_10.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_11.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_14.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_15.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/as/as_exert_04.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_06.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_08.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_09.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_01.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_02.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_03.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_04.wav" },
		},
		[4] = {
			coverme = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_04.wav" },
			death = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_supp_01.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_supp_02.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_supp_03.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_supp_04.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_supp_05.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_supp_06.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_06.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_12.wav" },
			flankright = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_07.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_13.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_01.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_05.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_11.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_grenatk_01.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_grenatk_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_grendng_01.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_grendng_02.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_grendng_03.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/mg/mg_charge_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_charge_02.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_01.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_02.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_04.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_08.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_10.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_11.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_14.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_15.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_undsup_01.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_undsup_02.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_undsup_03.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_undsup_04.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_undsup_05.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_undsup_06.wav" },
		},
		[5] = {
			coverme = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_04.wav" },
			death = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/br/as/as_uk_supp_01.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_02.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_03.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_04.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_05.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_06.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/br/qf/qf_uk_sighted_01a.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_sighted_01b.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_06.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_12.wav" },
			flankright = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_07.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_13.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_01.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_02.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_03.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_04.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_05.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_06.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_07.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_08.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_09.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_10.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_11.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_12.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_avoid_13.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/br/qf/qf_uk_greetloud_01.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_greetloud_02.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_greetloud_03.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_greetloud_04.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/br/qf/qf_uk_greetsoft_01.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_greetsoft_02.wav", "cod1/voiceovers/generic/allies/br/qf/qf_uk_greetsoft_03.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_grenatk_01.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_grenatk_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_grendng_01.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_grendng_02.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_grendng_03.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/mg/mg_charge_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_charge_02.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_01.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_02.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_04.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_08.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_10.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_11.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_14.wav", "cod1/voiceovers/generic/allies/br/nj/nj_uk_combat_15.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_01.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_02.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_03.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_04.wav" },
		},
		[6] = {
			coverme = { "cod1/voiceovers/generic/allies/br/js/js_uk_combat_04a.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_04b.wav" },
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/br/js/js_uk_suppfire.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/br/js/js_uk_sighted.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/br/js/js_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_06.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_12.wav" },
			flankright = { "cod1/voiceovers/generic/allies/br/js/js_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_07.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_13.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_04.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_05.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_06.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_07.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/br/js/js_uk_grenatk_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grenatk_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grenatk_03.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_04.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_05.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/br/js/js_uk_melee_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_04.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_05.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_06.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/br/js/js_uk_charge_01.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/br/js/js_uk_combat_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_04a.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_04b.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_08.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_10a.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_10b.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_10c.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_11.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_14a.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_14b.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_14c.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_15.wav" },
			pain = { "cod1/voiceovers/generic/allies/br/js/js_uk_pain_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_04.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_05.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_06.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_07.wav" },
		},
	},
	russian = {
		[1] = {
			death = { "cod1/voiceovers/stalingrad/conscript1_line_21c.wav", "cod1/voiceovers/stalingrad/conscript1_line_21d.wav", "cod1/voiceovers/stalingrad/conscript2_line_23c.wav", "cod1/voiceovers/stalingrad/conscript2_line_23d.wav" },
			enemykilled = { "cod1/voiceovers/stalingrad/buildingcommissar.wav" },
			enemysighted = { "cod1/voiceovers/stalingrad/commissar3_line_83.wav", "cod1/voiceovers/stalingrad/leadconscript_line_11b.wav" },
			flankright = { "cod1/voiceovers/stalingrad/russian_amb_03.wav" },
			grenadedanger = { "cod1/voiceovers/stalingrad/artilleryspotter_line_71.wav", "cod1/voiceovers/stalingrad/commissar3_amb15.wav" },
			misccombat = { "cod1/voiceovers/stalingrad/russian_amb_01.wav", "cod1/voiceovers/stalingrad/russian_amb_02.wav", "cod1/voiceovers/stalingrad/russian_amb_04.wav", "cod1/voiceovers/stalingrad/russian_amb_05.wav", "cod1/voiceovers/stalingrad/russian_amb_06.wav" },
			pain = { "cod1/allied/pain01.wav", "cod1/allied/pain02.wav", "cod1/allied/pain03.wav", "cod1/allied/pain04.wav", "cod1/allied/pain05.wav", "cod1/allied/pain06.wav", "cod1/allied/pain07.wav", "cod1/allied/pain08.wav", "cod1/allied/pain09.wav", "cod1/allied/pain10.wav", "cod1/allied/pain11.wav", "cod1/allied/pain12.wav", "cod1/allied/pain13.wav", "cod1/allied/pain14.wav", "cod1/allied/pain15.wav", "cod1/allied/pain16.wav" },
		},
		[2] = {
			coverme = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_coverme_01.wav" },
			death = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/ru/mg/mg_ru_sighted_01.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_sighted_02.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_01.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_02.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_03.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_04.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_05.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_06.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_07.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_08.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_09.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/ru/mg/mg_ru_greetloud_01.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/ru/mg/mg_ru_greetsoft_01.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_grendng_03.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav" },
		},
		[3] = {
			coverme = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_coverme_01.wav" },
			death = { "cod1/voiceovers/generic/allies/am/as/as_exert_01.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_03.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_08.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/ru/as/as_ru_supp_01.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_supp_02.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_supp_03.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_supp_04.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_supp_05.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/ru/as/as_ru_sighted_01.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_sighted_02.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_sighted_03.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_supp_02.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_01.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_09.wav" },
			flankright = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_10.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_01.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_02.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_03.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_04.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_05.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_06.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_07.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_08.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/ru/as/as_ru_grenatk_01.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_grenatk_02.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_grenatk_03.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/ru/as/as_ru_grendng_01.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_grendng_02.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_grendng_03.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/as/as_exert_01.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_06.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_09.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/ru/as/as_ru_charge_01.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_charge_02.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_03.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_04.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_05.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_06.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_12.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/as/as_exert_04.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_06.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_08.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_09.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/ru/as/as_ru_undsup_01a.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_undsup_01b.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_undsup_02.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_undsup_03.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_undsup_04.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_undsup_05.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_undsup_06.wav" },
		},
		[4] = {
			coverme = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_coverme_01.wav" },
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_01.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_03.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_04.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_05.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_06.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_08.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_09.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/ru/jp/jp_ru_sighted_01.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_sighted_02.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_sighted_03.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_01.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_09.wav" },
			flankright = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_10.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/ru/jp/jp_ru_avoid_01.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_avoid_02.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_avoid_03.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_avoid_04.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_avoid_05.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_avoid_06.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/ru/as/as_ru_grenatk_01.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_grenatk_02.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_grenatk_03.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/ru/as/as_ru_grendng_01.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_grendng_02.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_grendng_03.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/ru/jp/jp_ru_exert_01.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_exert_02.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_exert_03.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_exert_04.wav", "cod1/voiceovers/generic/allies/ru/jp/jp_ru_exert_05.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_03.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_04.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_05.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_06.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_12.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/jp/jp_exert_01.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_02.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_03.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_04.wav", "cod1/voiceovers/generic/allies/am/jp/jp_exert_05.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_01.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_03.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_04.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_05.wav" },
		},
		[5] = {
			coverme = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_coverme_01.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_coverme_02.wav" },
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_01.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_03.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_04.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_05.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_06.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_08.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_09.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_supp_09.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_05.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_01.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_09.wav" },
			flankright = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_07.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_10.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_01.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_02.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_03.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_04.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_05.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_06.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_07.wav", "cod1/voiceovers/generic/allies/ru/as/as_ru_avoid_08.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_grenatk_01.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_grendng_01.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_grendng_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_grendng_03.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_grendng_04.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_03.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_04.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_05.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_06.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_combat_12.wav" },
			pain = { "cod1/allied/pain01.wav", "cod1/allied/pain02.wav", "cod1/allied/pain03.wav", "cod1/allied/pain04.wav", "cod1/allied/pain05.wav", "cod1/allied/pain06.wav", "cod1/allied/pain07.wav", "cod1/allied/pain08.wav", "cod1/allied/pain09.wav", "cod1/allied/pain10.wav", "cod1/allied/pain11.wav", "cod1/allied/pain12.wav", "cod1/allied/pain13.wav", "cod1/allied/pain14.wav", "cod1/allied/pain15.wav", "cod1/allied/pain16.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_01.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_03.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_04.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_05.wav" },
		},
		[6] = {
			coverme = { "cod1/voiceovers/generic/allies/ru/qf/qf_ru_coverme_01.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_coverme_02.wav" },
			death = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/ru/qf/qf_ru_sighted_01.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_sighted_02.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_sighted_03.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_sighted_04.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_sighted_05.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_sighted_06.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/ru/qf/qf_ru_avoid_01.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_avoid_02.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_avoid_03.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_avoid_04.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_avoid_05.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/ru/qf/qf_ru_greetloud_01.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_greetloud_02.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_greetloud_03.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_greetloud_04.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/ru/qf/qf_ru_greetsoft_01.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_greetsoft_02.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/ru/qf/qf_ru_grenatk_01.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_grenatk_02.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_grenatk_03.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/ru/qf/qf_ru_grendng_01.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_grendng_02.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_grendng_03.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_grendng_04.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_grendng_05.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_grendng_06.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/ru/qf/qf_ru_combat_01.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_combat_02.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_combat_03.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_combat_04.wav", "cod1/voiceovers/generic/allies/ru/qf/qf_ru_combat_06.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav" },
		},
	},
	price = {
		[1] = {
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/uk/pegnight/pegnight_price_02a.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/mg/mg_charge_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_charge_02.wav" },
			misccombat = { "cod1/voiceovers/uk/ship/ship_price_040.wav" },
			pain = { "cod1/allied/pain01.wav", "cod1/allied/pain02.wav", "cod1/allied/pain03.wav", "cod1/allied/pain04.wav", "cod1/allied/pain05.wav", "cod1/allied/pain06.wav", "cod1/allied/pain07.wav", "cod1/allied/pain08.wav", "cod1/allied/pain09.wav", "cod1/allied/pain10.wav", "cod1/allied/pain11.wav", "cod1/allied/pain12.wav", "cod1/allied/pain13.wav", "cod1/allied/pain14.wav", "cod1/allied/pain15.wav", "cod1/allied/pain16.wav" },
			undersuppression = { "cod1/voiceovers/uk/pegday/pegday_price_02.wav" },
		},
	},
	foley = {
		[1] = {
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/am/sb/foleyfire_03.wav", "cod1/voiceovers/generic/allies/am/sb/foleykeepfire_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleykeepshoot_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleyopenfire_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleysuppfire_01.wav", "cod1/voiceovers/us/burnville/burnville_foley_027.wav", "cod1/voiceovers/us/burnville/burnville_foley_047alt.wav", "cod1/voiceovers/us/burnville/burnville_foley_056.wav" },
			enemysighted = { "cod1/voiceovers/us/burnville/burnville_foley_026.wav", "cod1/voiceovers/us/burnville/burnville_foley_035alt.wav", "cod1/voiceovers/us/burnville/burnville_foley_040.wav" },
			flankleft = { "cod1/voiceovers/us/burnville/burnville_foley_046.wav" },
			greetplayerloud = { "cod1/voiceovers/us/training/training_foley_01.wav", "cod1/voiceovers/us/training/training_foley_13.wav", "cod1/voiceovers/us/training/training_foley_15.wav", "cod1/voiceovers/us/training/training_foley_22.wav" },
			greetplayerquiet = { "cod1/voiceovers/us/chateau/chateau_foley_094alt.wav", "cod1/voiceovers/us/training/training_foley_23.wav", "cod1/voiceovers/us/dawnville/dawnville_foley_091.wav" },
			grenadeattack = { "cod1/voiceovers/us/burnville/burnville_foley_037.wav", "cod1/voiceovers/us/burnville/burnville_foley_053alt.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/am/sb/foleytakecover_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleytakecover_02.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/sb/foleyexert_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleyexert_02.wav", "cod1/voiceovers/generic/allies/am/sb/foleyexert_03.wav", "cod1/voiceovers/generic/allies/am/sb/foleyexert_04.wav", "cod1/voiceovers/generic/allies/am/sb/foleyexert_05.wav", "cod1/voiceovers/generic/allies/am/sb/foleyexert_06.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/sb/foleycharge_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleycharge_02.wav", "cod1/voiceovers/generic/allies/am/sb/foleycharge_03.wav", "cod1/voiceovers/generic/allies/am/sb/foleycharge_04.wav", "cod1/voiceovers/generic/allies/am/sb/foleycharge_05.wav", "cod1/voiceovers/generic/allies/am/sb/foleycharge_06.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/am/sb/foleycovfire_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleygetdown_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleysuppfire_01.wav", "cod1/voiceovers/us/burnville/burnville_foley_025alt.wav", "cod1/voiceovers/us/burnville/burnville_foley_032.wav", "cod1/voiceovers/us/burnville/burnville_foley_036.wav", "cod1/voiceovers/us/burnville/burnville_foley_042.wav", "cod1/voiceovers/us/burnville/burnville_foley_045.wav", "cod1/voiceovers/us/burnville/burnville_foley_054.wav", "cod1/voiceovers/us/training/training_foley_03.wav", "cod1/voiceovers/us/training/training_foley_06.wav", "cod1/voiceovers/us/hurtgen/hurtgen_foley_104alt.wav" },
			pain = { "cod1/allied/pain01.wav", "cod1/allied/pain02.wav", "cod1/allied/pain03.wav", "cod1/allied/pain04.wav", "cod1/allied/pain05.wav", "cod1/allied/pain06.wav", "cod1/allied/pain07.wav", "cod1/allied/pain08.wav", "cod1/allied/pain09.wav", "cod1/allied/pain10.wav", "cod1/allied/pain11.wav", "cod1/allied/pain12.wav", "cod1/allied/pain13.wav", "cod1/allied/pain14.wav", "cod1/allied/pain15.wav", "cod1/allied/pain16.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/am/sb/foleygetdown_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleygetdown_02.wav", "cod1/voiceovers/generic/allies/am/sb/foleyheadsdown_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleyhelpme_01.wav", "cod1/voiceovers/generic/allies/am/sb/foleypinned_01.wav", "cod1/voiceovers/us/burnville/burnville_foley_029.wav", "cod1/voiceovers/us/burnville/burnville_foley_030.wav", "cod1/voiceovers/us/burnville/burnville_foley_031alt.wav", "cod1/voiceovers/us/training/training_foley_20.wav", "cod1/voiceovers/us/training/training_foley_21.wav" },
		},
	},
	moody = {
		[1] = {
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/am/gb/moodydoingsupp01.wav", "cod1/voiceovers/generic/allies/am/gb/moodydoingsupp02.wav", "cod1/voiceovers/us/brecourt/brecourt_moody_079.wav", "cod1/voiceovers/us/carride/carride_moody_050.wav" },
			greetplayerloud = { "cod1/voiceovers/us/training/training_moody_009_2.wav" },
			greetplayerquiet = { "cod1/voiceovers/us/training/training_moody_010.wav", "cod1/voiceovers/us/training/training_moody_027.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/am/gb/moodygrenatk_01.wav", "cod1/voiceovers/us/training/training_moody_039.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/am/gb/moodygrendanger_01.wav", "cod1/voiceovers/us/brecourt/brecourt_moody_072.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/gb/moodyexert_a_01.wav", "cod1/voiceovers/generic/allies/am/gb/moodyexert_a_02.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/gb/moodycharge_a_04.wav", "cod1/voiceovers/generic/allies/am/gb/moodycharge_a_05.wav", "cod1/voiceovers/generic/allies/am/gb/moodycharge_die_a_01.wav", "cod1/voiceovers/generic/allies/am/gb/moodycharge_die_a_03.wav" },
			misccombat = { "cod1/voiceovers/us/brecourt/brecourt_moody_069.wav", "cod1/voiceovers/us/brecourt/brecourt_moody_071b.wav", "cod1/voiceovers/us/brecourt/brecourt_moody_073.wav", "cod1/voiceovers/us/brecourt/brecourt_moody_075.wav", "cod1/voiceovers/us/brecourt/brecourt_moody_077alt2.wav", "cod1/voiceovers/us/carride/carride_moody_047.wav" },
			pain = { "cod1/allied/pain01.wav", "cod1/allied/pain02.wav", "cod1/allied/pain03.wav", "cod1/allied/pain04.wav", "cod1/allied/pain05.wav", "cod1/allied/pain06.wav", "cod1/allied/pain07.wav", "cod1/allied/pain08.wav", "cod1/allied/pain09.wav", "cod1/allied/pain10.wav", "cod1/allied/pain11.wav", "cod1/allied/pain12.wav", "cod1/allied/pain13.wav", "cod1/allied/pain14.wav", "cod1/allied/pain15.wav", "cod1/allied/pain16.wav" },
		},
	},
	elder = {
		[1] = {
			coverme = { "cod1/voiceovers/generic/allies/am/gr/eldercoverme_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldercoverme_02.wav" },
			death = { "cod1/voiceovers/generic/allies/am/gr/elderexert_06.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_03.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/am/gr/elderatwill_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderatwill_02.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/am/gr/eldersighted_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_02.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_03.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_04.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_05.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_06.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_07.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_08.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_09.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_10.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_11.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_12.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_13.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_14.wav", "cod1/voiceovers/generic/allies/am/gr/eldersighted_15.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/am/gr/elderflankleft_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderflankthem01.wav", "cod1/voiceovers/generic/allies/am/gr/elderleftflank_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderleftflank_02.wav" },
			flankright = { "cod1/voiceovers/generic/allies/am/gr/elderflankright_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderflankright_02.wav", "cod1/voiceovers/generic/allies/am/gr/elderflankthem02.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/am/gr/eldergreetloud_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldergreetloud_02.wav", "cod1/voiceovers/generic/allies/am/gr/eldergreetloud_03.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/am/gr/eldergreetsoft_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldergreetsoft_02.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/am/gr/eldertakecover_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldertakecover_02.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/gr/elderexert_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_02.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_03.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_04.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_05.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_06.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/gr/eldercharge_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldercharge_02.wav", "cod1/voiceovers/generic/allies/am/gr/eldercharge_03.wav", "cod1/voiceovers/generic/allies/am/gr/eldercharge_04.wav", "cod1/voiceovers/generic/allies/am/gr/eldercharge_05.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/am/gr/eldercoverme_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldercoverme_02.wav", "cod1/voiceovers/generic/allies/am/gr/eldergogogo_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldermovein01.wav", "cod1/voiceovers/generic/allies/am/gr/eldermovein02.wav", "cod1/voiceovers/generic/allies/am/gr/eldermoveit_01.wav", "cod1/voiceovers/generic/allies/am/gr/eldermoveit_02.wav", "cod1/voiceovers/us/carride/carride_elder_005.wav", "cod1/voiceovers/us/carride/carride_elder_012.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/gr/elderexert_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_02.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_03.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_04.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_05.wav", "cod1/voiceovers/generic/allies/am/gr/elderexert_06.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/am/gr/elderstaylow_01.wav", "cod1/voiceovers/generic/allies/am/gr/elderstaylow_02.wav" },
		},
	},
	waters = {
		[1] = {
			coverme = { "cod1/voiceovers/generic/allies/br/js/js_uk_combat_04a.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_04b.wav" },
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/br/js/js_uk_suppfire.wav", "cod1/voiceovers/uk/truckride/truckride_waters_025.wav", "cod1/voiceovers/uk/truckride/truckride_waters_026alt.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/br/js/js_uk_sighted.wav" },
			flankleft = { "cod1/voiceovers/generic/allies/br/js/js_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_06.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_12.wav" },
			flankright = { "cod1/voiceovers/generic/allies/br/js/js_uk_combat_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_07.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_13.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_04.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_05.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_06.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_avoid_07.wav" },
			grenadeattack = { "cod1/voiceovers/generic/allies/br/js/js_uk_grenatk_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grenatk_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grenatk_03.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_04.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_grendng_05.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/br/js/js_uk_melee_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_04.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_05.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_melee_06.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/br/js/js_uk_charge_01.wav" },
			misccombat = { "cod1/voiceovers/generic/allies/br/js/js_uk_combat_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_04a.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_04b.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_08.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_10a.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_10b.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_10c.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_11.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_14a.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_14b.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_14c.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_combat_15.wav", "cod1/voiceovers/uk/truckride/truckride_waters_020.wav", "cod1/voiceovers/uk/truckride/truckride_waters_023.wav" },
			pain = { "cod1/voiceovers/generic/allies/br/js/js_uk_pain_01.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_02.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_03.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_04.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_05.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_06.wav", "cod1/voiceovers/generic/allies/br/js/js_uk_pain_07.wav" },
		},
	},
	ingram = {
		[1] = {
			death = { "cod1/allied/death01.wav", "cod1/allied/death02.wav", "cod1/allied/death03.wav", "cod1/allied/death04.wav", "cod1/allied/death05.wav", "cod1/allied/death06.wav", "cod1/allied/death07.wav", "cod1/allied/death08.wav", "cod1/allied/death09.wav", "cod1/allied/death10.wav", "cod1/allied/death11.wav" },
			pain = { "cod1/allied/pain01.wav", "cod1/allied/pain02.wav", "cod1/allied/pain03.wav", "cod1/allied/pain04.wav", "cod1/allied/pain05.wav", "cod1/allied/pain06.wav", "cod1/allied/pain07.wav", "cod1/allied/pain08.wav", "cod1/allied/pain09.wav", "cod1/allied/pain10.wav", "cod1/allied/pain11.wav", "cod1/allied/pain12.wav", "cod1/allied/pain13.wav", "cod1/allied/pain14.wav", "cod1/allied/pain15.wav", "cod1/allied/pain16.wav" },
		},
	},
	mills = {
		[1] = {
			death = { "cod1/voiceovers/generic/allies/am/as/as_exert_01.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_03.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_08.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/br/as/as_uk_supp_01.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_02.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_03.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_04.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_05.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_supp_06.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/as/as_exert_01.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_06.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_09.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/am/as/as_exert_02.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_05.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_07.wav" },
			misccombat = { "cod1/voiceovers/uk/pegnight/pegnight_mills_03.wav", "cod1/voiceovers/uk/pegnight/pegnight_mills_05.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/as/as_exert_04.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_06.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_08.wav", "cod1/voiceovers/generic/allies/am/as/as_exert_09.wav" },
			undersuppression = { "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_01.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_02.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_03.wav", "cod1/voiceovers/generic/allies/br/as/as_uk_undsup_04.wav" },
		},
	},
	pavlov = {
		[1] = {
			death = { "cod1/voiceovers/generic/allies/ru/mb/mb_ru_exert_04.wav" },
			doingsuppression = { "cod1/voiceovers/generic/allies/ru/mb/mb_ru_sightsupp_01.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/ru/mb/mb_ru_sightsupp_01.wav", "cod1/voiceovers/ru/ph/pavlov_kamarov_006 alt_snipwindows.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/ru/mb/mb_ru_exert_01.wav", "cod1/voiceovers/generic/allies/ru/mb/mb_ru_exert_02.wav", "cod1/voiceovers/generic/allies/ru/mb/mb_ru_exert_03.wav", "cod1/voiceovers/generic/allies/ru/mb/mb_ru_exert_04.wav" },
			meleecharge = { "cod1/voiceovers/generic/allies/ru/mb/mb_ru_charge_01.wav", "cod1/voiceovers/generic/allies/ru/mb/mb_ru_charge_02.wav", "cod1/voiceovers/generic/allies/ru/mb/mb_ru_charge_03.wav", "cod1/voiceovers/generic/allies/ru/mb/mb_ru_charge_04.wav" },
			misccombat = { "cod1/voiceovers/ru/ph/pavlov_clear_0.wav", "cod1/voiceovers/ru/ph/pavlov_clear_1.wav", "cod1/voiceovers/ru/ph/pavlov_clear_2.wav", "cod1/voiceovers/ru/ph/pavlov_clear_3.wav", "cod1/voiceovers/ru/ph/pavlov_clear_top.wav", "cod1/voiceovers/ru/ph/pavlov_holdthispos.wav" },
			pain = { "cod1/voiceovers/generic/allies/ru/mb/mb_ru_exert_01.wav", "cod1/voiceovers/generic/allies/ru/mb/mb_ru_exert_02.wav", "cod1/voiceovers/generic/allies/ru/mb/mb_ru_exert_03.wav", "cod1/voiceovers/generic/allies/ru/mb/mb_ru_exert_04.wav" },
		},
	},
	kovalenko = {
		[1] = {
			death = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_01.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_02.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_03.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_04.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_05.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_06.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_07.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_08.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_09.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_grendng_03.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav" },
		},
	},
	makarov = {
		[1] = {
			coverme = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_coverme_01.wav" },
			death = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav" },
			enemysighted = { "cod1/voiceovers/generic/allies/ru/mg/mg_ru_sighted_01.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_sighted_02.wav" },
			giveupposition = { "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_01.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_02.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_03.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_04.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_05.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_06.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_07.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_08.wav", "cod1/voiceovers/generic/allies/ru/mg/mg_ru_avoid_09.wav" },
			greetplayerloud = { "cod1/voiceovers/generic/allies/ru/mg/mg_ru_greetloud_01.wav" },
			greetplayerquiet = { "cod1/voiceovers/generic/allies/ru/mg/mg_ru_greetsoft_01.wav" },
			grenadedanger = { "cod1/voiceovers/generic/allies/ru/nj/nj_ru_undsup_02.wav", "cod1/voiceovers/generic/allies/ru/nj/nj_ru_grendng_03.wav" },
			meleeattack = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_02.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_03.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_05.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_09.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_10.wav" },
			pain = { "cod1/voiceovers/generic/allies/am/mg/mg_exert_01.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_04.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_06.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_07.wav", "cod1/voiceovers/generic/allies/am/mg/mg_exert_08.wav" },
		},
	},
}

COD1.QuickChat = {
	american = {
		area_secure = { "cod1/voiceovers/mp/us/stat/us_stat_secure.wav" },
		attack_left_flank = { "cod1/voiceovers/mp/us/cmds/us_cmd_ltflank.wav" },
		attack_right_flank = { "cod1/voiceovers/mp/us/cmds/us_cmd_rtflank01.wav", "cod1/voiceovers/mp/us/cmds/us_cmd_rtflank02.wav" },
		crazy = { "cod1/voiceovers/mp/us/resp/us_resp_crazy01.wav", "cod1/voiceovers/mp/us/resp/us_resp_crazy02.wav", "cod1/voiceovers/mp/us/resp/us_resp_crazy03.wav" },
		enemy_down = { "cod1/voiceovers/mp/us/stat/us_stat_enemydn.wav" },
		enemy_grenade = { "cod1/voiceovers/mp/us/stat/us_stat_gren01.wav" },
		enemy_spotted = { "cod1/voiceovers/mp/us/stat/us_stat_enemyspot.wav" },
		fall_back = { "cod1/voiceovers/mp/us/cmds/us_cmd_fallback.wav" },
		follow_me = { "cod1/voiceovers/mp/us/cmds/us_cmd_followme.wav" },
		great_shot = { "cod1/voiceovers/mp/us/resp/us_resp_greatshot.wav" },
		grenade = { "cod1/voiceovers/mp/us/stat/us_stat_gren02.wav" },
		hold_fire = { "cod1/voiceovers/mp/us/stat/us_stat_holdfire.wav" },
		hold_position = { "cod1/voiceovers/mp/us/cmds/us_cmd_holdpos.wav" },
		in_position = { "cod1/voiceovers/mp/us/stat/us_stat_inpos.wav" },
		move_in = { "cod1/voiceovers/mp/us/cmds/us_cmd_movein01.wav", "cod1/voiceovers/mp/us/cmds/us_cmd_movein02.wav", "cod1/voiceovers/mp/us/cmds/us_cmd_movein03.wav" },
		need_reinforcements = { "cod1/voiceovers/mp/us/stat/us_stat_reinforce.wav" },
		no_sir = { "cod1/voiceovers/mp/us/resp/us_resp_nosir.wav" },
		on_my_way = { "cod1/voiceovers/mp/us/resp/us_resp_onmyway.wav" },
		regroup = { "cod1/voiceovers/mp/us/cmds/us_cmd_regroup01.wav" },
		sniper = { "cod1/voiceovers/mp/us/stat/us_stat_sniper.wav" },
		sorry = { "cod1/voiceovers/mp/us/resp/us_resp_sorry.wav" },
		stick_together = { "cod1/voiceovers/mp/us/cmds/us_cmd_regroup02.wav" },
		suppressing_fire = { "cod1/voiceovers/mp/us/cmds/us_cmd_suppfire.wav" },
		took_long_enough = { "cod1/voiceovers/mp/us/resp/us_resp_tooklong.wav" },
		yes_sir = { "cod1/voiceovers/mp/us/resp/us_resp_yessir.wav" },
	},
	british = {
		area_secure = { "cod1/voiceovers/mp/uk/stat/uk_stat_secure.wav" },
		attack_left_flank = { "cod1/voiceovers/mp/uk/cmds/uk_cmd_ltflank.wav" },
		attack_right_flank = { "cod1/voiceovers/mp/uk/cmds/uk_cmd_rtflank.wav" },
		crazy = { "cod1/voiceovers/mp/uk/resp/uk_resp_crazy.wav" },
		enemy_down = { "cod1/voiceovers/mp/uk/stat/uk_stat_enemydn.wav" },
		enemy_spotted = { "cod1/voiceovers/mp/uk/stat/uk_stat_spotted.wav" },
		fall_back = { "cod1/voiceovers/mp/uk/cmds/uk_cmd_fallback.wav" },
		follow_me = { "cod1/voiceovers/mp/uk/cmds/uk_cmd_follow01.wav", "cod1/voiceovers/mp/uk/cmds/uk_cmd_follow02.wav" },
		great_shot = { "cod1/voiceovers/mp/uk/resp/uk_resp_greatshot.wav" },
		grenade = { "cod1/voiceovers/mp/uk/stat/uk_stat_gren01.wav", "cod1/voiceovers/mp/uk/stat/uk_stat_gren02.wav" },
		hold_fire = { "cod1/voiceovers/mp/uk/stat/uk_stat_holdfire01.wav", "cod1/voiceovers/mp/uk/stat/uk_stat_holdfire02.wav" },
		hold_position = { "cod1/voiceovers/mp/uk/cmds/uk_cmd_holdpos01.wav", "cod1/voiceovers/mp/uk/cmds/uk_cmd_holdpos02.wav" },
		in_position = { "cod1/voiceovers/mp/uk/stat/uk_stat_inpos.wav" },
		move_in = { "cod1/voiceovers/mp/uk/cmds/uk_cmd_movein.wav" },
		need_reinforcements = { "cod1/voiceovers/mp/uk/stat/uk_stat_reinforce.wav" },
		no_sir = { "cod1/voiceovers/mp/uk/resp/uk_resp_nosir01.wav", "cod1/voiceovers/mp/uk/resp/uk_resp_nosir02.wav" },
		on_my_way = { "cod1/voiceovers/mp/uk/resp/uk_resp_onmyway.wav" },
		regroup = { "cod1/voiceovers/mp/uk/cmds/uk_cmd_regroup01.wav" },
		sniper = { "cod1/voiceovers/mp/uk/stat/uk_stat_sniper.wav" },
		sorry = { "cod1/voiceovers/mp/uk/resp/uk_resp_sorry.wav" },
		stick_together = { "cod1/voiceovers/mp/uk/cmds/uk_cmd_regroup02.wav" },
		suppressing_fire = { "cod1/voiceovers/mp/uk/cmds/uk_cmd_suppfire.wav" },
		took_long_enough = { "cod1/voiceovers/mp/uk/resp/uk_resp_tooklong.wav" },
		yes_sir = { "cod1/voiceovers/mp/uk/resp/uk_resp_yessir.wav" },
	},
	german = {
		area_secure = { "cod1/voiceovers/mp/ge/stat/ge_stat_secure_01.wav", "cod1/voiceovers/mp/ge/stat/ge_stat_secure_02.wav" },
		attack_left_flank = { "cod1/voiceovers/mp/ge/cmds/ge_cmd_leftflank.wav" },
		attack_right_flank = { "cod1/voiceovers/mp/ge/cmds/ge_cmd_rightflank.wav" },
		crazy = { "cod1/voiceovers/mp/ge/resp/ge_resp_crazy.wav" },
		enemy_down = { "cod1/voiceovers/mp/ge/stat/ge_stat_enemydown.wav" },
		enemy_spotted = { "cod1/voiceovers/mp/ge/stat/ge_stat_spotted.wav" },
		fall_back = { "cod1/voiceovers/mp/ge/cmds/ge_cmd_fallback.wav" },
		follow_me = { "cod1/voiceovers/mp/ge/cmds/ge_cmd_followme.wav" },
		great_shot = { "cod1/voiceovers/mp/ge/resp/ge_resp_goodshot_01.wav", "cod1/voiceovers/mp/ge/resp/ge_resp_goodshot_02.wav" },
		grenade = { "cod1/voiceovers/mp/ge/stat/ge_stat_grenade_01.wav", "cod1/voiceovers/mp/ge/stat/ge_stat_grenade_02.wav" },
		hold_fire = { "cod1/voiceovers/mp/ge/stat/ge_stat_holdfire.wav" },
		hold_position = { "cod1/voiceovers/mp/ge/cmds/ge_cmd_holdpos.wav" },
		in_position = { "cod1/voiceovers/mp/ge/stat/ge_stat_inpos.wav" },
		move_in = { "cod1/voiceovers/mp/ge/cmds/ge_cmd_movein.wav" },
		need_reinforcements = { "cod1/voiceovers/mp/ge/stat/ge_stat_reinforce.wav" },
		no_sir = { "cod1/voiceovers/mp/ge/resp/ge_resp_nosir.wav" },
		on_my_way = { "cod1/voiceovers/mp/ge/resp/ge_resp_onmyway.wav" },
		regroup = { "cod1/voiceovers/mp/ge/cmds/ge_cmd_regroup.wav" },
		sniper = { "cod1/voiceovers/mp/ge/stat/ge_stat_sniper.wav" },
		sorry = { "cod1/voiceovers/mp/ge/resp/ge_resp_sorry.wav" },
		suppressing_fire = { "cod1/voiceovers/mp/ge/cmds/ge_cmd_suppress.wav" },
		took_long_enough = { "cod1/voiceovers/mp/ge/resp/ge_resp_longenuf.wav" },
		yes_sir = { "cod1/voiceovers/mp/ge/resp/ge_resp_yessir.wav" },
	},
	russian = {
		area_secure = { "cod1/voiceovers/mp/ru/stat/ru_stat_secure.wav" },
		attack_left_flank = { "cod1/voiceovers/mp/ru/cmds/ru_cmd_leftflank.wav" },
		attack_right_flank = { "cod1/voiceovers/mp/ru/cmds/ru_cmd_rightflank.wav" },
		crazy = { "cod1/voiceovers/mp/ru/resp/ru_resp_crazy.wav" },
		enemy_down = { "cod1/voiceovers/mp/ru/stat/ru_stat_enemydn.wav" },
		enemy_spotted = { "cod1/voiceovers/mp/ru/stat/ru_stat_spotted.wav" },
		fall_back = { "cod1/voiceovers/mp/ru/cmds/ru_cmd_fallback.wav" },
		follow_me = { "cod1/voiceovers/mp/ru/cmds/ru_cmd_followme.wav" },
		great_shot = { "cod1/voiceovers/mp/ru/resp/ru_resp_greatshot.wav" },
		grenade = { "cod1/voiceovers/mp/ru/stat/ru_stat_grenade.wav" },
		hold_fire = { "cod1/voiceovers/mp/ru/stat/ru_stat_holdfire.wav" },
		hold_position = { "cod1/voiceovers/mp/ru/cmds/ru_cmd_holdpos.wav" },
		in_position = { "cod1/voiceovers/mp/ru/stat/ru_stat_inpos.wav" },
		move_in = { "cod1/voiceovers/mp/ru/cmds/ru_cmd_movein.wav" },
		need_reinforcements = { "cod1/voiceovers/mp/ru/stat/ru_stat_reinforce.wav" },
		no_sir = { "cod1/voiceovers/mp/ru/resp/ru_resp_nosir_01.wav", "cod1/voiceovers/mp/ru/resp/ru_resp_nosir_02.wav" },
		on_my_way = { "cod1/voiceovers/mp/ru/resp/ru_resp_onmyway.wav" },
		regroup = { "cod1/voiceovers/mp/ru/cmds/ru_cmd_regroup.wav" },
		sniper = { "cod1/voiceovers/mp/ru/stat/ru_stat_sniper.wav" },
		sorry = { "cod1/voiceovers/mp/ru/resp/ru_resp_sorry.wav" },
		suppressing_fire = { "cod1/voiceovers/mp/ru/cmds/ru_cmd_suppress.wav" },
		took_long_enough = { "cod1/voiceovers/mp/ru/resp/ru_resp_longenuf.wav" },
		yes_sir = { "cod1/voiceovers/mp/ru/resp/ru_resp_yessir.wav" },
	},
}
COD1.MedicLines = { "cod1/voiceovers/us/brecourt/brecourt_medic_001alt.wav", "cod1/voiceovers/us/brecourt/brecourt_medic_002.wav" }

local BR = "cod1/voiceovers/generic/allies/br/"
local function more( voice, event, files )
	local v = COD1.Voices.british[ voice ]
	v[ event ] = v[ event ] or {}
	for _, f in ipairs( files ) do table.insert( v[ event ], BR .. f ) end
end
local QF_GREN_ATK = { "qf/qf_uk_grenatk_01a.wav", "qf/qf_uk_grenatk_01b.wav" }
local QF_GREN_DNG = { "qf/qf_uk_grendng_01.wav", "qf/qf_uk_grendng_02.wav", "qf/qf_uk_grendng_03.wav", "qf/qf_uk_grendng_04.wav", "qf/qf_uk_grendng_05.wav" }
more( 1, "misccombat", { "ga/ga_uk_combat_06.wav", "ga/ga_uk_combat_10.wav" } )
more( 2, "misccombat", { "mg/mg_uk_combat_05.wav", "mg/mg_uk_combat_09.wav" } )
more( 3, "grenadeattack", QF_GREN_ATK )
more( 3, "grenadedanger", QF_GREN_DNG )
more( 3, "enemysighted", { "qf/qf_uk_sighted_02.wav" } )
more( 3, "misccombat", { "nj/nj_uk_combat_05.wav", "nj/nj_uk_combat_09.wav" } )
more( 4, "enemysighted", { "qf/qf_uk_sighted_02.wav" } )
more( 4, "misccombat", { "nj/nj_uk_combat_05.wav", "nj/nj_uk_combat_09.wav" } )
more( 5, "misccombat", { "nj/nj_uk_combat_05.wav", "nj/nj_uk_combat_09.wav" } )
more( 6, "enemykilled", { "js/js_uk_enemydn.wav" } )
more( 6, "misccombat", { "js/js_uk_combat_05.wav", "js/js_uk_combat_09.wav" } )
for _, voice in ipairs( { 3, 4 } ) do
	for _, ev in ipairs( { "greetplayerloud", "greetplayerquiet" } ) do
		COD1.Voices.british[ voice ][ ev ] = COD1.Voices.british[ voice ][ ev ] or COD1.Voices.british[ 5 ][ ev ]
	end
end

--all the sounds, every "grenade!" is in here somewhere
