COD1.VehicleCategory = "Call of Duty 1: Vehicles"

local GER = { team = "axis", crew = "german_tankcrew", crewClass = "npc_cod1_german", crewCount = 3 }
local SOV = { team = "allies", crew = "russian_tankcrew", crewClass = "npc_cod1_airborne", crewCount = 3 }
local US = { team = "allies", crew = "airborne_uo", crewClass = "npc_cod1_airborne", crewCount = 2 }

local function tank( base, t )
	return table.Merge( table.Copy( base ), t )
end

COD1.TankTypes = {
	tiger = tank( GER, { name = "Tiger I", model = "tank_tiger", hp = 2400, speed = 140, turretRate = 20, reload = 6.5,
		engine = "Tiger", boom = "explosions/vehicles/tiger_complete" } ),
	tiger_camo = tank( GER, { name = "Tiger I (Camouflage)", model = "tank_tiger_camo", hp = 2400, speed = 140, turretRate = 20, reload = 6.5,
		engine = "Tiger", boom = "explosions/vehicles/tiger_complete" } ),
	tiger_snow = tank( GER, { name = "Tiger I (Winter)", model = "tank_tiger_snow", dead = "tank_tiger_dead", hp = 2400, speed = 140,
		turretRate = 20, reload = 6.5, engine = "Tiger", boom = "explosions/vehicles/tiger_complete" } ),
	panzeriv = tank( GER, { name = "Panzer IV", model = "tank_panzeriv", hp = 1600, speed = 170, turretRate = 28, reload = 5,
		engine = "Panzer", boom = "explosions/vehicles/panzeriv_complete" } ),
	panzeriv_camo = tank( GER, { name = "Panzer IV (Camouflage)", model = "tank_panzeriv_camo", hp = 1600, speed = 170, turretRate = 28,
		reload = 5, engine = "Panzer", boom = "explosions/vehicles/panzeriv_complete" } ),
	elefant = tank( GER, { name = "Elefant", model = "tank_elefant", hp = 3200, speed = 105, turretRate = 14, reload = 7.5, traverse = 12,
		engine = "Tiger", boom = "explosions/vehicles/elefant_complete" } ),
	t34 = tank( SOV, { name = "T-34", model = "tank_t34", hp = 1600, speed = 190, turretRate = 26, reload = 5,
		engine = "T34", boom = "explosions/vehicles/t34_complete" } ),
	t34_camo = tank( SOV, { name = "T-34 (Winter)", model = "tank_t34_camo", hp = 1600, speed = 190, turretRate = 26, reload = 5,
		engine = "T34", boom = "explosions/vehicles/t34_complete" } ),
	su152 = tank( SOV, { name = "SU-152", model = "tank_su152", hp = 2600, speed = 130, turretRate = 12, reload = 9, traverse = 12,
		engine = "T34", boom = "explosions/vehicles/generic_complete", blast = 420 } ),
	sherman = tank( US, { name = "M4 Sherman", model = "tank_sherman", hp = 1500, speed = 180, turretRate = 30, reload = 5,
		engine = "Sherman", boom = "explosions/vehicles/sherman_complete" } ),
	sherman_snow = tank( US, { name = "M4 Sherman (Winter)", model = "tank_sherman_snow", hp = 1500, speed = 180, turretRate = 30, reload = 5,
		engine = "Sherman", boom = "explosions/vehicles/sherman_complete" } ),
}

for key, t in pairs( COD1.TankTypes ) do
	t.key = key
	t.dead = t.dead or ( t.model .. "_dead" )
	t.tags = COD1.VehicleTags and COD1.VehicleTags[ t.model ] or {}
	list.Set( "NPC", "npc_cod1_tank_" .. key, { Name = t.name, Class = "cod1_tank", Category = COD1.VehicleCategory,
		KeyValues = { cod1_tank = key } } )
end
list.Set( "ContentCategoryIcons", COD1.VehicleCategory, "cod1/ui/tank16.png" )

function COD1.HostileToPlayer( team, ply )
	if not IsValid( ply ) or not ply:IsPlayer() or not ply:Alive() then return false end
	if GetConVar( "ai_ignoreplayers" ):GetBool() or ply:IsFlagSet( FL_NOTARGET ) then return false end
	if team == "axis" and COD1.IsUndercover( ply ) then return false end
	return GetConVar( team ~= COD1.PlayerSide() and "cod1_axis_hostile_players" or "cod1_npc_hostile_players" ):GetBool()
end

--tiger tank go boom
