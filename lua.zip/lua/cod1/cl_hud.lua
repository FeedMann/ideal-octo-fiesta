local pageMats = {}
for i, path in ipairs( COD1.Font.pages ) do pageMats[ i - 1 ] = Material( path ) end
local glyphs = COD1.Font.glyphs

function COD1.TextWidth( text, scale )
	local use = scale * COD1.Font.glyphScale
	local w = 0
	for i = 1, #text do
		local gl = glyphs[ string.byte( text, i ) ]
		if gl then w = w + gl[ 6 ] * use end
	end
	return w
end

function COD1.DrawText( text, vx, vy, scale, r, g, b, a, shadow, align )
	local s = ScrH() / 480
	local ox = ScrW() / 2 - 320 * s
	local use = scale * COD1.Font.glyphScale
	local x = vx
	if align == "right" then x = vx - COD1.TextWidth( text, scale ) elseif align == "center" then x = vx - COD1.TextWidth( text, scale ) / 2 end
	for i = 1, #text do
		local gl = glyphs[ string.byte( text, i ) ]
		if gl then
			if gl[ 2 ] > 0 then
				local px, py = ox + ( x + gl[ 5 ] * use ) * s, ( vy - gl[ 4 ] * use ) * s
				local w, h = gl[ 2 ] * use * s, gl[ 3 ] * use * s
				surface.SetMaterial( pageMats[ gl[ 1 ] ] )
				if shadow then
					surface.SetDrawColor( 0, 0, 0, a )
					surface.DrawTexturedRectUV( px + s, py + s, w, h, gl[ 7 ], gl[ 8 ], gl[ 9 ], gl[ 10 ] )
				end
				surface.SetDrawColor( r, g, b, a )
				surface.DrawTexturedRectUV( px, py, w, h, gl[ 7 ], gl[ 8 ], gl[ 9 ], gl[ 10 ] )
			end
			x = x + gl[ 6 ] * use
		end
	end
end

local FRIENDLY = Material( "cod1/hud/friendlyfire" )

local function friendAhead()
	if COD1.CreditsPlaying then return end
	local tr = LocalPlayer():GetEyeTrace()
	local ent = tr.Entity
	if not IsValid( ent ) or ent:GetNWString( "COD1Team" ) ~= COD1.PlayerSide() or ent:GetNWBool( "COD1Dead" ) then return end
	if tr.StartPos:Distance( tr.HitPos ) > 2000 then return end
	return ent
end

hook.Add( "HUDShouldDraw", "COD1FriendCrosshair", function( name )
	if name == "CHudCrosshair" and friendAhead() then return false end
end )

hook.Add( "HUDPaint", "COD1FriendName", function()
	local ent = friendAhead()
	if not ent then return end
	local s = ScrH() / 480
	surface.SetMaterial( FRIENDLY )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawTexturedRect( ScrW() / 2 - 16 * s, ScrH() / 2 - 16 * s, 32 * s, 32 * s )
	local hp = ent:GetNWFloat( "COD1HP", 1 )
	local r, g
	if hp > 0.5 then r, g = ( 1 - hp ) * 2, 1 else r, g = 1, hp * 2 end
	COD1.DrawText( ent:GetNWString( "COD1Name" ), 345, 217, 1 / 3, r * 255, g * 255, 0, 255, true )
	COD1.DrawText( ent:GetNWString( "COD1Role" ), 345, 235, 1 / 3, 255, 255, 255, 178, true )
end )

local hint
net.Receive( "cod1_hint", function()
	local text, dur = net.ReadString(), net.ReadFloat()
	hint = { text = text, t0 = CurTime(), t1 = CurTime() + dur }
end )

hook.Add( "HUDPaint", "COD1Hint", function()
	if not hint or COD1.CreditsPlaying then return end
	local now = CurTime()
	if now > hint.t1 + 0.5 then hint = nil return end
	local a = math.Clamp( math.min( ( now - hint.t0 ) / 0.15, ( hint.t1 + 0.5 - now ) / 0.5 ), 0, 1 ) * 255
	COD1.DrawText( hint.text, 320, 330, 0.35, 255, 255, 255, a, true, "center" )
end )

--hud looks just like the real one, took forever to get the font right
