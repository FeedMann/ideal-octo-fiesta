local C = {
	panel = Color( 30, 29, 24 ),
	row = Color( 38, 36, 29 ),
	head = Color( 64, 61, 40 ),
	headHover = Color( 82, 78, 51 ),
	line = Color( 120, 108, 64 ),
	gold = Color( 232, 198, 112 ),
	text = Color( 228, 222, 200 ),
	dim = Color( 150, 143, 120 ),
	button = Color( 72, 68, 46 ),
	buttonHover = Color( 98, 92, 60 ),
	active = Color( 150, 120, 50 ),
}

surface.CreateFont( "COD1MenuHead", { font = "Trebuchet MS", size = 16, weight = 900, antialias = true } )
surface.CreateFont( "COD1MenuText", { font = "Tahoma", size = 13, weight = 500, antialias = true } )
surface.CreateFont( "COD1MenuSmall", { font = "Tahoma", size = 11, weight = 500, antialias = true } )

local BANNER = Material( "cod1/ui/banner.png", "smooth" )
local LOGO = Material( "cod1/ui/logo.png", "smooth" )
local STAR = Material( "cod1/ui/star16.png", "smooth" )

local PRESETS = {
	{ "Call of Duty", { cod1_npc_health = 100, cod1_npc_damage = 9, cod1_npc_accuracy = 1, cod1_npc_fair = 0 }, "Plays like the actual game. start here" },
	{ "Greenhorn", { cod1_npc_health = 100, cod1_npc_damage = 5, cod1_npc_accuracy = 0.7, cod1_npc_fair = 0 }, "They miss more and hurt less, good for a chill session" },
	{ "Veteran", { cod1_npc_health = 100, cod1_npc_damage = 14, cod1_npc_accuracy = 1.3, cod1_npc_fair = 0 }, "Keep your head down. seriously" },
	{ "Long battles", { cod1_npc_health = 250, cod1_npc_damage = 6, cod1_npc_accuracy = 0.6, cod1_npc_fair = 1 }, "Tanky guys and even sides so big npc battles actually last a while" },
}

local ALL = { "cod1_npc_health", "cod1_npc_damage", "cod1_npc_accuracy", "cod1_npc_fair", "cod1_npc_grenades", "cod1_npc_chatter", "cod1_geneva", "cod1_rescue",
	"cod1_rescue_chance", "cod1_rescue_recover", "cod1_npc_death_anims", "cod1_npc_ragdolls", "cod1_npc_corpse_sink", "cod1_npc_corpse_time",
	"cod1_npc_corpse_sink_time", "cod1_npc_max_bodies", "cod1_npc_blood_decals", "cod1_npc_drop_guns", "cod1_player_axis", "cod1_player_undercover", "cod1_npc_follow", "cod1_npc_ai", "cod1_npc_advance", "cod1_npc_hold_posts",
	"cod1_axis_hostile_players", "cod1_npc_hostile_players", "cod1_player_hands", "cod1_swep_damage", "cod1_artillery", "cod1_artillery_cooldown", "cod1_para_height", "cod1_para_chute_time",
	"cod1_eureka_variant", "cod1_eureka_count", "cod1_gunpass_recruits", "cod1_efx_quality", "cod1_efx_impacts", "cod1_efx_lights",
	"cod1_music_battle", "cod1_music_volume", "cod1_ambience_volume",
	"cod1mv_enable", "cod1mv_codonly", "cod1mv_footsteps", "cod1mv_bob", "cod1mv_hud", "cod1mv_codkeys" }

local tracked

local function track( cvar )
	if tracked and not table.HasValue( tracked, cvar ) then table.insert( tracked, cvar ) end
end

local function canEditServer()
	return game.SinglePlayer() or IsValid( LocalPlayer() ) and LocalPlayer():IsAdmin()
end

local function styleLabel( lbl, font, col )
	lbl:SetFont( font or "COD1MenuText" )
	lbl:SetTextColor( col or C.text )
end

local function note( body, text )
	local l = body:Add( "DLabel" )
	l:SetText( text )
	l:SetWrap( true )
	l:SetAutoStretchVertical( true )
	styleLabel( l, "COD1MenuSmall", C.dim )
	l:DockMargin( 0, 2, 0, 4 )
	return l
end

local function section( panel, title, open, server )
	local cat = vgui.Create( "DCollapsibleCategory" )
	cat:SetLabel( "" )
	cat:SetExpanded( open ~= false )
	cat.Header:SetTall( 24 )
	cat.Header.Paint = function( s, w, h )
		draw.RoundedBoxEx( 4, 0, 0, w, h, s:IsHovered() and C.headHover or C.head, true, true, not cat:GetExpanded(), not cat:GetExpanded() )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( STAR )
		surface.DrawTexturedRect( 6, 4, 16, 16 )
		draw.SimpleText( string.upper( title ), "COD1MenuHead", 28, h / 2, C.gold, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
		draw.SimpleText( cat:GetExpanded() and "-" or "+", "COD1MenuHead", w - 10, h / 2, C.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER )
	end
	cat.Paint = function( s, w, h )
		draw.RoundedBox( 4, 0, 0, w, h, C.panel )
	end
	local body = vgui.Create( "DListLayout" )
	body:DockPadding( 8, 6, 8, 8 )
	body.Paint = function() end
	cat:SetContents( body )
	panel:AddItem( cat )
	if server and not canEditServer() then
		note( body, "Only the host can change these" )
		body.Locked = true
	end
	return body
end

local function lock( body, pnl )
	if body.Locked then
		pnl:SetEnabled( false )
		pnl:SetAlpha( 110 )
	end
	return pnl
end

local function check( body, cvar, text, tip )
	track( cvar )
	local c = body:Add( "DCheckBoxLabel" )
	c:SetText( text )
	c:SetConVar( cvar )
	styleLabel( c.Label )
	c:DockMargin( 0, 3, 0, 3 )
	if tip then c:SetTooltip( tip ) end
	return lock( body, c )
end

local function styleSlider( s, tip )
	s:SetTall( 26 )
	styleLabel( s.Label )
	s.TextArea:SetTextColor( C.gold )
	if tip then s:SetTooltip( tip ) end
end

local function slider( body, cvar, text, min, max, dec, tip )
	track( cvar )
	local s = body:Add( "DNumSlider" )
	s:SetText( text )
	s:SetMinMax( min, max )
	s:SetDecimals( dec or 0 )
	s:SetConVar( cvar )
	styleSlider( s, tip )
	return lock( body, s )
end

local function percent( body, cvar, text, tip )
	track( cvar )
	local s = body:Add( "DNumSlider" )
	s:SetText( text )
	s:SetMinMax( 0, 100 )
	s:SetDecimals( 0 )
	s:SetValue( math.Round( GetConVar( cvar ):GetFloat() * 100 ) )
	s.OnValueChanged = function( _, v ) RunConsoleCommand( cvar, string.format( "%.2f", v / 100 ) ) end
	styleSlider( s, tip )
	return lock( body, s )
end

local function combo( body, text, choices, current, onPick, tip )
	local row = body:Add( "DPanel" )
	row:SetTall( 26 )
	row.Paint = function() end
	local lbl = vgui.Create( "DLabel", row )
	lbl:SetText( text )
	styleLabel( lbl )
	lbl:Dock( LEFT )
	lbl:SetWide( 110 )
	local cb = vgui.Create( "DComboBox", row )
	cb:Dock( FILL )
	cb:DockMargin( 0, 2, 0, 2 )
	for _, ch in ipairs( choices ) do cb:AddChoice( ch[ 1 ], ch[ 2 ], ch[ 2 ] == current ) end
	cb.OnSelect = function( _, _, _, data ) onPick( data ) end
	if tip then row:SetTooltip( tip ) end
	lock( body, cb )
	return cb
end

local function cvarCombo( body, cvar, text, choices, tip )
	track( cvar )
	return combo( body, text, choices, GetConVar( cvar ):GetString(), function( v ) RunConsoleCommand( cvar, v ) end, tip )
end

local function button( parent, text, onClick, tip, isActive )
	local b = vgui.Create( "DButton", parent )
	b:SetText( "" )
	b:SetTall( 26 )
	b.Paint = function( s, w, h )
		local on = isActive and isActive()
		local col = ( s:IsDown() or on ) and C.active or ( s:IsHovered() and s:IsEnabled() and C.buttonHover or C.button )
		draw.RoundedBox( 3, 0, 0, w, h, col )
		surface.SetDrawColor( on and C.gold or C.line )
		surface.DrawOutlinedRect( 0, 0, w, h )
		draw.SimpleText( text, "COD1MenuText", w / 2, h / 2, C.text, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	b.DoClick = onClick
	if tip then b:SetTooltip( tip ) end
	return b
end

local function buttonGrid( body, list )
	local grid = body:Add( "DPanel" )
	grid.Paint = function() end
	grid:SetTall( math.ceil( #list / 2 ) * 30 )
	grid.PerformLayout = function( s, w )
		for i, b in ipairs( s.Buttons ) do
			local col, row = ( i - 1 ) % 2, math.floor( ( i - 1 ) / 2 )
			local bw = ( i == #s.Buttons and #s.Buttons % 2 == 1 ) and w or ( w - 4 ) / 2
			b:SetPos( col * ( ( w - 4 ) / 2 + 4 ), row * 30 )
			b:SetSize( bw, 26 )
		end
	end
	grid.Buttons = {}
	for _, d in ipairs( list ) do
		table.insert( grid.Buttons, lock( body, button( grid, d[ 1 ], d[ 2 ], d[ 3 ], d[ 4 ] ) ) )
	end
	grid:DockMargin( 0, 4, 0, 2 )
	return grid
end

local function header( panel, title )
	local h = vgui.Create( "DPanel" )
	h:SetTall( 92 )
	h.Paint = function( s, w, hh )
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( BANNER )
		local bw = hh * 3.2
		surface.DrawTexturedRectUV( 0, 0, w, hh, 1 - math.min( w / bw, 1 ), 0, 1, 1 )
		surface.SetDrawColor( 0, 0, 0, 120 )
		surface.DrawRect( 0, 0, w, hh )
		surface.SetDrawColor( C.line )
		surface.DrawOutlinedRect( 0, 0, w, hh )
		draw.SimpleText( string.upper( title ), "COD1MenuSmall", w / 2, hh - 11, C.gold, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER )
	end
	local logo = vgui.Create( "DButton", h )
	logo:SetText( "" )
	logo:SetCursor( "arrow" )
	logo.Paint = function( s, w, hh )
		local lw = math.min( w - 20, 230 )
		local lh = lw * 0.237
		local k = math.max( 0, 1 - ( RealTime() - ( s.ShakeAt or -10 ) ) / 0.45 )
		local amp = ( s.ShakeAmp or 0 ) * k * k
		local ox = math.sin( RealTime() * 70 ) * amp
		local oy = math.cos( RealTime() * 53 ) * amp * 0.45
		local grow = 1 + 0.04 * amp / 6
		local dw, dh = lw * grow, lh * grow
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( LOGO )
		surface.DrawTexturedRect( ( w - dw ) / 2 + ox, ( hh - dh ) / 2 + oy, dw, dh )
		if ( s.Glow or 0 ) > 0 then
			surface.SetDrawColor( 232, 198, 112, 120 * s.Glow )
			surface.DrawTexturedRect( ( w - dw ) / 2 + ox, ( hh - dh ) / 2 + oy, dw, dh )
			s.Glow = math.max( 0, s.Glow - FrameTime() * 1.5 )
		end
	end
	logo.Clicks = {}
	logo.DoClick = function( s )
		local now = RealTime()
		table.insert( s.Clicks, now )
		while #s.Clicks > 0 and now - s.Clicks[ 1 ] > 2 do table.remove( s.Clicks, 1 ) end
		s.ShakeAt = now
		s.ShakeAmp = 2 + #s.Clicks * 2.5
		if #s.Clicks >= 3 and COD1.PlayCredits then
			s.Clicks = {}
			s.Glow = 1
			s.ShakeAmp = 10
			surface.PlaySound( "cod1/misc/equip_rifle02.wav" )
			timer.Simple( 0.45, function()
				if IsValid( g_SpawnMenu ) then g_SpawnMenu:Close() end
				COD1.PlayCredits()
			end )
		else
			surface.PlaySound( "cod1/misc/pu_weapon0" .. ( #s.Clicks == 1 and "1" or "3" ) .. ".wav" )
		end
	end
	h.PerformLayout = function( s, w, hh )
		logo:SetPos( 0, 4 )
		logo:SetSize( w, hh - 22 )
	end
	panel:AddItem( h )
end

local function presetActive( values )
	return function()
		for cvar, v in pairs( values ) do
			local cv = GetConVar( cvar )
			if not cv or math.abs( cv:GetFloat() - v ) > 0.001 then return false end
		end
		return true
	end
end

local function cleanupMode()
	if GetConVar( "cod1_npc_corpse_sink" ):GetBool() then return "sink" end
	return GetConVar( "cod1_npc_corpse_time" ):GetFloat() > 0 and "remove" or "keep"
end

local function battlefieldPage( panel )
	local p = section( panel, "Difficulty", true, true )
	local list = {}
	for _, pr in ipairs( PRESETS ) do
		list[ #list + 1 ] = { pr[ 1 ], function() for cvar, v in pairs( pr[ 2 ] ) do RunConsoleCommand( cvar, tostring( v ) ) end end, pr[ 3 ], presetActive( pr[ 2 ] ) }
	end
	buttonGrid( p, list )
	slider( p, "cod1_npc_health", "Health", 1, 500, 0, "How much a guy can take before he goes down. 100 is normal" )
	slider( p, "cod1_npc_damage", "Bullet damage", 1, 50, 0, "Basically rifle damage, MGs and pistols scale off this" )
	slider( p, "cod1_npc_accuracy", "Aim", 0.2, 2, 2, "Lower = stormtroopers, higher = they will ruin your day" )
	check( p, "cod1_npc_fair", "Even sides", "In the real game your side gets a small edge (aims faster, ducks more). Tick this to make it fair" )

	local s = section( panel, "Soldiers", true, true )
	cvarCombo( s, "cod1_npc_ai", "AI", { { "Advanced", "advanced" }, { "Call of Duty 1", "cod1" } }, "Advanced = squads that cover eachother, flank, clear rooms and pull back when it goes bad. Call of Duty 1 = like the original, they grab the closest cover near where you put them and fight from there" )
	check( s, "cod1_npc_grenades", "Throw grenades", "Turn off if you are tired of getting nade spammed" )
	cvarCombo( s, "cod1_npc_advance", "Advance", { { "Both sides attack", "1" }, { "Only my side attacks", "2" }, { "Only the enemy attacks", "3" },
		{ "Hold where placed", "0" } }, "Who does the pushing. Guys who know where the enemy is move up cover to cover, like an assault in the campaign" )
	check( s, "cod1_npc_hold_posts", "Hold strong spots", "Put a guy in a building, on a roof or behind a wall and he stays there and fights from the windows instead of running off with everyone else. If a nade flushes him out he goes back after" )
	check( s, "cod1_npc_chatter", "Battle chatter", "\"Grenade!\", \"Cover me!\" and all the other yelling" )
	check( s, "cod1_geneva", "Geneva Convention", "Lord help me get one more" )
	local wounded = check( s, "cod1_rescue", "Wounded soldiers", "Some hits drop a guy instead of killing him and a buddy drags him into cover. Off = dead is dead" )
	local chance = percent( s, "cod1_rescue_chance", "Chance to go down (%)", "Headshots and big explosions always kill no matter what" )
	local recover = slider( s, "cod1_rescue_recover", "Gets back up after (s)", 5, 180, 0, "Unless a medic gets to him first" )
	local function syncWounded( on )
		for _, c in ipairs( { chance, recover } ) do
			if not s.Locked then
				c:SetEnabled( on )
				c:SetAlpha( on and 255 or 110 )
			end
		end
	end
	syncWounded( GetConVar( "cod1_rescue" ):GetBool() )
	local old = wounded.OnChange
	wounded.OnChange = function( self, v )
		if old then old( self, v ) end
		syncWounded( v )
	end

	local d = section( panel, "Bodies", false, true )
	track( "cod1_npc_death_anims" )
	track( "cod1_npc_ragdolls" )
	local anims, rag = GetConVar( "cod1_npc_death_anims" ):GetBool(), GetConVar( "cod1_npc_ragdolls" ):GetBool()
	local deathBox
	local function applyDeath( v )
		RunConsoleCommand( "cod1_npc_death_anims", v == "c" and "0" or "1" )
		RunConsoleCommand( "cod1_npc_ragdolls", v == "b" and "0" or "1" )
	end
	deathBox = combo( d, "When killed", { { "Death animation", "b" }, { "Animation, then ragdoll", "a" }, { "Ragdoll", "c" } },
		not anims and "c" or ( rag and "a" or "b" ), function( v )
			if v == "b" then applyDeath( v ) return end
			Derma_Query( "Heads up, ragdolls can still stretch out or sink into the floor sometimes. The death animations look alot better imo", "Ragdolls",
				"Use ragdolls", function() applyDeath( v ) end,
				"Keep animations", function() applyDeath( "b" ) if IsValid( deathBox ) then deathBox:ChooseOptionID( 1 ) end end )
		end )
	track( "cod1_npc_corpse_sink" )
	track( "cod1_npc_corpse_time" )
	track( "cod1_npc_corpse_sink_time" )
	local after
	local function syncAfter()
		if not IsValid( after ) then return end
		local mode = cleanupMode()
		after:SetEnabled( mode ~= "keep" and not d.Locked )
		after:SetAlpha( mode ~= "keep" and not d.Locked and 255 or 110 )
		after:SetValue( GetConVar( mode == "sink" and "cod1_npc_corpse_sink_time" or "cod1_npc_corpse_time" ):GetFloat() )
	end
	combo( d, "Clean up", { { "Keep them", "keep" }, { "Remove after a while", "remove" }, { "Sink into the ground", "sink" } }, cleanupMode(), function( v )
		local t = math.max( IsValid( after ) and after:GetValue() or 60, 10 )
		RunConsoleCommand( "cod1_npc_corpse_sink", v == "sink" and "1" or "0" )
		RunConsoleCommand( "cod1_npc_corpse_time", v == "remove" and tostring( math.Round( t ) ) or "0" )
		if v == "sink" then RunConsoleCommand( "cod1_npc_corpse_sink_time", tostring( math.Round( t ) ) ) end
		timer.Simple( 0.1, syncAfter )
	end )
	after = d:Add( "DNumSlider" )
	after:SetText( "After (s)" )
	after:SetMinMax( 10, 600 )
	after:SetDecimals( 0 )
	styleSlider( after )
	after.OnValueChanged = function( _, v )
		local mode = cleanupMode()
		if mode == "keep" then return end
		RunConsoleCommand( mode == "sink" and "cod1_npc_corpse_sink_time" or "cod1_npc_corpse_time", tostring( math.Round( v ) ) )
	end
	syncAfter()
	slider( d, "cod1_npc_max_bodies", "Most bodies kept", 0, 100, 0, "0 = no limit (your fps might not like that)" )
	check( d, "cod1_npc_blood_decals", "Blood on walls", "Blood splats on walls and floors when someone gets hit" )
	check( d, "cod1_npc_drop_guns", "Drop guns on death", "They let go of there gun when they die, walk over it to pick it up" )

	local m = section( panel, "Map setup", false, true )
	buttonGrid( m, {
		{ "Build navmesh", function() RunConsoleCommand( "cod1_nav_generate" ) end, "Game freezes for a bit while it builds, dont panic" },
		{ "Rebuild cover spots", function() RunConsoleCommand( "cod1_nodes_rebuild" ) end },
		{ "Show cover spots", function() RunConsoleCommand( "developer", "1" ) RunConsoleCommand( "cod1_nodes_show" ) end },
	} )
	note( m, "Soldiers need a navmesh to walk around. You only have to build it once per map" )
end

local function playerPage( panel )
	local sd = section( panel, "Your side", true, true )
	cvarCombo( sd, "cod1_player_axis", "I fight for", { { "The Allies", "0" }, { "The Germans", "1" } } )
	check( sd, "cod1_player_undercover", "Undercover", "Germans think your one of them. Shoot anywhere near them and its over" )
	check( sd, "cod1_npc_follow", "Soldiers follow me when I press E", "Press E on a guy from your side and he tags along" )
	check( sd, "cod1_axis_hostile_players", "Enemies shoot at players" )
	check( sd, "cod1_npc_hostile_players", "My own side shoots at players" )

	local w = section( panel, "Weapons", true, true )
	cvarCombo( w, "cod1_player_hands", "Arms", { { "Match my side", "auto" }, { "US Airborne", "us" }, { "US Airborne (winter)", "uswinter" },
		{ "British commando", "british" }, { "British paratrooper", "british_air" }, { "Russian", "russian" }, { "Wehrmacht", "whermact" },
		{ "Waffen-SS", "waffen" }, { "Fallschirmjäger", "fallschirmjager" } } )
	slider( w, "cod1_swep_damage", "Damage", 0.1, 3, 2, "1 = same as the real game" )
	check( w, "cod1_artillery", "Binocular artillery", "Look through the binoculars and click, a fire mission lands where your looking. just like UO multiplayer" )
	slider( w, "cod1_artillery_cooldown", "Artillery cooldown (s)", 10, 180, 0, "How long till you can call it again" )
	note( w, "For melee bind a key to cod1_melee" )
end

local function movementPage( panel )
	local m = section( panel, "Movement", true, true )
	check( m, "cod1mv_enable", "Call of Duty movement", "Stand, crouch, prone, lean and sprint like in the game" )
	check( m, "cod1mv_codonly", "Only with Call of Duty weapons", "Turns it off when your holding something else" )
	check( m, "cod1mv_footsteps", "Footstep sounds", "Different sound for every ground, plus the gear rattle" )

	local v = section( panel, "Your view", true )
	check( v, "cod1mv_bob", "View and weapon bob" )
	check( v, "cod1mv_hud", "Stance icon" )
	check( v, "cod1mv_codkeys", "Call of Duty keys" )
	note( v, "Alt sprint, Shift melee, Q / E lean, F use, Ctrl prone, C crouch, Space to stand up. The physgun, toolgun and camera keep the normal keys." )
	note( v, "Off by default so Q, C and E still open your menus. With it off Shift sprints, Ctrl crouches and you bind the rest yourself: +cod1mv_leanleft, +cod1mv_leanright, cod1mv_goprone" )
end

local function reinforcementsPage( panel )
	local r = section( panel, "Call in", true, true )
	buttonGrid( r, {
		{ "US paradrop", function() RunConsoleCommand( "cod1_paradrop", "6", "airborne_summer" ) end, "6 guys come down wherever you're looking" },
		{ "British paradrop", function() RunConsoleCommand( "cod1_paradrop", "6", "british_para" ) end, "Same thing but brits" },
		{ "German paradrop", function() RunConsoleCommand( "cod1_paradrop", "6", "german_fallschirm" ) end, "Fallschirmjäger, also 6, also where you look" },
		{ "Stalingrad charge", function() RunConsoleCommand( "cod1_stalingrad" ) end, "Commissar, flag guy, some riflemen and a bunch of conscripts with no rifles. you know the one" },
	} )

	local p = section( panel, "Paratroopers", true, true )
	slider( p, "cod1_para_height", "Jump height", 300, 3000, 0, "How high up they jump from" )
	slider( p, "cod1_para_chute_time", "Remove parachutes after (s)", 0, 600, 0, "0 = never" )
	cvarCombo( p, "cod1_eureka_variant", "C-47 drops", { { "US Airborne", "airborne_summer" }, { "US Airborne (winter)", "airborne_winter" },
		{ "British paratroopers", "british_para" }, { "Fallschirmjäger", "german_fallschirm" } }, "Put a Eureka beacon down (its in the Entities tab) and a C-47 flies over and drops them on it" )
	slider( p, "cod1_eureka_count", "Men per pass", 1, 16, 0, "How many jump out each time the plane goes over" )

	local g = section( panel, "Supply station", true, true )
	slider( g, "cod1_gunpass_recruits", "Conscripts it brings", 0, 60, 0, "They line up for a rifle or a clip. One gets the rifle, the other gets the ammo. 0 = only the ones you spawn yourself" )
end

local function nowPlaying( body )
	local M = COD1.MusicPlayer
	local row = body:Add( "DPanel" )
	row:SetTall( 26 )
	row.Paint = function( s, w, h )
		local cur = M.Current()
		draw.RoundedBox( 3, 0, 0, w, h, C.row )
		draw.SimpleText( cur and ( "Now playing: " .. ( cur.title or "?" ) ) or "Nothing playing", "COD1MenuSmall", 8, h / 2, cur and C.gold or C.dim,
			TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
	end
	local stop = button( row, "Stop", function() M.Stop( 1 ) end )
	row.PerformLayout = function( s, w, h ) stop:SetPos( w - 60, 3 ) stop:SetSize( 56, h - 6 ) end
	row:DockMargin( 0, 2, 0, 4 )
end

local function effectsPage( panel )
	local e = section( panel, "Effects" )
	cvarCombo( e, "cod1_efx_quality", "Detail", { { "Low", "0" }, { "Like the game", "1" }, { "High", "2" } }, "Muzzle flashes, impacts, explosions, fire, smoke. Turn it down if your pc is struggling" )
	cvarCombo( e, "cod1_efx_impacts", "Bullet impacts", { { "Call of Duty", "1" }, { "Garry's Mod", "2" }, { "Off", "0" } }, "Bullet holes stay either way" )
	check( e, "cod1_efx_lights", "Muzzle flashes light up the area" )

	local m = section( panel, "Music & voice" )
	check( m, "cod1_music_battle", "Battle music", "Kicks in when a firefight starts near you" )
	percent( m, "cod1_music_volume", "Music volume (%)" )
	percent( m, "cod1_ambience_volume", "Map ambience (%)", "The background noise on the Call of Duty maps" )

	local j = section( panel, "Battle mussic", false )
	nowPlaying( j )
	local list = j:Add( "DScrollPanel" )
	list:SetTall( 170 )
	list:DockMargin( 0, 2, 0, 4 )
	list.Paint = function( s, w, h ) draw.RoundedBox( 3, 0, 0, w, h, C.row ) end
	local M = COD1.MusicPlayer
	for i, t in ipairs( COD1.Music or {} ) do
		local b = list:Add( "DButton" )
		b:Dock( TOP )
		b:SetTall( 20 )
		b:SetText( "" )
		b.Paint = function( s, w, h )
			local cur = M.Current()
			local playing = cur and cur.file == t.file
			if playing then draw.RoundedBox( 2, 2, 1, w - 4, h - 2, C.head ) elseif s:IsHovered() then draw.RoundedBox( 2, 2, 1, w - 4, h - 2, C.button ) end
			draw.SimpleText( ( playing and "> " or "   " ) .. t.title, "COD1MenuSmall", 6, h / 2, playing and C.gold or C.text, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER )
			draw.SimpleText( t.mood, "COD1MenuSmall", w - 8, h / 2, C.dim, TEXT_ALIGN_RIGHT, TEXT_ALIGN_CENTER )
		end
		b.DoClick = function() M.PlayTrack( i ) end
	end
	local auto = j:Add( "DCheckBoxLabel" )
	auto:SetText( "Keep playing" )
	auto:SetValue( M.autoNext and 1 or 0 )
	auto.OnChange = function( _, v ) M.autoNext = v end
	styleLabel( auto.Label )
	buttonGrid( j, { { "Shuffle", function() M.autoNext = true M.PlayTrack( math.random( #COD1.Music ) ) end } } )
end

local PAGES = {
	{ "cod1_page_ai", "NPC AI", battlefieldPage, true },
	{ "cod1_page_effects", "Effects & Sound", effectsPage },
	{ "cod1_page_player", "Player", playerPage },
	{ "cod1_page_movement", "Movement", movementPage },
	{ "cod1_page_reinforcements", "Reinforcements", reinforcementsPage },
}

local function resetList( cvars )
	for _, name in ipairs( cvars ) do
		local cv = GetConVar( name )
		if cv then RunConsoleCommand( name, cv:GetDefault() ) end
	end
end

local buildPage

local function footer( panel, page, cvars )
	local f = vgui.Create( "DPanel" )
	f.Paint = function() end
	local items = {}
	if #cvars > 0 then
		items[ #items + 1 ] = button( f, "Reset this page", function()
			resetList( cvars )
			timer.Simple( 0.3, function() if IsValid( panel ) then buildPage( panel, page ) end end )
		end )
	end
	if page[ 4 ] then
		items[ #items + 1 ] = button( f, "Reset everything", function()
			Derma_Query( "Put every setting back to default? cant undo this", "Reset everything", "Reset", function()
				resetList( ALL )
				timer.Simple( 0.3, function() if IsValid( panel ) then buildPage( panel, page ) end end )
			end, "Cancel" )
		end )
	end
	f:SetTall( #items * 30 + 4 )
	f.PerformLayout = function( s, w )
		for i, b in ipairs( items ) do b:SetPos( 0, 4 + ( i - 1 ) * 30 ) b:SetSize( w, 26 ) end
	end
	panel:AddItem( f )
end

buildPage = function( panel, page )
	panel:Clear()
	header( panel, page[ 2 ] )
	tracked = {}
	page[ 3 ]( panel )
	local cvars = tracked
	tracked = nil
	footer( panel, page, cvars )
end

hook.Add( "PopulateToolMenu", "COD1NPCSettings", function()
	for _, page in ipairs( PAGES ) do
		spawnmenu.AddToolMenuOption( "Utilities", "Call of Duty 1", page[ 1 ], page[ 2 ], "", "", function( panel ) buildPage( panel, page ) end )
	end
end )

hook.Add( "AddToolMenuCategories", "COD1NPCSettings", function()
	spawnmenu.AddToolCategory( "Utilities", "Call of Duty 1", "Call of Duty 1" )
end )

--if you are reading this you found the settings code, congrats soldier
