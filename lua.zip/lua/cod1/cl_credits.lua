local SHIFT = Vector( 7700, 20350, 0 )
local SUN = Vector( 0.579, 0.579, 0.574 )
local DIM = Color( 170, 162, 140 )
local MAXTRI = 8000
local FX_MAT = {}
local function fxMat( name )
	FX_MAT[ name ] = FX_MAT[ name ] or Material( name )
	return FX_MAT[ name ]
end

local S, Set

local function P( x, y, z )
	return Vector( x + SHIFT.x, y + SHIFT.y, z or 0 )
end

local function ease( k )
	k = math.Clamp( k, 0, 1 )
	return k * k * ( 3 - 2 * k )
end

local function rot( v, yaw )
	local r = math.rad( yaw )
	local c, s = math.cos( r ), math.sin( r )
	return Vector( v.x * c - v.y * s, v.x * s + v.y * c, v.z )
end

local function nums( s )
	local t, n = {}, 0
	for v in string.gmatch( s, "%S+" ) do
		n = n + 1
		t[ n ] = tonumber( v )
	end
	return t
end

local function loadData()
	if not COD1.CreditsSet then include( "cod1/credits_set.lua" ) end
	if not COD1.CineData then include( "cod1/cine_data.lua" ) end
	if not COD1.CreditsScript then include( "cod1/credits_script.lua" ) end
	return COD1.CreditsSet ~= nil and COD1.CineData ~= nil and COD1.CreditsScript ~= nil
end

local function seqData( name )
	return COD1.CineData.seq[ name ] or { dur = 1, notes = {} }
end

local function addMeshes( list, mat, v, idx, stride, put, model )
	local total = #idx
	local s = 1
	while s <= total do
		local e = math.min( total, s + MAXTRI * 3 - 1 )
		local m = Mesh( mat )
		mesh.Begin( m, MATERIAL_TRIANGLES, ( e - s + 1 ) / 3 )
		for k = s, e do
			put( v, idx[ k ] * stride )
			mesh.AdvanceVertex()
		end
		mesh.End()
		list[ #list + 1 ] = { mat = mat, mesh = m, model = model }
		s = e + 1
		coroutine.yield()
	end
end

local function addGround( v, idx, stride, model, surf )
	local cells = Set.ground
	for k = 1, #idx, 3 do
		local a, b, c = idx[ k ] * stride, idx[ k + 1 ] * stride, idx[ k + 2 ] * stride
		local ax, ay, az = v[ a + 1 ] + SHIFT.x, v[ a + 2 ] + SHIFT.y, v[ a + 3 ]
		local bx, by, bz = v[ b + 1 ] + SHIFT.x, v[ b + 2 ] + SHIFT.y, v[ b + 3 ]
		local cx, cy, cz = v[ c + 1 ] + SHIFT.x, v[ c + 2 ] + SHIFT.y, v[ c + 3 ]
		local nx = ( by - ay ) * ( cz - az ) - ( bz - az ) * ( cy - ay )
		local ny = ( bz - az ) * ( cx - ax ) - ( bx - ax ) * ( cz - az )
		local nz = ( bx - ax ) * ( cy - ay ) - ( by - ay ) * ( cx - ax )
		local len = math.sqrt( nx * nx + ny * ny + nz * nz )
		if len > 1e-6 and math.abs( nz ) / len > 0.3 then
			local tri = { ax, ay, az, bx, by, bz, cx, cy, cz, model, surf }
			for gx = math.floor( math.min( ax, bx, cx ) / 256 ), math.floor( math.max( ax, bx, cx ) / 256 ) do
				for gy = math.floor( math.min( ay, by, cy ) / 256 ), math.floor( math.max( ay, by, cy ) / 256 ) do
					local key = ( gx + 128 ) * 1024 + gy + 128
					cells[ key ] = cells[ key ] or {}
					table.insert( cells[ key ], tri )
				end
			end
		end
	end
end

local function groundZ( x, y, below )
	local cell = Set and Set.ground[ ( math.floor( x / 256 ) + 128 ) * 1024 + math.floor( y / 256 ) + 128 ]
	if not cell then return nil end
	local best, surf
	local hidden = Set.hidden
	below = below or math.huge
	for _, t in ipairs( cell ) do
		local x1, y1, x2, y2, x3, y3 = t[ 1 ], t[ 2 ], t[ 4 ], t[ 5 ], t[ 7 ], t[ 8 ]
		local det = ( y2 - y3 ) * ( x1 - x3 ) + ( x3 - x2 ) * ( y1 - y3 )
		if math.abs( det ) > 1e-9 and not ( t[ 10 ] and hidden[ t[ 10 ] ] ) then
			local l1 = ( ( y2 - y3 ) * ( x - x3 ) + ( x3 - x2 ) * ( y - y3 ) ) / det
			local l2 = ( ( y3 - y1 ) * ( x - x3 ) + ( x1 - x3 ) * ( y - y3 ) ) / det
			local l3 = 1 - l1 - l2
			if l1 >= -0.001 and l2 >= -0.001 and l3 >= -0.001 then
				local z = l1 * t[ 3 ] + l2 * t[ 6 ] + l3 * t[ 9 ]
				if z <= below and ( not best or z > best ) then best, surf = z, t[ 11 ] end
			end
		end
	end
	return best, surf
end

local function onGround( v, below )
	local z = groundZ( v.x, v.y, below or ( v.z + 40 ) )
	return Vector( v.x, v.y, z or v.z )
end

local function lightAt( pos )
	local g = Set.light
	local fx, fy = ( pos.x - SHIFT.x - g.x0 ) / g.step, ( pos.y - SHIFT.y - g.y0 ) / g.step
	local i, j = math.Clamp( math.floor( fx ), 0, g.w - 2 ), math.Clamp( math.floor( fy ), 0, g.h - 2 )
	local tx, ty = math.Clamp( fx - i, 0, 1 ), math.Clamp( fy - j, 0, 1 )
	local function at( a, b, k ) return g.data[ ( b * g.w + a ) * 3 + k ] end
	local out = Vector()
	for k = 1, 3 do
		local top = Lerp( tx, at( i, j, k ), at( i + 1, j, k ) )
		local bot = Lerp( tx, at( i, j + 1, k ), at( i + 1, j + 1, k ) )
		out[ k ] = Lerp( ty, top, bot )
	end
	return out
end

local SURFACE = { grass = "grass", dirt = "dirt", mud = "mud", gravel = "dirt", sand = "dirt", rock = "stone", concrete = "stone",
	brick = "stone", plaster = "stone", asphalt = "stone", stone = "stone", paper = "stone", wood = "wood", metal = "metal", water = "water",
	foliage = "leaves", leaves = "leaves", carpet = "carpet", glass = "glass", snow = "snow" }

local function surfaceOf( name )
	local file = string.match( name or "", "([^/]+)$" ) or ""
	return SURFACE[ string.match( file, "^(%a+)_" ) or "" ] or "dirt"
end

local function buildSet()
	local D = COD1.CreditsSet
	Set = { mats = {}, lms = {}, albedo = {}, overlay = {}, light = {}, lmPass = {}, decal = {}, masked = {}, models = {}, ground = {}, hidden = {} }
	for i, name in ipairs( D.materials ) do Set.mats[ i ] = Material( name ) end
	for i, name in ipairs( D.lightmaps ) do Set.lms[ i ] = Material( name ) end
	local g = D.lightgrid
	Set.light = { x0 = g.x0, y0 = g.y0, step = g.step, w = g.w, h = g.h, data = {} }
	local data, n = Set.light.data, 0
	for k = 1, #g.data, 2 do
		n = n + 1
		data[ n ] = tonumber( string.sub( g.data, k, k + 1 ), 16 ) / 255
	end
	coroutine.yield()
	local sx, sy = SHIFT.x, SHIFT.y
	for _, b in ipairs( D.batches ) do
		local v, idx = nums( b.v ), nums( b.i )
		local mat = Set.mats[ b.mat ]
		if D.materials[ b.mat ] == "cod1/credits/black" then
			addGround( v, idx, 7, nil, "dirt" )
		elseif b.kind == "solid" then
			addMeshes( Set.albedo, mat, v, idx, 7, function( t, o )
				mesh.Position( Vector( t[ o + 1 ] + sx, t[ o + 2 ] + sy, t[ o + 3 ] ) )
				mesh.TexCoord( 0, t[ o + 4 ], t[ o + 5 ] )
				mesh.Color( 255, 255, 255, 255 )
			end, b.model )
			if b.lm then
				addMeshes( Set.lmPass, Set.lms[ b.lm ], v, idx, 7, function( t, o )
					mesh.Position( Vector( t[ o + 1 ] + sx, t[ o + 2 ] + sy, t[ o + 3 ] ) )
					mesh.TexCoord( 0, t[ o + 6 ], t[ o + 7 ] )
					mesh.Color( 255, 255, 255, 255 )
				end, b.model )
			end
			addGround( v, idx, 7, b.model, surfaceOf( D.materials[ b.mat ] ) )
		elseif b.kind == "overlay" then
			addMeshes( Set.overlay, mat, v, idx, 6, function( t, o )
				mesh.Position( Vector( t[ o + 1 ] + sx, t[ o + 2 ] + sy, t[ o + 3 ] ) )
				mesh.TexCoord( 0, t[ o + 4 ], t[ o + 5 ] )
				mesh.Color( 255, 255, 255, t[ o + 6 ] * 255 )
			end, b.model )
		elseif b.kind == "decal" then
			addMeshes( Set.decal, mat, v, idx, 9, function( t, o )
				mesh.Position( Vector( t[ o + 1 ] + sx, t[ o + 2 ] + sy, t[ o + 3 ] ) )
				mesh.TexCoord( 0, t[ o + 4 ], t[ o + 5 ] )
				mesh.Color( math.min( t[ o + 6 ] * 255, 255 ), math.min( t[ o + 7 ] * 255, 255 ), math.min( t[ o + 8 ] * 255, 255 ), t[ o + 9 ] * 255 )
			end, b.model )
		else
			addMeshes( Set.masked, mat, v, idx, 8, function( t, o )
				mesh.Position( Vector( t[ o + 1 ] + sx, t[ o + 2 ] + sy, t[ o + 3 ] ) )
				mesh.TexCoord( 0, t[ o + 4 ], t[ o + 5 ] )
				local r, g, b = t[ o + 6 ], t[ o + 7 ], t[ o + 8 ]
				local m = math.max( r, g, b )
				local k = m < 0.3 and ( m > 0.02 and 0.3 / m or 0 ) or 1
				if k == 0 then r, g, b, k = 0.28, 0.28, 0.3, 1 end
				mesh.Color( math.min( r * k * 255, 255 ), math.min( g * k * 255, 255 ), math.min( b * k * 255, 255 ), 255 )
			end, b.model )
		end
	end
	local parts = {}
	for mi, m in ipairs( D.models ) do
		parts[ mi ] = {}
		for pi, p in ipairs( m.parts ) do
			parts[ mi ][ pi ] = { mat = p.mat, v = nums( p.v ), i = nums( p.i ), foliage = string.find( D.materials[ p.mat ], "foliage", 1, true ) ~= nil }
		end
	end
	local inst = nums( D.instances )
	local groups = {}
	for k = 1, #inst, 11 do
		local id = inst[ k ]
		local p, y, r = math.rad( inst[ k + 4 ] ), math.rad( inst[ k + 5 ] ), math.rad( inst[ k + 6 ] )
		local cp, sp, cy, sy2, cr, sr = math.cos( p ), math.sin( p ), math.cos( y ), math.sin( y ), math.cos( r ), math.sin( r )
		local R = { cy * cp, cy * sp * sr - sy2 * cr, cy * sp * cr + sy2 * sr, sy2 * cp, sy2 * sp * sr + cy * cr, sy2 * sp * cr - cy * sr, -sp, cp * sr, cp * cr }
		local l = Vector( inst[ k + 8 ], inst[ k + 9 ], inst[ k + 10 ] )
		local lm = math.max( l.x, l.y, l.z )
		if lm < 0.32 then l = lm > 0.02 and l * ( 0.32 / lm ) or Vector( 0.3, 0.3, 0.33 ) end
		local e = { o = Vector( inst[ k + 1 ] + sx, inst[ k + 2 ] + sy, inst[ k + 3 ] ), R = R, s = inst[ k + 7 ], l = l }
		for _, part in ipairs( parts[ id ] or {} ) do
			groups[ part.mat ] = groups[ part.mat ] or {}
			table.insert( groups[ part.mat ], { part = part, e = e } )
		end
	end
	coroutine.yield()
	for mat, list in pairs( groups ) do
		local batch, tris = {}, 0
		local function flush()
			if tris == 0 then return end
			local m = Mesh( Set.mats[ mat ] )
			mesh.Begin( m, MATERIAL_TRIANGLES, tris )
			for _, it in ipairs( batch ) do
				local v, idx, e, boost = it.part.v, it.part.i, it.e, it.part.foliage and 1.25 or 1.05
				local R, s, o = e.R, e.s, e.o
				for _, ix in ipairs( idx ) do
					local b = ix * 8
					local x, y, z = v[ b + 1 ] * s, v[ b + 2 ] * s, v[ b + 3 ] * s
					local nx, ny, nz = v[ b + 4 ], v[ b + 5 ], v[ b + 6 ]
					local wnx, wny, wnz = R[ 1 ] * nx + R[ 2 ] * ny + R[ 3 ] * nz, R[ 4 ] * nx + R[ 5 ] * ny + R[ 6 ] * nz, R[ 7 ] * nx + R[ 8 ] * ny + R[ 9 ] * nz
					local k = ( 0.78 + 0.42 * math.max( 0, wnx * SUN.x + wny * SUN.y + wnz * SUN.z ) ) * boost * 255
					mesh.Position( Vector( o.x + R[ 1 ] * x + R[ 2 ] * y + R[ 3 ] * z, o.y + R[ 4 ] * x + R[ 5 ] * y + R[ 6 ] * z, o.z + R[ 7 ] * x + R[ 8 ] * y + R[ 9 ] * z ) )
					mesh.TexCoord( 0, v[ b + 7 ], v[ b + 8 ] )
					mesh.Color( math.min( e.l.x * k, 255 ), math.min( e.l.y * k, 255 ), math.min( e.l.z * k, 255 ), 255 )
					mesh.AdvanceVertex()
				end
			end
			mesh.End()
			Set.models[ #Set.models + 1 ] = { mat = Set.mats[ mat ], mesh = m }
			batch, tris = {}, 0
			coroutine.yield()
		end
		for _, it in ipairs( list ) do
			local n = #it.part.i / 3
			if tris + n > MAXTRI then flush() end
			batch[ #batch + 1 ] = it
			tris = tris + n
		end
		flush()
	end
	Set.ready = true
end

local function destroySet()
	if not Set then return end
	for _, list in ipairs( { Set.albedo, Set.overlay, Set.lmPass, Set.decal, Set.masked, Set.models } ) do
		for _, m in ipairs( list ) do
			if m.mesh then m.mesh:Destroy() end
		end
	end
	Set = nil
end

local Actor = {}
Actor.__index = Actor

local function setGroup( ent, name, value )
	local id = ent:FindBodygroupByName( name )
	if id and id >= 0 then ent:SetBodygroup( id, value ) end
end

local function newActor( model, groups, skin )
	local a = setmetatable( {}, Actor )
	a.drv = ClientsideModel( "models/cod1/cine/driver2.mdl", RENDERGROUP_OPAQUE )
	a.drv:SetNoDraw( true )
	a.vis = ClientsideModel( model, RENDERGROUP_OPAQUE )
	a.vis:SetNoDraw( true )
	a.vis:SetParent( a.drv )
	a.vis:AddEffects( EF_BONEMERGE )
	for name, value in pairs( groups or {} ) do setGroup( a.vis, name, value ) end
	a.vis:SetSkin( skin or 0 )
	a.pos, a.yaw = Vector(), 0
	a.seq, a.t0, a.rate, a.loop = "idle", 0, 1, true
	a.visible = true
	a.bones = {}
	S.actors[ #S.actors + 1 ] = a
	a:Play( "idle", { loop = true } )
	return a
end

function Actor:Bone( name )
	local id = self.bones[ name ]
	if id == nil then
		id = self.drv:LookupBone( name ) or -1
		self.bones[ name ] = id
	end
	if id < 0 then return self.pos end
	local m = self.drv:GetBoneMatrix( id )
	return m and m:GetTranslation() or self.pos
end

function Actor:Play( name, opt )
	opt = opt or {}
	self.seq = name
	self.dur = math.max( seqData( name ).dur or 1, 0.05 )
	self.rate = opt.rate or 1
	self.loop = opt.loop == true
	self.hold = opt.hold
	self.t0 = S.t - ( opt.from or 0 ) * self.dur / self.rate
	self.seqId = self.drv:LookupSequence( name )
	self.notes = {}
	for _, n in ipairs( seqData( name ).notes or {} ) do self.notes[ #self.notes + 1 ] = { n[ 1 ], n[ 2 ] } end
	self.onNote = opt.onNote
	self.lastEl = nil
end

function Actor:Cycle()
	if self.hold then return self.hold end
	local c = ( S.t - self.t0 ) * self.rate / self.dur
	if self.loop then return c % 1 end
	return math.Clamp( c, 0, 1 )
end

function Actor:Elapsed()
	return ( S.t - self.t0 ) * self.rate
end

function Actor:Done()
	return not self.loop and self:Elapsed() >= self.dur
end

function Actor:Settle()
	local f = seqData( self.seq ).finish
	if not f then return end
	self.pos = onGround( self.pos + rot( f.pos, self.yaw ), self.pos.z + 40 )
	self.yaw = self.yaw + f.yaw
	self.snap = true
end

function Actor:Place( pos, yaw )
	self.pos = pos
	if yaw then self.yaw = yaw end
end

function Actor:Pose()
	self.drv:SetPos( self.pos + Vector( 0, 0, self.zoff or 0 ) + ( self.toff or vector_origin ) )
	self.drv:SetAngles( Angle( 0, self.yaw, 0 ) )
	local changed = self.seqId and self.seqId >= 0 and self.drv:GetSequence() ~= self.seqId
	local snap = changed and self.snap
	if snap then self.drv:AddEffects( EF_NOINTERP ) end
	if changed then self.drv:SetSequence( self.seqId ) end
	self.drv:SetCycle( self:Cycle() )
	self.drv:SetPlaybackRate( 0 )
	self.drv:InvalidateBoneCache()
	self.drv:SetupBones()
	if snap then
		self.drv:RemoveEffects( EF_NOINTERP )
		self.snap = nil
	end
	local el = self:Elapsed()
	if self.loop and not self.hold then
		local prev = self.lastEl or el
		local d = self.dur
		if el > prev and d > 0 then
			local c0, c1 = prev % d, el % d
			local wrapped = math.floor( el / d ) > math.floor( prev / d )
			for _, n in ipairs( seqData( self.seq ).notes or {} ) do
				local t = n[ 2 ]
				if ( wrapped and ( t > c0 or t <= c1 ) ) or ( not wrapped and t > c0 and t <= c1 ) then self:Note( n[ 1 ] ) end
			end
		end
	else
		for i = #self.notes, 1, -1 do
			local n = self.notes[ i ]
			if el >= n[ 2 ] then
				table.remove( self.notes, i )
				self:Note( n[ 1 ] )
			end
		end
	end
	self.lastEl = el
end

function Actor:Remove()
	if IsValid( self.vis ) then self.vis:Remove() end
	if IsValid( self.drv ) then self.drv:Remove() end
end

local function newProp( model, seq )
	local e = ClientsideModel( model, RENDERGROUP_OPAQUE )
	e:SetNoDraw( true )
	local p = { ent = e, seq = seq or "idle", t0 = S and S.t or 0, rate = 1, loop = false, visible = true, scale = 1 }
	S.props[ #S.props + 1 ] = p
	return p
end

local function propPlay( p, seq, loop )
	p.seq, p.t0, p.loop = seq, S.t, loop
	p.dur = math.max( seqData( p.model and ( p.model .. "." .. seq ) or seq ).dur or 1, 0.05 )
end

local function emit( p )
	p.born = S.t
	p.vel = p.vel or Vector()
	S.fx[ #S.fx + 1 ] = p
end

local function flashLight( pos, col, radius, life )
	S.lights[ #S.lights + 1 ] = { pos = pos, col = col, radius = radius, t1 = S.t + life, life = life }
end

local function shake( amount )
	S.shake = math.max( S.shake, amount )
end

local function sfx( path, vol, pitch )
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	sound.Play( path, ply:EyePos(), 75, pitch or 100, math.Clamp( vol or 1, 0, 1 ) )
end

local function sfxAt( path, pos, vol, pitch )
	local d = pos:Distance( S.focus or S.cam.pos )
	sfx( path, ( vol or 1 ) * math.Clamp( 1.2 - d / 2600, 0.1, 1 ), pitch )
end

local function loopSound( key, path, vol )
	local token = {}
	S.loops[ key ] = { token = token, vol = vol or 1, target = vol or 1 }
	sound.PlayFile( "sound/" .. path, "noplay noblock", function( ch )
		if not IsValid( ch ) then return end
		local l = S and S.loops[ key ]
		if not l or l.token ~= token then ch:Stop() return end
		l.ch = ch
		ch:EnableLooping( true )
		ch:SetVolume( l.vol )
		ch:Play()
	end )
end

local POOLS = {}
local function pool( pattern )
	local list = POOLS[ pattern ]
	if not list then
		list = {}
		local dir = string.match( pattern, "^(.*/)" ) or ""
		for _, f in ipairs( file.Find( "sound/" .. pattern, "GAME" ) or {} ) do list[ #list + 1 ] = dir .. f end
		POOLS[ pattern ] = list
	end
	return list
end

local function pick( pattern )
	local list = pool( pattern )
	if #list == 0 then return nil end
	return list[ math.random( #list ) ]
end

local function surfaceAt( pos )
	local _, surf = groundZ( pos.x, pos.y, pos.z + 24 )
	return surf or "dirt"
end

local STEP = { dirt = "foot_dirt", grass = "foot_grass", mud = "foot_mud", stone = "foot_stone", wood = "foot_wood", metal = "foot_metal",
	leaves = "foot_leaves", carpet = "foot_carpet", glass = "foot_glass", snow = "foot_snow", water = "water_wade" }
local LAND = { dirt = "dirt", grass = "grass", mud = "mud", stone = "stone", wood = "wood", metal = "metal", leaves = "leaves",
	carpet = "carpet", glass = "stone", snow = "snow", water = "water" }
local FALL = { dirt = "dirt", grass = "dirt", mud = "dirt", leaves = "dirt", snow = "dirt", stone = "stone", glass = "stone",
	carpet = "wood", wood = "wood", metal = "metal", water = "water" }

local function heard( pos )
	return pos:Distance( S.focus or S.cam.pos ) < 1500
end

local function footstep( a, vol )
	if not heard( a.pos ) then return end
	local snd = pick( "cod1/footsteps/" .. ( STEP[ surfaceAt( a.pos ) ] or "foot_dirt" ) .. "*.wav" )
	if snd then sfxAt( snd, a.pos, ( vol or 0.5 ) * ( a == S.ender and 1 or 0.75 ), math.random( 94, 106 ) ) end
	a.steps = ( a.steps or 0 ) + 1
	if a.steps % 3 == 0 and math.random() < 0.6 then
		local g = pick( "cod1/misc/gear_rattle*.wav" )
		if g then sfxAt( g, a.pos, 0.28, math.random( 95, 105 ) ) end
	end
end

local function landSound( a )
	if not heard( a.pos ) then return end
	sfxAt( "cod1/footsteps/land_" .. ( LAND[ surfaceAt( a.pos ) ] or "dirt" ) .. ".wav", a.pos, 0.8 )
	local g = pick( "cod1/misc/gear_rattle*.wav" )
	if g then sfxAt( g, a.pos, 0.45 ) end
end

local function bodyfall( a, large )
	if not heard( a.pos ) then return end
	local snd = pick( "cod1/bodyfalls/bodyfall_" .. ( FALL[ surfaceAt( a.pos ) ] or "dirt" ) .. "*.wav" )
	if snd then sfxAt( snd, a.pos, large and 0.85 or 0.55, math.random( 95, 105 ) ) end
	if large then
		local g = pick( "cod1/misc/gear_rattle*.wav" )
		if g then sfxAt( g, a.pos, 0.4 ) end
	end
end

function Actor:Note( name )
	if self.onNote then self.onNote( name, self ) end
	if string.find( name, "footstep", 1, true ) then
		footstep( self )
	elseif string.find( name, "bodyfall", 1, true ) or name == "body fall sound" then
		self.fell = true
		bodyfall( self, string.find( name, "small", 1, true ) == nil )
	elseif name == "pronecrawl - start" then
		local c = pick( "cod1/footsteps/crawl*.wav" )
		if c and heard( self.pos ) then sfxAt( c, self.pos, 0.5 ) end
	elseif name == "collision off" then
		local c = pick( "cod1/footsteps/foot_scrape*.wav" )
		if c and heard( self.pos ) then sfxAt( c, self.pos, 0.6 ) end
	end
end

local function loopVolume( key, target, speed )
	local l = S.loops[ key ]
	if l then l.target, l.speed = target, speed or 1 end
end

local function music( file, fade )
	local M = COD1.MusicPlayer
	if M then M.Play( file, { kind = "credits", fadeIn = fade or 2, fadeOut = 1.5, title = "Credits" } ) end
end

local function muzzle( pos, dir, big )
	emit( { mat = fxMat( "effects/muzzleflash" .. math.random( 1, 4 ) ), pos = pos + dir * 4, life = 0.06, s0 = big and 16 or 11, s1 = big and 22 or 15, col = Vector( 255, 230, 190 ), a0 = 255, a1 = 0, add = true } )
	emit( { mat = fxMat( "sprites/light_glow02_add" ), pos = pos, life = 0.08, s0 = 46, s1 = 30, col = Vector( 255, 190, 110 ), a0 = 200, a1 = 0, add = true } )
	emit( { mat = fxMat( "particle/particle_smokegrenade" ), pos = pos + dir * 6, vel = dir * 30 + Vector( 0, 0, 14 ), life = 1.2, s0 = 3, s1 = 16, col = Vector( 150, 145, 140 ), a0 = 70, a1 = 0, drag = 1.5 } )
	flashLight( pos, Vector( 1.0, 0.75, 0.4 ), 220, 0.07 )
end

local function tracer( from, to )
	S.beams[ #S.beams + 1 ] = { a = from, b = to, t1 = S.t + 0.07 }
end

local function dirtPuff( pos )
	for _ = 1, 3 do
		emit( { mat = fxMat( "particle/particle_smokegrenade" ), pos = pos + VectorRand() * 3, vel = Vector( math.Rand( -20, 20 ), math.Rand( -20, 20 ), math.Rand( 40, 90 ) ), life = 0.9, s0 = 4, s1 = 18, col = Vector( 96, 82, 64 ), a0 = 170, a1 = 0, grav = -120 } )
	end
end

local function explosion( pos, scale, opt )
	opt = opt or {}
	scale = scale or 1
	flashLight( pos + Vector( 0, 0, 40 * scale ), Vector( 1.0, 0.62, 0.28 ) * 2, 900 * scale, 0.35 )
	emit( { mat = fxMat( "sprites/light_glow02_add" ), pos = pos + Vector( 0, 0, 30 * scale ), life = 0.35, s0 = 380 * scale, s1 = 120 * scale, col = Vector( 255, 200, 140 ), a0 = 255, a1 = 0, add = true } )
	for _ = 1, math.floor( 7 * scale ) + 3 do
		emit( { mat = fxMat( "effects/fire_cloud" .. math.random( 1, 2 ) ), pos = pos + VectorRand() * 20 * scale + Vector( 0, 0, 20 * scale ),
			vel = VectorRand() * 90 * scale + Vector( 0, 0, 160 * scale ), life = math.Rand( 0.35, 0.7 ), s0 = 40 * scale, s1 = 110 * scale,
			col = Vector( 255, 200, 150 ), a0 = 255, a1 = 0, add = true, drag = 2.5 } )
	end
	local dirt = opt.metal and Vector( 60, 56, 52 ) or Vector( 92, 76, 58 )
	for _ = 1, math.floor( 10 * scale ) + 4 do
		local v = Vector( math.Rand( -1, 1 ), math.Rand( -1, 1 ), 0 ) * 120 * scale + Vector( 0, 0, math.Rand( 200, 520 ) * scale )
		emit( { mat = fxMat( "particle/particle_smokegrenade" ), pos = pos + VectorRand() * 12 * scale, vel = v, life = math.Rand( 1.2, 2.2 ), s0 = 20 * scale, s1 = 90 * scale,
			col = dirt, a0 = 230, a1 = 0, grav = -260, drag = 1.2 } )
	end
	for _ = 1, math.floor( 12 * scale ) do
		emit( { mat = fxMat( "effects/fleck_cement" .. math.random( 1, 2 ) ), pos = pos + Vector( 0, 0, 10 ), vel = VectorRand() * 260 * scale + Vector( 0, 0, 380 * scale ),
			life = math.Rand( 0.8, 1.4 ), s0 = 4 * scale, s1 = 4 * scale, col = Vector( 70, 60, 50 ), a0 = 255, a1 = 255, grav = -700 } )
	end
	for _ = 1, math.floor( 6 * scale ) + 2 do
		emit( { mat = fxMat( "particle/particle_smokegrenade" ), pos = pos + VectorRand() * 30 * scale + Vector( 0, 0, 40 * scale ), vel = Vector( math.Rand( -15, 15 ), math.Rand( -15, 15 ), math.Rand( 30, 70 ) ) * scale,
			life = math.Rand( 4, 7 ), s0 = 60 * scale, s1 = 220 * scale, col = Vector( 40, 38, 36 ), a0 = 150, a1 = 0, drag = 0.3, slow = true } )
	end
	local d = pos:Distance( S.focus or S.cam.pos )
	shake( math.Clamp( 1.6 - d / 900, 0, 1.4 ) * scale )
	if not opt.silent then
		sfxAt( opt.metal and "cod1/cine/explo_metal01.wav" or ( "cod1/cine/mortar_dirt0" .. math.random( 1, 4 ) .. ".wav" ), pos, opt.vol or 1 )
	end
end

local function fireTick( f, dt )
	f.acc = ( f.acc or 0 ) + dt * f.rate
	while f.acc >= 1 do
		f.acc = f.acc - 1
		emit( { mat = fxMat( "effects/fire_cloud" .. math.random( 1, 2 ) ), pos = f.pos + Vector( math.Rand( -f.w, f.w ), math.Rand( -f.w, f.w ), 0 ),
			vel = Vector( math.Rand( -8, 8 ), math.Rand( -8, 8 ), math.Rand( 50, 90 ) * f.size ), life = math.Rand( 0.5, 0.9 ), s0 = 26 * f.size, s1 = 8 * f.size,
			col = Vector( 255, 190, 120 ), a0 = 230, a1 = 0, add = true } )
		if math.random() < 0.35 then
			emit( { mat = fxMat( "particle/particle_smokegrenade" ), pos = f.pos + Vector( 0, 0, 40 * f.size ), vel = Vector( math.Rand( -10, 10 ), math.Rand( -10, 10 ), math.Rand( 40, 70 ) ),
				life = math.Rand( 3, 5 ), s0 = 30 * f.size, s1 = 140 * f.size, col = Vector( 30, 28, 26 ), a0 = 120, a1 = 0, drag = 0.2, slow = true } )
		end
	end
end

local function addFire( pos, size, rate, w, glow )
	local f = { pos = pos, size = size or 1, rate = rate or 10, w = w or 10, glow = glow }
	S.fires[ #S.fires + 1 ] = f
	return f
end

local function nearestLights( pos )
	local list = {}
	for _, l in ipairs( S.lights ) do
		if S.t < l.t1 then
			local k = ( l.t1 - S.t ) / l.life
			local d = pos:Distance( l.pos )
			if d < l.radius * 1.5 then list[ #list + 1 ] = { pos = l.pos, col = l.col * k, radius = l.radius, d = d } end
		end
	end
	for _, f in ipairs( S.fires ) do
		if f.glow then
			local d = pos:Distance( f.pos )
			if d < 700 then
				local flick = 0.85 + 0.15 * math.sin( S.t * 13 + f.pos.x ) + 0.1 * math.sin( S.t * 31 + f.pos.y )
				list[ #list + 1 ] = { pos = f.pos + Vector( 0, 0, 30 ), col = Vector( 1.0, 0.55, 0.2 ) * f.glow * flick, radius = 450, d = d }
			end
		end
	end
	table.sort( list, function( a, b ) return a.d < b.d end )
	return list
end

local function lightModel( pos )
	local c = lightAt( pos ) * 2 * S.lightMul + S.ambient
	render.SetModelLighting( 0, c.x * 0.85, c.y * 0.85, c.z * 0.85 )
	render.SetModelLighting( 1, c.x * 0.7, c.y * 0.7, c.z * 0.7 )
	render.SetModelLighting( 2, c.x * 0.8, c.y * 0.8, c.z * 0.8 )
	render.SetModelLighting( 3, c.x * 0.75, c.y * 0.75, c.z * 0.75 )
	render.SetModelLighting( 4, c.x * 1.05, c.y * 1.05, c.z * 1.05 )
	render.SetModelLighting( 5, c.x * 0.4, c.y * 0.4, c.z * 0.4 )
	local lights = { { type = MATERIAL_LIGHT_DIRECTIONAL, color = S.sunColor, dir = -SUN } }
	for _, l in ipairs( nearestLights( pos ) ) do
		if #lights >= 4 then break end
		lights[ #lights + 1 ] = { type = MATERIAL_LIGHT_POINT, color = l.col, pos = l.pos, fiftyPercentDistance = l.radius * 0.35, zeroPercentDistance = l.radius }
	end
	render.SetLocalModelLights( lights )
end

local function drawList( list )
	local hidden = Set.hidden
	for _, m in ipairs( list ) do
		if not ( m.model and hidden[ m.model ] ) then
			render.SetMaterial( m.mat )
			m.mesh:Draw()
		end
	end
end

local function drawProp( p )
	local e = p.ent
	if not p.visible or not p.pos or not IsValid( e ) then return end
	e:SetPos( p.pos )
	e:SetAngles( p.ang or Angle( 0, p.yaw or 0, 0 ) )
	local id = e:LookupSequence( p.seq )
	if id and id >= 0 and e:GetSequence() ~= id then e:SetSequence( id ) end
	local c = 0
	if p.dur then
		c = ( S.t - p.t0 ) / p.dur
		c = p.loop and c % 1 or math.Clamp( c, 0, 1 )
	end
	e:SetCycle( c )
	e:SetPlaybackRate( 0 )
	e:InvalidateBoneCache()
	lightModel( p.pos + Vector( 0, 0, 30 ) )
	e:DrawModel()
end

local function drawFx()
	render.SetMaterial( fxMat( "effects/spark" ) )
	for _, b in ipairs( S.beams ) do
		if S.t < b.t1 then render.DrawBeam( b.a, b.b, 2.5, 0, 1, Color( 255, 220, 160, 255 ) ) end
	end
	for _, p in ipairs( S.fx ) do
		local age = S.t - p.born
		local k = math.Clamp( age / p.life, 0, 1 )
		local size = Lerp( p.slow and math.sqrt( k ) or k, p.s0, p.s1 )
		local a = Lerp( k, p.a0, p.a1 )
		if p.slow then a = a * math.min( 1, age / 0.4 ) end
		local c = p.col
		local mul = p.add and 1 or S.fxLight
		render.SetMaterial( p.mat )
		render.DrawSprite( p.pos, size, size, Color( math.min( c.x * mul, 255 ), math.min( c.y * mul, 255 ), math.min( c.z * mul, 255 ), a ) )
	end
	for _, f in ipairs( S.fires ) do
		if f.glow then
			render.SetMaterial( fxMat( "sprites/light_glow02_add" ) )
			local flick = 0.8 + 0.2 * math.sin( S.t * 11 + f.pos.x )
			render.DrawSprite( f.pos + Vector( 0, 0, 20 * f.size ), 160 * f.size * flick, 120 * f.size * flick, Color( 255, 140, 60, 70 * f.glow ) )
		end
	end
	for _, a in ipairs( S.actors ) do
		if a.cig and a.visible then
			local hand, finger = a:Bone( "bip01 r hand" ), a:Bone( "bip01 r finger1" )
			local dir = ( finger - hand ):GetNormalized()
			local base = finger + dir * 0.6
			local tip = base + dir * 2.6
			render.SetMaterial( fxMat( "effects/spark" ) )
			render.DrawBeam( base, tip, 0.55, 0, 1, Color( 235, 228, 210, 255 ) )
			local glow = 0.6 + 0.4 * ( a.drag or 0 )
			render.SetMaterial( fxMat( "sprites/light_glow02_add" ) )
			render.DrawSprite( tip, 3 + 4 * glow, 3 + 4 * glow, Color( 255, 120, 40, 200 * glow ) )
		end
	end
end

local FOLLOW_GROUND = { knockdown = true, wobble = true, land = true, crouchrun2prone = true, prone2crouch = true, truck_out = false,
	death_topple = true, death_crumple = true, death_spin = true, death_neck = true, death_lowerback = true, death_legs = true,
	death_run_stumble = true, crouch_death = true, death_prone = true, death_explode = true }

local function drawActor( a )
	if not a.visible or not IsValid( a.drv ) or not IsValid( a.vis ) then return end
	local want = 0
	if FOLLOW_GROUND[ a.seq ] and a.pelvis then
		local base = groundZ( a.pos.x, a.pos.y, a.pos.z + 24 ) or a.pos.z
		local g = groundZ( a.pelvis.x, a.pelvis.y, a.pos.z + 48 )
		if g then want = math.Clamp( g - base, -40, 40 ) end
	end
	a.zoff = Lerp( math.min( 1, S.dt * 12 ), a.zoff or 0, want )
	a:Pose()
	a.pelvis = a:Bone( "bip01 pelvis" )
	if a.moving and a.footSync and a.alive ~= false then
		a.feet = a.feet or { {}, {} }
		for i, bone in ipairs( { "bip01 l foot", "bip01 r foot" } ) do
			local f = a.feet[ i ]
			local z = a:Bone( bone ).z - a.pos.z
			f.low = math.min( ( f.low or z ) + S.dt * 6, z )
			if f.up and z < f.low + 2.5 then
				f.up = false
				footstep( a, 0.5 )
			elseif not f.up and z > f.low + 7 then
				f.up = true
			end
		end
	else
		a.feet = nil
	end
	lightModel( a:Bone( "bip01 pelvis" ) )
	a.vis:DrawModel()
end

local function renderScene()
	if not S or not Set or not Set.ready then
		render.Clear( 0, 0, 0, 255, true, true )
		return true
	end
	local cam3 = S.cam
	render.Clear( S.fogColor.x, S.fogColor.y, S.fogColor.z, 255, true, true )
	cam.Start3D( cam3.pos, cam3.ang, cam3.fov, 0, 0, ScrW(), ScrH(), 3, 12000 )
	S.inCam = true
	render.FogMode( MATERIAL_FOG_LINEAR )
	render.FogStart( S.fogStart )
	render.FogEnd( S.fogEnd )
	render.FogMaxDensity( 1 )
	render.FogColor( S.fogColor.x, S.fogColor.y, S.fogColor.z )
	drawList( Set.albedo )
	drawList( Set.overlay )
	drawList( Set.lmPass )
	drawList( Set.masked )
	drawList( Set.models )
	drawList( Set.decal )
	render.SuppressEngineLighting( true )
	for _, p in ipairs( S.props ) do drawProp( p ) end
	for _, a in ipairs( S.actors ) do drawActor( a ) end
	render.SetLocalModelLights( {} )
	render.SuppressEngineLighting( false )
	drawFx()
	render.FogMode( MATERIAL_FOG_NONE )
	cam.End3D()
	S.inCam = false
	hook.Run( "COD1CreditsRendered", S.t )
	return true
end

local function updateCamera( dt )
	if not S.shot then return end
	local pos, ang, fov, focus = S.shot( S.t )
	S.focus = focus or pos
	local k = S.camCut and 1 or 1 - math.exp( -dt * ( S.camStiff or 3.2 ) )
	S.camCut = nil
	S.cam.base = S.cam.base and LerpVector( k, S.cam.base, pos ) or pos
	S.cam.baseAng = S.cam.baseAng and LerpAngle( k, S.cam.baseAng, ang ) or ang
	S.cam.fov = Lerp( k, S.cam.fov or fov, fov )
	S.shake = math.max( 0, S.shake - dt * 1.6 )
	local sh = S.shake * S.shake
	S.cam.pos = S.cam.base + VectorRand() * 6 * sh
	S.cam.ang = S.cam.baseAng + Angle( math.Rand( -1, 1 ) * 2.5 * sh, math.Rand( -1, 1 ) * 2.5 * sh, math.Rand( -1, 1 ) * 3 * sh )
end

local function cut( shot, stiff )
	S.shot = shot
	S.camStiff = stiff
	S.camCut = true
end

local function wait( d )
	local until_ = S.t + d
	while S and S.t < until_ do coroutine.yield() end
end

local function waitUntil( fn, limit )
	local stop = S.t + ( limit or 60 )
	while S and not fn() and S.t < stop do coroutine.yield() end
end

local function go( fn )
	S.threads[ #S.threads + 1 ] = coroutine.create( fn )
end

local function fade( to, time )
	S.fadeFrom, S.fadeTo, S.fadeT0, S.fadeLen = S.black, to, S.t, time
end

local function waitAnim( a )
	local seq = a.seq
	a.scripted = true
	while S and a.seq == seq and not a:Done() do coroutine.yield() end
	a.scripted = nil
end

local function detour( from, to )
	local B = S.tankBlock
	if not B then return { to } end
	local function loc( v )
		local d = v - B.c
		return Vector( d:Dot( B.f ), d:Dot( B.r ), 0 )
	end
	local la, lb = loc( from ), loc( to )
	local hit = false
	for k = 0, 24 do
		local q = LerpVector( k / 24, la, lb )
		if math.abs( q.x ) < B.len + 30 and math.abs( q.y ) < B.wid + 30 then
			hit = true
			break
		end
	end
	if not hit then return { to } end
	local sa, sb = la.y >= 0 and 1 or -1, lb.y >= 0 and 1 or -1
	local ex = B.f.x >= 0 and 1 or -1
	local function world( x, y ) return onGround( B.c + B.f * x + B.r * y, B.c.z + 60 ) end
	local out = { world( ex * ( B.len + 70 ), sa * ( B.wid + 70 ) ) }
	if sb ~= sa then out[ #out + 1 ] = world( ex * ( B.len + 70 ), sb * ( B.wid + 70 ) ) end
	out[ #out + 1 ] = to
	return out
end

local function moveAlong( a, points, seq, opt )
	opt = opt or {}
	a:Play( seq, { loop = true, rate = opt.rate } )
	local speed = ( seqData( seq ).speed or 150 ) * ( opt.rate or 1 )
	local list = {}
	for _, goal in ipairs( points ) do
		for _, v in ipairs( detour( list[ #list ] or a.pos, goal ) ) do list[ #list + 1 ] = v end
	end
	for _, target in ipairs( list ) do
		local from = a.pos
		local total = math.max( Vector( target.x - from.x, target.y - from.y, 0 ):Length(), 1 )
		while S do
			local d = Vector( target.x - a.pos.x, target.y - a.pos.y, 0 )
			local len = d:Length()
			if len < 6 then break end
			local want = d:Angle().y
			a.yaw = math.ApproachAngle( a.yaw, opt.face or want, S.dt * ( opt.turn or 300 ) )
			local step = math.min( len, speed * S.dt )
			local np = a.pos + d:GetNormalized() * step
			local ez = Lerp( 1 - ( len - step ) / total, from.z, target.z )
			local g = groundZ( np.x, np.y, math.max( a.pos.z + 20, ez + 40 ) )
			if not g then g = ez - 8 end
			local z = a.pos.z
			if g > z + 14 then
				z = math.min( g, z + 330 * S.dt )
				a.vz = 0
			elseif g < z - 14 then
				a.vz = ( a.vz or 0 ) + 900 * S.dt
				z = math.max( g, z - a.vz * S.dt )
			else
				z = g
				a.vz = 0
			end
			a.pos = Vector( np.x, np.y, z )
			local d = seqData( a.seq )
			if not d.stepNotes then
				d.stepNotes = 0
				for _, n in ipairs( d.notes or {} ) do
					if string.find( n[ 1 ], "footstep", 1, true ) or string.find( n[ 1 ], "pronecrawl", 1, true ) then d.stepNotes = 1 end
				end
			end
			a.footSync = d.stepNotes == 0
			if opt.stop and opt.stop() then return end
			coroutine.yield()
		end
	end
end

local function turnTo( a, yaw, speed )
	while S and math.abs( math.AngleDifference( a.yaw, yaw ) ) > 1 do
		a.yaw = math.ApproachAngle( a.yaw, yaw, S.dt * ( speed or 240 ) )
		coroutine.yield()
	end
end

local CLASSES = {
	actor_ally_airborne_thompson = { variant = "airborne_summer", weapon = 0, belt = 0, snd = "cod1/weapons/thompson/thompson_01.wav", burst = 3 },
	actor_ally_airborne_garand = { variant = "airborne_summer", weapon = 1, belt = 1, snd = "cod1/weapons/m1garand/m1garand_01.wav", burst = 1 },
	actor_ally_airborne_carbine = { variant = "airborne_summer", weapon = 2, belt = 2, snd = "cod1/weapons/m1carbine/m1carbine_01.wav", burst = 1 },
	actor_ally_airborne_BAR = { variant = "airborne_summer", weapon = 3, belt = 3, snd = "cod1/weapons/bar/bar_01.wav", burst = 3 },
	actor_axis_wehrmacht_soldier_kar98k = { variant = "german_wehrmacht", weapon = 0, belt = 0, snd = "cod1/weapons/kar98k/kar98_01.wav", burst = 1, axis = true },
	actor_axis_waffen_soldier_mp40 = { variant = "german_waffenss", weapon = 1, belt = 1, snd = "cod1/weapons/mp40/mp40_01.wav", burst = 3, axis = true },
	actor_axis_fallschirmjager_soldier_kar98k = { variant = "german_fallschirm", weapon = 0, belt = 0, snd = "cod1/weapons/kar98k/kar98_01.wav", burst = 1, axis = true },
}
local DEATHS = { "death_topple", "death_spin", "death_neck", "death_lowerback", "death_legs" }
local RUN_DEATHS = { "death_crumple", "death_run_stumble" }
local STANCE = {
	stand = { aim = "aim", shoot = "shoot" },
	crouch = { aim = "crouch_aim", shoot = "crouch_shoot" },
	prone = { aim = "prone_aim", shoot = "prone_shoot" },
}
local NODE_STANCE = { node_cover_crouch = "crouch", node_concealment_crouch = "crouch", node_concealment_prone = "prone", node_cover_prone = "prone" }
local MPH = 17.6

local CS

local function W( v )
	return Vector( v.x + SHIFT.x, v.y + SHIFT.y, v.z )
end

local function inside( pos, b, padz )
	if not b then return false end
	local x, y, z = pos.x - SHIFT.x, pos.y - SHIFT.y, pos.z
	local lo, hi = b[ 1 ], b[ 2 ]
	padz = padz or 72
	return x >= lo.x and x <= hi.x and y >= lo.y and y <= hi.y and z >= lo.z - padz and z <= hi.z + padz
end

local function soldier( class, look )
	local c = CLASSES[ class ] or CLASSES.actor_ally_airborne_garand
	local v = COD1.Variants[ c.variant ] or {}
	local function pick( n ) return math.random( 0, math.max( ( n or 1 ) - 1, 0 ) ) end
	local groups = { body = pick( v.bodies ), head = pick( v.heads ), helmet = v.helmets and v.helmets[ math.random( #v.helmets ) ] or 0,
		load = pick( v.loads ), belt = c.belt, weapon = c.weapon }
	if v.fronts then groups.front = pick( v.fronts ) end
	local a = look and newActor( look.model, look.groups, 0 ) or newActor( v.model or "models/cod1/american/airborne.mdl", groups, pick( v.skins ) )
	a.cls, a.axis, a.alive, a.hp, a.snd, a.burst = c, c.axis, true, c.axis and 2 or 3, c.snd, c.burst
	a.stance, a.born = "stand", S.t
	table.insert( c.axis and S.axis or S.allies, a )
	return a
end

local function nearestFoe( a, range )
	local best, bd
	for _, f in ipairs( a.axis and S.allies or S.axis ) do
		if f.alive and f ~= a and not f.inTruck and not f.unseen then
			local d = f.pos:Distance( a.pos )
			if d < ( range or 1300 ) and ( not bd or d < bd ) then best, bd = f, d end
		end
	end
	return best
end

local function unanchor( a )
	if not a.anchored then return end
	local d = seqData( a.seq )
	local r = a:Done() and d.finish or d.start
	if r then
		a.pos = onGround( a.pos + rot( r.pos, a.yaw ), a.pos.z + 60 )
		a.yaw = a.yaw + r.yaw
	end
	a.anchored = nil
end

local function killActor( v )
	if not v.alive then return end
	v.alive = false
	v.dead = true
	unanchor( v )
	local seq
	if v.stance == "prone" then
		seq = "death_prone"
	elseif v.moving then
		seq = RUN_DEATHS[ math.random( #RUN_DEATHS ) ]
	elseif v.stance == "crouch" then
		seq = "crouch_death"
	else
		seq = DEATHS[ math.random( #DEATHS ) ]
	end
	v.moving = false
	v.fell = false
	v:Play( seq )
	if v.axis and heard( v.pos ) and math.random() < 0.8 then
		local c = pick( "cod1/german/*.wav" )
		if c then sfxAt( c, v.pos, 0.75, math.random( 96, 104 ) ) end
	end
	go( function()
		wait( seqData( seq ).dur * 0.6 )
		if S and not v.fell then bodyfall( v, true ) end
	end )
end

local function shootAt( a, target, accuracy )
	local m = a:Bone( "thompson_tag_flash" )
	local aim = target:Bone( "bip01 pelvis" ) + Vector( 0, 0, 6 ) + VectorRand() * 8
	local dir = ( aim - m ):GetNormalized()
	if a.cls and a.cls.weapon ~= 0 or a.axis then m = m + dir * 12 end
	muzzle( m, dir )
	sfxAt( a.snd or "cod1/weapons/thompson/thompson_01.wav", m, 0.75, math.random( 95, 104 ) )
	if math.random() < 0.45 then tracer( m + dir * 30, aim ) end
	local dist = m:Distance( aim )
	local duel = target.ladderTarget and S.ladderGuy
	if duel and a ~= duel then accuracy = 0 elseif duel and a == duel then accuracy = duel.climbed and 1 or 0 end
	if target.axis and math.random() < accuracy * math.Clamp( 650 / math.max( dist, 1 ), 0.7, 3.5 ) then
		target.hp = target.hp - 1
		if heard( aim ) then
			local c = pick( "cod1/weapons/impact/impact_flesh_*.wav" ) or pick( "cod1/weapons/impact/bullet_flesh*.wav" )
			if c then sfxAt( c, aim, 0.6 ) end
		end
		if target.hp <= 0 then
			killActor( target )
		elseif math.random() < 0.6 and heard( aim ) then
			local c = pick( "cod1/german/pain*.wav" )
			if c then sfxAt( c, aim, 0.7 ) end
		end
	elseif math.random() < 0.5 then
		local hit = onGround( aim + Vector( math.Rand( -40, 40 ), math.Rand( -40, 40 ), 0 ), aim.z )
		dirtPuff( hit )
		if heard( hit ) and math.random() < 0.6 then
			local c = pick( "cod1/weapons/impact/impact_dirt_*.wav" )
			if c then sfxAt( c, hit, 0.45 ) end
		end
	end
end

local function fightStep( a, accuracy )
	if not a.alive or a.scripted or a.reloading then return end
	local f = nearestFoe( a, a == S.ender and 1500 or 1300 )
	if not f then return end
	local face = ( f.pos - a.pos ):Angle().y
	if a.moving then
		if ( a.moveSeq or "run" ) ~= "run" or f.pos:Distance( a.pos ) > 1000 or math.abs( math.AngleDifference( face, a.yaw ) ) > 60 then return end
	else
		a.yaw = math.ApproachAngle( a.yaw, face, S.dt * 320 )
	end
	if S.t < ( a.nextShot or 0 ) or a.shooting then return end
	a.shooting = true
	go( function()
		local st = STANCE[ a.stance or "stand" ]
		if a.moving then
			if a.seq == "run" then a:Play( "run_shoot", { loop = true } ) end
		elseif not a.scripted then
			a:Play( st.shoot )
		end
		for i = 1, a.burst or 1 do
			if not S or not a.alive or not f.alive then break end
			shootAt( a, f, accuracy )
			if i < ( a.burst or 1 ) then wait( 0.1 ) end
		end
		wait( 0.25 )
		if not S then return end
		a.shooting = false
		a.nextShot = S.t + math.Rand( 0.5, 1.4 ) * ( a.axis and 1.6 or 1 ) * ( a.moving and 1.8 or 1 )
		a.fired = ( a.fired or 0 ) + 1
		if not a.alive then return end
		if a.seq == "run_shoot" then
			a:Play( a.moving and "run" or st.aim, { loop = true } )
		elseif a.seq == st.shoot and a.fired >= 6 and a.stance == "stand" then
			a.fired = 0
			a.reloading = true
			a:Play( "reload" )
			wait( seqData( "reload" ).dur )
			if not S then return end
			a.reloading = false
			if a.alive and a.seq == "reload" then a:Play( st.aim, { loop = true } ) end
		elseif a.seq == st.shoot then
			a:Play( st.aim, { loop = true } )
		end
	end )
end

local function fightUntil( a, done, accuracy )
	if a.alive and not a.moving then a:Play( STANCE[ a.stance or "stand" ].aim, { loop = true } ) end
	while S and a.alive and not done() do
		if a.interrupt then
			local f = a.interrupt
			a.interrupt = nil
			f()
			if a.alive then a:Play( STANCE[ a.stance or "stand" ].aim, { loop = true } ) end
		end
		fightStep( a, accuracy )
		coroutine.yield()
	end
end

local CORNER_SET = { node_cover_left = "cr", node_cover_right = "cl" }
local CORNER_YAW = { cr = { 60, 15, -30 }, cl = { 30, -15, -60 } }
local LOW_WALL = { node_cover_crouch = true, node_cover_stand = true }
local PRONE = { node_concealment_prone = true, node_cover_prone = true }

local function playWait( a, seq )
	if not a.alive then return false end
	a:Play( seq )
	waitAnim( a )
	if not a.alive then return false end
	a:Settle()
	return true
end

local function holdFor( a, t, done )
	local stop = S.t + t
	while S and a.alive and S.t < stop and not done() do coroutine.yield() end
	return S and a.alive
end

local function fireAnim( a, seq, foe, accuracy )
	local shots = 0
	a:Play( seq, { onNote = function( note )
		if note == "fire" and foe.alive and a.alive and ( a.burst > 1 or shots == 0 ) then
			shots = shots + 1
			shootAt( a, foe, accuracy )
		end
	end } )
	waitAnim( a )
	return a.alive
end

local function exposedFire( a, foe, accuracy )
	local st = STANCE[ a.stance ]
	turnTo( a, ( foe.pos - a.pos ):Angle().y, 500 )
	a:Play( st.aim, { loop = true } )
	if not holdFor( a, math.Rand( 0.2, 0.4 ), function() return false end ) then return false end
	for _ = 1, math.random( 2, 4 ) do
		if not foe.alive or not a.alive then break end
		a:Play( st.shoot )
		for i = 1, a.burst do
			if not foe.alive or not a.alive then break end
			shootAt( a, foe, accuracy )
			if i < a.burst then wait( 0.1 ) end
		end
		if not a.alive then return false end
		a:Play( st.aim, { loop = true } )
		if not holdFor( a, math.Rand( 0.35, 0.8 ), function() return false end ) then return false end
		a.yaw = ( foe.pos - a.pos ):Angle().y
	end
	return a.alive
end

local function takeInterrupt( a )
	if not a.interrupt then return end
	local f = a.interrupt
	a.interrupt = nil
	f()
end

local function holdCover( a, node, done, accuracy )
	local cls = node and node.class
	local set = CORNER_SET[ cls ]
	if node and node.yaw then turnTo( a, node.yaw, 720 ) end
	a.covering = true
	if set then
		a.stance = "crouch"
		if not playWait( a, set .. "_arrive" ) or not playWait( a, set .. "_down" ) then return end
		local bursts = 0
		while S and a.alive and not done() do
			takeInterrupt( a )
			a:Play( set .. "_idle", { loop = true } )
			if not holdFor( a, math.Rand( 0.5, 1.4 ), done ) then return end
			if done() then break end
			local foe = nearestFoe( a, 1400 )
			if foe then
				local rel = math.AngleDifference( ( foe.pos - a.pos ):Angle().y, a.yaw )
				local k, best = 0, math.huge
				for j, y in ipairs( CORNER_YAW[ set ] ) do
					if math.abs( rel - y ) < best then k, best = j - 1, math.abs( rel - y ) end
				end
				if not playWait( a, set .. "_out" .. k ) then return end
				for _ = 1, math.random( 1, 3 ) do
					if not foe.alive then break end
					if not fireAnim( a, set .. "_fire" .. k, foe, accuracy ) then return end
					a:Play( set .. "_aim" .. k, { loop = true } )
					if not holdFor( a, math.Rand( 0.2, 0.6 ), function() return false end ) then return end
				end
				if not playWait( a, set .. "_in" .. k ) then return end
				bursts = bursts + 1
				if bursts >= 4 then
					bursts = 0
					if not playWait( a, set .. "_reload" ) then return end
				end
			elseif math.random() < 0.45 then
				if not playWait( a, set .. "_look" ) then return end
			end
		end
		if not playWait( a, set .. "_up" ) then return end
	elseif LOW_WALL[ cls ] then
		local standing = cls == "node_cover_stand"
		a.stance = "crouch"
		if not playWait( a, "lw_stand_down" ) then return end
		local bursts = 0
		while S and a.alive and not done() do
			takeInterrupt( a )
			a:Play( "lw_idle", { loop = true } )
			if not holdFor( a, math.Rand( 0.6, 1.5 ), done ) then return end
			if done() then break end
			local foe = nearestFoe( a, 1400 )
			if foe then
				if standing then
					if not playWait( a, "lw_stand_up" ) then return end
					a.stance = "stand"
				else
					if not playWait( a, "lw_up" ) then return end
				end
				local yaw = a.yaw
				if not exposedFire( a, foe, accuracy ) then return end
				turnTo( a, yaw, 600 )
				a.stance = "crouch"
				if not playWait( a, standing and "lw_stand_down" or "lw_down" ) then return end
				bursts = bursts + 1
			elseif math.random() < 0.4 then
				if not playWait( a, "lw_idle2" ) then return end
			end
		end
		if not playWait( a, standing and "lw_stand_up" or "crouch2stand" ) then return end
	elseif PRONE[ cls ] then
		if not playWait( a, "crouchrun2prone" ) then return end
		a.stance = "prone"
		fightUntil( a, done, accuracy )
		if not playWait( a, "prone2crouch" ) then return end
	else
		a.stance = NODE_STANCE[ cls ] or "stand"
		fightUntil( a, done, accuracy )
	end
	a.covering = nil
	a.stance = "stand"
end

local function axisInside( b )
	for _, x in ipairs( S.axis ) do
		if x.alive and inside( x.pos, b, 128 ) then return true end
	end
	return false
end

local function ladder( a, goal, yaw )
	a:Place( onGround( a.pos, a.pos.z + 30 ), yaw )
	local off = seqData( "ladder_off" ).finish or { pos = Vector(), yaw = 0 }
	local top = goal - rot( off.pos, a.yaw ) + Vector( 0, 0, 1 )
	local c = seqData( "ladder_climb" )
	local rate = math.max( ( c.finish and c.finish.pos.z or 0 ) / c.dur, 30 )
	local from = a.pos
	local total = math.max( top.z - from.z, 1 )
	a:Play( "ladder_climb", { loop = true } )
	a.scripted = true
	local rung = 0
	while S and a.alive and a.pos.z < top.z do
		rung = rung + rate * S.dt
		if rung > 16 then
			rung = 0
			local c = pick( "cod1/footsteps/foot_wood*.wav" )
			if c and heard( a.pos ) then sfxAt( c, a.pos, 0.45, math.random( 105, 115 ) ) end
		end
		local z = math.min( top.z, a.pos.z + rate * S.dt )
		local k = ( z - from.z ) / total
		a.pos = Vector( Lerp( k, from.x, top.x ), Lerp( k, from.y, top.y ), z )
		coroutine.yield()
	end
	a.scripted = nil
	if not S or not a.alive then return end
	a:Play( "ladder_off" )
	waitAnim( a )
	a:Settle()
	a.vz = 0
	a.climbed = true
end

local function traversal( a, goal, seq, yaw )
	if seq == "ladder" then return ladder( a, goal, yaw ) end
	a:Place( onGround( a.pos, a.pos.z + 30 ), yaw )
	local d = seqData( seq )
	local f = d.finish or { pos = Vector(), yaw = 0 }
	local animEnd = a.pos + rot( f.pos, a.yaw )
	local fix = Vector( goal.x - animEnd.x, goal.y - animEnd.y, 0 )
	if fix:Length() > 48 then fix = Vector() end
	local land = Vector( animEnd.x + fix.x, animEnd.y + fix.y, 0 )
	land.z = groundZ( land.x, land.y, math.max( a.pos.z, goal.z, animEnd.z ) + 40 ) or animEnd.z
	local dz = math.Clamp( land.z - animEnd.z, -300, 80 )
	land.z = animEnd.z + dz
	local tg = d.dur * 0.6
	for _, n in ipairs( d.notes or {} ) do
		if n[ 1 ] == "gravity on" then tg = n[ 2 ] end
	end
	a:Play( seq )
	a.scripted = true
	while S do
		local t = a:Elapsed()
		local k = ease( t / d.dur )
		local z
		if dz >= 0 then
			z = dz * ease( t / math.max( tg, 0.05 ) )
		else
			z = math.max( dz, -450 * math.max( 0, t - tg ) ^ 2 )
		end
		a.toff = Vector( fix.x * k, fix.y * k, z )
		if t >= d.dur then
			if dz >= 0 or z <= dz + 0.5 then break end
			a.hold = 1
		end
		coroutine.yield()
	end
	a.hold = nil
	a.scripted = nil
	a.toff = nil
	if not S then return end
	a.pos = land
	a.yaw = a.yaw + f.yaw
	a.vz = 0
	a.snap = true
	if seq == "wall_dive" then
		local c = pick( "cod1/bodyfalls/dive_over_wall*.wav" )
		if c and heard( a.pos ) then sfxAt( c, a.pos, 0.8 ) end
	end
	landSound( a )
end

local function runSteps( a, steps, seq, opt )
	opt = opt or {}
	for _, st in ipairs( steps ) do
		if not S or ( opt.stop and opt.stop() ) then return end
		if st[ 1 ] == "trav" then
			traversal( a, W( st[ 2 ] ), st[ 3 ], st[ 4 ] )
		else
			moveAlong( a, { W( st[ 2 ] ) }, seq, opt )
		end
	end
end

local function interruptible( a )
	return function()
		if a.interrupt then
			local f = a.interrupt
			a.interrupt = nil
			a.moving = false
			f()
			a.moving = true
			a:Play( a.moveSeq or "run", { loop = true } )
		end
		if a == S.ender then fightStep( a, 0.18 ) end
		return false
	end
end

local MG_GRIP, MG_FLASH = Vector( -33.6, 0, 12.1 ), Vector( 8.4, 0.1, 15.2 )

local function manMG( a )
	local mg, best
	for _, m in ipairs( CS.mg42 or {} ) do
		local d = W( m.pos ):DistToSqr( a.pos )
		if not best or d < best then mg, best = m, d end
	end
	if not mg or best > 300 * 300 then return false end
	local base = W( mg.pos )
	a.yaw = mg.yaw
	a.pos = base + rot( MG_GRIP, mg.yaw )
	a.anchored = true
	a.scripted = true
	a.stance = "prone"
	local flash = base + rot( MG_FLASH, mg.yaw )
	local fwd = Angle( 0, mg.yaw, 0 ):Forward()
	while S and a.alive do
		a:Play( "mg_aim", { loop = true } )
		if not holdFor( a, math.Rand( 0.5, 1.3 ), function() return false end ) then break end
		a:Play( "mg_fire", { loop = true } )
		for _ = 1, math.random( 8, 16 ) do
			if not S or not a.alive then break end
			local dir = ( fwd + VectorRand() * 0.035 ):GetNormalized()
			muzzle( flash, dir, true )
			if heard( flash ) then sfxAt( "cod1/weapons/mg42/mg42_01.wav", flash, 0.8, math.random( 96, 104 ) ) end
			if math.random() < 0.5 then tracer( flash + dir * 30, flash + dir * 1600 ) end
			wait( 0.06 )
		end
	end
	if S then a.scripted = nil end
	return true
end

local function spawnGroup( g )
	for _, d in ipairs( g.actors ) do
		local a = soldier( d.class )
		a:Place( onGround( W( d.pos ), d.pos.z + 40 ), d.yaw )
		if g.note == "nohealth" then a.hp = 1 end
		if d.note == "tank killer" then S.tankKiller = a end
		if d.note == "unseen" then
			a.unseen = true
			S.ladderGuy = a
		end
		local tail = d.legs[ #d.legs ]
		if a.axis and tail and math.abs( tail.pos.x + 17200 ) < 80 and math.abs( tail.pos.y + 19525 ) < 60 then
			a.ladderTarget = true
			a.born = math.huge
		end
		go( function()
			a.moving = true
			a.moveSeq = "run"
			for _, leg in ipairs( d.legs ) do
				runSteps( a, leg.steps, "run", { stop = function()
					if a.alive and not a.busy then fightStep( a, a.axis and 0 or 0.08 ) end
					return not a.alive or a.busy
				end } )
				if not a.alive or a.busy then a.moving = false return end
			end
			a.moving = false
			local last = d.legs[ #d.legs ] or { class = math.random() < 0.5 and "node_concealment_crouch" or "node_pathnode", yaw = a.yaw }
			if a == S.tankKiller then a:Play( "idle", { loop = true } ) return end
			if a.ladderTarget and manMG( a ) then return end
			holdCover( a, last, function() return a.busy end, a.axis and 0 or 0.08 )
		end )
		if a.axis then
			go( function()
				local life = math.Rand( 20, 25 )
				while S and a.alive and S.t - a.born < life do coroutine.yield() end
				if S and a.alive and a.pos:Distance( S.ender.pos ) >= 350 then
					killActor( a )
				elseif S and a.alive then
					a.hp = 1
					wait( math.Rand( 0.8, 2.5 ) )
					if S and a.alive then killActor( a ) end
				end
			end )
		end
	end
end

local function driveVehicle( v, path, opt )
	local i = 1
	local speed = ( tonumber( path[ 1 ].speed ) or 10 ) * MPH
	while S and i <= #path do
		local n = path[ i ]
		local target = onGround( W( n.pos ), n.pos.z + 60 )
		while S do
			local d = Vector( target.x - v.pos.x, target.y - v.pos.y, 0 )
			local len = d:Length()
			if len < 10 then break end
			local want = d:Angle().y
			v.yaw = math.ApproachAngle( v.yaw, want, S.dt * ( opt.turn or 60 ) )
			local step = math.min( len, v.speed * S.dt )
			local cap = speed
			if i == #path then cap = math.min( speed, math.max( 12, math.sqrt( 2 * ( opt.brake or 600 ) * len ) ) ) end
			v.speed = math.Approach( v.speed, cap, S.dt * ( v.speed > cap and ( opt.brake or 600 ) * 1.6 or ( opt.accel or 200 ) ) )
			v.pos = onGround( v.pos + d:GetNormalized() * step, v.pos.z + 50 )
			v.spin = ( ( v.spin or 0 ) + step / ( opt.wheel or 22 ) * 57.3 ) % 360
			if opt.tick then opt.tick( step ) end
			coroutine.yield()
		end
		local sp = tonumber( n.speed )
		if sp and sp > 0 then speed = sp * MPH end
		if opt.reached then opt.reached( n, i ) end
		i = i + 1
	end
	v.speed = 0
end

local function truckEvent()
	local T = CS.truck
	local truck = newProp( "models/cod1/vehicles/opel_truck.mdl" )
	truck.pos, truck.yaw, truck.speed = onGround( W( T.pos ), T.pos.z + 60 ), T.yaw, 25 * MPH
	local wheels = {}
	for _, name in ipairs( { "tag_wheel_back_left", "tag_wheel_back_right", "tag_wheel_front_left", "tag_wheel_front_right" } ) do
		local b = truck.ent:LookupBone( name )
		if b then wheels[ #wheels + 1 ] = b end
	end
	local tags = COD1.VehicleTags and COD1.VehicleTags.opel_truck or {}
	local seatTag = tags.tag_driver or { Vector( 27.4, 13.6, 49.1 ), 0 }
	local d = soldier( "actor_ally_airborne_carbine" )
	d.inTruck = true
	d:Play( "truck_drive", { loop = true } )
	local function seat() d:Place( truck.pos + rot( seatTag[ 1 ], truck.yaw ), truck.yaw + seatTag[ 2 ] ) end
	seat()
	loopSound( "truck", "cod1/vehicles/truck_move.wav", 0.8 )
	local out = false
	driveVehicle( truck, T.path, { turn = 90, accel = 500, brake = 650, wheel = tags.wheel or 22, tick = function()
		for _, b in ipairs( wheels ) do truck.ent:ManipulateBoneAngles( b, Angle( truck.spin, 0, 0 ) ) end
		if not d.free then seat() end
		loopVolume( "truck", math.Clamp( truck.speed / 300, 0.25, 0.85 ), 2 )
	end, reached = function( n )
		if n.note == "get out" and not out then
			out = true
			sfxAt( "cod1/vehicles/skids/skid02.wav", truck.pos, 0.6 )
		end
	end } )
	truck.speed = 0
	loopVolume( "truck", 0.25, 1.5 )
	if not S or not out then return end
	seat()
	truck.seq, truck.t0, truck.dur, truck.loop = "climbout", S.t, seqData( "truck_out" ).dur, false
	d:Play( "truck_out" )
	waitAnim( d )
	if not S then return end
	seat()
	d:Settle()
	d.free = true
	d.inTruck = false
	d.moving = true
	d.moveSeq = "run"
	for _, leg in ipairs( T.driver ) do
		runSteps( d, leg.steps, "run", { stop = function() return not d.alive end } )
	end
	d.moving = false
	holdCover( d, T.driver[ #T.driver ], function() return false end, 0.08 )
end

local function mortarEvent()
	local e = S.ender
	go( function()
		wait( 0.35 )
		sfx( "cod1/cine/incoming08.wav", 0.9 )
		wait( 0.68 )
		if not S then return end
		local hit = onGround( W( CS.mortar.origin ), CS.mortar.origin.z + 60 )
		explosion( hit, 2 )
		local burn = addFire( hit + Vector( 0, 0, 6 ), 0.8, 10, 26, 1 )
		go( function()
			wait( 2.5 )
			if S then table.RemoveByValue( S.fires, burn ) end
		end )
		wait( 0.1 )
		if not S then return end
		Set.hidden[ CS.mortar.patch ] = true
		e.interrupt = function()
			e:Play( "knockdown" )
			waitAnim( e )
			e:Settle()
			e:Play( "wobble" )
			waitAnim( e )
			e:Settle()
			wait( 0.25 )
			go( truckEvent )
		end
	end )
end

local function mortarTeam()
	local M = CS.mortarteam
	local node = onGround( W( M.pos ), M.pos.z + 60 )
	local roles = { { "mortar_aim_wait", "mortar_aim_pickup", "mortar_aim_idle", "mortar_aim_fire" }, { "mortar_load_wait", "mortar_load_pickup", "mortar_load_idle", "mortar_load_fire" } }
	S.mortarCrew = {}
	for i, c in ipairs( M.crew ) do
		local a = soldier( "actor_axis_fallschirmjager_soldier_kar98k" )
		a:Place( node, M.yaw )
		a.anchored = true
		a.busy = true
		a.stance = "crouch"
		a.born = math.huge
		a.roles = roles[ i ] or roles[ 1 ]
		a:Play( a.roles[ 1 ], { loop = true, from = i * 0.3 } )
		S.mortarCrew[ i ] = a
	end
end

local function mortarFire()
	if S.mortarFiring then return end
	S.mortarFiring = true
	local node = onGround( W( CS.mortarteam.pos ), CS.mortarteam.pos.z + 60 )
	go( function()
		for _, a in ipairs( S.mortarCrew ) do if a.alive then a:Play( a.roles[ 2 ] ) end end
		wait( 1.5 )
		while S do
			local alive = false
			for _, a in ipairs( S.mortarCrew ) do
				if a.alive then
					alive = true
					a:Play( a.roles[ 4 ] )
				end
			end
			if not alive then return end
			wait( 0.6 )
			if not S then return end
			sfxAt( "cod1/cine/mortar_launch.wav", node, 0.9 )
			emit( { mat = fxMat( "sprites/light_glow02_add" ), pos = node + Vector( 0, 0, 40 ), life = 0.12, s0 = 90, s1 = 40, col = Vector( 255, 200, 140 ), a0 = 255, a1 = 0, add = true } )
			for _ = 1, 4 do
				emit( { mat = fxMat( "particle/particle_smokegrenade" ), pos = node + Vector( 0, 0, 40 ), vel = Vector( math.Rand( -20, 20 ), math.Rand( -20, 20 ), math.Rand( 80, 160 ) ),
					life = math.Rand( 2, 3.5 ), s0 = 10, s1 = 70, col = Vector( 150, 145, 140 ), a0 = 120, a1 = 0, drag = 0.5, slow = true } )
			end
			go( function()
				wait( 1.4 )
				if not S then return end
				sfx( "cod1/cine/incoming0" .. ( { 1, 5, 8 } )[ math.random( 1, 3 ) ] .. ".wav", 0.6 )
				wait( 1.3 )
				if not S then return end
				local e = S.ender
				local ang = math.Rand( 0, 360 )
				local r = math.Rand( 320, 750 )
				explosion( onGround( e.pos + Vector( math.cos( math.rad( ang ) ) * r, math.sin( math.rad( ang ) ) * r, 0 ), e.pos.z + 200 ), 1 )
			end )
			for _, a in ipairs( S.mortarCrew ) do
				if a.alive then
					waitAnim( a )
					if a.alive then a:Play( a.roles[ 3 ], { loop = true } ) end
				end
			end
			wait( math.Rand( 2.5, 4 ) )
		end
	end )
end

local function tankStart()
	if S.tank then return end
	local T = CS.tank
	local tank = newProp( "models/cod1/cine/tiger.mdl" )
	tank.model = "tiger"
	propPlay( tank, "idle", false )
	tank.pos = onGround( W( T.path[ 1 ].pos ), T.path[ 1 ].pos.z + 60 )
	tank.yaw = ( W( T.path[ 2 ].pos ) - W( T.path[ 1 ].pos ) ):Angle().y
	tank.speed = 0
	S.tank = tank
	loopSound( "tank", "cod1/cine/tank_move.wav", 0 )
	go( function()
		driveVehicle( tank, T.path, { turn = 35, accel = 60, brake = 110, tick = function()
			loopVolume( "tank", math.Clamp( 1.2 - tank.pos:Distance( S.ender.pos ) / 2400, 0.15, 0.9 ), 1.5 )
			shake( math.Clamp( 0.45 - tank.pos:Distance( S.cam.pos ) / 1600, 0, 0.3 ) )
		end } )
		S.tankArrived = true
		local ang = Angle( 0, tank.yaw, 0 )
		S.tankBlock = { c = tank.pos, f = ang:Forward(), r = ang:Right(), len = 190, wid = 105 }
		loopVolume( "tank", 0.1, 0.4 )
		loopSound( "tankidle", "cod1/cine/tank_idle.wav", 0.45 )
	end )
end

local function tankKill()
	local e = S.ender
	e.stance = "stand"
	fightUntil( e, function() return S.tankArrived end, 0.18 )
	local tank = S.tank
	local hatch = tank.pos + rot( COD1.CineData.tags.tiger.tag_hatch.pos, tank.yaw )
	local hyaw = tank.yaw
	local run1, run2 = seqData( "tank_runup" ).start, seqData( "tank_runup2" ).start
	local start1 = onGround( hatch + rot( run1.pos, hyaw ), tank.pos.z + 40 )
	local start2 = onGround( hatch + rot( run2.pos, hyaw ), tank.pos.z + 40 )
	local g = S.tankKiller
	if not g or not g.alive then
		g = soldier( "actor_ally_airborne_garand" )
		g:Place( onGround( W( Vector( -14976, -19605, -90 ) ), -50 ), 180 )
		S.tankKiller = g
	end
	g.busy = true
	g.moving = false
	go( function()
		g.moving = true
		moveAlong( g, { start2 }, "run" )
		g.moving = false
		turnTo( g, hyaw + run2.yaw, 500 )
		g:Place( hatch, hyaw )
		g.anchored = true
		g:Play( "tank_runup2" )
		waitAnim( g )
		g:Play( "tank_runup2", { hold = 1 } )
		g.ready = true
	end )
	e.moving = true
	moveAlong( e, { start1 }, "run" )
	e.moving = false
	turnTo( e, hyaw + run1.yaw, 500 )
	e:Place( hatch, hyaw )
	e:Play( "tank_runup" )
	waitAnim( e )
	e:Play( "tank_wait", { loop = true } )
	waitUntil( function() return g.ready end, 10 )
	local nade = newProp( "models/cod1/props/mk2_grenade.mdl" )
	nade.visible = false
	propPlay( tank, "hatch", false )
	sfxAt( "cod1/cine/tank_hatch.wav", hatch, 0.9 )
	e:Play( "tank_attack", { onNote = function( note, a )
		if note == "fire" then
			local mz = a:Bone( "thompson_tag_flash" )
			local into = hatch + Vector( 0, 0, -40 )
			muzzle( mz, ( into - mz ):GetNormalized() )
			sfxAt( "cod1/weapons/thompson/thompson_01.wav", mz, 0.9, math.random( 92, 100 ) )
		end
	end } )
	g:Play( "tank_attack2", { onNote = function( note, a )
		if note == "grenade attach" then
			nade.visible = true
			go( function()
				while S and nade.visible and not nade.thrown do
					nade.pos = a:Bone( "bip01 r hand" )
					coroutine.yield()
				end
			end )
		elseif note == "grenade throw" then
			nade.thrown = true
			local from = a:Bone( "bip01 r hand" )
			go( function()
				local t0 = S.t
				while S and S.t < t0 + 0.35 do
					nade.pos = LerpVector( ( S.t - t0 ) / 0.35, from, hatch + Vector( 0, 0, -10 ) )
					coroutine.yield()
				end
				if S then nade.visible = false end
			end )
		end
	end } )
	go( function()
		wait( seqData( "tiger.hatch" ).dur or 4.8 )
		waitAnim( g )
		if not S then return end
		g.anchored = true
		unanchor( g )
		g.moving = true
		moveAlong( g, { onGround( W( CS.tank.flee ), CS.tank.flee.z + 60 ) }, "run" )
		g.moving = false
		g.stance = "crouch"
		g.busy = false
		fightUntil( g, function() return false end, 0.3 )
	end )
	go( function()
		wait( ( seqData( "tiger.hatch" ).dur or 4.8 ) + 3 )
		if not S then return end
		loopVolume( "tankidle", 0, 3 )
		loopVolume( "tank", 0, 3 )
		tank.visible = false
		local wreck = newProp( "models/cod1/cine/tiger_d.mdl" )
		wreck.pos, wreck.yaw = tank.pos, tank.yaw
		explosion( tank.pos + Vector( 0, 0, 40 ), 2.4, { metal = true } )
		explosion( tank.pos + Vector( 0, 0, 90 ), 1.2, { silent = true } )
		shake( 1.6 )
		addFire( tank.pos + Vector( 0, 0, 70 ), 1.6, 18, 40, 1.4 )
		addFire( tank.pos + rot( Vector( -80, 30, 40 ), tank.yaw ), 1, 10, 20, 0.8 )
	end )
	waitAnim( e )
	e.anchored = true
	e:Settle()
	e.anchored = nil
end

local function enderScript()
	local e = S.ender
	local legs = CS.ender.legs
	local L1 = legs[ 1 ]
	local node = onGround( W( L1.pos ), L1.pos.z + 40 )
	local chute = newProp( "models/cod1/cine/chute.mdl" )
	chute.model = "chute"
	chute.pos, chute.yaw = node, L1.yaw
	propPlay( chute, "land", false )
	e:Place( node, L1.yaw )
	e:Play( "land" )
	S.camDest = node.z
	go( function()
		wait( 1.0 )
		if not S then return end
		sfx( "cod1/misc/para_land_player.wav", 0.9 )
		dirtPuff( node )
	end )
	waitAnim( e )
	e:Settle()
	local i = 2
	local held = {}
	while S and i <= #legs do
		local leg = legs[ i ]
		if leg.wait and not held[ i ] then
			local lim = S.t + 40
			fightUntil( e, function() return not axisInside( leg.wait ) or S.t > lim end, 0.18 )
		end
		e.moving = true
		e.moveSeq = "run"
		runSteps( e, leg.steps, "run", { stop = interruptible( e ) } )
		e.moving = false
		local note = leg.note
		if note == "tank" then
			tankKill()
			local t3 = S.t + 3
			fightUntil( e, function() return S.t > t3 end, 0.18 )
		elseif note == "prone attack" then
			e:Play( "crouchrun2prone" )
			waitAnim( e )
			e:Settle()
			e.stance = "prone"
			local nxt = legs[ i + 1 ]
			if nxt then
				e.moving = true
				e.moveSeq = "prone_crawl"
				runSteps( e, nxt.steps, "prone_crawl", { stop = interruptible( e ) } )
				e.moving = false
				i = i + 1
			end
			local t4 = S.t + 4
			fightUntil( e, function() return S.t > t4 end, 0.18 )
			e:Play( "prone2crouch" )
			waitAnim( e )
			e:Settle()
			e.stance = "crouch"
			local after = legs[ i + 1 ]
			if after and after.wait then
				local lim = S.t + 40
				fightUntil( e, function() return not axisInside( after.wait ) or S.t > lim end, 0.18 )
			end
			e.stance = "stand"
		elseif note ~= "dont stop" and note ~= "neutral" then
			local t3 = S.t + 3
			local nxt = legs[ i + 1 ]
			local gate = nxt and nxt.wait
			local lim = S.t + 43
			held[ i + 1 ] = gate and true or nil
			holdCover( e, leg, function()
				return S.t > t3 and ( not gate or not axisInside( gate ) or S.t > lim )
			end, 0.18 )
			e.stance = "stand"
		end
		i = i + 1
	end
	S.ending = S.t
	fade( 1, 5 )
	if COD1.MusicPlayer then COD1.MusicPlayer.Stop( 5 ) end
	for _, l in pairs( S.loops ) do l.target, l.speed = 0, 0.3 end
	go( function() holdCover( e, legs[ #legs ], function() return false end, 0.18 ) end )
	wait( 5.5 )
end

local function triggers()
	local e = S.ender
	local spawned, heights = {}, {}
	while S do
		local p = e:Bone( "bip01 pelvis" )
		p = Vector( p.x, p.y, e.pos.z )
		for gi, g in ipairs( CS.spawns ) do
			if not spawned[ gi ] and inside( p, g.bounds ) then
				spawned[ gi ] = true
				spawnGroup( g )
			end
		end
		for _, h in ipairs( CS.heights ) do
			if inside( p, h.bounds, 400 ) then
				S.camDest = h.height
				if h.note == "make mortars" then mortarFire() end
			end
		end
		if not S.mortarDone and inside( p, CS.mortar.bounds, 96 ) then
			S.mortarDone = true
			mortarEvent()
		end
		if not S.tank and inside( p, CS.tank.trigger, 96 ) then tankStart() end
		coroutine.yield()
	end
end

local function replica()
	CS = COD1.CreditsScript
	S.camDest, S.camHeight, S.leftOffset = 0, 0, 0
	local e = soldier( "actor_ally_airborne_thompson", { model = "models/cod1/american/heroes.mdl",
		groups = { body = 0, head = 0, helmet = 2, load = 0, weapon = 0 } } )
	S.ender = e
	e.hp = 1e9
	e:Place( onGround( W( CS.ender.pos ), CS.ender.pos.z + 40 ), 180 )
	mortarTeam()
	music( "sound/cod1/music/pegasusbridge_credits.mp3", 0.5 )
	go( function()
		wait( 81 )
		if S and not S.ending then music( "sound/cod1/music/codtheme.mp3", 2 ) end
	end )
	loopSound( "night", "cod1/ambient/amb_pegasusnight.mp3", 0.35 )
	sfx( "cod1/vehicles/c47_flyby0" .. math.random( 1, 4 ) .. ".wav", 0.7 )
	go( triggers )
	S.camDest = e.pos.z
	S.camHeight = e.pos.z
	cut( function()
		local pos = Vector( e.pos.x - 40 + S.leftOffset, e.pos.y - 400, 54 + 60 + S.camHeight )
		local top = math.max( pos.z, e.pos.z ) + 320
		local gz = groundZ( pos.x, pos.y, top )
		for k = 1, 10 do
			if gz then break end
			pos.y = pos.y + 32
			gz = groundZ( pos.x, pos.y, top )
		end
		if gz and pos.z < gz + 28 then pos.z = gz + 28 end
		return pos, Angle( 10, 90, 0 ), 80, e.pos
	end, 9 )
	fade( 0, 1.2 )
	enderScript()
end

local function overlay()
	if not S then return end
	local w, h = ScrW(), ScrH()
	if S.whiteout > 0 then
		surface.SetDrawColor( 255, 245, 230, 255 * S.whiteout )
		surface.DrawRect( 0, 0, w, h )
	end
	if S.black > 0 then
		surface.SetDrawColor( 0, 0, 0, 255 * S.black )
		surface.DrawRect( 0, 0, w, h )
	end
	if not Set or not Set.ready then
		COD1.DrawText( "...", 320, 440, 0.4, DIM.r, DIM.g, DIM.b, 120, false, "center" )
	end
	hook.Run( "COD1CreditsOverlay", S.t )
end

local function stop()
	if not S then return end
	local st = S
	S = nil
	COD1.CreditsPlaying = nil
	for _, a in ipairs( st.actors ) do a:Remove() end
	for _, p in ipairs( st.props ) do if IsValid( p.ent ) then p.ent:Remove() end end
	for _, l in pairs( st.loops ) do if IsValid( l.ch ) then l.ch:Stop() end end
	if COD1.MusicPlayer then COD1.MusicPlayer.Stop( 2 ) end
	if COD1.AmbienceChannel and IsValid( COD1.AmbienceChannel ) then COD1.AmbienceChannel:Play() end
	for _, pnl in ipairs( st.hiddenKids ) do if IsValid( pnl ) then pnl:SetVisible( true ) end end
	for _, pnl in ipairs( st.panels ) do if IsValid( pnl ) then pnl:SetVisible( true ) end end
	destroySet()
	for _, name in ipairs( { "RenderScene", "DrawOverlay", "HUDShouldDraw", "PreDrawViewModel", "CreateMove", "Think", "ShutDown" } ) do
		hook.Remove( name, "COD1Credits" )
	end
end

local function fail( where, err )
	ErrorNoHalt( "[CoD1] credits stopped (" .. where .. "): " .. tostring( err ) .. "\n" )
	stop()
end

local function think()
	if not S then return end
	local now = RealTime()
	local dt = math.Clamp( now - S.real, 0, 0.1 ) * S.timeScale
	S.real = now
	if S.building then
		local ok, err = coroutine.resume( S.building )
		if not ok then return fail( "loading", err ) end
		if coroutine.status( S.building ) == "dead" then
			S.building = nil
			S.t = S.startAt
			S.threads = {}
			S.main = coroutine.create( replica )
		end
		return
	end
	S.dt = dt
	S.t = S.t + dt
	if system.HasFocus() and ( input.IsKeyDown( KEY_SPACE ) or input.IsKeyDown( KEY_ENTER ) ) then
		S.skipHold = ( S.skipHold or 0 ) + dt
	else
		S.skipHold = math.max( 0, ( S.skipHold or 0 ) - dt * 2 )
	end
	if S.skipHold >= 0.9 and not S.skipping then
		S.skipping = true
		fade( 1, 0.8 )
		if COD1.MusicPlayer then COD1.MusicPlayer.Stop( 1 ) end
		timer.Simple( 0.9, stop )
	end
	local ok, err = coroutine.resume( S.main )
	if not S then return end
	if not ok then return fail( "script", err ) end
	if coroutine.status( S.main ) == "dead" then stop() return end
	for i = #S.threads, 1, -1 do
		local th = S.threads[ i ]
		local tok, terr = coroutine.resume( th )
		if not S then return end
		if not tok then return fail( "script", terr ) end
		if coroutine.status( th ) == "dead" then table.remove( S.threads, i ) end
	end
	if S.fadeT0 then
		local k = math.Clamp( ( S.t - S.fadeT0 ) / S.fadeLen, 0, 1 )
		S.black = Lerp( ease( k ), S.fadeFrom, S.fadeTo )
		if k >= 1 then S.fadeT0 = nil end
	end
	S.whiteout = math.max( 0, S.whiteout - dt * 0.6 )
	S.camHeight = S.camHeight * 0.98 ^ ( dt / 0.05 ) + S.camDest * ( 1 - 0.98 ^ ( dt / 0.05 ) )
	if S.ending then S.leftOffset = S.leftOffset - math.min( 5, math.floor( ( S.t - S.ending ) / 0.3 ) ) * dt / 0.05 end
	for i = #S.fx, 1, -1 do
		local p = S.fx[ i ]
		if S.t - p.born > p.life then
			table.remove( S.fx, i )
		else
			if p.grav then p.vel.z = p.vel.z + p.grav * dt end
			if p.drag then p.vel = p.vel * math.max( 0, 1 - p.drag * dt ) end
			p.pos = p.pos + p.vel * dt
		end
	end
	for i = #S.lights, 1, -1 do if S.t > S.lights[ i ].t1 then table.remove( S.lights, i ) end end
	for i = #S.beams, 1, -1 do if S.t > S.beams[ i ].t1 then table.remove( S.beams, i ) end end
	for _, f in ipairs( S.fires ) do fireTick( f, dt ) end
	for _, l in pairs( S.loops ) do
		if l.speed then l.vol = math.Approach( l.vol, l.target, dt * l.speed ) end
		if IsValid( l.ch ) then l.ch:SetVolume( l.vol ) end
	end
	for _, pnl in ipairs( { vgui.GetWorldPanel(), unpack( S.panels ) } ) do
		if IsValid( pnl ) then
			for _, c in ipairs( pnl:GetChildren() ) do
				if c:IsVisible() and ( c.ClassName == "NoticePanel" or pnl ~= vgui.GetWorldPanel() ) then
					c:SetVisible( false )
					S.hiddenKids[ #S.hiddenKids + 1 ] = c
				end
			end
		end
	end
	updateCamera( dt )
end

local function begin( speed )
	if S then stop() end
	if not loadData() then
		ErrorNoHalt( "[CoD1] credits data missing\n" )
		return
	end
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	S = {
		t = 0, real = RealTime(), dt = 0, startAt = 0, timeScale = speed or 1,
		actors = {}, props = {}, fx = {}, lights = {}, beams = {}, fires = {}, loops = {}, allies = {}, axis = {},
		cam = { pos = Vector(), ang = Angle(), fov = 75 }, shake = 0, black = 1, whiteout = 0,
		lightMul = 1, camDest = 0, camHeight = 0, leftOffset = 0,
		fogColor = Vector( 0, 0, 0 ), fogStart = 290, fogEnd = 700, sunColor = Vector( 0.12, 0.1, 0.09 ),
		ambient = Vector( 0.03, 0.035, 0.05 ), fxLight = 0.75,
	}
	S.building = coroutine.create( function()
		if not Set or not Set.ready then buildSet() end
	end )
	COD1.CreditsPlaying = true
	if COD1.MusicPlayer then COD1.MusicPlayer.Stop( 1 ) end
	if COD1.AmbienceChannel and IsValid( COD1.AmbienceChannel ) then COD1.AmbienceChannel:Pause() end
	S.panels, S.hiddenKids = {}, {}
	for _, pnl in ipairs( { GetHUDPanel and GetHUDPanel(), GetOverlayPanel and GetOverlayPanel() } ) do
		if IsValid( pnl ) and pnl:IsVisible() then
			S.panels[ #S.panels + 1 ] = pnl
			pnl:SetVisible( false )
		end
	end
	for _, fire in ipairs( { { -14583, -19397, -45, 1 }, { -18183, -19832, -89, 1 }, { -17677, -19565, -82, 1.4 }, { -17535, -19572, 100, 0.8 } } ) do
		local f = { pos = P( fire[ 1 ], fire[ 2 ], fire[ 3 ] ), size = fire[ 4 ], rate = 12, w = 18 * fire[ 4 ], glow = 1 }
		S.fires[ #S.fires + 1 ] = f
	end
	hook.Add( "RenderScene", "COD1Credits", function()
		local ok, res = pcall( renderScene )
		if not ok then
			if S and S.inCam then cam.End3D() end
			render.SuppressEngineLighting( false )
			render.SetColorModulation( 1, 1, 1 )
			fail( "render", res )
			return
		end
		return res
	end )
	hook.Add( "DrawOverlay", "COD1Credits", function()
		local ok, err = pcall( overlay )
		if not ok then fail( "overlay", err ) end
	end )
	hook.Add( "HUDShouldDraw", "COD1Credits", function() return false end )
	hook.Add( "PreDrawViewModel", "COD1Credits", function() return true end )
	hook.Add( "CreateMove", "COD1Credits", function( cmd )
		cmd:ClearMovement()
		cmd:ClearButtons()
	end )
	hook.Add( "Think", "COD1Credits", function()
		local ok, err = pcall( think )
		if not ok then fail( "think", err ) end
	end )
	hook.Add( "ShutDown", "COD1Credits", stop )
end

function COD1.PlayCredits()
	begin( 1 )
end

function COD1.StopCredits()
	stop()
end

concommand.Add( "cod1_credits", function( _, _, args )
	begin( math.Clamp( tonumber( args[ 1 ] or "1" ) or 1, 0.25, 8 ) )
end )

--the credits took me way longer then the actual soldiers lol
