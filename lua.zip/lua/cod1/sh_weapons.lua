CreateConVar( "cod1_player_hands", "auto", { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "First-person arms: auto, us, uswinter, british, british_air, russian, whermact, waffen, fallschirmjager" )
CreateConVar( "cod1_swep_damage", "1", { FCVAR_ARCHIVE, FCVAR_NOTIFY, FCVAR_REPLICATED }, "Damage multiplier for the CoD1 player weapons" )

COD1.HandSets = { "us", "uswinter", "british", "british_air", "russian", "whermact", "waffen", "fallschirmjager" }
function COD1.HandSet()
	local v = GetConVar( "cod1_player_hands" ):GetString()
	if v == "auto" or not table.HasValue( COD1.HandSets, v ) then v = COD1.PlayerSide() == "axis" and "whermact" or "us" end
	return table.KeyFromValue( COD1.HandSets, v ) - 1
end

for key, d in pairs( COD1.WeaponDefs ) do
	game.AddAmmoType( { name = "cod1_" .. key, dmgtype = DMG_BULLET, tracer = TRACER_LINE_AND_WHIZ, plydmg = 0, npcdmg = 0, force = 2000, maxcarry = d.maxAmmo or 300 } )
	if CLIENT then language.Add( "cod1_" .. key .. "_ammo", d.name .. " rounds" ) end
end

local HOLD = { pistol = "pistol", smg = "smg", grenade = "grenade", rocketlauncher = "rpg", flamethrower = "shotgun", spotter = "camera" }
local SLOT = { pistol = 1, grenade = 4, rocketlauncher = 3, flamethrower = 3, spotter = 5 }
function COD1.SetupSWEP( SWEP, category )
	local d = COD1.WeaponDefs[ SWEP.CoDKey ]
	SWEP.PrintName = d.name
	SWEP.Category = category or "Call of Duty 1"
	SWEP.Author = "adodser"
	SWEP.ViewModel = "models/cod1/weapons/v_" .. SWEP.CoDKey .. ".mdl"
	SWEP.WorldModel = "models/cod1/weapons/w_" .. SWEP.CoDKey .. ".mdl"
	SWEP.HoldType = HOLD[ d.class ] or "ar2"
	SWEP.Slot = SLOT[ d.class ] or 2
	SWEP.SlotPos = 10
	if d.class == "grenade" then
		SWEP.Primary = { ClipSize = -1, DefaultClip = d.startAmmo or 3, Automatic = false, Ammo = "cod1_" .. SWEP.CoDKey }
		return
	end
	if d.class == "spotter" then
		SWEP.Primary = { ClipSize = -1, DefaultClip = 0, Automatic = false, Ammo = "none" }
		return
	end
	SWEP.Primary = { ClipSize = d.clipSize, DefaultClip = d.clipSize + ( d.startAmmo or d.clipSize * 3 ),
		Automatic = d.semiAuto ~= 1, Ammo = "cod1_" .. SWEP.CoDKey }
end

concommand.Add( "cod1_melee", function( ply )
	local w = IsValid( ply ) and ply:GetActiveWeapon()
	if IsValid( w ) and w.Melee and w.CoDKey then w:Melee() end
end )

hook.Add( "SetupMove", "COD1ADSSpeed", function( ply, mv )
	local w = ply:GetActiveWeapon()
	if not ( IsValid( w ) and w.CoDKey and w.GetADS and w:GetADS() ) then return end
	if w.Deployable then
		mv:SetMaxClientSpeed( 0 )
		mv:SetForwardSpeed( 0 )
		mv:SetSideSpeed( 0 )
		mv:SetButtons( bit.band( mv:GetButtons(), bit.bnot( IN_JUMP ) ) )
	else
		mv:SetMaxClientSpeed( mv:GetMaxClientSpeed() * 0.6 )
	end
end )

local GUN_POS, GUN_ANG = Vector( 1, -0.385, 1.42 ), Angle( 4.623, 90.663, 8.753 )
function COD1.PlaceWorldGun( ent, pos, ang )
	local fwd, up = GUN_ANG:Forward(), GUN_ANG:Up()
	local right = fwd:Cross( up )
	local wf, wr, wu = ang:Forward(), ang:Right(), ang:Up()
	local function toWorld( v ) return wf * v:Dot( fwd ) + wr * v:Dot( right ) + wu * v:Dot( up ) end
	local entFwd, entUp = toWorld( Vector( 1, 0, 0 ) ), toWorld( Vector( 0, 0, 1 ) )
	local entAng = entFwd:AngleEx( entUp )
	ent:SetAngles( entAng )
	ent:SetPos( pos - entAng:Forward() * GUN_POS.x + entAng:Right() * GUN_POS.y - entAng:Up() * GUN_POS.z )
end

--weapon setup, every gun from both games
