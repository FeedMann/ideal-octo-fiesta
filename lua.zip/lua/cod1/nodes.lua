COD1.Nodes = COD1.Nodes or {}

local CELL = 256
local CORNER_WALL, CORNER_EDGE = 26, 18
local MASK = MASK_SOLID_BRUSHONLY
local DIRS = {}
for i = 0, 7 do DIRS[ #DIRS + 1 ] = Vector( math.cos( i * math.pi / 4 ), math.sin( i * math.pi / 4 ), 0 ) end

local grid, building, ready = {}, nil, false

local function cellKey( x, y ) return math.floor( x / CELL ) .. ":" .. math.floor( y / CELL ) end

local function addNode( n )
	COD1.Nodes[ #COD1.Nodes + 1 ] = n
	local k = cellKey( n.pos.x, n.pos.y )
	grid[ k ] = grid[ k ] or {}
	table.insert( grid[ k ], n )
end

function COD1.NodesNear( pos, radius )
	local out, r2 = {}, radius * radius
	local x0, x1 = math.floor( ( pos.x - radius ) / CELL ), math.floor( ( pos.x + radius ) / CELL )
	local y0, y1 = math.floor( ( pos.y - radius ) / CELL ), math.floor( ( pos.y + radius ) / CELL )
	for x = x0, x1 do
		for y = y0, y1 do
			for _, n in ipairs( grid[ x .. ":" .. y ] or {} ) do
				if n.pos:DistToSqr( pos ) < r2 then out[ #out + 1 ] = n end
			end
		end
	end
	return out
end

local function flat( v ) return Vector( v.x, v.y, 0 ) end

local function wallAhead( p, dir, z, dist )
	local s = p + Vector( 0, 0, z )
	return util.TraceLine( { start = s, endpos = s + dir * dist, mask = MASK } )
end

local function ground( p )
	local tr = util.TraceLine( { start = p + Vector( 0, 0, 40 ), endpos = p - Vector( 0, 0, 60 ), mask = MASK } )
	if tr.Hit and not tr.StartSolid and tr.HitNormal.z > 0.7 then return tr.HitPos end
end

local function roomFor( p )
	return not util.TraceHull( { start = p + Vector( 0, 0, 4 ), endpos = p + Vector( 0, 0, 4 ),
		mins = Vector( -14, -14, 0 ), maxs = Vector( 14, 14, 68 ), mask = MASK } ).Hit
end

local function duplicate( pos, kind, fwd, side )
	for _, n in ipairs( COD1.NodesNear( pos, 40 ) ) do
		if n.kind == kind and n.side == side and n.fwd:Dot( fwd ) > 0.85 then return true end
	end
	return false
end

local function openAt( p, fwd, reach )
	return not wallAhead( p, fwd, 16, reach ).Hit and not wallAhead( p, fwd, 50, reach ).Hit and not wallAhead( p, fwd, 84, reach ).Hit
end

local function findEdge( base, fwd, lat )
	local up = Vector( 0, 0, 50 )
	local last = 0
	local reach = CORNER_WALL + 14
	for e = 12, 120, 12 do
		if util.TraceLine( { start = base + lat * last + up, endpos = base + lat * e + up, mask = MASK } ).Hit then return end
		if not wallAhead( base + lat * e, fwd, 50, reach ).Hit then
			if not openAt( base + lat * e, fwd, reach ) then return end
			for f = e - 8, e - 4, 4 do
				if openAt( base + lat * f, fwd, reach ) then return f end
			end
			return e
		end
		last = e
	end
end

local function scan( p )
	for _, d in ipairs( DIRS ) do
		local tr = wallAhead( p, d, 24, 48 )
		if not tr.Hit or tr.StartSolid then tr = wallAhead( p, d, 40, 48 ) end
		if tr.Hit and not tr.StartSolid and math.abs( tr.HitNormal.z ) < 0.3 then
			local fwd = flat( -tr.HitNormal ):GetNormalized()
			if fwd:Dot( d ) > 0.7 then
				local base = ground( Vector( tr.HitPos.x, tr.HitPos.y, p.z ) - fwd * CORNER_WALL )
				if base and roomFor( base ) then
					local reach = CORNER_WALL + 14
					local low, mid, high = wallAhead( base, fwd, 26, reach ).Hit, wallAhead( base, fwd, 44, reach ).Hit, wallAhead( base, fwd, 66, reach ).Hit
					local lintel = wallAhead( base, fwd, 96, reach + 20 ).Hit
					if low and not mid and ( not lintel or not high ) then
						if not wallAhead( base, fwd, 50, reach + 80 ).Hit and not duplicate( base, "crouch", fwd ) then
							addNode( { pos = base, fwd = fwd, yaw = fwd:Angle().y, kind = "crouch", window = lintel or nil } )
						end
					elseif mid and not high then
						if not wallAhead( base, fwd, 70, reach + 80 ).Hit and not duplicate( base, "stand", fwd ) then
							addNode( { pos = base, fwd = fwd, yaw = fwd:Angle().y, kind = "stand", window = lintel or nil } )
						end
					elseif high then
						local left = Vector( -fwd.y, fwd.x, 0 )
						for _, side in ipairs( { 1, -1 } ) do
							local lat = left * side
							local e = findEdge( base, fwd, lat )
							local spot = e and ground( base + lat * ( e - CORNER_EDGE ) )
							if spot and roomFor( spot ) and not duplicate( spot, "corner", fwd, side == 1 and "r" or "l" ) then
								local peek = spot + lat * 28 + fwd * 22
								if not util.TraceLine( { start = spot + Vector( 0, 0, 52 ), endpos = peek + Vector( 0, 0, 52 ), mask = MASK } ).Hit then
									addNode( { pos = spot, fwd = fwd, yaw = fwd:Angle().y, kind = "corner", side = side == 1 and "r" or "l" } )
								end
							end
						end
					end
				end
			end
		end
	end
end

local function samples( area )
	local out = {}
	local nw = area:GetCorner( 0 )
	local sx, sy = area:GetSizeX(), area:GetSizeY()
	local step = 48
	for x = 8, math.max( 8, sx - 8 ), step do
		for y = 8, math.max( 8, sy - 8 ), step do
			local p = Vector( nw.x + math.min( x, sx - 8 ), nw.y + math.min( y, sy - 8 ), 0 )
			p.z = area:GetZ( p )
			out[ #out + 1 ] = p
			if #out >= 64 then return out end
		end
	end
	return out
end

local function cachePath() return "cod1_nodes/" .. game.GetMap() .. ".txt" end
local function signature() return "3:" .. #navmesh.GetAllNavAreas() end

local function save()
	local rows = {}
	for _, n in ipairs( COD1.Nodes ) do
		rows[ #rows + 1 ] = { n.pos.x, n.pos.y, n.pos.z, n.fwd.x, n.fwd.y, n.kind, n.side or "", n.window and 1 or 0 }
	end
	file.CreateDir( "cod1_nodes" )
	file.Write( cachePath(), util.TableToJSON( { sig = signature(), nodes = rows } ) )
end

local function load()
	local raw = file.Read( cachePath(), "DATA" )
	local t = raw and util.JSONToTable( raw )
	if not t or t.sig ~= signature() or not t.nodes then return false end
	COD1.Nodes, grid = {}, {}
	for _, r in ipairs( t.nodes ) do
		local fwd = Vector( r[ 4 ], r[ 5 ], 0 )
		addNode( { pos = Vector( r[ 1 ], r[ 2 ], r[ 3 ] ), fwd = fwd, yaw = fwd:Angle().y, kind = r[ 6 ], side = r[ 7 ] ~= "" and r[ 7 ] or nil, window = r[ 8 ] == 1 or nil } )
	end
	return true
end

function COD1.BuildNodes( force )
	if not navmesh.IsLoaded() or building then return end
	ready = false
	if not force and load() then
		ready = true
		print( "[CoD1] Loaded " .. #COD1.Nodes .. " cover nodes for " .. game.GetMap() )
		return
	end
	COD1.Nodes, grid = {}, {}
	local areas = navmesh.GetAllNavAreas()
	building = coroutine.create( function()
		for _, area in ipairs( areas ) do
			if IsValid( area ) and not area:IsUnderwater() and not area:HasAttributes( NAV_MESH_CROUCH )
				and area:GetSizeX() >= 16 and area:GetSizeY() >= 16 then
				for _, p in ipairs( samples( area ) ) do
					scan( p )
					coroutine.yield()
				end
			end
		end
	end )
	print( "[CoD1] Finding cover nodes in " .. #areas .. " navmesh areas..." )
end

hook.Add( "Think", "COD1BuildNodes", function()
	if not building then return end
	local t = SysTime()
	while SysTime() - t < 0.004 do
		local ok, err = coroutine.resume( building )
		if not ok then ErrorNoHalt( "[CoD1] cover node build failed: " .. tostring( err ) .. "\n" ) building = nil return end
		if coroutine.status( building ) == "dead" then
			building = nil
			ready = true
			save()
			local count = { corner = 0, crouch = 0, stand = 0, window = 0 }
			for _, n in ipairs( COD1.Nodes ) do count[ n.kind ] = count[ n.kind ] + 1 if n.window then count.window = count.window + 1 end end
			print( string.format( "[CoD1] %d cover nodes: %d corners, %d low walls, %d chest-high walls (%d of them windows)", #COD1.Nodes, count.corner, count.crouch, count.stand, count.window ) )
			return
		end
	end
end )

function COD1.NodesReady()
	if ready then return true end
	if not building and navmesh.IsLoaded() then COD1.BuildNodes() end
	return false
end

hook.Add( "InitPostEntity", "COD1BuildNodes", function() timer.Simple( 2, function() COD1.BuildNodes() end ) end )

function COD1.NodeTaken( n, by )
	for s, c in pairs( COD1.Cover ) do
		if s ~= by and IsValid( s ) and c:DistToSqr( n.pos ) < 48 * 48 then return true end
	end
	for s in pairs( COD1.Soldiers ) do
		if s ~= by and IsValid( s ) and not s.Dead and s:GetPos():DistToSqr( n.pos ) < 36 * 36 then return true end
	end
	return false
end

concommand.Add( "cod1_nodes_rebuild", function( ply )
	if IsValid( ply ) and not ply:IsSuperAdmin() and not game.SinglePlayer() then return end
	COD1.BuildNodes( true )
end )

concommand.Add( "cod1_nodes_show", function( ply, cmd, args )
	if IsValid( ply ) and not ply:IsAdmin() and not game.SinglePlayer() then return end
	local t = tonumber( args[ 1 ] ) or 20
	local center = IsValid( ply ) and ply:GetPos() or vector_origin
	local col = { corner = Color( 60, 140, 255 ), crouch = Color( 60, 255, 90 ), stand = Color( 255, 220, 40 ) }
	local shown = 0
	for _, n in ipairs( COD1.NodesNear( center, 3000 ) ) do
		local c = col[ n.kind ]
		if n.kind == "corner" and n.side == "l" then c = Color( 60, 230, 255 ) end
		debugoverlay.Box( n.pos, Vector( -6, -6, 0 ), Vector( 6, 6, n.kind == "crouch" and 38 or 64 ), t, Color( c.r, c.g, c.b, 60 ) )
		debugoverlay.Line( n.pos + Vector( 0, 0, 40 ), n.pos + Vector( 0, 0, 40 ) + n.fwd * 28, t, c, true )
		shown = shown + 1
	end
	if IsValid( ply ) then
		ply:ChatPrint( string.format( "[CoD1] %d cover nodes near you (blue/cyan corners, green low walls, yellow chest-high). Needs 'developer 1' to draw.", shown ) )
	end
end )

--cover spots. if they hide behind a fence post its not my fault
