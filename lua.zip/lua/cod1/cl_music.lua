local M = COD1.MusicPlayer or {}
COD1.MusicPlayer = M
M.channels = M.channels or {}

local function volume()
	return math.Clamp( GetConVar( "cod1_music_volume" ):GetFloat(), 0, 1 )
end

function M.FadeOutAll( t )
	for _, c in ipairs( M.channels ) do
		c.target = 0
		c.speed = 1 / math.max( t or 1, 0.05 )
		c.dying = true
	end
	M.current = nil
end

function M.Play( file, opts )
	opts = opts or {}
	M.FadeOutAll( opts.fadeOut or 1.5 )
	local token = {}
	M.pending = token
	sound.PlayFile( file, "noplay noblock", function( ch )
		if not IsValid( ch ) then return end
		if M.pending ~= token then ch:Stop() return end
		M.pending = nil
		ch:EnableLooping( opts.loop == true )
		ch:SetVolume( 0 )
		if opts.rate then ch:SetPlaybackRate( opts.rate ) end
		ch:Play()
		local c = { ch = ch, file = file, vol = 0, mul = opts.volume or 1, target = 1, speed = 1 / math.max( opts.fadeIn or 1, 0.05 ),
			kind = opts.kind, onEnd = opts.onEnd, title = opts.title }
		table.insert( M.channels, c )
		M.current = c
	end )
end

function M.Stop( t )
	M.pending = nil
	M.FadeOutAll( t or 1.5 )
end

function M.Current()
	return M.current
end

hook.Add( "Think", "COD1Music", function()
	local dt = FrameTime()
	for i = #M.channels, 1, -1 do
		local c = M.channels[ i ]
		if not IsValid( c.ch ) then
			table.remove( M.channels, i )
		else
			c.vol = math.Approach( c.vol, c.target, c.speed * dt )
			c.ch:SetVolume( c.vol * c.mul * volume() )
			if c.dying and c.vol <= 0 then
				c.ch:Stop()
				table.remove( M.channels, i )
			elseif c.ch:GetState() == GMOD_CHANNEL_STOPPED and not c.dying then
				table.remove( M.channels, i )
				if M.current == c then M.current = nil end
				if c.onEnd then c.onEnd() end
			end
		end
	end
end )

local function tracks( mood )
	local out = {}
	for _, t in ipairs( COD1.Music or {} ) do
		if t.mood == mood then out[ #out + 1 ] = t end
	end
	return out
end

local lastBattleTrack
local function nextBattleTrack()
	local list = tracks( "battle" )
	if #list == 0 then return end
	local pick
	for _ = 1, 4 do
		pick = list[ math.random( #list ) ]
		if pick ~= lastBattleTrack then break end
	end
	lastBattleTrack = pick
	M.Play( pick.file, { kind = "battle", fadeIn = 2.5, fadeOut = 2, volume = 0.8, title = pick.title, onEnd = function()
		if M.inBattle then nextBattleTrack() end
	end } )
end

timer.Create( "COD1BattleMusic", 1, 0, function()
	local ply = LocalPlayer()
	if not IsValid( ply ) then return end
	local cur = M.current
	if COD1.CreditsPlaying or cur and ( cur.kind == "jukebox" or cur.kind == "credits" ) then return end
	local on = GetConVar( "cod1_music_battle" ):GetBool()
	local last = ply:GetNW2Float( "COD1Battle", 0 )
	local fighting = on and last > 0 and CurTime() - last < 8
	if fighting then
		M.inBattle = true
		M.calmSince = nil
		if not cur or cur.kind ~= "battle" then nextBattleTrack() end
	elseif M.inBattle then
		M.calmSince = M.calmSince or CurTime()
		if not on or CurTime() - M.calmSince > 10 then
			M.inBattle = false
			if cur and cur.kind == "battle" then M.Stop( 5 ) end
		end
	end
end )

function M.PlayTrack( i )
	local t = COD1.Music and COD1.Music[ i ]
	if not t then return end
	M.Play( t.file, { kind = "jukebox", fadeIn = 0.5, fadeOut = 0.8, title = t.title, onEnd = function()
		local n = COD1.Music[ i + 1 ] and i + 1 or 1
		if M.autoNext then M.PlayTrack( n ) end
	end } )
	M.jukeboxIndex = i
end

--the music in this game still goes hard
