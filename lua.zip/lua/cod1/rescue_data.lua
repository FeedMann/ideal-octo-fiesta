COD1.RescueLayout = { start = { 34.83, -0.55, -213.66 }, fallen = { 8.92, 0.06, 0.00 } }

--drag your buddy to safety numbers
