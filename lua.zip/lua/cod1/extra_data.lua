COD1 = COD1 or {}

COD1.Speeches = {
	com_52 = { snd = "cod1/voiceovers/stalingrad/commissar2_line_52.wav", text = "No hesitation comrades! Do not take one step backwards!", at = 0.000 },
	com_50 = { snd = "cod1/voiceovers/stalingrad/commissar4_line_50.wav", text = "For Mother Russia comrades! Do not turn your back on her!", at = 0.000 },
	com_51b = { snd = "cod1/voiceovers/stalingrad/commissar4_line_51.wav", text = "", at = 0.000 },
	com_41 = { snd = "cod1/voiceovers/stalingrad/commissar4_line_41.wav", text = "Kill him! Death to traitors!", at = 0.000 },
	com_40 = { snd = "cod1/voiceovers/stalingrad/commissar1_line_40.wav", text = "Traitor!!", at = 0.000 },
	com_51 = { snd = "cod1/voiceovers/stalingrad/commissar2_line_51.wav", text = "Move, damn you, move! Don't fall back!", at = 0.000 },
	com_49 = { snd = "cod1/voiceovers/stalingrad/commissar3_line_49.wav", text = "", at = 0.000 },
	com_building = { snd = "cod1/voiceovers/stalingrad/buildingcommissar.wav", text = "", at = 0.000 },
	mega_42 = { snd = "cod1/voiceovers/stalingrad/megaphonecommissar_line_42.wav", text = "", at = 0.167 },
	mega_43 = { snd = "cod1/voiceovers/stalingrad/megaphonecommissar_line_43.wav", text = "", at = 0.000 },
	mega_44 = { snd = "cod1/voiceovers/stalingrad/megaphonecommissar_line_44.wav", text = "", at = 0.000 },
}
COD1.CommissarShouts = {
	{ snd = "cod1/voiceovers/stalingrad/commissar4_line_49.wav", text = "Do not retreat! Cowards and traitors will be shot!!" },
	{ snd = "cod1/voiceovers/stalingrad/commissar4_line_9.wav", text = "Victory or death!" },
	{ snd = "cod1/voiceovers/stalingrad/commissar3_line_76.wav", text = "Death to the Fascists!" },
	{ snd = "cod1/voiceovers/stalingrad/commissar1_line_86.wav", text = "Pick up your gun and shoot!" },
	{ snd = "cod1/voiceovers/stalingrad/commissar3_amb16.wav", text = "Come on, come on, come on!" },
	{ snd = "cod1/voiceovers/stalingrad/commissar1_line_29.wav", text = "Stop those traitors!" },
	{ snd = "cod1/voiceovers/stalingrad/commissar1_line_26.wav", text = "Traitor! Traitor!" },
	{ snd = "cod1/voiceovers/stalingrad/commissar3_line_28.wav", text = "No retreat! Kill them! Kill the deserters!" },
	{ snd = "cod1/voiceovers/stalingrad/commissar4_line_27.wav", text = "No mercy for deserters! No mercy!!" },
}
COD1.CommissarCharge = { "cod1/voiceovers/stalingrad/commissar1_line_73.wav", "cod1/voiceovers/stalingrad/commissar3_line_77.wav", "cod1/voiceovers/stalingrad/commissar4_line_73.wav", "cod1/voiceovers/stalingrad/commissar4_line_74.wav", "cod1/voiceovers/stalingrad/commissar3_line_76.wav", "cod1/voiceovers/stalingrad/commissar4_line_9.wav" }
COD1.CommissarPain = { "cod1/voiceovers/stalingrad/commissar1_line_46a.wav", "cod1/voiceovers/stalingrad/commissar1_line_46b.wav", "cod1/voiceovers/stalingrad/commissar2_line_48a.wav", "cod1/voiceovers/stalingrad/commissar2_line_48b.wav" }
COD1.CommissarDeath = { "cod1/voiceovers/stalingrad/commissar1_line_46c.wav", "cod1/voiceovers/stalingrad/commissar1_line_46d.wav", "cod1/voiceovers/stalingrad/commissar2_line_48c.wav", "cod1/voiceovers/stalingrad/commissar2_line_48d.wav" }
COD1.Music = {
	{ file = "sound/cod1/music/codtheme.mp3", title = "Call of Duty Theme", mood = "theme" },
	{ file = "sound/cod1/music/mainmenu1.mp3", title = "Main Menu", mood = "calm" },
	{ file = "sound/cod1/music/pegasusbridge.mp3", title = "Pegasus Bridge", mood = "battle" },
	{ file = "sound/cod1/music/pf_stealth.mp3", title = "Pathfinder: Stealth", mood = "calm" },
	{ file = "sound/cod1/music/pf_frantic.mp3", title = "Pathfinder: Frantic", mood = "battle" },
	{ file = "sound/cod1/music/airfield_main.mp3", title = "Airfield", mood = "battle" },
	{ file = "sound/cod1/music/airfield_escape.mp3", title = "Airfield Escape", mood = "battle" },
	{ file = "sound/cod1/music/carride_a.mp3", title = "Car Ride I", mood = "battle" },
	{ file = "sound/cod1/music/carride_b.mp3", title = "Car Ride II", mood = "battle" },
	{ file = "sound/cod1/music/dam_a.mp3", title = "Eder Dam I", mood = "battle" },
	{ file = "sound/cod1/music/dam_b.mp3", title = "Eder Dam II", mood = "battle" },
	{ file = "sound/cod1/music/truckride.mp3", title = "Truck Ride", mood = "battle" },
	{ file = "sound/cod1/music/powcamp_ramgate.mp3", title = "POW Camp", mood = "battle" },
	{ file = "sound/cod1/music/ship_approach.mp3", title = "Battleship Tirpitz: Approach", mood = "calm" },
	{ file = "sound/cod1/music/ship_loop.mp3", title = "Battleship Tirpitz", mood = "calm" },
	{ file = "sound/cod1/music/ship_action.mp3", title = "Battleship Tirpitz: Action", mood = "battle" },
	{ file = "sound/cod1/music/stalingrad_boatride.mp3", title = "Stalingrad: The Volga", mood = "calm" },
	{ file = "sound/cod1/music/stalingrad_battle.mp3", title = "Stalingrad", mood = "battle" },
	{ file = "sound/cod1/music/stalingrad_victory.mp3", title = "Stalingrad: Victory", mood = "victory" },
	{ file = "sound/cod1/music/redsquare_dark.mp3", title = "Red Square: Dark", mood = "calm" },
	{ file = "sound/cod1/music/redsquare_tense.mp3", title = "Red Square: Tense", mood = "calm" },
	{ file = "sound/cod1/music/redsquare_charge.mp3", title = "Red Square: Charge", mood = "battle" },
	{ file = "sound/cod1/music/tankdrive_a.mp3", title = "Tank Drive I", mood = "battle" },
	{ file = "sound/cod1/music/tankdrive_b.mp3", title = "Tank Drive II", mood = "battle" },
	{ file = "sound/cod1/music/phonograph_bruckner.mp3", title = "Bruckner on the Phonograph", mood = "calm" },
	{ file = "sound/cod1/music/datestamp.mp3", title = "Datestamp", mood = "sting" },
	{ file = "sound/cod1/music/training_datestamp.mp3", title = "Training Datestamp", mood = "sting" },
}


--extra bits that didnt fit anywhere else
