COD1.CreditsScript = {
	ender = { pos = Vector( 2061.0, -21200.0, 6.0 ), legs = {
			{ pos = Vector( 2024.0, -21208.0, 24.0 ), class = "node_scripted", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( 2024.0, -21208.0, 24.0 ) } } },
			{ pos = Vector( 941.0, -21216.0, 25.0 ), class = "node_cover_left", note = "", yaw = 90.0, wait = nil, steps = { { "move", Vector( 1921.0, -21197.0, 21.0 ) }, { "move", Vector( 1345.0, -21261.0, 43.0 ) }, { "trav", Vector( 1263.0, -21278.0, 43.0 ), "wall_dive", 192.0 }, { "move", Vector( 941.0, -21216.0, 25.0 ) } } },
			{ pos = Vector( 453.0, -21096.0, 21.0 ), class = "node_cover_crouch", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( 453.0, -21096.0, 21.0 ) } } },
			{ pos = Vector( -530.0, -21099.0, 28.0 ), class = "node_concealment_prone", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( 474.0, -21176.0, 33.0 ) }, { "move", Vector( -13.0, -21136.0, 81.0 ) }, { "trav", Vector( -65.0, -21136.0, 85.0 ), "fence_climb", 180.0 }, { "move", Vector( -270.0, -21158.0, 24.0 ) }, { "move", Vector( -530.0, -21099.0, 28.0 ) } } },
			{ pos = Vector( -2537.0, -21030.0, 37.0 ), class = "node_cover_crouch", note = "", yaw = 90.0, wait = nil, steps = { { "move", Vector( -932.0, -21088.0, 0.0 ) }, { "move", Vector( -2537.0, -21030.0, 37.0 ) } } },
			{ pos = Vector( -4434.0, -20742.0, -174.0 ), class = "node_pathnode", note = "dont stop", yaw = 270.0, wait = nil, steps = { { "move", Vector( -2927.0, -21070.0, 70.0 ) }, { "move", Vector( -4065.0, -21000.0, -40.0 ) }, { "trav", Vector( -4167.0, -21025.0, -64.0 ), "jump_down", 194.0 }, { "move", Vector( -4434.0, -20742.0, -174.0 ) } } },
			{ pos = Vector( -4941.0, -20597.0, -61.0 ), class = "node_pathnode", note = "dont stop", yaw = 61.6, wait = nil, steps = { { "move", Vector( -4779.0, -20812.0, -96.0 ) }, { "move", Vector( -4941.0, -20597.0, -61.0 ) } } },
			{ pos = Vector( -6601.0, -19577.0, -96.0 ), class = "node_cover_stand", note = "dont stop", yaw = 180.0, wait = nil, steps = { { "move", Vector( -5098.0, -20496.0, -60.0 ) }, { "move", Vector( -6351.0, -19862.0, -49.0 ) }, { "move", Vector( -6448.0, -19604.0, -49.0 ) }, { "move", Vector( -6601.0, -19577.0, -96.0 ) } } },
			{ pos = Vector( -7495.0, -20190.0, -49.0 ), class = "node_cover_stand", note = "", yaw = 145.0, wait = nil, steps = { { "move", Vector( -6809.0, -19568.0, -49.0 ) }, { "move", Vector( -6957.0, -19752.0, -49.0 ) }, { "move", Vector( -6931.0, -19868.0, -49.0 ) }, { "move", Vector( -6998.0, -20140.0, -49.0 ) }, { "move", Vector( -7051.0, -20270.0, -49.0 ) }, { "move", Vector( -7358.0, -20312.0, -49.0 ) }, { "move", Vector( -7495.0, -20190.0, -49.0 ) } } },
			{ pos = Vector( -9285.0, -19975.0, -73.0 ), class = "node_pathnode", note = "neutral", yaw = 180.0, wait = nil, steps = { { "move", Vector( -7625.0, -20120.0, -49.0 ) }, { "move", Vector( -7849.0, -20234.0, -49.0 ) }, { "move", Vector( -8147.0, -20255.0, -49.0 ) }, { "move", Vector( -8480.0, -20174.0, -49.0 ) }, { "move", Vector( -8501.0, -20055.0, -46.0 ) }, { "trav", Vector( -8545.0, -20056.0, 6.0 ), "step_up", 180.0 }, { "move", Vector( -8872.0, -20017.0, -27.0 ) }, { "move", Vector( -9285.0, -19975.0, -73.0 ) } } },
			{ pos = Vector( -9853.0, -19865.0, -164.0 ), class = "node_pathnode", note = "prone attack", yaw = 180.0, wait = nil, steps = { { "move", Vector( -9853.0, -19865.0, -164.0 ) } } },
			{ pos = Vector( -10149.0, -19860.0, -164.0 ), class = "node_pathnode", note = "mortar guys", yaw = 0.0, wait = nil, steps = { { "move", Vector( -10149.0, -19860.0, -164.0 ) } } },
			{ pos = Vector( -14379.0, -19637.0, -69.0 ), class = "node_cover_left", note = "", yaw = 180.0, wait = { Vector( -10569.0, -20081.0, -338.0 ), Vector( -10149.0, -19664.0, -50.0 ) }, steps = { { "move", Vector( -10366.0, -19927.0, -191.0 ) }, { "move", Vector( -10648.0, -20014.0, -193.0 ) }, { "move", Vector( -11243.0, -19868.0, -112.0 ) }, { "move", Vector( -11785.0, -19855.0, -30.0 ) }, { "move", Vector( -14379.0, -19637.0, -69.0 ) } } },
			{ pos = Vector( -14769.0, -19770.0, -58.0 ), class = "node_negotiation_end", note = "dont stop", yaw = 180.0, wait = nil, steps = { { "move", Vector( -14342.0, -19666.0, -63.0 ) }, { "move", Vector( -14693.0, -19770.0, -62.0 ) }, { "trav", Vector( -14769.0, -19770.0, -58.0 ), "window", 180.0 }, { "move", Vector( -14769.0, -19770.0, -58.0 ) } } },
			{ pos = Vector( -14859.0, -19904.0, -74.0 ), class = "node_cover_left", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( -14859.0, -19904.0, -74.0 ) } } },
			{ pos = Vector( -15434.0, -19969.0, -62.0 ), class = "node_pathnode", note = "tank", yaw = 0.0, wait = { Vector( -15920.0, -20057.0, -188.0 ), Vector( -14721.0, -19384.0, 100.0 ) }, steps = { { "move", Vector( -14893.0, -19936.0, -62.0 ) }, { "move", Vector( -15434.0, -19969.0, -62.0 ) } } },
			{ pos = Vector( -15993.0, -19646.0, -109.0 ), class = "node_pathnode", note = "dont stop", yaw = 0.0, wait = nil, steps = { { "move", Vector( -15993.0, -19646.0, -109.0 ) } } },
			{ pos = Vector( -16735.0, -19644.0, -69.0 ), class = "node_cover_left", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( -16166.0, -19667.0, -107.0 ) }, { "move", Vector( -16735.0, -19644.0, -69.0 ) } } },
			{ pos = Vector( -16959.0, -19676.0, -35.0 ), class = "node_cover_left", note = "", yaw = 90.0, wait = nil, steps = { { "move", Vector( -16806.0, -19734.0, -91.0 ) }, { "move", Vector( -16874.0, -19714.0, -77.0 ) }, { "move", Vector( -16959.0, -19676.0, -35.0 ) } } },
			{ pos = Vector( -17447.0, -19740.0, -76.0 ), class = "node_cover_left", note = "dont stop", yaw = 180.0, wait = { Vector( -17902.0, -20063.0, -182.0 ), Vector( -16990.0, -19436.0, 105.0 ) }, steps = { { "move", Vector( -17181.0, -19803.0, -96.0 ) }, { "move", Vector( -17447.0, -19740.0, -76.0 ) } } }
		} },
	spawns = {
		{ bounds = { Vector( -5644.0, -20755.0, -182.0 ), Vector( -5589.0, -19324.0, 105.0 ) }, note = "", actors = {
			{ class = "actor_ally_airborne_garand", pos = Vector( -5102.0, -19629.0, 99.0 ), yaw = 180.0, note = "", legs = {
			{ pos = Vector( -7220.0, -19566.0, 97.0 ), class = "node_pathnode", note = "", yaw = 225.0, wait = nil, steps = { { "move", Vector( -5341.0, -19697.0, 64.0 ) }, { "move", Vector( -6245.0, -19614.0, -9.0 ) }, { "move", Vector( -6573.0, -19366.0, 0.0 ) }, { "move", Vector( -7220.0, -19566.0, 97.0 ) } } },
			{ pos = Vector( -7261.0, -20046.0, 32.0 ), class = "node_concealment_prone", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( -7261.0, -20046.0, 32.0 ) } } }
		} },
			{ class = "actor_ally_airborne_garand", pos = Vector( -5218.0, -19723.0, 67.0 ), yaw = 180.0, note = "", legs = {
			{ pos = Vector( -6821.0, -19342.0, 8.0 ), class = "node_concealment_prone", note = "", yaw = 210.0, wait = nil, steps = { { "move", Vector( -5493.0, -19801.0, 40.0 ) }, { "move", Vector( -6821.0, -19342.0, 8.0 ) } } }
		} },
			{ class = "actor_ally_airborne_garand", pos = Vector( -5179.0, -19840.0, 74.0 ), yaw = 180.0, note = "", legs = {
			{ pos = Vector( -6493.0, -19366.0, -32.0 ), class = "node_concealment_prone", note = "", yaw = 210.0, wait = nil, steps = { { "move", Vector( -5221.0, -19865.0, 32.0 ) }, { "move", Vector( -6493.0, -19366.0, -32.0 ) } } }
		} }
		} },
		{ bounds = { Vector( -5890.0, -20767.0, -182.0 ), Vector( -5835.0, -19336.0, 105.0 ) }, note = "", actors = {
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -6721.0, -19565.0, -65.0 ), yaw = 0.0, note = "", legs = {
			{ pos = Vector( -6601.0, -19577.0, -96.0 ), class = "node_cover_stand", note = "dont stop", yaw = 180.0, wait = nil, steps = { { "move", Vector( -6601.0, -19577.0, -96.0 ) } } },
			{ pos = Vector( -7495.0, -20190.0, -49.0 ), class = "node_cover_stand", note = "", yaw = 145.0, wait = nil, steps = { { "move", Vector( -6809.0, -19568.0, -49.0 ) }, { "move", Vector( -6957.0, -19752.0, -49.0 ) }, { "move", Vector( -6931.0, -19868.0, -49.0 ) }, { "move", Vector( -6998.0, -20140.0, -49.0 ) }, { "move", Vector( -7051.0, -20270.0, -49.0 ) }, { "move", Vector( -7358.0, -20312.0, -49.0 ) }, { "move", Vector( -7495.0, -20190.0, -49.0 ) } } },
			{ pos = Vector( -9285.0, -19975.0, -73.0 ), class = "node_pathnode", note = "neutral", yaw = 180.0, wait = nil, steps = { { "move", Vector( -7625.0, -20120.0, -49.0 ) }, { "move", Vector( -7849.0, -20234.0, -49.0 ) }, { "move", Vector( -8147.0, -20255.0, -49.0 ) }, { "move", Vector( -8480.0, -20174.0, -49.0 ) }, { "move", Vector( -8501.0, -20055.0, -46.0 ) }, { "trav", Vector( -8545.0, -20056.0, 6.0 ), "step_up", 180.0 }, { "move", Vector( -8872.0, -20017.0, -27.0 ) }, { "move", Vector( -9285.0, -19975.0, -73.0 ) } } },
			{ pos = Vector( -9853.0, -19865.0, -164.0 ), class = "node_pathnode", note = "prone attack", yaw = 180.0, wait = nil, steps = { { "move", Vector( -9853.0, -19865.0, -164.0 ) } } },
			{ pos = Vector( -10149.0, -19860.0, -164.0 ), class = "node_pathnode", note = "mortar guys", yaw = 0.0, wait = nil, steps = { { "move", Vector( -10149.0, -19860.0, -164.0 ) } } },
			{ pos = Vector( -14379.0, -19637.0, -69.0 ), class = "node_cover_left", note = "", yaw = 180.0, wait = { Vector( -10569.0, -20081.0, -338.0 ), Vector( -10149.0, -19664.0, -50.0 ) }, steps = { { "move", Vector( -10366.0, -19927.0, -191.0 ) }, { "move", Vector( -10648.0, -20014.0, -193.0 ) }, { "move", Vector( -11243.0, -19868.0, -112.0 ) }, { "move", Vector( -11785.0, -19855.0, -30.0 ) }, { "move", Vector( -14379.0, -19637.0, -69.0 ) } } },
			{ pos = Vector( -14769.0, -19770.0, -58.0 ), class = "node_negotiation_end", note = "dont stop", yaw = 180.0, wait = nil, steps = { { "move", Vector( -14342.0, -19666.0, -63.0 ) }, { "move", Vector( -14693.0, -19770.0, -62.0 ) }, { "trav", Vector( -14769.0, -19770.0, -58.0 ), "window", 180.0 }, { "move", Vector( -14769.0, -19770.0, -58.0 ) } } },
			{ pos = Vector( -14859.0, -19904.0, -74.0 ), class = "node_cover_left", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( -14859.0, -19904.0, -74.0 ) } } },
			{ pos = Vector( -15434.0, -19969.0, -62.0 ), class = "node_pathnode", note = "tank", yaw = 0.0, wait = { Vector( -15920.0, -20057.0, -188.0 ), Vector( -14721.0, -19384.0, 100.0 ) }, steps = { { "move", Vector( -14893.0, -19936.0, -62.0 ) }, { "move", Vector( -15434.0, -19969.0, -62.0 ) } } },
			{ pos = Vector( -15993.0, -19646.0, -109.0 ), class = "node_pathnode", note = "dont stop", yaw = 0.0, wait = nil, steps = { { "move", Vector( -15993.0, -19646.0, -109.0 ) } } },
			{ pos = Vector( -16735.0, -19644.0, -69.0 ), class = "node_cover_left", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( -16166.0, -19667.0, -107.0 ) }, { "move", Vector( -16735.0, -19644.0, -69.0 ) } } },
			{ pos = Vector( -16959.0, -19676.0, -35.0 ), class = "node_cover_left", note = "", yaw = 90.0, wait = nil, steps = { { "move", Vector( -16806.0, -19734.0, -91.0 ) }, { "move", Vector( -16874.0, -19714.0, -77.0 ) }, { "move", Vector( -16959.0, -19676.0, -35.0 ) } } },
			{ pos = Vector( -17447.0, -19740.0, -76.0 ), class = "node_cover_left", note = "dont stop", yaw = 180.0, wait = { Vector( -17902.0, -20063.0, -182.0 ), Vector( -16990.0, -19436.0, 105.0 ) }, steps = { { "move", Vector( -17181.0, -19803.0, -96.0 ) }, { "move", Vector( -17447.0, -19740.0, -76.0 ) } } }
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -7150.0, -19502.0, 68.0 ), yaw = 0.0, note = "", legs = {
			
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -6670.0, -19845.0, 6.0 ), yaw = 0.0, note = "", legs = {
			
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -6405.0, -19946.0, -77.0 ), yaw = 0.0, note = "", legs = {
			
		} }
		} },
		{ bounds = { Vector( -6658.0, -19662.0, -182.0 ), Vector( -6603.0, -19391.0, 105.0 ) }, note = "", actors = {
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -7599.0, -20121.0, -93.0 ), yaw = 0.0, note = "", legs = {
			
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -7867.0, -20082.0, -53.0 ), yaw = 0.0, note = "", legs = {
			{ pos = Vector( -7800.0, -20068.0, -11.0 ), class = "node_concealment_prone", note = "", yaw = 23.0, wait = nil, steps = { { "move", Vector( -7800.0, -20068.0, -11.0 ) } } }
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -7925.0, -20123.0, -44.0 ), yaw = 0.0, note = "", legs = {
			
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -8331.0, -20115.0, -72.0 ), yaw = 0.0, note = "", legs = {
			
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -8210.0, -20048.0, -69.0 ), yaw = 0.0, note = "", legs = {
			{ pos = Vector( -7673.0, -19916.0, 31.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -7673.0, -19916.0, 31.0 ) } } }
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -7549.0, -19735.0, 59.0 ), yaw = 271.0, note = "", legs = {
			{ pos = Vector( -7591.0, -19997.0, 15.0 ), class = "node_pathnode", note = "", yaw = 270.0, wait = nil, steps = { { "move", Vector( -7591.0, -19997.0, 15.0 ) } } }
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -7444.0, -19225.0, 76.0 ), yaw = 271.0, note = "", legs = {
			{ pos = Vector( -7698.0, -19988.0, 14.0 ), class = "node_pathnode", note = "", yaw = 270.0, wait = nil, steps = { { "move", Vector( -7558.0, -19476.0, 94.0 ) }, { "move", Vector( -7698.0, -19988.0, 14.0 ) } } }
		} },
			{ class = "actor_ally_airborne_garand", pos = Vector( -6540.0, -19097.0, -8.0 ), yaw = 285.0, note = "", legs = {
			{ pos = Vector( -7737.0, -20068.0, -9.0 ), class = "node_pathnode", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( -6765.0, -19318.0, 32.0 ) }, { "move", Vector( -7737.0, -20068.0, -9.0 ) } } }
		} },
			{ class = "actor_ally_airborne_BAR", pos = Vector( -6462.0, -19022.0, -16.0 ), yaw = 282.0, note = "", legs = {
			{ pos = Vector( -7850.0, -20042.0, -13.0 ), class = "node_pathnode", note = "", yaw = 195.0, wait = nil, steps = { { "move", Vector( -6709.0, -19174.0, 80.0 ) }, { "move", Vector( -7227.0, -19443.0, 119.0 ) }, { "move", Vector( -7850.0, -20042.0, -13.0 ) } } }
		} },
			{ class = "actor_ally_airborne_garand", pos = Vector( -6277.0, -18989.0, -16.0 ), yaw = 285.0, note = "", legs = {
			{ pos = Vector( -7474.0, -19623.0, 98.0 ), class = "node_pathnode", note = "", yaw = 240.0, wait = nil, steps = { { "move", Vector( -6645.0, -19150.0, 8.0 ) }, { "move", Vector( -7227.0, -19443.0, 119.0 ) }, { "move", Vector( -7474.0, -19623.0, 98.0 ) } } },
			{ pos = Vector( -8276.0, -19870.0, -16.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -7653.0, -19788.0, 53.0 ) }, { "move", Vector( -8276.0, -19870.0, -16.0 ) } } }
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -7990.0, -20096.0, -44.0 ), yaw = 0.0, note = "", legs = {
			
		} },
			{ class = "actor_axis_wehrmacht_soldier_kar98k", pos = Vector( -8101.0, -20121.0, -44.0 ), yaw = 0.0, note = "", legs = {
			
		} }
		} },
		{ bounds = { Vector( -7926.0, -20959.0, -182.0 ), Vector( -7871.0, -19528.0, 105.0 ) }, note = "", actors = {
			{ class = "actor_ally_airborne_garand", pos = Vector( -8403.0, -19021.0, 176.0 ), yaw = 180.0, note = "", legs = {
			{ pos = Vector( -7989.0, -20326.0, -49.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -8300.0, -19342.0, 72.0 ) }, { "move", Vector( -7951.0, -20155.0, -26.0 ) }, { "move", Vector( -7989.0, -20326.0, -49.0 ) } } }
		} },
			{ class = "actor_ally_airborne_BAR", pos = Vector( -8318.0, -19595.0, 8.0 ), yaw = 177.0, note = "", legs = {
			{ pos = Vector( -8388.0, -19886.0, -24.0 ), class = "node_pathnode", note = "", yaw = 270.0, wait = nil, steps = { { "move", Vector( -8388.0, -19886.0, -24.0 ) } } }
		} },
			{ class = "actor_ally_airborne_garand", pos = Vector( -8407.0, -19267.0, 88.0 ), yaw = 180.0, note = "", legs = {
			{ pos = Vector( -8213.0, -19910.0, -24.0 ), class = "node_pathnode", note = "", yaw = 270.0, wait = nil, steps = { { "move", Vector( -8213.0, -19910.0, -24.0 ) } } }
		} },
			{ class = "actor_ally_airborne_garand", pos = Vector( -8552.0, -19344.0, 88.0 ), yaw = 180.0, note = "", legs = {
			{ pos = Vector( -8147.0, -20255.0, -49.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -8372.0, -19422.0, 56.0 ) }, { "move", Vector( -8287.0, -20006.0, -49.0 ) }, { "move", Vector( -8286.0, -20148.0, -49.0 ) }, { "move", Vector( -8147.0, -20255.0, -49.0 ) } } }
		} }
		} },
		{ bounds = { Vector( -13787.0, -20918.0, -182.0 ), Vector( -13732.0, -19487.0, 105.0 ) }, note = "unkillable", actors = {
			{ class = "actor_ally_airborne_garand", pos = Vector( -13449.0, -19491.0, -184.0 ), yaw = 180.0, note = "", legs = {
			{ pos = Vector( -14709.0, -19902.0, -62.0 ), class = "node_cover_left", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( -13787.0, -19424.0, -150.0 ) }, { "move", Vector( -14709.0, -19902.0, -62.0 ) } } }
		} },
			{ class = "actor_ally_airborne_garand", pos = Vector( -13401.0, -19483.0, -184.0 ), yaw = 180.0, note = "", legs = {
			{ pos = Vector( -14674.0, -19996.0, -64.0 ), class = "node_cover_crouch", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( -13536.0, -19414.0, -160.0 ) }, { "move", Vector( -14674.0, -19996.0, -64.0 ) } } }
		} }
		} },
		{ bounds = { Vector( -15113.0, -19853.0, -182.0 ), Vector( -14741.0, -19821.0, 105.0 ) }, note = "", actors = {
			{ class = "actor_axis_waffen_soldier_mp40", pos = Vector( -15485.0, -19851.0, -105.0 ), yaw = 270.0, note = "", legs = {
			{ pos = Vector( -15119.0, -19904.0, -62.0 ), class = "node_cover_right", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -15302.0, -19984.0, -62.0 ) }, { "move", Vector( -15181.0, -19936.0, -62.0 ) }, { "move", Vector( -15119.0, -19904.0, -62.0 ) } } }
		} },
			{ class = "actor_axis_waffen_soldier_mp40", pos = Vector( -15583.0, -19854.0, -119.0 ), yaw = 270.0, note = "", legs = {
			{ pos = Vector( -14975.0, -19904.0, -62.0 ), class = "node_cover_right", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -15302.0, -19984.0, -62.0 ) }, { "move", Vector( -15037.0, -19936.0, -62.0 ) }, { "move", Vector( -14975.0, -19904.0, -62.0 ) } } }
		} },
			{ class = "actor_axis_waffen_soldier_mp40", pos = Vector( -15750.0, -19770.0, -143.0 ), yaw = 270.0, note = "", legs = {
			{ pos = Vector( -15039.0, -19999.0, -82.0 ), class = "node_concealment_prone", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -15629.0, -19824.0, -98.0 ) }, { "move", Vector( -15302.0, -19984.0, -62.0 ) }, { "move", Vector( -15039.0, -19999.0, -82.0 ) } } }
		} }
		} },
		{ bounds = { Vector( -15584.0, -20739.0, -272.0 ), Vector( -15529.0, -19308.0, 15.0 ) }, note = "", actors = {
			{ class = "actor_ally_airborne_garand", pos = Vector( -14976.0, -19605.0, -90.0 ), yaw = 180.0, note = "tank killer", legs = {
			{ pos = Vector( -15420.0, -20137.0, -68.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -15016.0, -19691.0, -72.0 ) }, { "move", Vector( -15085.0, -19678.0, -62.0 ) }, { "move", Vector( -15263.0, -19904.0, -62.0 ) }, { "move", Vector( -15420.0, -20137.0, -68.0 ) } } }
		} }
		} },
		{ bounds = { Vector( -16523.0, -19758.0, -182.0 ), Vector( -16468.0, -19527.0, 105.0 ) }, note = "", actors = {
			{ class = "actor_ally_airborne_garand", pos = Vector( -16827.0, -19538.0, -120.0 ), yaw = 180.0, note = "nohealth", legs = {
			{ pos = Vector( -17072.0, -19816.0, -105.0 ), class = "node_concealment_crouch", note = "", yaw = 180.0, wait = nil, steps = { { "move", Vector( -16775.0, -19550.0, -104.0 ) }, { "move", Vector( -16691.0, -19581.0, -104.0 ) }, { "move", Vector( -16735.0, -19644.0, -69.0 ) }, { "move", Vector( -16806.0, -19734.0, -91.0 ) }, { "move", Vector( -16847.0, -19788.0, -93.0 ) }, { "move", Vector( -16981.0, -19838.0, -98.0 ) }, { "move", Vector( -17072.0, -19816.0, -105.0 ) } } }
		} }
		} },
		{ bounds = { Vector( -16840.0, -19932.0, -182.0 ), Vector( -16785.0, -19608.0, 105.0 ) }, note = "unkillable", actors = {
			{ class = "actor_ally_airborne_garand", pos = Vector( -16836.0, -19490.0, -120.0 ), yaw = 180.0, note = "unseen", legs = {
			{ pos = Vector( -17187.0, -19511.0, 33.0 ), class = "node_pathnode", note = "", yaw = 270.0, wait = nil, steps = { { "move", Vector( -16729.0, -19511.0, -100.0 ) }, { "move", Vector( -16735.0, -19644.0, -69.0 ) }, { "move", Vector( -16806.0, -19734.0, -91.0 ) }, { "move", Vector( -16874.0, -19714.0, -77.0 ) }, { "move", Vector( -16959.0, -19676.0, -35.0 ) }, { "move", Vector( -17027.0, -19621.0, -24.0 ) }, { "move", Vector( -17016.0, -19572.0, -36.0 ) }, { "trav", Vector( -17019.0, -19538.0, 125.0 ), "ladder", 96.0 }, { "move", Vector( -17035.0, -19522.0, 120.0 ) }, { "move", Vector( -17080.0, -19519.0, 120.0 ) }, { "move", Vector( -17087.0, -19520.0, 120.0 ) }, { "trav", Vector( -17140.0, -19520.0, 120.0 ), "jump_down", 180.0 }, { "move", Vector( -17187.0, -19511.0, 33.0 ) } } },
			{ pos = Vector( -17246.0, -19540.0, 33.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -17246.0, -19540.0, 33.0 ) } } }
		} }
		} },
		{ bounds = { Vector( -16983.0, -19890.0, -182.0 ), Vector( -16928.0, -19566.0, 105.0 ) }, note = "nohealth", actors = {
			{ class = "actor_axis_waffen_soldier_mp40", pos = Vector( -17300.0, -19536.0, 17.0 ), yaw = 270.0, note = "", legs = {
			{ pos = Vector( -17187.0, -19511.0, 33.0 ), class = "node_pathnode", note = "", yaw = 270.0, wait = nil, steps = { { "move", Vector( -17187.0, -19511.0, 33.0 ) } } },
			{ pos = Vector( -17246.0, -19540.0, 33.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -17246.0, -19540.0, 33.0 ) } } }
		} }
		} },
	},
	heights = { { bounds = { Vector( -3840.0, -22784.0, -768.0 ), Vector( -3584.0, -18176.0, 1280.0 ) }, height = -190, note = "" }, { bounds = { Vector( -7168.0, -22784.0, -768.0 ), Vector( -6912.0, -18176.0, 1280.0 ) }, height = -20, note = "" }, { bounds = { Vector( -11776.0, -22784.0, -768.0 ), Vector( -11520.0, -18176.0, 1280.0 ) }, height = -120, note = "" }, { bounds = { Vector( -6400.0, -22784.0, -768.0 ), Vector( -6144.0, -18176.0, 1280.0 ) }, height = -60, note = "" }, { bounds = { Vector( -9136.0, -22784.0, -768.0 ), Vector( -9060.0, -18176.0, 1280.0 ) }, height = -160, note = "make mortars" }, { bounds = { Vector( -4864.0, -22784.0, -768.0 ), Vector( -4608.0, -18176.0, 1280.0 ) }, height = 0, note = "" } },
	mortar = { bounds = { Vector( -1864.0, -21217.0, -18.0 ), Vector( -1776.0, -20971.0, 128.0 ) }, origin = Vector( -1821.0, -21092.0, -39.0 ), patch = 3 },
	truck = { pos = Vector( -1710.0, -22167.0, -6.0 ), yaw = 165, path = { { pos = Vector( -1789.0, -22136.0, 30.0 ), speed = 25, note = "" }, { pos = Vector( -2268.0, -21476.0, 50.0 ), speed = 25, note = "" }, { pos = Vector( -2277.0, -21230.0, 49.0 ), speed = 25, note = "get out" }, { pos = Vector( -2269.0, -21006.0, 49.0 ), speed = 2, note = "" } }, driver = {
			{ pos = Vector( -2757.0, -21124.0, 120.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -2757.0, -21124.0, 120.0 ) } } },
			{ pos = Vector( -3696.0, -21137.0, -7.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -3078.0, -21063.0, 50.0 ) }, { "move", Vector( -3696.0, -21137.0, -7.0 ) } } },
			{ pos = Vector( -4239.0, -21027.0, -174.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -4065.0, -21000.0, -40.0 ) }, { "trav", Vector( -4167.0, -21025.0, -64.0 ), "jump_down", 194.0 }, { "move", Vector( -4239.0, -21027.0, -174.0 ) } } },
			{ pos = Vector( -4783.0, -20899.0, -102.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -4304.0, -20828.0, -174.0 ) }, { "move", Vector( -4618.0, -20862.0, -150.0 ) }, { "move", Vector( -4783.0, -20899.0, -102.0 ) } } },
			{ pos = Vector( -4990.0, -20716.0, -65.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -4990.0, -20716.0, -65.0 ) } } },
			{ pos = Vector( -8441.0, -20206.0, -49.0 ), class = "node_pathnode", note = "", yaw = 0.0, wait = nil, steps = { { "move", Vector( -5264.0, -20431.0, -64.0 ) }, { "move", Vector( -5956.0, -20046.0, -9.0 ) }, { "move", Vector( -6068.0, -19902.0, -9.0 ) }, { "move", Vector( -6245.0, -19614.0, -9.0 ) }, { "move", Vector( -6573.0, -19366.0, 0.0 ) }, { "move", Vector( -6877.0, -19462.0, -8.0 ) }, { "move", Vector( -7591.0, -19997.0, 15.0 ) }, { "move", Vector( -7619.0, -20102.0, -49.0 ) }, { "move", Vector( -7849.0, -20234.0, -49.0 ) }, { "move", Vector( -8441.0, -20206.0, -49.0 ) } } }
		} },
	tank = { pos = Vector( -14890.0, -21185.0, -172.0 ), yaw = 89, path = { { pos = Vector( -14627.0, -21269.0, -127.0 ), speed = 5 }, { pos = Vector( -14654.0, -20373.0, -127.0 ), speed = 10 }, { pos = Vector( -14825.0, -20210.0, -127.0 ), speed = 10 }, { pos = Vector( -15068.0, -20152.0, -124.0 ), speed = 10 }, { pos = Vector( -15351.0, -20110.0, -132.0 ), speed = 10 }, { pos = Vector( -15686.0, -20073.0, -131.0 ), speed = 0 }, { pos = Vector( -15987.0, -20059.0, -130.0 ), speed = 0 } }, trigger = { Vector( -14708.0, -20235.0, -182.0 ), Vector( -14654.0, -19582.0, 197.0 ) }, flee = Vector( -14510.0, -20069.0, -82.0 ) },
	mortarteam = { pos = Vector( -10396.0, -19863.0, -214.0 ), yaw = 180, crew = { { pos = Vector( -10316.0, -19817.0, -175.0 ), yaw = 333.0 }, { pos = Vector( -10317.0, -19904.0, -175.0 ), yaw = 333.0 } } },
	mg42 = { { pos = Vector( -8305.0, -20900.0, 38.0 ), yaw = 44 }, { pos = Vector( -6038.0, -20746.0, -66.0 ), yaw = 360 }, { pos = Vector( -17187.0, -19571.0, 31.0 ), yaw = 270 } },
}

--roll the credits
