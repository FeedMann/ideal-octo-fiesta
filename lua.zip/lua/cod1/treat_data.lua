COD1.TreatData = { fps = 30, events = { gun_down = 10, dressing_out = 26, dressing_on = 98, gun_up = 132 }, medicSpot = Vector( 6.00, -31.00, 0 ), medicTurn = 90.00, gunInAnim = true }

--medic patching people up, i animated this one myself
