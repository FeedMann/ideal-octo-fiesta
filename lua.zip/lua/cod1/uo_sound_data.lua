COD1 = COD1 or {}

sound.Add( { name = "COD1.Fire.g43", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 85, 90 }, sound = { "cod1/weapons/gewehr43/gewehr43_01.wav" } } )
sound.Add( { name = "COD1.Reload.g43", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/gewehr43/gewehr43_reload.wav" } } )
sound.Add( { name = "COD1.Fire.svt40", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 95, 105 }, sound = { "cod1/weapons/svt40/svt40_01.wav" } } )
sound.Add( { name = "COD1.Reload.svt40", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/svt40/svt40_reload.wav" } } )
sound.Add( { name = "COD1.Fire.tt33", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/tt33/tt33_01.wav" } } )
sound.Add( { name = "COD1.Reload.tt33", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/tt33/tt33_reload.wav" } } )
sound.Add( { name = "COD1.Fire.webley", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/webley/webley_01.wav" } } )
sound.Add( { name = "COD1.Reload.webley", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/webley/weap_webley_reload.wav" } } )
sound.Add( { name = "COD1.Fire.stensd", channel = CHAN_WEAPON, level = 135, volume = 0.60, pitch = { 90, 100 }, sound = { "cod1/weapons/sten/silenced_sten_01.wav" } } )
sound.Add( { name = "COD1.Reload.stensd", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/sten/sten_reload.wav" } } )
sound.Add( { name = "COD1.Fire.pfaust", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/panzerfaust/panzerfaust_fire.wav" } } )
sound.Add( { name = "COD1.Fire.pschreck", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/bazooka/bazooka_01.wav" } } )
sound.Add( { name = "COD1.Reload.pschreck", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/bazooka/bazooka_reload.wav" } } )
sound.Add( { name = "COD1.Fire.bazooka", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/bazooka/bazooka_01.wav" } } )
sound.Add( { name = "COD1.Reload.bazooka", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/bazooka/bazooka_reload.wav" } } )
sound.Add( { name = "COD1.Fire.mg34", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 100, 110 }, sound = { "cod1/weapons/mg34/mg34_loop01_shot.wav" } } )
sound.Add( { name = "COD1.Loop.mg34", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 100, 110 }, sound = { "cod1/weapons/mg34/mg34_loop01_loop.wav" } } )
sound.Add( { name = "COD1.Reload.mg34", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/mg34/weap_mg34_reload.wav" } } )
sound.Add( { name = "COD1.Fire.dp28", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 95, 100 }, sound = { "cod1/weapons/dp28/dp28_loop01_shot.wav" } } )
sound.Add( { name = "COD1.Loop.dp28", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 95, 100 }, sound = { "cod1/weapons/dp28/dp28_loop01_loop.wav" } } )
sound.Add( { name = "COD1.Reload.dp28", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/dp28/weap_dp28_reload.wav" } } )
sound.Add( { name = "COD1.Fire.mg30cal", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 99, 101 }, sound = { "cod1/weapons/30cal/30cal_loop_shot.wav" } } )
sound.Add( { name = "COD1.Loop.mg30cal", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 99, 101 }, sound = { "cod1/weapons/30cal/30cal_loop_loop.wav" } } )
sound.Add( { name = "COD1.Reload.mg30cal", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/30cal/weap_30cal_fast_reload.wav" } } )
sound.Add( { name = "COD1.Flame.Start", channel = CHAN_WEAPON, level = 100, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/flamethrower/fl_start.wav" } } )
sound.Add( { name = "COD1.Flame.Loop", channel = CHAN_WEAPON, level = 100, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/flamethrower/fl_fire_loop.wav" } } )
sound.Add( { name = "COD1.Flame.Stop", channel = CHAN_WEAPON, level = 95, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/flamethrower/fl_cooldown.wav" } } )
sound.Add( { name = "COD1.Flame.Empty", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/flamethrower/fl_empty.wav" } } )
sound.Add( { name = "COD1.SmokePop", channel = CHAN_AUTO, level = 90, volume = 1.00, pitch = { 80, 120 }, sound = { "cod1/weapons/smokegrenade/smoke_grenade_explode01.wav" } } )
sound.Add( { name = "COD1.SmokeHiss", channel = CHAN_AUTO, level = 80, volume = 1.00, pitch = { 80, 120 }, sound = { "cod1/weapons/smokegrenade/smoke_grenade_smoke01.wav" } } )
sound.Add( { name = "COD1.SatchelPlant", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/misc/bomb_plant01.wav" } } )
sound.Add( { name = "COD1.SatchelBounce", channel = CHAN_BODY, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/satchel/satchel_bounce01.wav", "cod1/weapons/satchel/satchel_bounce02.wav", "cod1/weapons/satchel/satchel_bounce03.wav" } } )
sound.Add( { name = "COD1.BigExplode", channel = CHAN_AUTO, level = 150, volume = 1.00, pitch = { 80, 110 }, sound = { "cod1/explosions/explo_metal01.wav", "cod1/explosions/explo_metal02.wav" } } )
sound.Add( { name = "COD1.RocketExplode", channel = CHAN_AUTO, level = 145, volume = 1.00, pitch = { 80, 120 }, sound = { "cod1/explosions/grenade_explo01.wav", "cod1/explosions/grenade_explo02.wav" } } )
sound.Add( { name = "COD1.ShellExplode", channel = CHAN_AUTO, level = 150, volume = 1.00, pitch = { 80, 120 }, sound = { "cod1/explosions/mortar_dirt01.wav", "cod1/explosions/mortar_dirt02.wav", "cod1/explosions/mortar_dirt03.wav", "cod1/explosions/mortar_dirt04.wav", "cod1/explosions/mortar_dirt05.wav", "cod1/explosions/mortar_dirt01_muffled.wav", "cod1/explosions/mortar_dirt02_muffled.wav", "cod1/explosions/mortar_dirt03_muffled.wav", "cod1/explosions/mortar_dirt04_muffled.wav", "cod1/explosions/mortar_dirt05_muffled.wav" } } )
sound.Add( { name = "COD1.ShellIncoming", channel = CHAN_AUTO, level = 120, volume = 1.00, pitch = { 90, 110 }, sound = { "cod1/explosions/incoming05.wav", "cod1/explosions/incoming08.wav", "cod1/explosions/incoming11.wav", "cod1/explosions/incoming01.wav", "cod1/explosions/incoming02.wav", "cod1/explosions/incoming05_muffled.wav", "cod1/explosions/incoming08_muffled.wav", "cod1/explosions/incoming11_muffled.wav", "cod1/explosions/incoming01_muffled.wav", "cod1/explosions/incoming02_muffled.wav" } } )
sound.Add( { name = "COD1.Tank.TigerIdle", channel = CHAN_STATIC, level = 85, volume = 1.00, pitch = { 75, 75 }, sound = { "cod1/vehicles/tank_02_idle_loop.wav" } } )
sound.Add( { name = "COD1.Tank.TigerMove", channel = CHAN_STATIC, level = 90, volume = 1.00, pitch = { 75, 75 }, sound = { "cod1/vehicles/tank_02_move_loop.wav" } } )
sound.Add( { name = "COD1.Tank.PanzerIdle", channel = CHAN_STATIC, level = 85, volume = 1.00, pitch = { 75, 75 }, sound = { "cod1/vehicles/tank_02_idle_loop.wav" } } )
sound.Add( { name = "COD1.Tank.PanzerMove", channel = CHAN_STATIC, level = 90, volume = 1.00, pitch = { 75, 75 }, sound = { "cod1/vehicles/tank_03_move_loop.wav" } } )
sound.Add( { name = "COD1.Tank.ShermanIdle", channel = CHAN_STATIC, level = 85, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/vehicles/tank_04_idle_loop.wav" } } )
sound.Add( { name = "COD1.Tank.ShermanMove", channel = CHAN_STATIC, level = 90, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/vehicles/tank_04_move_loop.wav" } } )
sound.Add( { name = "COD1.Tank.T34Idle", channel = CHAN_STATIC, level = 85, volume = 1.00, pitch = { 75, 75 }, sound = { "cod1/vehicles/tank_01_idle_loop.wav" } } )
sound.Add( { name = "COD1.Tank.T34Move", channel = CHAN_STATIC, level = 90, volume = 1.00, pitch = { 75, 75 }, sound = { "cod1/vehicles/tank_01_move_loop.wav" } } )
sound.Add( { name = "COD1.Tank.Turret", channel = CHAN_ITEM, level = 80, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/vehicles/turret_spin_01.wav" } } )
sound.Add( { name = "COD1.Tank.TurretStop", channel = CHAN_ITEM, level = 80, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/vehicles/turret_end_01.wav" } } )
sound.Add( { name = "COD1.Tank.Fire", channel = CHAN_WEAPON, level = 160, volume = 1.00, pitch = { 90, 110 }, sound = { "cod1/weapons/flak/flak88_fire02.wav", "cod1/weapons/flak/flak88_fire03.wav" } } )
sound.Add( { name = "COD1.Tank.Die", channel = CHAN_AUTO, level = 150, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/vehicles/crashes/sherman_die02.mp3" } } )
sound.Add( { name = "COD1.Tank.MGLoop", channel = CHAN_ITEM, level = 130, volume = 1.00, pitch = { 98, 100 }, sound = { "cod1/weapons/30cal/30cal_tank_loop02_loop.wav" } } )
sound.Add( { name = "COD1.Tank.MGStop", channel = CHAN_ITEM, level = 120, volume = 1.00, pitch = { 98, 100 }, sound = { "cod1/weapons/30cal/30cal_tank_cooldown02.wav" } } )
sound.Add( { name = "COD1.Tank.Hotwire", channel = CHAN_ITEM, level = 70, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/vehicles/tank_hotwire.wav" } } )
sound.Add( { name = "COD1.SatchelThrow", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 95, 105 }, sound = { "cod1/weapons/satchel/satchel_throw.wav" } } )
sound.Add( { name = "COD1.SatchelCord", channel = CHAN_ITEM, level = 75, volume = 1, pitch = { 95, 105 }, sound = { "cod1/weapons/satchel/satchel_cord.wav" } } )
sound.Add( { name = "COD1.weap_30cal_cooldown", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 99, 101 }, sound = { "cod1/weapons/30cal/30cal_cooldown.wav" } } )
sound.Add( { name = "COD1.weap_30cal_loop", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 99, 101 }, sound = { "cod1/weapons/30cal/30cal_loop_loop.wav" } } )
sound.Add( { name = "COD1.weap_30cal_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/30cal/weap_30cal_fast_reload.wav" } } )
sound.Add( { name = "COD1.weap_30cal_undeploy", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/30cal/weap_30cal_undeploy.wav" } } )
sound.Add( { name = "COD1.weap_bazooka_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/bazooka/bazooka_01.wav" } } )
sound.Add( { name = "COD1.weap_bazooka_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/bazooka/bazooka_reload.wav" } } )
sound.Add( { name = "COD1.weap_dp28_cooldown", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 95, 100 }, sound = { "cod1/weapons/dp28/dp28_cooldown.wav" } } )
sound.Add( { name = "COD1.weap_dp28_loop", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 95, 100 }, sound = { "cod1/weapons/dp28/dp28_loop01_loop.wav" } } )
sound.Add( { name = "COD1.weap_dp28_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/dp28/weap_dp28_reload.wav" } } )
sound.Add( { name = "COD1.weap_dp28_undeploy", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/dp28/weap_dp28_undeploy.wav" } } )
sound.Add( { name = "COD1.weap_fraggrenade_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/grenade/us_grenade_throw.wav" } } )
sound.Add( { name = "COD1.weap_fraggrenade_pin", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/grenade/us_grenade_pin.wav" } } )
sound.Add( { name = "COD1.weap_germgrenade_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/grenade/german_grenade_throw.wav", "cod1/weapons/grenade/german_grenade_throw02.wav", "cod1/weapons/grenade/german_grenade_throw03.wav" } } )
sound.Add( { name = "COD1.weap_gewehr43_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 85, 90 }, sound = { "cod1/weapons/gewehr43/gewehr43_01.wav" } } )
sound.Add( { name = "COD1.weap_gewehr43_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/gewehr43/gewehr43_reload.wav" } } )
sound.Add( { name = "COD1.weap_gewehr43_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/gewehr43/gewehr43_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_mg34_cooldown", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 110 }, sound = { "cod1/weapons/mg34/mg34_cooldown.wav" } } )
sound.Add( { name = "COD1.weap_mg34_deploy", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/mg34/weap_mg34_deploy.wav" } } )
sound.Add( { name = "COD1.weap_mg34_loop", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 100, 110 }, sound = { "cod1/weapons/mg34/mg34_loop01_loop.wav" } } )
sound.Add( { name = "COD1.weap_mg34_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/mg34/weap_mg34_reload.wav" } } )
sound.Add( { name = "COD1.weap_mg34_undeploy", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/mg34/weap_mg34_undeploy.wav" } } )
sound.Add( { name = "COD1.weap_panzerfaust_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/panzerfaust/panzerfaust_fire.wav" } } )
sound.Add( { name = "COD1.weap_panzerschreck_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/bazooka/bazooka_reload.wav" } } )
sound.Add( { name = "COD1.weap_pickup", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 90, 110 }, sound = { "cod1/misc/pu_weapon01.wav", "cod1/misc/pu_weapon03.wav", "cod1/misc/pu_weapon04.wav" } } )
sound.Add( { name = "COD1.weap_rusgrenade_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/grenade/german_grenade_throw.wav", "cod1/weapons/grenade/german_grenade_throw02.wav", "cod1/weapons/grenade/german_grenade_throw03.wav" } } )
sound.Add( { name = "COD1.weap_silenced_sten_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 100 }, sound = { "cod1/weapons/sten/silenced_sten_01.wav" } } )
sound.Add( { name = "COD1.weap_sten_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/sten/sten_reload.wav" } } )
sound.Add( { name = "COD1.weap_sten_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/sten/sten_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_svt40_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 95, 105 }, sound = { "cod1/weapons/svt40/svt40_01.wav" } } )
sound.Add( { name = "COD1.weap_svt40_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/svt40/svt40_reload.wav" } } )
sound.Add( { name = "COD1.weap_svt40_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/svt40/svt40_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_tt33_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/tt33/tt33_01.wav" } } )
sound.Add( { name = "COD1.weap_tt33_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/tt33/tt33_reload.wav" } } )
sound.Add( { name = "COD1.weap_tt33_reload_not_empty", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/tt33/tt33_reload_not_empty.wav" } } )
sound.Add( { name = "COD1.weap_webley_fire", channel = CHAN_WEAPON, level = 140, volume = 1.00, pitch = { 90, 105 }, sound = { "cod1/weapons/webley/webley_01.wav" } } )
sound.Add( { name = "COD1.weap_webley_reload", channel = CHAN_ITEM, level = 75, volume = 1.00, pitch = { 100, 100 }, sound = { "cod1/weapons/webley/weap_webley_reload.wav" } } )

COD1.Voices.moody_uo = { [ 1 ] = {
	doingsuppression = { "cod1/uo/voiceovers/bastogne1/moody_keepfiring01.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring02.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring03.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring04.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring06.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring07.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring08.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring09.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring10.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring11.mp3", "cod1/uo/voiceovers/bastogne1/moody_keepfiring12.mp3", "cod1/uo/voiceovers/foy/moody_keep_up_fire.mp3" },
	misccombat = { "cod1/uo/voiceovers/bastogne1/moody_go.mp3", "cod1/uo/voiceovers/bastogne2/moody_letsgo.mp3", "cod1/uo/voiceovers/bastogne1/moody_withme.mp3", "cod1/uo/voiceovers/bastogne2/moody_keep_moving_forward.mp3", "cod1/uo/voiceovers/foy/moody_dont_stop.mp3", "cod1/uo/voiceovers/bastogne2/moody_now.mp3", "cod1/uo/voiceovers/bastogne2/moody_runforit.mp3", "cod1/uo/voiceovers/bastogne2/moody_heavy_fire.mp3", "cod1/uo/voiceovers/bastogne2/moody_helluva_fight.mp3", "cod1/uo/voiceovers/foy/moody_fire_manuver.mp3" },
	enemysighted = { "cod1/uo/voiceovers/bastogne1/moody_deadahead.mp3", "cod1/uo/voiceovers/bastogne1/moody_watchout.mp3", "cod1/uo/voiceovers/bastogne1/moody_watchit.mp3", "cod1/uo/voiceovers/bastogne1/moody_eyesopen.mp3", "cod1/uo/voiceovers/noville/moody_germans_north.mp3" },
	coverme = { "cod1/uo/voiceovers/bastogne2/moody_cover_me.mp3", "cod1/uo/voiceovers/bastogne1/moody_changin.mp3" },
	flankleft = { "cod1/uo/voiceovers/bastogne1/moody_totheleft.mp3", "cod1/uo/voiceovers/foy/moody_action_left.mp3" },
	flankright = { "cod1/uo/voiceovers/bastogne1/moody_totheright.mp3", "cod1/uo/voiceovers/bastogne1/moody_rightflank.mp3", "cod1/uo/voiceovers/foy/moody_action_right.mp3" },
	grenadeattack = { "cod1/uo/voiceovers/bastogne2/moody_grenades.mp3" },
	grenadedanger = { "cod1/uo/voiceovers/bastogne2/moody_hit_dirt.mp3" },
	undersuppression = { "cod1/uo/voiceovers/bastogne2/moody_hold.mp3", "cod1/uo/voiceovers/bastogne2/moody_hangin.mp3", "cod1/uo/voiceovers/bastogne2/moody_hit_dirt.mp3" },
	greetplayerquiet = { "cod1/uo/voiceovers/bastogne2/moody_lookin_good.mp3", "cod1/uo/voiceovers/bastogne2/moody_more_like_it.mp3", "cod1/uo/voiceovers/bastogne2/moody_yessir.mp3" },
	greetplayerloud = { "cod1/uo/voiceovers/bastogne1/moody_report.mp3", "cod1/uo/voiceovers/bastogne1/moody_withme.mp3" },
	enemykilled = { "cod1/uo/voiceovers/bastogne2/moody_terrific.mp3", "cod1/uo/voiceovers/noville/moody_dang_nailed.mp3", "cod1/uo/voiceovers/bastogne2/moody_lucky.mp3", "cod1/uo/voiceovers/foy/moody_gotit.mp3", "cod1/uo/voiceovers/bastogne1/moody_clear.mp3" },
	giveupposition = { "cod1/uo/voiceovers/foy/moody_regroup01.mp3", "cod1/uo/voiceovers/foy/moody_regroup02.mp3", "cod1/uo/voiceovers/foy/moody_regroup03.mp3", "cod1/uo/voiceovers/foy/moody_regroup04.mp3" },
	tanksighted = { "cod1/uo/voiceovers/bastogne1/moody_tanks.mp3", "cod1/uo/voiceovers/bastogne1/moody_another_panzer.mp3", "cod1/uo/voiceovers/bastogne1/moody_tincans.mp3", "cod1/uo/voiceovers/noville/moody_panzer_north.mp3", "cod1/uo/voiceovers/noville/moody_panzer_south.mp3", "cod1/uo/voiceovers/noville/moody_panzer_west.mp3" },
	tankkilled = { "cod1/uo/voiceovers/bastogne2/moody_scrap_panzer.mp3", "cod1/uo/voiceovers/bastogne1/moody_oh_baby.mp3" },
	smoke = { "cod1/uo/voiceovers/bastogne1/moody_pop_smoke.mp3" },
	bazooka = { "cod1/uo/voiceovers/bastogne1/moody_bazooka.mp3", "cod1/uo/voiceovers/noville/moody_bazooka_up_here.mp3", "cod1/uo/voiceovers/noville/moody_rpg_panzer.mp3" },
	medic = { "cod1/uo/voiceovers/bastogne1/moody_medic.mp3" },
} }
COD1.Voices.foley_uo = { [ 1 ] = {
	misccombat = { "cod1/uo/voiceovers/noville/foley_letsgo.mp3", "cod1/uo/voiceovers/noville/foley_keep_advancing.mp3", "cod1/uo/voiceovers/noville/foley_drive_em_back.mp3", "cod1/uo/voiceovers/noville/foley_up_street.mp3", "cod1/uo/voiceovers/noville/foley_next_building.mp3", "cod1/uo/voiceovers/noville/foley_hold_chateau.mp3" },
	enemysighted = { "cod1/uo/voiceovers/noville/foley_germans_north.mp3", "cod1/uo/voiceovers/noville/foley_germans_porch.mp3", "cod1/uo/voiceovers/noville/foley_germans_in_house.mp3", "cod1/uo/voiceovers/noville/foley_germans_north_kitchen.mp3" },
	coverme = { "cod1/uo/voiceovers/foy/foley_take_cover.mp3", "cod1/uo/voiceovers/noville/foley_cover_third.mp3" },
	undersuppression = { "cod1/uo/voiceovers/noville/foley_sonofa.mp3", "cod1/uo/voiceovers/foy/foley_take_cover.mp3" },
	giveupposition = { "cod1/uo/voiceovers/noville/foley_fall_back.mp3" },
	enemykilled = { "cod1/uo/voiceovers/noville/foley_goodjob.mp3", "cod1/uo/voiceovers/noville/foley_dang_nailed.mp3" },
	greetplayerquiet = { "cod1/uo/voiceovers/foy/foley_stay_with.mp3" },
	greetplayerloud = { "cod1/uo/voiceovers/noville/foley_get_back_here.mp3" },
	tanksighted = { "cod1/uo/voiceovers/noville/foley_panzer_north.mp3", "cod1/uo/voiceovers/noville/foley_panzer_south.mp3", "cod1/uo/voiceovers/noville/foley_panzer_west.mp3", "cod1/uo/voiceovers/noville/foley_halftrack_north.mp3" },
	bazooka = { "cod1/uo/voiceovers/noville/foley_bazooka_up_here.mp3", "cod1/uo/voiceovers/noville/foley_panzerschreck.mp3" },
	satchel = { "cod1/uo/voiceovers/noville/foley_satchel.mp3" },
} }
COD1.Voices.antonov = { [ 1 ] = {
	doingsuppression = { "cod1/uo/voiceovers/trenches/antonov_keepfiring01.mp3", "cod1/uo/voiceovers/trenches/antonov_keepfiring02.mp3", "cod1/uo/voiceovers/trenches/antonov_keepfiring03.mp3", "cod1/uo/voiceovers/kharkov1/antonov_keepfiring04.mp3" },
	misccombat = { "cod1/uo/voiceovers/kharkov1/antonov_advance.mp3", "cod1/uo/voiceovers/kharkov1/antonov_advance2.mp3", "cod1/uo/voiceovers/kharkov1/antonov_letsmove.mp3", "cod1/uo/voiceovers/trenches/antonov_move_forward.mp3", "cod1/uo/voiceovers/kharkov2/antonov_keep_moving2.mp3", "cod1/uo/voiceovers/ponyri/antonov_assault.mp3", "cod1/uo/voiceovers/trenches/antonov_thru_here.mp3" },
	enemysighted = { "cod1/uo/voiceovers/kharkov1/antonov_windows.mp3", "cod1/uo/voiceovers/ponyri/antonov_stopmg.mp3", "cod1/uo/voiceovers/ponyri/antonov_stopmg2.mp3", "cod1/uo/voiceovers/kharkov2/antonov_another.mp3" },
	flankleft = { "cod1/uo/voiceovers/ponyri/antonov_outflank.mp3" },
	flankright = { "cod1/uo/voiceovers/kharkov2/antonov_flank_right.mp3" },
	coverme = { "cod1/uo/voiceovers/kharkov1/antonov_follow.mp3" },
	giveupposition = { "cod1/uo/voiceovers/ponyri/antonov_regroup1.mp3", "cod1/uo/voiceovers/ponyri/antonov_regroup2.mp3" },
	enemykilled = { "cod1/uo/voiceovers/kharkov1/antonov_goodjob.wav" },
	greetplayerquiet = { "cod1/uo/voiceovers/kharkov2/antonov_yes.mp3", "cod1/uo/voiceovers/kharkov1/antonov_check.mp3" },
	greetplayerloud = { "cod1/uo/voiceovers/kharkov1/antonov_follow.mp3" },
	tanksighted = { "cod1/uo/voiceovers/ponyri/antonov_killtank1.mp3", "cod1/uo/voiceovers/ponyri/antonov_killtank2.mp3", "cod1/uo/voiceovers/ponyri/antonov_tankscover.mp3" },
	bazooka = { "cod1/uo/voiceovers/ponyri/antonov_pfaust.mp3", "cod1/uo/voiceovers/ponyri/antonov_pfaust2.mp3" },
	undersuppression = { "cod1/uo/voiceovers/kharkov2/antonov_dammit.mp3" },
} }
COD1.Voices.ingram_uo = { [ 1 ] = {
	doingsuppression = { "cod1/uo/voiceovers/sicily2/ingram_fire01.mp3", "cod1/uo/voiceovers/sicily2/ingram_fire02.mp3", "cod1/uo/voiceovers/sicily2/ingram_fire03.mp3", "cod1/uo/voiceovers/sicily2/ingram_fire04.mp3" },
	enemykilled = { "cod1/uo/voiceovers/sicily2/ingram_niceshot1.mp3", "cod1/uo/voiceovers/sicily2/ingram_niceshot2.mp3", "cod1/uo/voiceovers/sicily2/ingram_niceshot3.mp3", "cod1/uo/voiceovers/sicily2/ingram_good_show.mp3" },
	misccombat = { "cod1/uo/voiceovers/trainbridge/ingram_lets_move.mp3", "cod1/uo/voiceovers/trainbridge/ingram_letsgo.mp3", "cod1/uo/voiceovers/sicily2/ingram_follow_me.mp3", "cod1/uo/voiceovers/trainbridge/ingram_alright_go.mp3", "cod1/uo/voiceovers/trainbridge/ingram_alright_go2.mp3", "cod1/uo/voiceovers/trainbridge/ingram_steponit.mp3", "cod1/uo/voiceovers/trainbridge/ingram_spreadout.mp3", "cod1/uo/voiceovers/sicily2/ingram_leapfrog.mp3" },
	enemysighted = { "cod1/uo/voiceovers/trainbridge/ingram_behind_you.mp3", "cod1/uo/voiceovers/sicily2/ingram_eye_out.mp3", "cod1/uo/voiceovers/sicily2/ingram_eye_out2.mp3", "cod1/uo/voiceovers/sicily2/ingram_on_left.mp3", "cod1/uo/voiceovers/sicily2/ingram_damn_jerries.mp3" },
	grenadeattack = { "cod1/uo/voiceovers/sicily2/ingram_use_grenades.mp3" },
	coverme = { "cod1/uo/voiceovers/trainbridge/ingram_find_cover.mp3", "cod1/uo/voiceovers/sicily1/ingram_low_cover.mp3", "cod1/uo/voiceovers/sicily1/ingram_staylow.mp3" },
	undersuppression = { "cod1/uo/voiceovers/sicily2/ingram_blimey.mp3", "cod1/uo/voiceovers/sicily1/ingram_staylow.mp3" },
	greetplayerquiet = { "cod1/uo/voiceovers/trainbridge/ingram_quiet.mp3", "cod1/uo/voiceovers/trainbridge/ingram_shh.mp3", "cod1/uo/voiceovers/trainbridge/ingram_careful.mp3" },
	greetplayerloud = { "cod1/uo/voiceovers/trainbridge/ingram_over_here.mp3" },
} }
COD1.Voices.miesha = { [ 1 ] = {
	misccombat = { "cod1/uo/voiceovers/kharkov1/miesha_letsgo.mp3", "cod1/uo/voiceovers/kharkov1/miesha_rightaway.mp3", "cod1/uo/voiceovers/trenches/miesha_comin_round.mp3" },
	enemysighted = { "cod1/uo/voiceovers/kharkov1/miesha_enemy_gun.mp3" },
	tanksighted = { "cod1/uo/voiceovers/kharkov1/miesha_tank.mp3", "cod1/uo/voiceovers/kharkov1/miesha_tiger.mp3", "cod1/uo/voiceovers/kharkov1/miesha_tiger2.mp3" },
	undersuppression = { "cod1/uo/voiceovers/kharkov1/miesha_hell.mp3", "cod1/uo/voiceovers/kharkov2/miesha_doingbest.mp3" },
	greetplayerquiet = { "cod1/uo/voiceovers/kharkov2/miesha_yes_sergeant.mp3", "cod1/uo/voiceovers/kharkov2/miesha_yes_sgt.mp3", "cod1/uo/voiceovers/trenches/miesha_you_alright.mp3" },
	greetplayerloud = { "cod1/uo/voiceovers/kharkov2/miesha_iknow.mp3" },
	radio = { "cod1/uo/voiceovers/kharkov1/miesha_firemission01.mp3", "cod1/uo/voiceovers/kharkov1/miesha_firemission02.mp3", "cod1/uo/voiceovers/kharkov1/miesha_firemission03.mp3", "cod1/uo/voiceovers/kharkov1/miesha_ready1.mp3", "cod1/uo/voiceovers/kharkov1/miesha_ready2.mp3" },
} }
for _, ev in ipairs( { "pain", "death" } ) do COD1.Voices.foley_uo[ 1 ][ ev ] = COD1.Voices.foley[ 1 ][ ev ] end
for _, ev in ipairs( { "pain", "death" } ) do COD1.Voices.moody_uo[ 1 ][ ev ] = COD1.Voices.moody[ 1 ][ ev ] end
for _, ev in ipairs( { "pain", "death" } ) do COD1.Voices.antonov[ 1 ][ ev ] = COD1.Voices.russian[ 1 ][ ev ] end
for _, ev in ipairs( { "pain", "death" } ) do COD1.Voices.ingram_uo[ 1 ][ ev ] = COD1.Voices.ingram[ 1 ][ ev ] end
for _, ev in ipairs( { "pain", "death" } ) do COD1.Voices.miesha[ 1 ][ ev ] = COD1.Voices.russian[ 1 ][ ev ] end
COD1.SoundLen = COD1.SoundLen or {}
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_another_panzer.mp3" ] = 2.53
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_bazooka.mp3" ] = 3.68
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_changin.mp3" ] = 2.93
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_clear.mp3" ] = 2.22
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_deadahead.mp3" ] = 1.46
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_eyesopen.mp3" ] = 1.46
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_go.mp3" ] = 2.25
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring01.mp3" ] = 1.52
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring02.mp3" ] = 0.91
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring03.mp3" ] = 1.44
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring04.mp3" ] = 3.97
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring06.mp3" ] = 1.20
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring07.mp3" ] = 0.89
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring08.mp3" ] = 1.57
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring09.mp3" ] = 3.34
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring10.mp3" ] = 1.41
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring11.mp3" ] = 1.12
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_keepfiring12.mp3" ] = 2.19
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_medic.mp3" ] = 1.78
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_oh_baby.mp3" ] = 2.43
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_pop_smoke.mp3" ] = 8.57
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_report.mp3" ] = 4.96
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_rightflank.mp3" ] = 2.95
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_tanks.mp3" ] = 2.56
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_tincans.mp3" ] = 5.20
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_totheleft.mp3" ] = 1.49
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_totheright.mp3" ] = 1.12
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_watchit.mp3" ] = 0.55
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_watchout.mp3" ] = 1.25
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne1/moody_withme.mp3" ] = 3.71
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_cover_me.mp3" ] = 3.74
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_grenades.mp3" ] = 4.68
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_hangin.mp3" ] = 3.11
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_heavy_fire.mp3" ] = 2.53
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_helluva_fight.mp3" ] = 3.84
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_hit_dirt.mp3" ] = 2.04
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_hold.mp3" ] = 1.72
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_keep_moving_forward.mp3" ] = 3.40
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_letsgo.mp3" ] = 3.16
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_lookin_good.mp3" ] = 3.32
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_lucky.mp3" ] = 0.71
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_more_like_it.mp3" ] = 2.69
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_now.mp3" ] = 2.14
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_runforit.mp3" ] = 1.75
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_scrap_panzer.mp3" ] = 3.45
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_terrific.mp3" ] = 5.96
COD1.SoundLen[ "cod1/uo/voiceovers/bastogne2/moody_yessir.mp3" ] = 0.50
COD1.SoundLen[ "cod1/uo/voiceovers/foy/foley_stay_with.mp3" ] = 1.31
COD1.SoundLen[ "cod1/uo/voiceovers/foy/foley_take_cover.mp3" ] = 1.10
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_action_left.mp3" ] = 1.02
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_action_right.mp3" ] = 0.99
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_dont_stop.mp3" ] = 2.04
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_fire_manuver.mp3" ] = 1.25
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_gotit.mp3" ] = 1.78
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_keep_up_fire.mp3" ] = 1.33
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_regroup01.mp3" ] = 1.36
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_regroup02.mp3" ] = 1.72
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_regroup03.mp3" ] = 3.84
COD1.SoundLen[ "cod1/uo/voiceovers/foy/moody_regroup04.mp3" ] = 2.09
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/antonov_advance.mp3" ] = 3.55
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/antonov_advance2.mp3" ] = 3.32
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/antonov_check.mp3" ] = 4.73
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/antonov_follow.mp3" ] = 4.34
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/antonov_keepfiring04.mp3" ] = 1.72
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/antonov_letsmove.mp3" ] = 2.98
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/antonov_windows.mp3" ] = 2.04
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_enemy_gun.mp3" ] = 2.22
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_firemission01.mp3" ] = 6.50
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_firemission02.mp3" ] = 6.35
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_firemission03.mp3" ] = 6.82
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_hell.mp3" ] = 3.81
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_letsgo.mp3" ] = 2.77
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_ready1.mp3" ] = 3.03
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_ready2.mp3" ] = 2.12
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_rightaway.mp3" ] = 1.83
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_tank.mp3" ] = 3.55
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_tiger.mp3" ] = 4.62
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov1/miesha_tiger2.mp3" ] = 4.47
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov2/antonov_another.mp3" ] = 2.43
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov2/antonov_dammit.mp3" ] = 2.38
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov2/antonov_flank_right.mp3" ] = 5.46
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov2/antonov_keep_moving2.mp3" ] = 0.86
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov2/antonov_yes.mp3" ] = 1.72
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov2/miesha_doingbest.mp3" ] = 5.93
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov2/miesha_iknow.mp3" ] = 1.80
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov2/miesha_yes_sergeant.mp3" ] = 1.57
COD1.SoundLen[ "cod1/uo/voiceovers/kharkov2/miesha_yes_sgt.mp3" ] = 1.33
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_bazooka_up_here.mp3" ] = 2.32
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_cover_third.mp3" ] = 3.94
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_dang_nailed.mp3" ] = 1.70
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_drive_em_back.mp3" ] = 1.12
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_fall_back.mp3" ] = 2.69
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_germans_in_house.mp3" ] = 1.96
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_germans_north.mp3" ] = 2.17
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_germans_north_kitchen.mp3" ] = 2.14
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_germans_porch.mp3" ] = 1.67
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_get_back_here.mp3" ] = 2.53
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_goodjob.mp3" ] = 12.07
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_halftrack_north.mp3" ] = 1.33
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_hold_chateau.mp3" ] = 2.01
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_keep_advancing.mp3" ] = 2.01
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_letsgo.mp3" ] = 6.58
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_next_building.mp3" ] = 1.99
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_panzer_north.mp3" ] = 1.96
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_panzer_south.mp3" ] = 3.32
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_panzer_west.mp3" ] = 2.77
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_panzerschreck.mp3" ] = 1.38
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_satchel.mp3" ] = 2.22
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_sonofa.mp3" ] = 3.42
COD1.SoundLen[ "cod1/uo/voiceovers/noville/foley_up_street.mp3" ] = 2.32
COD1.SoundLen[ "cod1/uo/voiceovers/noville/moody_bazooka_up_here.mp3" ] = 2.77
COD1.SoundLen[ "cod1/uo/voiceovers/noville/moody_dang_nailed.mp3" ] = 1.49
COD1.SoundLen[ "cod1/uo/voiceovers/noville/moody_germans_north.mp3" ] = 2.90
COD1.SoundLen[ "cod1/uo/voiceovers/noville/moody_panzer_north.mp3" ] = 2.25
COD1.SoundLen[ "cod1/uo/voiceovers/noville/moody_panzer_south.mp3" ] = 3.71
COD1.SoundLen[ "cod1/uo/voiceovers/noville/moody_panzer_west.mp3" ] = 3.29
COD1.SoundLen[ "cod1/uo/voiceovers/noville/moody_rpg_panzer.mp3" ] = 3.13
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_assault.mp3" ] = 3.11
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_killtank1.mp3" ] = 5.69
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_killtank2.mp3" ] = 3.34
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_outflank.mp3" ] = 3.89
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_pfaust.mp3" ] = 3.68
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_pfaust2.mp3" ] = 1.23
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_regroup1.mp3" ] = 0.89
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_regroup2.mp3" ] = 0.68
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_stopmg.mp3" ] = 3.11
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_stopmg2.mp3" ] = 3.08
COD1.SoundLen[ "cod1/uo/voiceovers/ponyri/antonov_tankscover.mp3" ] = 3.06
COD1.SoundLen[ "cod1/uo/voiceovers/sicily1/ingram_low_cover.mp3" ] = 1.59
COD1.SoundLen[ "cod1/uo/voiceovers/sicily1/ingram_staylow.mp3" ] = 3.74
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_blimey.mp3" ] = 2.43
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_damn_jerries.mp3" ] = 2.95
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_eye_out.mp3" ] = 2.74
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_eye_out2.mp3" ] = 1.33
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_fire01.mp3" ] = 0.57
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_fire02.mp3" ] = 1.04
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_fire03.mp3" ] = 1.02
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_fire04.mp3" ] = 0.52
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_follow_me.mp3" ] = 1.54
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_good_show.mp3" ] = 4.62
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_leapfrog.mp3" ] = 2.53
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_niceshot1.mp3" ] = 3.74
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_niceshot2.mp3" ] = 3.84
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_niceshot3.mp3" ] = 2.56
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_on_left.mp3" ] = 1.31
COD1.SoundLen[ "cod1/uo/voiceovers/sicily2/ingram_use_grenades.mp3" ] = 3.76
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_alright_go.mp3" ] = 1.78
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_alright_go2.mp3" ] = 1.91
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_behind_you.mp3" ] = 1.25
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_careful.mp3" ] = 1.65
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_find_cover.mp3" ] = 1.44
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_lets_move.mp3" ] = 1.83
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_letsgo.mp3" ] = 3.11
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_over_here.mp3" ] = 4.10
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_quiet.mp3" ] = 6.79
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_shh.mp3" ] = 2.22
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_spreadout.mp3" ] = 1.57
COD1.SoundLen[ "cod1/uo/voiceovers/trainbridge/ingram_steponit.mp3" ] = 3.63
COD1.SoundLen[ "cod1/uo/voiceovers/trenches/antonov_keepfiring01.mp3" ] = 2.17
COD1.SoundLen[ "cod1/uo/voiceovers/trenches/antonov_keepfiring02.mp3" ] = 3.11
COD1.SoundLen[ "cod1/uo/voiceovers/trenches/antonov_keepfiring03.mp3" ] = 1.46
COD1.SoundLen[ "cod1/uo/voiceovers/trenches/antonov_move_forward.mp3" ] = 3.08
COD1.SoundLen[ "cod1/uo/voiceovers/trenches/antonov_thru_here.mp3" ] = 1.07
COD1.SoundLen[ "cod1/uo/voiceovers/trenches/miesha_comin_round.mp3" ] = 1.38
COD1.SoundLen[ "cod1/uo/voiceovers/trenches/miesha_you_alright.mp3" ] = 3.47

--united offensive sounds, the expansion was underrated
