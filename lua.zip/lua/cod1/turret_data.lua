COD1.TurretParts = {
	mg42_gun = { muzzle = Vector( 11.39, 0.09, 2.29 ), butt = Vector( -46.65, -0.06, -1.92 ), pivot = Vector( -2.98, 0.06, 12.87 ), grip = Vector( -30.61, -0.09, -0.75 ), mins = Vector( -47.6, -3.0, -4.5 ), maxs = Vector( 11.1, 3.8, 5.2 ) },
	mg42_bipod = { mins = Vector( -4.0, -11.8, -0.1 ), maxs = Vector( 0.4, 11.5, 13.5 ) },
	b30cal_gun = { muzzle = Vector( 26.81, 0.36, 2.93 ), pivot = Vector( 0.00, 0.00, 0.00 ), grip = Vector( -17.51, -0.23, 2.61 ), mins = Vector( -20.4, -2.8, -1.1 ), maxs = Vector( 26.8, 1.5, 7.0 ) },
	sandbags = { mins = Vector( -7.9, -96.5, -0.0 ), maxs = Vector( 9.2, 97.4, 34.4 ) },
}

--turret aiming data, pain
