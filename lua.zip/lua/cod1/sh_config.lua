local FLAGS = { FCVAR_ARCHIVE, FCVAR_NOTIFY, FCVAR_REPLICATED }
CreateConVar( "cod1_npc_health", "100", FLAGS, "Health of Call of Duty 1 soldiers" )
CreateConVar( "cod1_npc_damage", "9", FLAGS, "Base damage of a soldier's bullet (scaled per weapon)" )
CreateConVar( "cod1_npc_accuracy", "1", FLAGS, "Soldier accuracy multiplier" )
CreateConVar( "cod1_npc_hostile_players", "0", FLAGS, "1 = your own side shoots players" )
CreateConVar( "cod1_axis_hostile_players", "1", FLAGS, "1 = the enemy side shoots players" )
CreateConVar( "cod1_npc_death_anims", "1", FLAGS, "1 = play CoD death animations" )
CreateConVar( "cod1_npc_ragdolls", "0", FLAGS, "1 = ragdoll after the death animation, 0 = stay in the final pose like CoD" )

if SERVER and not file.Exists( "cod1/bodies_default_v2.txt", "DATA" ) then
	file.CreateDir( "cod1" )
	file.Write( "cod1/bodies_default_v2.txt", "1" )
	RunConsoleCommand( "cod1_npc_death_anims", "1" )
	RunConsoleCommand( "cod1_npc_ragdolls", "0" )
end
CreateConVar( "cod1_npc_corpse_time", "0", FLAGS, "Seconds before posed corpses are removed (0 = never)" )
CreateConVar( "cod1_npc_drop_guns", "1", FLAGS, "1 = soldiers drop their gun when they die and you can pick it up, like in Call of Duty" )
CreateConVar( "cod1_npc_max_bodies", "40", FLAGS, "Most posed corpses kept; the oldest is removed beyond this (0 = no limit)" )
CreateConVar( "cod1_npc_corpse_sink", "0", FLAGS, "1 = bodies slowly sink into the ground and disappear, like in Call of Duty" )
CreateConVar( "cod1_npc_corpse_sink_time", "30", FLAGS, "Seconds a body stays before it sinks into the ground" )
CreateConVar( "cod1_rescue", "1", FLAGS, "1 = soldiers can go down wounded instead of dying and get carried to cover" )
CreateConVar( "cod1_rescue_chance", "0.3", FLAGS, "Chance a killing hit leaves a soldier down and wounded instead" )
CreateConVar( "cod1_rescue_recover", "40", FLAGS, "Seconds a downed soldier stays down before getting back up" )
CreateConVar( "cod1_geneva", "0", FLAGS, "1 = soldiers don't fire on medics; medics only shoot back in self-defence, collect wounded of both sides when it goes quiet and surrender when caught alone (not between Soviets and Germans)" )
CreateConVar( "cod1_npc_grenades", "1", FLAGS, "1 = soldiers throw grenades" )
CreateConVar( "cod1_npc_chatter", "1", FLAGS, "1 = battle chatter" )
CreateConVar( "cod1_npc_follow", "1", FLAGS, "1 = press E on your side's soldiers to have them follow you" )
CreateConVar( "cod1_npc_advance", "1", FLAGS, "0 = soldiers hold where placed, 1 = both sides move up on the enemy, 2 = only your side, 3 = only the enemy side" )
CreateConVar( "cod1_npc_ai", "advanced", FLAGS, "advanced = smart squad tactics, cod1 = the original Call of Duty AI (cover nodes near their post, no squad tactics)" )
CreateConVar( "cod1_npc_hold_posts", "1", FLAGS, "Soldiers placed indoors, up high or behind low cover hold that spot and fight from the cover and windows around it" )
CreateConVar( "cod1_player_axis", "0", FLAGS, "1 = you fight for the Germans" )
CreateConVar( "cod1_player_undercover", "0", FLAGS, "1 = Germans take you for one of their own until you shoot near them" )
CreateConVar( "cod1_npc_fair", "0", FLAGS, "1 = both sides fight equally well" )
CreateConVar( "cod1_npc_blood_decals", "1", FLAGS, "1 = blood splashes on walls" )
CreateConVar( "cod1_para_height", "1500", FLAGS, "Paratrooper drop height" )
CreateConVar( "cod1_para_chute_time", "60", FLAGS, "Seconds landed parachutes stay (0 = forever)" )
CreateConVar( "cod1_eureka_count", "8", FLAGS, "Paratroopers per C-47 pass" )
CreateConVar( "cod1_eureka_variant", "airborne_summer", FLAGS, "Troops the C-47 drops" )
CreateConVar( "cod1_gunpass_recruits", "16", FLAGS, "Unarmed conscripts each supply station brings to its queue (0 = only the ones you spawn)" )
CreateConVar( "cod1_artillery", "1", FLAGS, "1 = look through the binoculars and fire to call in an artillery strike" )
CreateConVar( "cod1_artillery_cooldown", "45", FLAGS, "Seconds before you can call in artillery again" )

if CLIENT then
	CreateClientConVar( "cod1_music_battle", "1", true, false, "Play Call of Duty music during firefights" )
	CreateClientConVar( "cod1_music_volume", "0.6", true, false, "Call of Duty music volume" )
	CreateClientConVar( "cod1_ambience_volume", "1", true, false, "Volume of the background ambience on ported Call of Duty maps" )
end

function COD1.PlayerSide()
	return GetConVar( "cod1_player_axis" ):GetBool() and "axis" or "allies"
end

function COD1.IsUndercover( e )
	if not IsValid( e ) then return false end
	if e:IsPlayer() then
		return e:Alive() and COD1.PlayerSide() == "allies" and GetConVar( "cod1_player_undercover" ):GetBool() and not e:GetNWBool( "COD1CoverBlown" )
	end
	return e.Undercover == true
end

COD1.Weapons = {
	thompson = { name = "Thompson", role = "Submachine Gunner", clip = 30, auto = true, delay = 0.0833, damage = 1.0, spread = 0.035, shell = "ShellEject" },
	garand = { name = "M1 Garand", role = "Rifleman", clip = 8, auto = false, delay = 0.3, damage = 1.7, spread = 0.012, ping = true, shell = "RifleShellEject" },
	carbine = { name = "M1 Carbine", role = "Rifleman", clip = 15, auto = false, delay = 0.25, damage = 1.25, spread = 0.018, shell = "RifleShellEject" },
	bar = { name = "BAR", role = "Support Gunner", clip = 20, auto = true, delay = 0.125, damage = 1.5, spread = 0.04, shell = "RifleShellEject" },
	kar98 = { name = "Kar98k", role = "Rifleman", clip = 5, auto = false, bolt = true, delay = 0.3, damage = 1.8, spread = 0.01, shell = "RifleShellEject" },
	mp40 = { name = "MP40", role = "Submachine Gunner", clip = 32, auto = true, delay = 0.125, damage = 0.9, spread = 0.035, shell = "ShellEject" },
	mp44 = { name = "MP44", role = "Rifleman", clip = 30, auto = true, delay = 0.125, damage = 1.1, spread = 0.03, shell = "RifleShellEject" },
	fg42 = { name = "FG42", role = "Support Gunner", clip = 20, auto = false, delay = 0.3, damage = 1.4, spread = 0.02 },
	luger = { name = "Luger", role = "Officer", clip = 8, auto = false, delay = 0.2, damage = 0.9, spread = 0.03, shell = "ShellEject" },
	colt = { name = "Colt .45", role = "Officer", clip = 7, auto = false, delay = 0.2, damage = 1.0, spread = 0.03, shell = "ShellEject" },
	enfield = { name = "Lee-Enfield", role = "Rifleman", clip = 10, auto = false, bolt = true, delay = 0.3, damage = 1.7, spread = 0.01, shell = "RifleShellEject" },
	sten = { name = "Sten", role = "Submachine Gunner", clip = 32, auto = true, delay = 0.1, damage = 0.9, spread = 0.04, shell = "ShellEject" },
	bren = { name = "Bren LMG", role = "Support Gunner", clip = 30, auto = true, delay = 0.125, damage = 1.5, spread = 0.035, shell = "RifleShellEject" },
	mosin = { name = "Mosin-Nagant", role = "Rifleman", clip = 5, auto = false, bolt = true, delay = 0.3, damage = 1.7, spread = 0.01, shell = "RifleShellEject" },
	ppsh = { name = "PPSh", role = "Submachine Gunner", clip = 71, auto = true, delay = 0.0667, damage = 0.8, spread = 0.045, shell = "ShellEject" },
	g43 = { name = "Gewehr 43", role = "Rifleman", clip = 10, auto = false, delay = 0.25, damage = 1.6, spread = 0.014, shell = "RifleShellEject" },
	svt40 = { name = "SVT-40", role = "Rifleman", clip = 10, auto = false, delay = 0.25, damage = 1.6, spread = 0.014, shell = "RifleShellEject" },
	mg34 = { name = "MG34", role = "Machine Gunner", clip = 75, auto = true, delay = 0.07, damage = 1.4, spread = 0.045, shell = "RifleShellEject", proneRange = 450 },
	dp28 = { name = "DP-28", role = "Machine Gunner", clip = 47, auto = true, delay = 0.1, damage = 1.5, spread = 0.04, shell = "RifleShellEject", proneRange = 450 },
	mg30cal = { name = ".30 cal", role = "Machine Gunner", clip = 100, auto = true, delay = 0.1, damage = 1.5, spread = 0.045, shell = "RifleShellEject", proneRange = 450 },
	tt33 = { name = "TT-33", role = "Officer", clip = 8, auto = false, delay = 0.2, damage = 0.9, spread = 0.03, shell = "ShellEject" },
	webley = { name = "Webley", role = "Officer", clip = 6, auto = false, delay = 0.3, damage = 1.2, spread = 0.03 },
	stensd = { name = "Silenced Sten", role = "Commando", clip = 32, auto = true, delay = 0.1, damage = 0.85, spread = 0.04, shell = "ShellEject", quiet = true },
	pschreck = { name = "Panzerschreck", role = "Anti-Tank", clip = 1, rocket = true, rockets = 4, speed = 2800, delay = 1, damage = 0, spread = 0 },
	bazooka = { name = "Bazooka", role = "Anti-Tank", clip = 1, rocket = true, rockets = 4, speed = 2800, delay = 1, damage = 0, spread = 0 },
	pfaust = { name = "Panzerfaust", role = "Anti-Tank", clip = 1, rocket = true, rockets = 1, speed = 2800, delay = 1, damage = 0, spread = 0, oneShot = true },
	flamer = { name = "Flammenwerfer 41", role = "Flamethrower", clip = 100, flame = true, delay = 0.1, damage = 0, spread = 0 },
	kar98_sniper = { name = "Kar98k Sniper", role = "Sniper", clip = 5, auto = false, bolt = true, delay = 0.3, damage = 4, spread = 0.003, sniper = true, shell = "RifleShellEject" },
	mosin_sniper = { name = "Mosin-Nagant Sniper", role = "Sniper", clip = 5, auto = false, bolt = true, delay = 0.3, damage = 4, spread = 0.003, sniper = true, shell = "RifleShellEject" },
	springfield = { name = "Springfield", role = "Sniper", clip = 5, auto = false, bolt = true, delay = 0.3, damage = 4, spread = 0.003, sniper = true, shell = "RifleShellEject" },
}

COD1.Surnames = {
	"Weir", "Perlman", "Holm", "Avery", "Fincher", "McManus", "Roe", "Messerly", "Kirkpatrick", "Griffen", "O'Neill",
	"Farrell", "Jacobs", "Scott", "Vickers", "Silvers", "Vaughn", "Fisher", "Ross", "Rice", "Limon", "Weaver", "Kaplan",
	"Hicks", "McKinny", "Heath", "Erickson", "Swanson", "Blackwell", "Turner", "Caputo", "Doherty", "Franklin", "Jenkins",
	"Manne", "Glenn", "Field", "Little", "McCandlish", "Olsen", "Sawyer", "Pearson", "Post", "Glasco", "Sweet",
	"Dominguez", "O'Doyle", "Delarosa", "Smith", "Jones", "Roosevelt", "Carter", "Baker", "Grenier", "Fitzpatrick",
	"McKnight", "Pacelli", "Conway", "D'Angelo", "Dunn", "Morrison", "Wilson", "Walton", "Fletcher", "Johnson",
	"Goldberg", "Svendson", "Pierce", "Robertson", "Pinkerton", "Kane", "Bales", "Lopresti", "Reagan", "Hawking",
	"Peterson", "Rogers", "Cutler", "Custer", "Manning", "Chevrier", "Hammon", "Zimmerman", "Taylor", "Daniels", "Cox",
	"Quinn", "O'Toole", "Glave", "Lyman", "Rutledge", "Norman", "Gigliotti", "Harper", "Walker", "Pendleton", "MacDonald",
	"King", "Collier", "Butler", "Welch", "O'Callaghan", "Conroy", "Davis", "Carmichael", "Irons", "Fishbourne",
	"Marshall", "Barrett", "Jury", "Ellis", "Irwin", "Matisse", "Barnes", "Woods", "Carpenter", "Stone", "O'Connell",
	"O'Brian", "Miller", "Long", "Lamia", "Rooney", "Zampella", "Peas", "Alderman", "Bell", "West", "Bennett", "Thomas",
	"Wright", "Hewitt", "Avalos", "Doornink", "Grossman", "Hagerty", "Callaway", "Kirshenbaum", "Oxnard", "Johnsen",
	"DeMaria", "Allen", "McCaffrey", "Ford", "Boswell", "Spears", "Mantarro", "Vantine", "Saltzman", "Pvt. Ambrose",
	"Pvt. Cline", "Pvt. Davis", "Pvt. Lawrence", "Pvt. Mantarro", "Pvt. Murphy", "Sgt. Avery", "Pvt. Baker",
	"Pvt. Franklin", "Pvt. Jackson", "Pvt. Johnson", "Pvt. Lewis", "Pvt. Parker", "Pvt. Brooks", "Pvt. Harding",
	"Lt. Tucker", "Lt. Davis",
}
COD1.BritishSurnames = {
	"Pvt. Baker", "Sgt. Heacock", "Pvt. Farmer", "Pvt. Dowd", "Pvt. Fitzroy", "Pvt. Tennyson", "Pvt. Bartlett",
	"Pvt. Plumber", "Pvt. Blair", "Pvt. Heath", "Pvt. Neeson", "Pvt. Wallace", "Pvt. Hopkins", "Pvt. Thompson",
	"Pvt. Grant", "Pvt. Carter", "Pvt. Ackroyd", "Pvt. Adams", "Pvt. Moore", "Pvt. Griffin", "Pvt. Boyd", "Pvt. Harris",
	"Pvt. Burton", "Pvt. Montgomery", "Pvt. Matthews", "Pvt. Astor", "Pvt. Bishop", "Pvt. Compton", "Pvt. Hawksford",
	"Pvt. Hoyt", "Pvt. Kent", "Pvt. Rothes", "Pvt. Ross", "Pvt. Smith", "Pvt. Brown", "Pvt. Buttler", "Pvt. Caldwell",
	"Pvt. Cotterhill", "Pvt. Dowton", "Pvt. Walcroft", "Pvt. Wells", "Pvt. Weisz", "Pvt. Watt", "Pvt. Veale",
	"Pvt. Abbott", "Pvt. Bowen", "Pvt. Carver", "Pvt. Brocklebank", "Pvt. Peacock", "Pvt. Pearce", "Pvt. Reed",
	"Pvt. Rogers", "Pvt. Major", "Pvt. Horrocks", "Pvt. Law", "Pvt. Ritchie", "Pvt. Beck", "Pvt. James", "Pvt. Jones",
	"Pvt. Harrison", "Pvt. Statham", "Pvt. Fletcher", "Pvt. Mackintosh", "Pvt. Sweeney", "Pvt. Moriarty", "Pvt. Leaver",
	"Pvt. McGregor", "Pvt. Bremner", "Pvt. Miller", "Pvt. Macdonald", "Pvt. Henderson", "Pvt. McQuarrie", "Pvt. Welsh",
	"Pvt. Murphy", "Pvt. Carlyle", "Pvt. Eadie", "Pvt. Nestor", "Pvt. Hodge", "Pvt. Fleming", "Pvt. Figg", "Pvt. Donnely",
	"Pvt. Bell", "Pvt. Browne", "Pvt. Boyle", "Pvt. Burke", "Pvt. Byrne", "Pvt. Nolan", "Pvt. Carroll", "Pvt. Clarke",
	"Pvt. Collins", "Pvt. Connolly", "Pvt. Connor", "Pvt. Fitzgerald", "Pvt. Flynn", "Pvt. Hughes", "Pvt. Kennedy",
	"Pvt. Murray", "Pvt. Ryan", "Pvt. Quinn", "Pvt. Shea", "Pvt. Sullivan", "Pvt. Lewis", "Pvt. Walsh", "Pvt. Connery",
	"Pvt. White", "Pvt. DeWitt", "Pvt. Stewart", "Pvt. Stevenson", "Pvt. Rankin", "Pvt. McDiarmid", "Pvt. Maxwell",
	"Pvt. Livingstone", "Pvt. Lipton", "Pvt. Liddell", "Pvt. Lennox", "Pvt. Kidd", "Pvt. Hamilton", "Pvt. Coltrane",
	"Pvt. Burns", "Pvt. Anderson", "Pvt. Lindsay", "Pvt. MacLeod", "Pvt. Sherman", "Pvt. Williamson", "Pvt. Kilgour",
	"Pvt. Watson", "Pvt. Holmes", "Sgt. Boon", "Pvt. Pritchard", "Pvt. Cook", "Pvt. Mitchell", "Pvt. Kilpatrick",
	"Sgt. Murphy", "Pvt. Brest", "Pvt. Rockhill", "Pvt. Riley", "Sgt. Hansell", "Pvt. Kieran", "Pvt. McWilliams",
	"Pvt. Ricketts", "Pvt. Beal", "Pvt. Bixby", "Pvt. Hanlon", "Pvt. Hassell", "Pvt. McRae", "Pvt. Owens", "Pvt. Thorne",
	"Pvt. Thornton", "Pvt. Tomblin", "Pvt. Walker", "Pvt. Wallis", "Sgt. Irwin",
}
COD1.RussianSurnames = {
	"Pvt. Ivanov", "Sgt. Smirnov", "Pvt. Vasilev", "Pvt. Petrov", "Pvt. Kyznetsov", "Pvt. Fedorov", "Pvt. Mikhailov",
	"Pvt. Sokolov", "Pvt. Filatov", "Pvt. Leonov", "Pvt. Danilov", "Pvt. Zaitsev", "Pvt. Ilin", "Pvt. Semenov",
	"Pvt. Lebedev", "Pvt. Golubev", "Pvt. Lukin", "Pvt. Zhuravlev", "Pvt. Gerasimov", "Pvt. Petrenko", "Pvt. Nikitin",
	"Pvt. Andropov", "Pvt. Chernenko", "Pvt. Brezhnev", "Pvt. Kalinin", "Pvt. Shvernik", "Pvt. Voroshilov",
	"Pvt. Mikoyan", "Pvt. Podgorniy", "Pvt. Kuznetsov", "Pvt. Grombyo", "Pvt. Rykov", "Pvt. Malenkov", "Pvt. Bulganin",
	"Pvt. Kosygin", "Pvt. Tikhonov", "Pvt. Ryzhkov", "Pvt. Vyshinskiy", "Pvt. Shevardnadze", "Pvt. Shepilov",
	"Pvt. Bessmertnykh", "Pvt. Pankin", "Pvt. Litvinov", "Pvt. Merkulov", "Pvt. Ogoltsov", "Pvt. Fedorchuk",
	"Pvt. Bakatin", "Pvt. Shebarshin", "Pvt. Semichastniy", "Pvt. Serov", "Pvt. Ustinov", "Pvt. Yazov", "Pvt. Grechko",
	"Pvt. Aleksandrov", "Pvt. Shatalov", "Pvt. Shonin", "Pvt. Filipchenko", "Pvt. Kubasov", "Pvt. Gorbatko",
	"Pvt. Volkov", "Pvt. Yeliseyev", "Pvt. Feoktistov", "Pvt. Tereshkov", "Pvt. Bykovsky", "Pvt. Artyukhin",
	"Pvt. Beregovy", "Pvt. Berezovoy", "Pvt. Demin", "Pvt. Jahn", "Pvt. Khrunov", "Pvt. Kovalyonok", "Pvt. Lazarev",
	"Pvt. Popovich", "Pvt. Romanenko", "Pvt. Rozhdestvensky", "Pvt. Rukavishnikov", "Pvt. Ryumin", "Pvt. Savinykh",
	"Pvt. Sevastyanov", "Pvt. Titov", "Pvt. Gagarin", "Pvt. Kinski", "Pvt. Todoroff", "Pvt. Goernshtein",
	"Pvt. Bondarachuk", "Pvt. Banionis", "Pvt. Solonitsyn", "Pvt. Grinko", "Pvt. Kerdimun", "Pvt. Kizilov", "Pvt. Malykh",
	"Pvt. Oganesyan", "Pvt. Ogorodnikov", "Pvt. Sargsyan", "Pvt. Semyonov", "Pvt. Statsinski", "Pvt. Sumenov",
	"Pvt. Tejkh", "Pvt. Tarasov", "Pvt. Artemyev", "Pvt. Ovchinnikov", "Pvt. Yusov", "Pvt. Kushneryov", "Pvt. Tarkovsky",
	"Pvt. Chugunov", "Pvt. Murashko", "Pvt. Nevsky", "Pvt. Paramanov", "Pvt. Shvedov", "Pvt. Glushenko",
	"Pvt. Chernogolov", "Pvt. Afanasyev", "Pvt. Bondarenko", "Pvt. Voronov", "Pvt. Gridin", "Pvt. Kiselev",
	"Pvt. Sarayev", "Pvt. Svirin", "Pvt. Sabgaida", "Pvt. Chernyshenko", "Pvt. Dovzhenko", "Pvt. Ivashenko",
	"Pvt. Shapovalov", "Pvt. Yakimenko", "Pvt. Masijashvili", "Pvt. Murzaev", "Pvt. Turdyev", "Pvt. Ramazanov",
	"Pvt. Avagimov", "Pvt. Demchenko", "Pvt. Stepanoshvili", "Pvt. Shkuratov", "Pvt. Yefremov", "Pvt. Ulyanova",
	"Pvt. Rose", "Cpl. Filatov", "Sgt. Borodin", "Sgt. Gromov", "Sr. Lt. Kozlov",
}
COD1.GermanFirstNames = {
	"Hans", "Fritz", "Karl", "Otto", "Heinz", "Kurt", "Walter", "Wilhelm", "Helmut", "Ernst", "Friedrich", "Hermann",
	"Werner", "Gerhard", "Franz", "Josef", "Paul", "Erich", "Rudolf", "Willi", "Horst", "Klaus", "Dieter", "Guenter",
	"Albert", "Bruno", "Max", "Ludwig", "Georg", "Johann", "Heinrich", "Alfred", "Emil", "Gustav", "Konrad", "Adam",
}
COD1.GermanSurnames = {
	"Mueller", "Schmidt", "Schneider", "Fischer", "Weber", "Meyer", "Wagner", "Becker", "Schulz", "Hoffmann", "Koch",
	"Richter", "Klein", "Wolf", "Schroeder", "Neumann", "Schwarz", "Zimmermann", "Braun", "Krueger", "Hartmann", "Lange",
	"Werner", "Krause", "Lehmann", "Schulze", "Maier", "Koehler", "Herrmann", "Koenig", "Walter", "Huber", "Kaiser",
	"Fuchs", "Peters", "Scholz", "Moeller", "Weiss", "Jung", "Hahn", "Vogel", "Keller", "Frank", "Berger", "Winkler",
	"Roth", "Beck", "Lorenz", "Baumann", "Franke", "Albrecht", "Schuster", "Ludwig", "Boehm", "Winter", "Kraus",
	"Schumacher", "Vogt", "Stein", "Jaeger", "Sommer", "Gross", "Seidel", "Brandt", "Haas", "Graf", "Ziegler", "Kuhn",
	"Engel", "Horn", "Busch", "Bergmann", "Voigt", "Sauer", "Arnold", "Pfeiffer", "Bauer", "Schaefer", "Hofer", "Trajzitfrig",
}
COD1.GrenadeModels = { german = "models/cod1/props/stielhandgranate.mdl", british = "models/cod1/props/mills_grenade.mdl",
	russian = "models/cod1/props/rgd33_grenade.mdl" }
COD1.SmokeClouds = COD1.SmokeClouds or {}
COD1.GermanRanks = { "Schtz.", "Schtz.", "Schtz.", "Gefr.", "Gefr.", "Ogefr.", "Uffz.", "Fw." }
COD1.GermanRoles = { kar98 = "Schuetze", kar98_sniper = "Scharfschuetze", mp40 = "MP-Schuetze", mp44 = "Sturmgewehr-Schuetze", fg42 = "Fallschirmschuetze", luger = "Offizier",
	g43 = "Schuetze", mg34 = "MG-Schuetze", pschreck = "Panzerschreck-Schuetze", pfaust = "Panzerjaeger", flamer = "Flammenwerfer-Schuetze" }

function COD1.GermanName( rank )
	return ( rank or COD1.GermanRanks[ math.random( #COD1.GermanRanks ) ] ) .. " "
		.. COD1.GermanFirstNames[ math.random( #COD1.GermanFirstNames ) ] .. " "
		.. COD1.GermanSurnames[ math.random( #COD1.GermanSurnames ) ]
end

function COD1.RandomName( rank, surnames, weapon )
	surnames = surnames or COD1.Surnames
	local name = surnames[ math.random( #surnames ) ]
	local own, surname = string.match( name, "^(.-%.) (%S+)$" )
	if rank then return rank .. " " .. ( surname or name ) end
	if own then return name end
	if weapon == "thompson" then return "Lt. " .. name end
	local r = math.random( 100 )
	return ( r > 40 and "Pvt." or r > 20 and "Cpl." or "Sgt." ) .. " " .. name
end

local function rnd( fmt, n )
	local t = {}
	for i = 1, n do t[ i ] = string.format( fmt, i ) end
	return t
end
sound.Add( { name = "COD1.Footstep", channel = CHAN_BODY, volume = 0.45, level = 70, pitch = { 95, 105 },
	sound = rnd( "cod1/footsteps/foot_dirt%02d.wav", 4 ) } )
sound.Add( { name = "COD1.BodyFall", channel = CHAN_BODY, volume = 0.9, level = 75, pitch = { 95, 105 },
	sound = rnd( "cod1/bodyfalls/bodyfall_dirt%02d.wav", 5 ) } )

local STEPS = { dirt = { "foot_dirt", 4 }, grass = { "foot_grass", 4 }, mud = { "foot_mud", 4 }, stone = { "foot_stone", 6 },
	wood = { "foot_wood", 6 }, metal = { "foot_metal", 4 }, leaves = { "foot_leaves", 4 }, carpet = { "foot_carpet", 4 },
	glass = { "foot_glass", 4 }, snow = { "foot_snow", 4 }, water = { "water_wade", 2 } }
for surf, s in pairs( STEPS ) do
	sound.Add( { name = "COD1.Step." .. surf, channel = CHAN_BODY, volume = surf == "water" and 0.6 or 0.5, level = 72, pitch = { 94, 106 },
		sound = rnd( "cod1/footsteps/" .. s[ 1 ] .. "%02d.wav", s[ 2 ] ) } )
	sound.Add( { name = "COD1.Land." .. surf, channel = CHAN_BODY, volume = 0.85, level = 75, pitch = { 95, 105 },
		sound = "cod1/footsteps/land_" .. ( surf == "glass" and "stone" or surf ) .. ".wav" } )
end
for surf, n in pairs( { dirt = 5, stone = 5, wood = 4, metal = 3, water = 3 } ) do
	sound.Add( { name = "COD1.Fall." .. surf, channel = CHAN_BODY, volume = 0.9, level = 75, pitch = { 95, 105 },
		sound = rnd( "cod1/bodyfalls/bodyfall_" .. surf .. "%02d.wav", n ) } )
end
sound.Add( { name = "COD1.Gear", channel = CHAN_ITEM, volume = 0.35, level = 65, pitch = { 95, 105 },
	sound = { "cod1/misc/gear_rattle02.wav", "cod1/misc/gear_rattle03.wav", "cod1/misc/gear_rattle04.wav", "cod1/misc/gear_rattle05.wav" } } )
sound.Add( { name = "COD1.GoProne", channel = CHAN_ITEM, volume = 0.8, level = 70, pitch = { 95, 105 }, sound = rnd( "cod1/misc/go_prone%02d.wav", 2 ) } )
for name, file in pairs( { WarrantPapers = "warrant_papers", WarrantSchmidt = "warrant_schmidt", WarrantWelcome = "warrant_welcome",
	WarrantGranted = "warrant_granted", GuardPapers = "guard_papers", GuardCheck = "guard_check", GuardOfficers = "guard_officers",
	PriceDonitz = "price_donitz", PricePermission = "price_permission" } ) do
	sound.Add( { name = "COD1.Ship." .. name, channel = CHAN_VOICE, volume = 1, level = 75, pitch = 100, sound = "cod1/ship/" .. file .. ".wav" } )
end
sound.Add( { name = "COD1.Paper", channel = CHAN_ITEM, volume = 0.7, level = 65, pitch = { 95, 105 }, sound = rnd( "cod1/misc/pu_paper%02d.wav", 2 ) } )
sound.Add( { name = "COD1.Crawl", channel = CHAN_BODY, volume = 0.55, level = 68, pitch = { 95, 105 }, sound = rnd( "cod1/footsteps/crawl%02d.wav", 2 ) } )
sound.Add( { name = "COD1.Scrape", channel = CHAN_ITEM, volume = 0.6, level = 70, pitch = { 95, 105 }, sound = rnd( "cod1/footsteps/foot_scrape%02d.wav", 2 ) } )
for key, shot in pairs( { kar98_sniper = "kar98k/kar98_sniper", mosin_sniper = "nagant/nagant_sniper", springfield = "springfield/springfield_01" } ) do
	sound.Add( { name = "COD1.Fire." .. key, channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 95, 103 }, sound = "cod1/weapons/" .. shot .. ".wav" } )
	sound.Add( { name = "COD1.Reload." .. key, channel = CHAN_ITEM, level = 70, volume = 1, pitch = 100, sound = "cod1/weapons/kar98k/kar98_reload.wav" } )
	sound.Add( { name = "COD1.Rechamber." .. key, channel = CHAN_ITEM, level = 75, volume = 1, pitch = 100, sound = "cod1/weapons/kar98k/kar98_rechamber.wav" } )
end

local MAT_SURFACE = { [ MAT_DIRT ] = "dirt", [ MAT_SAND ] = "dirt", [ MAT_GRASS ] = "grass", [ MAT_SNOW ] = "snow", [ MAT_SLOSH ] = "mud",
	[ MAT_FOLIAGE ] = "leaves", [ MAT_WOOD ] = "wood", [ MAT_METAL ] = "metal", [ MAT_VENT ] = "metal", [ MAT_GRATE ] = "metal",
	[ MAT_COMPUTER ] = "metal", [ MAT_GLASS ] = "glass", [ MAT_CONCRETE ] = "stone", [ MAT_TILE ] = "stone", [ MAT_PLASTIC ] = "stone",
	[ MAT_DEFAULT ] = "stone" }
local FALL_SURFACE = { grass = "dirt", mud = "dirt", leaves = "dirt", snow = "dirt", glass = "stone", carpet = "wood" }

local function notSoldier( e )
	return not ( e.IsCOD1Soldier or e:IsPlayer() or e:IsNPC() )
end

function COD1.SurfaceUnder( ent )
	local pos = ent:GetPos()
	if bit.band( util.PointContents( pos + Vector( 0, 0, 8 ) ), CONTENTS_WATER ) ~= 0 then return "water" end
	local tr = util.TraceLine( { start = pos + Vector( 0, 0, 16 ), endpos = pos - Vector( 0, 0, 48 ), filter = notSoldier, mask = MASK_SOLID } )
	if not tr.Hit then return "dirt" end
	return MAT_SURFACE[ tr.MatType ] or "dirt"
end

function COD1.FallSurface( surf )
	return FALL_SURFACE[ surf ] or surf
end

hook.Add( "ShouldCollide", "COD1SoldiersPass", function( a, b )
	if a.IsCOD1Truck and b.IsCOD1Soldier and b:GetNWEntity( "COD1Truck" ) == a then return false end
	if b.IsCOD1Truck and a.IsCOD1Soldier and a:GetNWEntity( "COD1Truck" ) == b then return false end
	if not ( a.IsCOD1Soldier and b.IsCOD1Soldier ) then return end
	if a:GetNWString( "COD1Team" ) == b:GetNWString( "COD1Team" ) then return false end
end )

hook.Add( "PhysgunPickup", "COD1Held", function( ply, ent )
	if ent.IsCOD1Soldier then ent.PhysgunHeld = true end
end )
hook.Add( "PhysgunDrop", "COD1Held", function( ply, ent )
	if ent.IsCOD1Soldier then
		ent.PhysgunHeld = false
		ent.UseBlockedUntil = CurTime() + 0.5
	end
end )
hook.Add( "OnEntityCreated", "COD1SoldierCollision", function( ent )
	timer.Simple( 0, function()
		if IsValid( ent ) and ent.IsCOD1Soldier then ent:SetCustomCollisionCheck( true ) end
	end )
end )

--all the numbers live here, tweak at your own risk
