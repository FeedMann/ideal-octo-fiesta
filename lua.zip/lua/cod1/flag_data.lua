COD1.FlagPickup = { time = 0.267, hand = Vector( 15.72, 17.95, 1.65 ) }

--where the flag guy grabs the flag, very important stuff
