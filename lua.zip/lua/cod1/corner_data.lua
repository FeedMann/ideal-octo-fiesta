COD1.CornerData = {
	as_r = { hide = 180, yaw = { 65.8, 20.8, -9.9 }, muzzle = Vector( 38.3, 32.9, 55.7 ), nade = 1.67 },
	as_l = { hide = 180, yaw = { 33.6, -23.6, -61.1 }, muzzle = Vector( 37.3, -34.0, 54.3 ), nade = 1.63 },
	ac_r = { hide = 180, yaw = { 61.6, 15.7, -19.5 }, muzzle = Vector( 41.7, 32.4, 32.1 ), nade = 1.77 },
	ac_l = { hide = 180, yaw = { 29.5, -13.3, -39.0 }, muzzle = Vector( 40.6, -27.6, 42.2 ), nade = 1.80 },
	bs_r = { hide = 0, yaw = { 56.7, 18.8, -25.8 }, muzzle = Vector( 32.9, 31.1, 48.7 ), nade = 1.47 },
	bs_l = { hide = 0, yaw = { 28.7, -14.1, -55.0 }, muzzle = Vector( 36.2, -26.7, 50.2 ), nade = 1.40 },
	bc_r = { hide = 0, yaw = { 58.4, 22.3, -22.3 }, muzzle = Vector( 33.5, 31.1, 21.9 ), nade = 1.43 },
	bc_l = { hide = 0, yaw = { 32.5, -15.8, -59.9 }, muzzle = Vector( 38.7, -27.5, 25.3 ), nade = 1.70 },
	ps_r = { hide = 0, yaw = { 60.0, 12.3, -32.4 }, muzzle = Vector( 57.6, 24.5, 61.4 ), nade = 1.00 },
	ps_l = { hide = 0, yaw = { 30.7, -22.5, -58.3 }, muzzle = Vector( 48.9, -34.8, 66.0 ), nade = 1.00 },
	pc_r = { hide = 0, yaw = { 32.9, -13.8, -64.4 }, muzzle = Vector( 55.4, 23.0, 22.5 ), nade = 1.00 },
	pc_l = { hide = 0, yaw = { 28.5, -15.4, -60.4 }, muzzle = Vector( 55.8, -35.0, 37.1 ), nade = 1.00 },
}
COD1.CornerRambo = {
	r = { 4.1, -55.8, -180.0 },
	l = { 4.5, 61.9, -180.0 },
}

--corner peeking numbers, dont touch these
