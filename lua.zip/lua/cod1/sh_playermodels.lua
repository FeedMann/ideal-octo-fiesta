COD1.PlayerModels = {
	{ "CoD1 US Airborne", "models/cod1/player/american/airborne.mdl" },
	{ "CoD1 US Airborne (Winter)", "models/cod1/player/american/airborne_winter.mdl" },
	{ "CoD1 US Heroes", "models/cod1/player/american/heroes.mdl" },
	{ "CoD1 US Medics", "models/cod1/player/american/medics.mdl" },
	{ "CoD1 US Snipers", "models/cod1/player/american/snipers.mdl" },
	{ "CoD UO US Army", "models/cod1/player/american/uo.mdl" },
	{ "CoD1 British Paratroopers", "models/cod1/player/british/paratroopers.mdl" },
	{ "CoD1 British Heroes", "models/cod1/player/british/heroes.mdl" },
	{ "CoD1 British Heroes (Winter)", "models/cod1/player/british/heroes_winter.mdl" },
	{ "CoD UO RAF Bomber Crew", "models/cod1/player/british/raf.mdl" },
	{ "CoD UO French Resistance", "models/cod1/player/british/resistance.mdl" },
	{ "CoD UO British", "models/cod1/player/british/uo.mdl" },
	{ "CoD1 Wehrmacht", "models/cod1/player/german/wehrmacht.mdl" },
	{ "CoD1 Waffen-SS", "models/cod1/player/german/waffen_ss.mdl" },
	{ "CoD1 Fallschirmjager", "models/cod1/player/german/fallschirmjager.mdl" },
	{ "CoD1 German Winter", "models/cod1/player/german/winter.mdl" },
	{ "CoD1 Kriegsmarine", "models/cod1/player/german/kriegsmarine.mdl" },
	{ "CoD1 German Snipers", "models/cod1/player/german/snipers.mdl" },
	{ "CoD UO Afrika Korps", "models/cod1/player/german/tropical.mdl" },
	{ "CoD UO German Assault", "models/cod1/player/german/assault.mdl" },
	{ "CoD UO German Winter Assault", "models/cod1/player/german/winter_assault.mdl" },
	{ "CoD1 Red Army", "models/cod1/player/russian/army.mdl" },
	{ "CoD1 Red Army (Winter)", "models/cod1/player/russian/winter.mdl" },
	{ "CoD1 Soviet Officers", "models/cod1/player/russian/officers.mdl" },
	{ "CoD1 Soviet Heroes", "models/cod1/player/russian/heroes.mdl" },
	{ "CoD1 Soviet Medics", "models/cod1/player/russian/medics.mdl" },
	{ "CoD1 Soviet Snipers", "models/cod1/player/russian/snipers.mdl" },
	{ "CoD UO Red Army", "models/cod1/player/russian/uo.mdl" },
	{ "CoD UO General Antonov", "models/cod1/player/russian/antonov.mdl" },
}

local HANDS = "models/weapons/c_arms_cstrike.mdl"
local IS = {}
for _, m in ipairs( COD1.PlayerModels ) do
	IS[ m[ 2 ] ] = true
	player_manager.AddValidModel( m[ 1 ], m[ 2 ] )
	player_manager.AddValidHands( m[ 1 ], HANDS, 0, "00000000" )
end

function COD1.IsCoDPlayer( ply )
	return IsValid( ply ) and IS[ string.lower( ply:GetModel() or "" ) ] == true
end

COD1.ANIM_MELEE = 7501
COD1.PlayerAnimSpeed = COD1.PlayerAnimSpeed or {}

local BOLT = { kar98k = true, kar98k_sniper = true, springfield = true, enfield = true, mosin_nagant = true, mosin_nagant_sniper = true }
local HEAVY = { bar = true, mp44 = true, bren = true, fg42 = true }
local STICK = { stielhandgranate = true, rgd33 = true }
local HOLD = {
	pistol = "pistol", revolver = "pistol", duel = "pistol",
	smg = "auto", ar2 = "auto", shotgun = "rifle", crossbow = "bolt",
	rpg = "rocket", grenade = "grenade", slam = "grenade", physgun = "physgun", camera = "binoc",
	normal = "none", fist = "none", melee = "none", melee2 = "none", knife = "none", passive = "none", magic = "none",
}

function COD1.PlayerWeaponClass( ply )
	local w = ply:GetActiveWeapon()
	if not IsValid( w ) then return "none", nil end
	local key = w.CoDKey
	local d = key and COD1.WeaponDefs and COD1.WeaponDefs[ key ]
	if d then
		local c = d.class
		if c == "pistol" then return "pistol", w end
		if c == "grenade" then return STICK[ key ] and "stick" or "grenade", w end
		if c == "rocketlauncher" then return "rocket", w end
		if c == "spotter" then return "binoc", w end
		if c == "lmg" or c == "mg" then return "lmg", w end
		if c == "smg" then return "auto", w end
		if c == "flamethrower" then return "heavy", w end
		if BOLT[ key ] or d.boltAction == 1 then return "bolt", w end
		if HEAVY[ key ] then return "heavy", w end
		return "rifle", w
	end
	return HOLD[ w:GetHoldType() ] or "rifle", w
end

local function ads( w )
	if not IsValid( w ) then return false end
	if w.GetADS then return w:GetADS() == true end
	if w.GetIronSights then return w:GetIronSights() == true end
	if w.GetIronsights then return w:GetIronsights() == true end
	return false
end

local function stance( ply )
	local M = COD1MV
	if M and M.Active and M.Active( ply ) then return M.Stance( ply ) end
	return ply:Crouching() and 1 or 0
end

local function sprinting( ply )
	local M = COD1MV
	return M and M.Active and M.Active( ply ) and M.Sprinting( ply ) or false
end

local function pick( ply, ... )
	for _, n in ipairs( { ... } ) do
		if n then
			local s = ply:LookupSequence( n )
			if s and s >= 0 then return s, n end
		end
	end
	return -1
end

local function rawDir( ply, vel, prev )
	local a = ply:GetAngles()
	local f, r = a:Forward(), a:Right()
	local fwd, side = f.x * vel.x + f.y * vel.y, r.x * vel.x + r.y * vel.y
	local k = ( prev == "left" or prev == "right" ) and 0.8 or 1.4
	if math.abs( side ) > math.abs( fwd ) * k then return side > 0 and "right" or "left" end
	return fwd >= 0 and "fwd" or "back"
end

local function moveDir( ply, vel )
	local now = CurTime()
	local want = rawDir( ply, vel, ply.c1pmDir )
	if want ~= ply.c1pmDir then
		if ply.c1pmDirWant ~= want then ply.c1pmDirWant, ply.c1pmDirSince = want, now end
		if not ply.c1pmDir or now - ply.c1pmDirSince > 0.12 then ply.c1pmDir = want end
	else
		ply.c1pmDirWant = nil
	end
	return ply.c1pmDir
end

local SUFFIX = { pistol = "_pistol", grenade = "_grenade", stick = "_grenade", rocket = "_rocket", binoc = "_binoc" }

local function dirName( base, dir, wc )
	local suf = SUFFIX[ wc ] or ""
	local d = dir == "fwd" and "" or "_" .. dir
	return base .. d .. suf, base .. d, base .. suf, base
end

local function body( ply, vel )
	local wc, w = COD1.PlayerWeaponClass( ply )
	local st, speed = stance( ply ), vel:Length2D()
	local mt = ply:GetMoveType()
	if ply:InVehicle() then return pick( ply, "truck_drive", "pm_crouch" ) end
	if mt == MOVETYPE_LADDER then return pick( ply, vel.z >= 0 and "pm_climbup" or "pm_climbdown", "pm_climbup" ) end
	local now = CurTime()
	if mt ~= MOVETYPE_NOCLIP and not ply:OnGround() and ply:WaterLevel() < 2 and st == 0 then
		local pist = ( wc == "pistol" or wc == "grenade" ) and "_pistol" or ""
		local run = ( ply.c1pmJumpSpeed or 0 ) > 120
		return pick( ply, ( run and "pm_runjump" or "pm_jump" ) .. pist, run and "pm_runjump" or "pm_jump" )
	end
	if now < ( ply.c1pmLandUntil or 0 ) and st == 0 then
		local pist = ( wc == "pistol" or wc == "grenade" ) and "_pistol" or ""
		local run = speed > 120
		return pick( ply, ( run and "pm_runland" or "pm_land" ) .. pist, run and "pm_runland" or "pm_land" )
	end
	local moving = speed > 10 and mt ~= MOVETYPE_NOCLIP
	local aimed = ads( w )
	if st == 2 then
		if not moving then
			local suf = wc == "none" and "_pistol" or SUFFIX[ wc ] or ""
			return pick( ply, "pm_prone" .. suf, "pm_prone" )
		end
		local dir = moveDir( ply, vel )
		local wcc = wc == "none" and "pistol" or wc
		return pick( ply, dirName( "pm_crawl", dir, wcc ) )
	end
	if st == 1 then
		if not moving then
			if wc == "none" then return pick( ply, "pm_crouch_unarmed", "pm_crouch" ) end
			if wc == "pistol" then return pick( ply, aimed and "pm_crouch_pistol_ads" or "pm_crouch_pistol", "pm_crouch" ) end
			if aimed and ( wc == "rifle" or wc == "auto" or wc == "bolt" or wc == "heavy" ) then return pick( ply, "pm_crouch_ads", "pm_crouch" ) end
			return pick( ply, "pm_crouch" .. ( SUFFIX[ wc ] or "" ), "pm_crouch" )
		end
		local dir = moveDir( ply, vel )
		if wc == "none" then return pick( ply, speed > 70 and "pm_crouchrun_unarmed" or "pm_crouchwalk_unarmed", "pm_crouchwalk_unarmed", "pm_crouchrun" ) end
		if wc == "grenade" or wc == "stick" then
			if speed > 70 and dir == "fwd" then return pick( ply, "pm_crouchrun_grenade", "pm_crouchrun" ) end
			return pick( ply, dirName( "pm_crouchwalk", dir, "pistol" ) )
		end
		local base = ( speed > 70 and wc ~= "rocket" and wc ~= "binoc" and not aimed ) and "pm_crouchrun" or "pm_crouchwalk"
		return pick( ply, dirName( base, dir, wc ) )
	end
	if not moving then
		if wc == "none" then return pick( ply, "pm_idle_unarmed", "pm_idle" ) end
		if wc == "pistol" then return pick( ply, aimed and "pm_idle_pistol_ads" or "pm_idle_pistol", "pm_idle" ) end
		if wc == "grenade" or wc == "stick" then return pick( ply, "pm_idle_grenade", "pm_idle" ) end
		if wc == "rocket" then return pick( ply, aimed and "pm_idle_rocket_ads" or "pm_idle_rocket", "pm_idle" ) end
		if wc == "binoc" then return pick( ply, aimed and "pm_idle_binoc_ads" or "pm_idle_binoc", "pm_idle" ) end
		if aimed and wc == "bolt" then return pick( ply, "pm_idle_sniper_ads", "pm_idle_ads", "pm_idle" ) end
		return pick( ply, aimed and "pm_idle_ads" or "pm_idle", "pm_idle" )
	end
	local dir = moveDir( ply, vel )
	if sprinting( ply ) and dir == "fwd" then
		if wc == "grenade" then return pick( ply, "pm_run_grenade", "pm_sprint" ) end
		if wc == "stick" then return pick( ply, "pm_run_stickgrenade", "pm_sprint" ) end
		if wc == "pistol" or wc == "none" then return pick( ply, "pm_run_pistol", "pm_sprint" ) end
		return pick( ply, "pm_sprint", "pm_run" )
	end
	local walk = speed < ( ply.c1pmWalking and 135 or 105 ) or aimed
	ply.c1pmWalking = walk
	if wc == "none" then
		if dir == "fwd" then return pick( ply, walk and "pm_walk_unarmed_sp" or "pm_run_unarmed", "pm_walk_unarmed", "pm_walk" ) end
		return pick( ply, dirName( walk and "pm_walk" or "pm_run", dir, "pistol" ) )
	end
	if wc == "binoc" then return pick( ply, dirName( "pm_walk", dir, "binoc" ) ) end
	if walk then
		local wcc = ( wc == "grenade" or wc == "stick" ) and "pistol" or wc
		if wc == "rocket" and dir == "fwd" then return pick( ply, "pm_run_rocket", "pm_walk" ) end
		return pick( ply, dirName( "pm_walk", dir, wcc ) )
	end
	if dir == "fwd" then
		if wc == "pistol" then return pick( ply, "pm_run_pistol", "pm_run" ) end
		if wc == "grenade" then return pick( ply, "pm_run_grenade", "pm_run" ) end
		if wc == "stick" then return pick( ply, "pm_run_stickgrenade", "pm_run" ) end
		if wc == "rocket" then return pick( ply, "pm_run_rocket", "pm_run" ) end
		if wc == "lmg" then return pick( ply, "pm_run_lmg", "pm_run_heavy", "pm_run" ) end
		if wc == "heavy" or wc == "physgun" then return pick( ply, "pm_run_heavy", "pm_run" ) end
		if wc == "auto" then return pick( ply, "pm_run_light", "pm_run" ) end
		if wc == "bolt" then return pick( ply, "pm_run_rifles", "pm_run" ) end
		return pick( ply, "pm_run" )
	end
	local wcc = ( wc == "grenade" or wc == "stick" ) and "pistol" or wc
	return pick( ply, dirName( "pm_run", dir, wcc ) )
end

hook.Add( "CalcMainActivity", "COD1PlayerModels", function( ply, vel )
	if not COD1.IsCoDPlayer( ply ) then return end
	local onGround = ply:OnGround() or ply:GetMoveType() ~= MOVETYPE_WALK
	if ply.c1pmAir and onGround then
		ply.c1pmLandUntil = CurTime() + 0.3
	end
	if not onGround and not ply.c1pmAir then ply.c1pmJumpSpeed = vel:Length2D() end
	ply.c1pmAir = not onGround
	local s, name = body( ply, vel )
	if s < 0 then return end
	ply.c1pmSeqName = name
	ply.CalcIdeal, ply.CalcSeqOverride = ACT_MP_STAND_IDLE, s
	return ACT_MP_STAND_IDLE, s
end )

hook.Add( "UpdateAnimation", "COD1PlayerModels", function( ply, vel )
	if not COD1.IsCoDPlayer( ply ) then return end
	local name = ply.c1pmSeqName or ""
	local speed = name:find( "climb", 1, true ) and math.abs( vel.z ) or vel:Length2D()
	local nat = COD1.PlayerAnimSpeed[ name ]
	local rate = 1
	if nat and nat > 1 and speed > 5 then rate = math.Clamp( speed / nat, 0.5, 2 ) end
	if ply:GetMoveType() == MOVETYPE_NOCLIP then rate = 1 end
	ply:SetPlaybackRate( rate )
	ply:SetPoseParameter( "look_pitch", math.Clamp( math.NormalizeAngle( ply:EyeAngles().p ), -60, 60 ) )
	local M = COD1MV
	local lean = M and M.Active and M.Active( ply ) and M.LeanEase( M.Lean( ply ) ) or 0
	ply:SetPoseParameter( "lean_roll", math.Clamp( lean, -1, 1 ) )
	if CLIENT then ply:InvalidateBoneCache() end
	return true
end )

local function gesture( ply, ... )
	local s = pick( ply, ... )
	if s >= 0 then ply:AddVCDSequenceToGestureSlot( GESTURE_SLOT_ATTACK_AND_RELOAD, s, 0, true ) end
end

local function stanceTag( ply )
	local st = stance( ply )
	return st == 2 and "prone_" or st == 1 and "crouch_" or ""
end

local function fireGesture( ply )
	local wc, w = COD1.PlayerWeaponClass( ply )
	if wc == "none" or wc == "binoc" then return end
	local st, aimed = stanceTag( ply ), ads( w )
	if wc == "grenade" or wc == "stick" then
		if st == "" and wc == "stick" then return gesture( ply, "pt_throw_stick", "pt_throw" ) end
		return gesture( ply, "pt_" .. st .. "throw", "pt_throw" )
	end
	if wc == "pistol" then return gesture( ply, "pt_" .. st .. "shoot_pistol", "pt_shoot_pistol" ) end
	if wc == "auto" or wc == "lmg" then
		if CurTime() - ( ply.c1pmFireT or 0 ) < 0.15 then return end
		ply.c1pmFireT = CurTime()
		return gesture( ply, "pt_" .. st .. "shoot_auto" .. ( aimed and st ~= "prone_" and "_ads" or "" ), "pt_" .. st .. "shoot_auto", "pt_shoot_auto" )
	end
	if wc == "bolt" then
		if st == "prone_" then return gesture( ply, "pt_bolt_prone" ) end
		return gesture( ply, ( aimed or st == "crouch_" ) and "pt_bolt_ads" or "pt_bolt", "pt_bolt" )
	end
	if wc == "rocket" then
		if st == "prone_" then return gesture( ply, "pt_prone_shoot" ) end
		return gesture( ply, "pt_" .. st .. "shoot_ads", "pt_shoot_ads" )
	end
	return gesture( ply, "pt_" .. st .. "shoot" .. ( aimed and st ~= "prone_" and "_ads" or "" ), "pt_" .. st .. "shoot", "pt_shoot" )
end

local function reloadGesture( ply )
	local wc, w = COD1.PlayerWeaponClass( ply )
	if wc == "none" or wc == "binoc" or wc == "grenade" or wc == "stick" then return end
	local st = stanceTag( ply )
	if wc == "pistol" then return gesture( ply, "pt_" .. st .. "reload_pistol", "pt_reload_pistol" ) end
	if wc == "auto" or wc == "lmg" or wc == "heavy" then
		if st == "prone_" then return gesture( ply, "pt_prone_reload_auto", "pt_prone_reload" ) end
		if st == "crouch_" then return gesture( ply, "pt_crouch_reload" ) end
		local key = IsValid( w ) and w.CoDKey
		if key == "mp40" or key == "ppsh" then return gesture( ply, "pt_reload_mp40", "pt_reload_auto" ) end
		if key == "sten" or key == "stensd" then return gesture( ply, "pt_reload_sten", "pt_reload_auto" ) end
		if key == "fg42" then return gesture( ply, "pt_reload_fg42", "pt_reload_auto" ) end
		return gesture( ply, "pt_reload_auto", "pt_reload" )
	end
	return gesture( ply, "pt_" .. st .. "reload", "pt_reload" )
end

local function meleeGesture( ply )
	local wc = COD1.PlayerWeaponClass( ply )
	local st = stance( ply )
	if st == 2 then return gesture( ply, "pt_prone_shoot" ) end
	if wc == "pistol" or wc == "grenade" or wc == "stick" or wc == "none" then return gesture( ply, "pt_melee_pistol" .. math.random( 4 ), "pt_melee_pistol1" ) end
	if st == 1 then return gesture( ply, "pt_crouch_melee" .. math.random( 3 ), "pt_crouch_melee1" ) end
	return gesture( ply, "pt_melee" .. math.random( 5 ), "pt_melee1" )
end

hook.Add( "DoAnimationEvent", "COD1PlayerModels", function( ply, event, data )
	if not COD1.IsCoDPlayer( ply ) then return end
	if event == PLAYERANIMEVENT_CUSTOM_GESTURE and data == COD1.ANIM_MELEE then
		meleeGesture( ply )
		return ACT_INVALID
	end
	if event == PLAYERANIMEVENT_ATTACK_PRIMARY or event == PLAYERANIMEVENT_ATTACK_SECONDARY then
		fireGesture( ply )
		return ACT_INVALID
	end
	if event == PLAYERANIMEVENT_ATTACK_GRENADE then
		gesture( ply, "pt_" .. stanceTag( ply ) .. "throw", "pt_throw" )
		return ACT_INVALID
	end
	if event == PLAYERANIMEVENT_RELOAD or event == PLAYERANIMEVENT_RELOAD_LOOP then
		reloadGesture( ply )
		return ACT_INVALID
	end
	if event == PLAYERANIMEVENT_JUMP then
		ply.c1pmJumpSpeed = ply:GetVelocity():Length2D()
		return ACT_INVALID
	end
	return ACT_INVALID
end )

hook.Add( "PlayerSwitchWeapon", "COD1PlayerModels", function( ply, old, new )
	if not COD1.IsCoDPlayer( ply ) or not IsValid( new ) then return end
	gesture( ply, "pt_" .. stanceTag( ply ) .. "draw", "pt_draw" )
end )

function COD1.PlayerMeleeAnim( ply )
	if SERVER and COD1.IsCoDPlayer( ply ) then ply:DoCustomAnimEvent( PLAYERANIMEVENT_CUSTOM_GESTURE, COD1.ANIM_MELEE ) end
end

if CLIENT then return end

local hidden = {}

local function gunBones( ply )
	local mdl = string.lower( ply:GetModel() )
	if hidden[ mdl ] then return hidden[ mdl ] end
	local list, inGun = {}, {}
	for i = 0, ply:GetBoneCount() - 1 do
		local n = string.lower( ply:GetBoneName( i ) or "" )
		local p = ply:GetBoneParent( i )
		if n == "tag_weapon_right" or n == "tag_weapon_left" then
			inGun[ i ] = "root"
		elseif p >= 0 and inGun[ p ] and not string.StartWith( n, "valvebiped" ) then
			inGun[ i ] = true
			list[ #list + 1 ] = i
		end
	end
	hidden[ mdl ] = list
	return list
end

local function apply( ply )
	if ply.c1pmHidden then
		for _, i in ipairs( ply.c1pmHidden ) do ply:ManipulateBoneScale( i, Vector( 1, 1, 1 ) ) end
		ply.c1pmHidden = nil
	end
	if not COD1.IsCoDPlayer( ply ) then return end
	local list = gunBones( ply )
	for _, i in ipairs( list ) do ply:ManipulateBoneScale( i, vector_origin ) end
	ply.c1pmHidden = list
end

timer.Create( "COD1PlayerModels", 0.5, 0, function()
	for _, ply in ipairs( player.GetAll() ) do
		local mdl = ply:GetModel()
		if ply.c1pmModel ~= mdl then
			ply.c1pmModel = mdl
			apply( ply )
		end
	end
end )

hook.Add( "PlayerSpawn", "COD1PlayerModels", function( ply )
	timer.Simple( 0.1, function() if IsValid( ply ) then ply.c1pmModel = nil end end )
end )

--now you can be the guy who gets shot first in every cutscene
