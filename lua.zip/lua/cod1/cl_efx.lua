local EFX = COD1.EFX or {}
local LINEAR, NONLINEAR, WAVE, RANDOM, CLAMP = 1, 2, 4, 8, 16
local F_RELATIVE, F_USEALPHA, F_PHYSICS, F_IMPACTKILLS, F_IMPACTFX, F_DEATHFX, F_EMITFX, F_MODEL = 1, 2, 4, 8, 16, 32, 64, 128
local S_SPHERE, S_CYLINDER, S_AXISSPHERE, S_EVEN, S_ABSVEL, S_ABSACCEL, S_RANDROT, S_RGBCOMP, S_CHEAPORG = 1, 2, 4, 8, 16, 32, 64, 128, 256
local MATERIALS, ITEMS, EMITTERS = {}, {}, {}
local MAX_EMITTERS, MAX_ITEMS, CYL_SEGMENTS = 160, 600, 16
local COL = Color( 255, 255, 255, 255 )
local lightId = 0
local play

local function mat( name )
	local m = MATERIALS[ name ]
	if not m then
		m = Material( name )
		MATERIALS[ name ] = m
	end
	return m
end

local function has( x, f ) return bit.band( x or 0, f ) ~= 0 end

local function between( a, b ) return a + ( b - a ) * math.random() end

local function rr( t, def )
	if not t then return def end
	return between( t[ 1 ], t[ 2 ] or t[ 1 ] )
end

local function rv( t )
	if not t then return Vector() end
	return Vector( between( t[ 1 ], t[ 4 ] or t[ 1 ] ), between( t[ 2 ], t[ 5 ] or t[ 2 ] ), between( t[ 3 ], t[ 6 ] or t[ 3 ] ) )
end

local function normalAxes( f )
	local r = Vector( f.z, -f.x, f.y )
	r = r - f * r:Dot( f )
	r:Normalize()
	return r, r:Cross( f )
end

function COD1.ViewPos()
	local lp = LocalPlayer()
	if not IsValid( lp ) then return EyePos() end
	local view = lp:GetViewEntity()
	if IsValid( view ) and view ~= lp then return view:GetPos() end
	return lp:EyePos()
end

local function quality()
	return math.Clamp( GetConVar( "cod1_efx_quality" ):GetFloat(), 0, 2 )
end

local function curve( blk, life )
	local f = blk and blk.f or 0
	local mode = ( has( f, CLAMP ) or has( f, NONLINEAR ) and has( f, WAVE ) ) and 3 or has( f, NONLINEAR ) and 1 or has( f, WAVE ) and 2 or 0
	local parm = blk and blk.p and rr( blk.p ) or 0
	return { s = blk and blk.s and rr( blk.s ) or 1, e = blk and blk.e and rr( blk.e ) or 1, mode = mode, life = life,
		parm = mode == 2 and parm * math.pi * 0.001 or parm * 0.01 * life, lin = has( f, LINEAR ), rand = has( f, RANDOM ) }
end

local function perc( c, t )
	local p = c.lin and 1 - t / c.life or 1
	local m = c.mode
	if m == 1 then
		local q = t > c.parm and 1 - ( t - c.parm ) / math.max( c.life - c.parm, 1 ) or 1
		p = c.lin and ( p + q ) * 0.5 or q
	elseif m == 2 then
		p = p * math.cos( t * c.parm )
	elseif m == 3 then
		local q = t < c.parm and ( c.parm - t ) / math.max( c.parm, 1 ) or 0
		p = c.lin and ( p + q ) * 0.5 or q
	end
	return p
end

local function value( c, t )
	local p = perc( c, t )
	if c.rand then p = math.random() * p end
	return c.s * p + c.e * ( 1 - p )
end

local function settled( c ) return c.mode == 0 and not c.rand end

local function colors( blk, comp )
	local k = comp and math.random() or nil
	local function pick( v )
		if not v then return { 1, 1, 1 } end
		if #v < 6 then return { v[ 1 ], v[ 2 ] or v[ 1 ], v[ 3 ] or v[ 1 ] } end
		return { Lerp( k or math.random(), v[ 1 ], v[ 4 ] ), Lerp( k or math.random(), v[ 2 ], v[ 5 ] ), Lerp( k or math.random(), v[ 3 ], v[ 6 ] ) }
	end
	return pick( blk and blk.s ), pick( blk and blk.e )
end

local function newLook( p, mname, life )
	local c0, c1 = colors( p.rgb, has( p.sf, S_RGBCOMP ) )
	local additive = string.sub( mname, -2 ) ~= "_a"
	return { size = curve( p.size, life ), alpha = curve( p.alpha, life ), rgb = curve( p.rgb, life ), c0 = c0, c1 = c1,
		useAlpha = additive or has( p.f, F_USEALPHA ), additive = additive }
end

local function look( l, t )
	local ap = perc( l.alpha, t )
	local a = math.Clamp( l.alpha.s * ap + l.alpha.e * ( 1 - ap ), 0, 1 )
	if l.alpha.rand then a = math.random() * a end
	local p = perc( l.rgb, t )
	if l.rgb.rand then p = math.random() * p end
	local c0, c1 = l.c0, l.c1
	local r, g, b = c0[ 1 ] * p + c1[ 1 ] * ( 1 - p ), c0[ 2 ] * p + c1[ 2 ] * ( 1 - p ), c0[ 3 ] * p + c1[ 3 ] * ( 1 - p )
	if not l.useAlpha then r, g, b, a = r * a, g * a, b * a, 1 end
	return math.Clamp( r, 0, 1 ) * 255, math.Clamp( g, 0, 1 ) * 255, math.Clamp( b, 0, 1 ) * 255, a * 255
end

local function boltFrame( bolt )
	if not bolt or not IsValid( bolt.ent ) then return end
	local a = bolt.ent:GetAttachment( bolt.att )
	if not a then return end
	return a.Pos, a.Ang:Forward(), a.Ang:Right(), a.Ang:Up()
end

local function relativePos( rel, bolt, ts )
	local o, f, r, u = boltFrame( bolt )
	if not o then return end
	local lv, la = rel.lv, rel.la
	local x = rel.lo.x + ts * ( lv.x + ts * la.x )
	local y = rel.lo.y + ts * ( lv.y + ts * la.y )
	local z = rel.lo.z + ts * ( lv.z + ts * la.z )
	local back = -( f * ( lv.x + 2 * ts * la.x ) + r * ( lv.y + 2 * ts * la.y ) + u * ( lv.z + 2 * ts * la.z ) )
	if back:LengthSqr() < 1e-6 then back = -f else back:Normalize() end
	return o + f * x + r * y + u * z + Vector( 0, 0, 0.5 * rel.g * ts * ts ), back
end

local function spawnPoint( p, pos, f, r, u )
	local sf = p.sf or 0
	local org = pos
	if p.o then
		local v = rv( p.o )
		org = has( sf, S_CHEAPORG ) and org + v or org + f * v.x + r * v.y + u * v.z
	end
	local pf, pr, pu = f, r, u
	if has( sf, S_SPHERE ) then
		local x, y = math.random() * math.pi * 2, math.random() * math.pi
		local w, h = rr( p.rad, 1 ), rr( p.h, 1 )
		local d = Vector( math.sin( x ) * w * math.sin( y ), math.cos( x ) * w * math.sin( y ), math.cos( y ) * h )
		org = org + d
		if has( sf, S_AXISSPHERE ) and d:LengthSqr() > 1e-6 then
			pf = d:GetNormalized()
			pr, pu = normalAxes( pf )
		end
	elseif has( sf, S_CYLINDER ) then
		local a = math.random() * math.pi * 2
		local d = ( r * math.cos( a ) + u * math.sin( a ) ) * rr( p.rad, 1 ) + f * ( ( math.random() * 2 - 1 ) * 0.5 * rr( p.h, 1 ) )
		org = org + d
		if has( sf, S_AXISSPHERE ) and d:LengthSqr() > 1e-6 then
			pf = d:GetNormalized()
			local up = pf.z >= 0.999 and Vector( 0, 1, 0 ) or Vector( 0, 0, 1 )
			pr = up:Cross( pf )
			pr:Normalize()
			pu = pf:Cross( pr )
		end
	end
	return org, pf, pr, pu
end

local function motion( p, f, r, u )
	local sf = p.sf or 0
	local v, a = rv( p.v ), rv( p.a )
	local vel = has( sf, S_ABSVEL ) and v or f * v.x + r * v.y + u * v.z
	local acc = has( sf, S_ABSACCEL ) and a or f * a.x + r * a.y + u * a.z
	acc.z = acc.z + rr( p.g, 0 )
	return vel, acc
end

local function relative( p, bolt )
	if not bolt or not has( p.f, F_RELATIVE ) then return end
	return { lo = rv( p.o ), lv = rv( p.v ), la = rv( p.a ), g = rr( p.g, 0 ) }
end

local function nativeParticle( ctx, p, mname, org, f, vel, acc, life, bolt )
	local three = p.k == "o"
	local em = three and ctx:em3() or ctx:em()
	if not em then return end
	local rel = relative( p, bolt )
	if rel then org = relativePos( rel, bolt, 0 ) or org end
	local part = em:Add( mname, org )
	if not part then return end
	local l = newLook( p, mname, life )
	local lifeS = life / 1000
	part:SetDieTime( lifeS )
	part:SetVelocity( rel and vector_origin or vel )
	part:SetGravity( rel and vector_origin or acc )
	part:SetAirResistance( 0 )
	part:SetLighting( false )
	local sz = l.size
	part:SetStartSize( sz.s )
	part:SetEndSize( sz.lin and sz.e or sz.s )
	local r0, g0, b0, a0 = look( l, 0 )
	part:SetColor( r0, g0, b0 )
	part:SetStartAlpha( a0 )
	local fading = l.useAlpha
	if fading then
		local al = l.alpha
		part:SetEndAlpha( math.Clamp( al.lin and al.e or al.s, 0, 1 ) * 255 )
	else
		part:SetEndAlpha( 255 )
	end
	local rot = rr( p.rot, 0 )
	if three then
		local ang = f:Angle()
		ang:RotateAroundAxis( f, rot )
		part:SetAngles( ang )
	else
		part:SetRoll( math.rad( rot ) )
		if p.rd then part:SetRollDelta( math.rad( rr( p.rd ) ) * 10 ) end
	end
	local pf = p.f or 0
	if has( pf, F_PHYSICS ) then
		part:SetCollide( true )
		part:SetBounce( rr( p.b, 0 ) )
		if has( pf, F_IMPACTKILLS ) or has( pf, F_IMPACTFX ) and p.ifx then
			part:SetCollideCallback( function( pp, hit, normal )
				if has( pf, F_IMPACTFX ) and p.ifx then play( p.ifx[ math.random( #p.ifx ) ], hit, normal ) end
				if has( pf, F_IMPACTKILLS ) then pp:SetDieTime( 0 ) end
			end )
		end
	end
	local recolor = l.rgb.lin and ( l.c0[ 1 ] ~= l.c1[ 1 ] or l.c0[ 2 ] ~= l.c1[ 2 ] or l.c0[ 3 ] ~= l.c1[ 3 ] ) or not settled( l.rgb )
	local darken = not fading and ( l.alpha.lin or not settled( l.alpha ) )
	local resize, realpha = not settled( sz ), fading and not settled( l.alpha )
	local death = has( pf, F_DEATHFX ) and not has( pf, F_IMPACTKILLS ) and p.dfx
	if not ( recolor or darken or resize or realpha or death or rel ) then return end
	local born = CurTime()
	part:SetThinkFunction( function( pp )
		local ts = CurTime() - born
		local t = math.min( ts * 1000, life )
		if recolor or darken or realpha then
			local r, g, b, a = look( l, t )
			pp:SetColor( r, g, b )
			if realpha then pp:SetStartAlpha( a ) pp:SetEndAlpha( a ) end
		end
		if resize then
			local s = value( sz, t )
			pp:SetStartSize( s )
			pp:SetEndSize( s )
		end
		if rel then
			local pos = relativePos( rel, bolt, ts )
			if pos then pp:SetPos( pos ) end
		end
		if death and t >= life * 0.97 then
			death = nil
			play( p.dfx[ math.random( #p.dfx ) ], pp:GetPos(), VectorRand():GetNormalized() )
		end
		pp:SetNextThink( CurTime() )
	end )
	part:SetNextThink( CurTime() )
end

local function addItem( it )
	if #ITEMS >= MAX_ITEMS then return end
	it.born = CurTime()
	ITEMS[ #ITEMS + 1 ] = it
end

local function customParticle( p, mname, org, f, vel, acc, life, bolt )
	local l = newLook( p, mname, life )
	local kind = p.k == "t" and "tail" or "sprite"
	local rel = relative( p, bolt )
	local back
	if rel then org, back = relativePos( rel, bolt, 0 ) end
	if not org then return end
	local it = { kind = kind, m = mat( mname ), look = l, life = life, pos = org, vel = vel, acc = acc, flags = p.f or 0, p = p,
		roll = rr( p.rot, 0 ), spin = rr( p.rd, 0 ) * 10, vm = bolt and bolt.vm, bolt = bolt, rel = rel, bounce = rr( p.b, 0 ) }
	if p.nu then it.size2 = curve( p.size2, life ) end
	if kind == "tail" then
		it.len = curve( p.len, life )
		it.dir = back or vel:LengthSqr() > 1e-4 and -vel:GetNormalized() or -f
	end
	addItem( it )
end

local function cylinder( p, mname, org, f, r, u, life )
	addItem( { kind = "cyl", m = mat( mname ), look = newLook( p, mname, life ), life = life, pos = org, f = f, r = r, u = u, p = p,
		size2 = curve( p.size2, life ), len = curve( p.len, life ) } )
end

local function line( p, mname, org, base, f, r, u )
	local life = math.max( rr( p.life, 1 ), 1 )
	local v = rv( p.o2 )
	addItem( { kind = "beam", m = mat( mname ), look = newLook( p, mname, life ), life = life, pos = org,
		b = base + f * v.x + r * v.y + u * v.z } )
end

local function light( p, org )
	if quality() <= 0 or not GetConVar( "cod1_efx_lights" ):GetBool() then return end
	local life = math.max( rr( p.life, 1 ), 1 )
	local sz = curve( p.size, life )
	local s0 = sz.s
	local s1 = sz.lin and sz.e or s0
	if math.max( s0, s1 ) < 16 then return end
	local c0 = colors( p.rgb, has( p.sf, S_RGBCOMP ) )
	lightId = ( lightId + 1 ) % 512
	local dl = DynamicLight( 40000 + lightId )
	if not dl then return end
	dl.pos = org
	dl.r, dl.g, dl.b = math.Clamp( c0[ 1 ], 0, 1 ) * 255, math.Clamp( c0[ 2 ], 0, 1 ) * 255, math.Clamp( c0[ 3 ], 0, 1 ) * 255
	dl.brightness = 1
	dl.size = math.max( s0, s1 )
	dl.decay = s0 > s1 and ( s0 - s1 ) / ( life / 1000 ) or 0
	dl.dietime = CurTime() + life / 1000
end

local function decalFilter( e ) return not ( e:IsPlayer() or e:IsNPC() or e.IsCOD1Soldier ) end

local noDecals = false

local function decal( p, org, f )
	if noDecals then return end
	local list = p.m
	if not list or #list == 0 then return end
	local tr = util.TraceLine( { start = org + f * 8, endpos = org - f * 24, mask = MASK_SOLID, filter = decalFilter } )
	if not tr.Hit or tr.HitSky then return end
	local m = mat( list[ math.random( #list ) ] )
	local natural = math.max( m:Width(), 1 ) * 0.25
	local scale = 2 * rr( p.size and p.size.s, 1 ) / natural
	local c0 = colors( p.rgb, has( p.sf, S_RGBCOMP ) )
	local a = math.Clamp( rr( p.alpha and p.alpha.s, 1 ), 0, 1 )
	util.DecalEx( m, tr.Entity, tr.HitPos, tr.HitNormal, Color( math.Clamp( c0[ 1 ], 0, 1 ) * 255, math.Clamp( c0[ 2 ], 0, 1 ) * 255,
		math.Clamp( c0[ 3 ], 0, 1 ) * 255, a * 255 ), scale, scale )
end

local function stepDist( p )
	return math.abs( rr( p.dens, 10 ) + ( math.random() * 2 - 1 ) * rr( p.var, 1 ) )
end

local function emitter( p, org, f, vel, acc, depth )
	if #EMITTERS >= MAX_EMITTERS or depth >= 2 then return end
	local life = math.max( rr( p.life, 1 ), 1 )
	local base = f:Angle()
	local ang = p.ang and Angle( base.p + between( p.ang[ 1 ], p.ang[ 4 ] or p.ang[ 1 ] ), base.y + between( p.ang[ 2 ], p.ang[ 5 ] or p.ang[ 2 ] ),
		base.r + between( p.ang[ 3 ], p.ang[ 6 ] or p.ang[ 3 ] ) ) or base
	local spin = p.angd and Angle( between( p.angd[ 1 ], p.angd[ 4 ] or p.angd[ 1 ] ), between( p.angd[ 2 ], p.angd[ 5 ] or p.angd[ 2 ] ),
		between( p.angd[ 3 ], p.angd[ 6 ] or p.angd[ 3 ] ) ) * 10 or Angle()
	local e = { p = p, pos = org, last = org, vel = vel, acc = acc, born = CurTime(), life = life, die = CurTime() + life / 1000,
		ang = ang, spin = spin, size = curve( p.size, life ), depth = depth, phys = has( p.f, F_PHYSICS ), step = stepDist( p ) }
	if has( p.f, F_MODEL ) and p.mdl and #p.mdl > 0 then
		local m = ClientsideModel( p.mdl[ math.random( #p.mdl ) ], RENDERGROUP_OPAQUE )
		if IsValid( m ) then
			m:SetPos( org )
			m:SetAngles( ang )
			m:SetModelScale( math.max( e.size.s, 0.01 ) )
			e.model = m
		end
	end
	EMITTERS[ #EMITTERS + 1 ] = e
end

local Ctx = {}
Ctx.__index = Ctx
function Ctx:em()
	if not self._em then self._em = ParticleEmitter( self.pos, false ) end
	return self._em
end
function Ctx:em3()
	if not self._em3 then self._em3 = ParticleEmitter( self.pos, true ) end
	return self._em3
end
function Ctx:finish()
	if self._em then self._em:Finish() end
	if self._em3 then self._em3:Finish() end
end

local function spawn( ctx, p, pos, f, r, u, bolt, depth )
	local k = p.k
	if has( p.sf, S_RANDROT ) then
		local a = math.random() * math.pi * 2
		r = r * math.cos( a ) + u * math.sin( a )
		u = f:Cross( r )
	end
	local org, pf, pr, pu = spawnPoint( p, pos, f, r, u )
	if k == "p" or k == "t" or k == "o" or k == "c" then
		local list = p.m
		if not list or #list == 0 then return end
		local mname = list[ math.random( #list ) ]
		local life = math.max( rr( p.life, 1 ), 1 )
		if k == "c" then return cylinder( p, mname, org, pf, pr, pu, life ) end
		local vel, acc = motion( p, pf, pr, pu )
		if k == "t" or p.nu or k == "p" and bolt and bolt.vm then
			customParticle( p, mname, org, pf, vel, acc, life, bolt )
		else
			nativeParticle( ctx, p, mname, org, pf, vel, acc, life, bolt )
		end
	elseif k == "l" then
		light( p, org )
	elseif k == "ln" then
		if p.m and #p.m > 0 then line( p, p.m[ math.random( #p.m ) ], org, pos, f, r, u ) end
	elseif k == "d" then
		decal( p, org, f )
	elseif k == "s" then
		if p.snd and #p.snd > 0 and not string.find( p.snd[ 1 ], "null", 1, true ) then
			sound.Play( p.snd[ math.random( #p.snd ) ], org, 75, math.random( 95, 105 ), 1 )
		end
	elseif k == "r" then
		if depth < 4 and p.fx and #p.fx > 0 then play( p.fx[ math.random( #p.fx ) ], org, pf, pr, pu, nil, depth + 1 ) end
	elseif k == "e" then
		local vel, acc = motion( p, pf, pr, pu )
		emitter( p, org, pf, vel, acc, depth )
	end
end

local function playAxes( name, pos, f, r, u, bolt, depth )
	local fx = EFX[ name ]
	if not fx or not pos then return end
	local q = quality()
	local reach = q >= 2 and 4 or q >= 1 and 2 or 1
	local dist = COD1.ViewPos():DistToSqr( pos )
	for _, p in ipairs( fx ) do
		local cull = p.cull and p.cull[ 1 ] or 0
		if cull <= 0 or dist <= ( cull * reach ) ^ 2 then
			local n = math.Round( rr( p.n, 1 ) )
			if p.k == "p" or p.k == "t" or p.k == "o" then
				n = q <= 0 and math.min( n, 1 ) or q >= 2 and n > 1 and math.Round( n * 1.6 ) or n
			end
			local even = has( p.sf, S_EVEN ) and p.delay and math.abs( p.delay[ 2 ] - p.delay[ 1 ] ) / math.max( n, 1 )
			local ctx
			for i = 1, n do
				local d = even and ( i - 1 ) * even or rr( p.delay, 0 )
				if d < 1 then
					ctx = ctx or setmetatable( { pos = pos }, Ctx )
					spawn( ctx, p, pos, f, r, u, bolt, depth )
				else
					timer.Simple( d / 1000, function()
						local bp, bf, br, bu = pos, f, r, u
						if bolt then
							local o, af, ar, au = boltFrame( bolt )
							if not o then return end
							bp, bf, br, bu = o, af, -ar, au
						end
						local c = setmetatable( { pos = bp }, Ctx )
						spawn( c, p, bp, bf, br, bu, bolt, depth )
						c:finish()
					end )
				end
			end
			if ctx then ctx:finish() end
		end
	end
end

play = function( name, pos, f, r, u, bolt, depth )
	if not r then
		f = ( f or Vector( 0, 0, 1 ) ):GetNormalized()
		if f:LengthSqr() < 0.5 then f = Vector( 0, 0, 1 ) end
		r, u = normalAxes( f )
	end
	playAxes( name, pos, f, r, u, bolt, depth or 0 )
end

function COD1.PlayEFX( name, pos, dir, ent, att )
	noDecals = string.StartWith( name, "impacts/" ) and not string.find( name, "mortar", 1, true )
	if IsValid( ent ) and att and att > 0 then
		local a = ent:GetAttachment( att )
		if a then
			local lp = LocalPlayer()
			local bolt = { ent = ent, att = att, vm = IsValid( lp ) and ent == lp:GetViewModel() }
			play( name, a.Pos, a.Ang:Forward(), -a.Ang:Right(), a.Ang:Up(), bolt, 0 )
			noDecals = false
			return
		end
	end
	play( name, pos, dir )
	noDecals = false
end

local function updateItem( it, now, dt )
	local ts = now - it.born
	if it.rel then
		local pos, back = relativePos( it.rel, it.bolt, ts )
		if not pos then return false end
		if it.kind == "tail" then it.dir = back end
		it.pos = pos
		return true
	end
	if not it.vel or it.rest then return true end
	it.vel = it.vel + it.acc * dt
	local old = it.pos
	local new = old + it.vel * dt
	if has( it.flags, F_PHYSICS ) then
		local tr = util.TraceLine( { start = old, endpos = new, mask = MASK_SOLID_BRUSHONLY } )
		if tr.Hit and not tr.StartSolid then
			local p = it.p
			if has( it.flags, F_IMPACTFX ) and p.ifx then play( p.ifx[ math.random( #p.ifx ) ], tr.HitPos, tr.HitNormal ) end
			if has( it.flags, F_IMPACTKILLS ) then return false end
			local n = tr.HitNormal
			it.vel = ( it.vel - 2 * it.vel:Dot( n ) * n ) * it.bounce
			new = tr.HitPos + n * 0.1
			if n.z > 0 and it.vel.z < 4 then it.rest = true end
		end
	end
	if it.kind == "tail" and new ~= old then it.dir = ( old - new ):GetNormalized() end
	it.pos = new
	return true
end

local function drawItem( it, now, eye )
	local t = math.min( ( now - it.born ) * 1000, it.life )
	local l = it.look
	local r, g, b, a = look( l, t )
	if a <= 0 or r + g + b <= 0 and l.additive then return end
	COL.r, COL.g, COL.b, COL.a = r, g, b, a
	render.SetMaterial( it.m )
	local kind = it.kind
	if kind == "sprite" then
		local w = 2 * value( l.size, t )
		local h = it.size2 and 2 * value( it.size2, t ) or w
		local n = eye - it.pos
		n:Normalize()
		render.DrawQuadEasy( it.pos, n, w, h, COL, it.roll + it.spin * ( now - it.born ) )
	elseif kind == "tail" then
		render.DrawBeam( it.pos, it.pos + it.dir * value( it.len, t ), 2 * value( l.size, t ), 0, 1, COL )
	elseif kind == "beam" then
		render.DrawBeam( it.pos, it.b, 2 * value( l.size, t ), 0, 1, COL )
	elseif kind == "cyl" then
		local r0, r1, len = value( l.size, t ), value( it.size2, t ), value( it.len, t )
		local top = it.pos + it.f * len
		mesh.Begin( MATERIAL_QUADS, CYL_SEGMENTS )
		for i = 0, CYL_SEGMENTS - 1 do
			local a0, a1 = i / CYL_SEGMENTS * math.pi * 2, ( i + 1 ) / CYL_SEGMENTS * math.pi * 2
			local d0 = it.r * math.cos( a0 ) + it.u * math.sin( a0 )
			local d1 = it.r * math.cos( a1 ) + it.u * math.sin( a1 )
			local u0, u1 = i / CYL_SEGMENTS, ( i + 1 ) / CYL_SEGMENTS
			mesh.Position( it.pos + d0 * r0 ) mesh.TexCoord( 0, u0, 1 ) mesh.Color( r, g, b, a ) mesh.AdvanceVertex()
			mesh.Position( top + d0 * r1 ) mesh.TexCoord( 0, u0, 0 ) mesh.Color( r, g, b, a ) mesh.AdvanceVertex()
			mesh.Position( top + d1 * r1 ) mesh.TexCoord( 0, u1, 0 ) mesh.Color( r, g, b, a ) mesh.AdvanceVertex()
			mesh.Position( it.pos + d1 * r0 ) mesh.TexCoord( 0, u1, 1 ) mesh.Color( r, g, b, a ) mesh.AdvanceVertex()
		end
		mesh.End()
	end
end

local function emitterAxes( e )
	return e.ang:Forward(), -e.ang:Right(), e.ang:Up()
end

hook.Add( "Think", "COD1EFX", function()
	local now = CurTime()
	local dt = math.min( FrameTime(), 0.1 )
	for i = #ITEMS, 1, -1 do
		local it = ITEMS[ i ]
		local alive = ( now - it.born ) * 1000 < it.life and updateItem( it, now, dt )
		if not alive then
			local p = it.p
			if p and has( p.f, F_DEATHFX ) and not has( p.f, F_IMPACTKILLS ) and p.dfx then
				play( p.dfx[ math.random( #p.dfx ) ], it.pos, VectorRand():GetNormalized() )
			end
			table.remove( ITEMS, i )
		end
	end
	if #EMITTERS == 0 then return end
	local rate = quality() >= 2 and 0.015 or 0.03
	for i = #EMITTERS, 1, -1 do
		local e = EMITTERS[ i ]
		local p = e.p
		local dead = now >= e.die
		local killed = false
		if not dead and not e.rest then
			e.vel = e.vel + e.acc * dt
			local old = e.pos
			local new = old + e.vel * dt
			if e.phys then
				local tr = util.TraceLine( { start = old, endpos = new, mask = MASK_SOLID_BRUSHONLY } )
				if tr.Hit and not tr.StartSolid then
					if has( p.f, F_IMPACTFX ) and p.ifx and not e.impacted then
						e.impacted = true
						play( p.ifx[ math.random( #p.ifx ) ], tr.HitPos, tr.HitNormal, nil, nil, nil, e.depth + 1 )
					end
					if has( p.f, F_IMPACTKILLS ) then
						dead, killed = true, true
					else
						local n = tr.HitNormal
						e.vel = ( e.vel - 2 * e.vel:Dot( n ) * n ) * rr( p.b, 0 )
						new = tr.HitPos + n * 0.5
						if n.z > 0 and e.vel.z < 4 then
							e.rest = true
							e.phys = false
						end
					end
				end
			end
			e.pos = new
		end
		if e.rest then e.spin = e.spin * 0.7 end
		e.ang = e.ang + e.spin * dt
		if IsValid( e.model ) then
			e.model:SetPos( e.pos )
			e.model:SetAngles( e.ang )
			if not settled( e.size ) or e.size.lin then e.model:SetModelScale( math.max( value( e.size, ( now - e.born ) * 1000 ), 0.01 ) ) end
		end
		if not dead and has( p.f, F_EMITFX ) and p.fx and #p.fx > 0 and now >= ( e.nextEmit or 0 ) and e.pos:DistToSqr( e.last ) >= e.step * e.step then
			e.last = e.pos
			e.step = stepDist( p )
			e.nextEmit = now + rate
			local f, r, u = emitterAxes( e )
			play( p.fx[ math.random( #p.fx ) ], e.pos, f, r, u, nil, e.depth + 1 )
		end
		if dead then
			if not killed and has( p.f, F_DEATHFX ) and p.dfx then play( p.dfx[ math.random( #p.dfx ) ], e.pos, VectorRand():GetNormalized() ) end
			if IsValid( e.model ) then e.model:Remove() end
			table.remove( EMITTERS, i )
		end
	end
end )

hook.Add( "PostDrawTranslucentRenderables", "COD1EFX", function( depth, sky )
	if depth or sky or #ITEMS == 0 then return end
	local now, eye = CurTime(), EyePos()
	for _, it in ipairs( ITEMS ) do
		if not it.vm then drawItem( it, now, eye ) end
	end
end )

local vmFrame
hook.Add( "PostDrawViewModel", "COD1EFX", function()
	if #ITEMS == 0 or vmFrame == FrameNumber() then return end
	vmFrame = FrameNumber()
	local now, eye = CurTime(), EyePos()
	for _, it in ipairs( ITEMS ) do
		if it.vm then drawItem( it, now, eye ) end
	end
end )

--more smoke = more better
