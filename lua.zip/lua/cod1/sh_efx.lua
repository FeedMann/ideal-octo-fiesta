COD1.EFXNames = table.GetKeys( COD1.EFX or {} )
table.sort( COD1.EFXNames )
COD1.EFXIndex = {}
for i, n in ipairs( COD1.EFXNames ) do COD1.EFXIndex[ n ] = i end

CreateConVar( "cod1_efx_quality", "2", { FCVAR_ARCHIVE }, "Call of Duty effects: 0 = few particles, 1 = like Call of Duty, 2 = extra dense" )

COD1.WeaponFX = {
	thompson = { "muzzleflashes/thompson", "muzzleflashes/thompson_view", "shellejects/pistol" },
	garand = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/rifle" },
	carbine = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/rifle" },
	bar = { "muzzleflashes/heavy", "muzzleflashes/heavy_view", "shellejects/rifle" },
	colt = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/pistol" },
	springfield = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/rifle" },
	enfield = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/rifle" },
	sten = { "muzzleflashes/german_mg", "muzzleflashes/german_mg_view", "shellejects/pistol" },
	bren = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/rifle" },
	mosin = { "muzzleflashes/german_mg", "muzzleflashes/german_mg_view", "shellejects/rifle" },
	mosin_sniper = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/rifle" },
	ppsh = { "muzzleflashes/russian_mg", "muzzleflashes/russian_mg_view", "shellejects/pistol" },
	kar98 = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/rifle" },
	kar98_sniper = { "muzzleflashes/standardflashworld_sniper", "muzzleflashes/standardflashview", "shellejects/rifle" },
	mp40 = { "muzzleflashes/heavy", "muzzleflashes/heavy_view", "shellejects/pistol" },
	mp44 = { "muzzleflashes/heavy", "muzzleflashes/heavy_view", "shellejects/rifle" },
	fg42 = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/rifle" },
	luger = { "muzzleflashes/standardflashworld", "muzzleflashes/standardflashview", "shellejects/pistol" },
	mg42 = { "muzzleflashes/mg42hv", "muzzleflashes/mg42hv_view2" },
	b30cal = { "muzzleflashes/mg42hv", "muzzleflashes/mg42hv_view" },
	g43 = { "weapon/muzzleflash/mf_gewehr43", "weapon/muzzleflash/mf_gewehr43_v", "shellejects/rifle" },
	svt40 = { "weapon/muzzleflash/mf_svt40", "weapon/muzzleflash/mf_svt40_v", "shellejects/rifle" },
	mg34 = { "weapon/muzzleflash/mf_mg34", "weapon/muzzleflash/mf_mg34_v", "shellejects/rifle" },
	dp28 = { "weapon/muzzleflash/mf_dp28", "weapon/muzzleflash/mf_dp28_v", "shellejects/rifle" },
	mg30cal = { "weapon/muzzleflash/mf_30cal", "weapon/muzzleflash/mf_30cal_v", "shellejects/rifle" },
	tt33 = { "weapon/muzzleflash/mf_tt33", "weapon/muzzleflash/mf_tt33_v", "shellejects/pistol" },
	webley = { "weapon/muzzleflash/mf_webley", "weapon/muzzleflash/mf_webley_v" },
	stensd = { "weapon/muzzleflash/mf_sten_silenced", "weapon/muzzleflash/mf_sten_silenced_v", "shellejects/pistol" },
	pschreck = { "weapon/muzzleflash/mf_panzerschreck", "weapon/muzzleflash/mf_panzerschreck_v" },
	bazooka = { "weapon/muzzleflash/mf_bazooka", "weapon/muzzleflash/mf_bazooka_v" },
	pfaust = { "muzzleflashes/panzerfaust", "muzzleflashes/panzerfaust" },
}
COD1.SWEPFXKey = { m1garand = "garand", m1carbine = "carbine", mosin_nagant = "mosin", mosin_nagant_sniper = "mosin_sniper",
	kar98k = "kar98", kar98k_sniper = "kar98_sniper" }
COD1.WeaponFXKeys = table.GetKeys( COD1.WeaponFX )
table.sort( COD1.WeaponFXKeys )
COD1.WeaponFXIndex = {}
for i, k in ipairs( COD1.WeaponFXKeys ) do COD1.WeaponFXIndex[ k ] = i end

if CLIENT then
	CreateClientConVar( "cod1_efx_lights", "1", true, false, "Muzzle flashes and explosions light up their surroundings" )
	CreateClientConVar( "cod1_efx_impacts", "1", true, false, "Bullet impacts: 1 = Call of Duty, 2 = Garry's Mod, 0 = off" )
end

COD1.RifleBullet = { garand = true, carbine = true, bar = true, springfield = true, enfield = true, bren = true, mosin = true, mosin_sniper = true,
	kar98 = true, kar98_sniper = true, mp44 = true, fg42 = true, mg42 = true, b30cal = true, g43 = true, svt40 = true, mg34 = true, dp28 = true,
	mg30cal = true }

local SMALL = { default = "default_hit", bark = "default_hit", brick = "small_brick", carpet = "default_hit", cloth = "default_hit",
	concrete = "small_concrete", dirt = "small_gravel2", foliage = "small_foliage", glass = "small_glass", grass = "small_grass", gravel = "small_gravel",
	ice = "snowhit_small", metal = "metalhit_small", mud = "default_hit", paper = "default_hit", plaster = "small_concrete", rock = "small_rock",
	sand = "small_gravel", snow = "snowhit_small", water = "waterhit_small", wood = "woodhit_small", asphalt = "small_concrete" }
local LARGE = { default = "default_hit", bark = "default_hit", brick = "large_brick", carpet = "default_hit", cloth = "default_hit",
	concrete = "large_plaster", dirt = "large_gravel2", foliage = "small_foliage", glass = "large_glass", grass = "default_hit", gravel = "large_gravel",
	ice = "snowhit_small", metal = "metalhit_large", mud = "default_hit", paper = "default_hit", plaster = "large_plaster", rock = "large_rock",
	sand = "default_hit", snow = "snowhit_large", water = "waterhit_large", wood = "woodhit_small", asphalt = "large_rock" }
local GRENADE = { default = "explosions/grenade2", bark = "explosions/grenade1", brick = "explosions/grenade2", carpet = "explosions/grenade1",
	cloth = "explosions/grenade2", concrete = "explosions/grenade2", dirt = "explosions/grenade2", foliage = "explosions/grenade1",
	glass = "explosions/grenade1", grass = "explosions/grenade1", gravel = "explosions/grenade2", ice = "explosions/grenade1",
	metal = "explosions/grenade1", mud = "explosions/grenade1", paper = "explosions/grenade1", plaster = "explosions/grenade2",
	rock = "explosions/grenade2", sand = "explosions/grenade1", snow = "impacts/snow_mortarlite", water = "explosions/grenade_water",
	wood = "explosions/grenade2", asphalt = "explosions/grenade3" }

local PROP_SURFACE = { brick = "brick", plaster = "plaster", gravel = "gravel", rock = "rock", boulder = "rock", dirt = "dirt", grass = "grass",
	sand = "sand", mud = "mud", quicksand = "mud", snow = "snow", ice = "ice", concrete = "concrete", concrete_block = "concrete", tile = "concrete",
	asphalt = "asphalt", glass = "glass", glassbottle = "glass", wood = "wood", metal = "metal", carpet = "carpet", paper = "paper",
	cardboard = "paper", papercup = "paper", foliage = "foliage", cloth = "cloth", water = "water", wade = "water", slosh = "mud" }
local PREFIX = { { "metal", "metal" }, { "wood", "wood" }, { "concrete", "concrete" }, { "glass", "glass" }, { "rock", "rock" },
	{ "brick", "brick" }, { "dirt", "dirt" }, { "chainlink", "metal" }, { "computer", "metal" }, { "canister", "metal" }, { "popcan", "metal" } }
local MAT_SURFACE = { [ MAT_CONCRETE ] = "concrete", [ MAT_TILE ] = "concrete", [ MAT_DIRT ] = "dirt", [ MAT_SAND ] = "sand", [ MAT_SLOSH ] = "mud",
	[ MAT_GRASS ] = "grass", [ MAT_SNOW ] = "snow", [ MAT_WOOD ] = "wood", [ MAT_METAL ] = "metal", [ MAT_VENT ] = "metal", [ MAT_GRATE ] = "metal",
	[ MAT_COMPUTER ] = "metal", [ MAT_GLASS ] = "glass", [ MAT_FOLIAGE ] = "foliage", [ MAT_PLASTIC ] = "default", [ MAT_DEFAULT ] = "default" }
local SKIP_IMPACT = { [ MAT_FLESH ] = true, [ MAT_BLOODYFLESH ] = true, [ MAT_ALIENFLESH ] = true, [ MAT_ANTLION ] = true }

function COD1.SurfaceType( tr )
	local name = tr.SurfaceProps and util.GetSurfacePropName( tr.SurfaceProps )
	if name and name ~= "" then
		name = string.lower( name )
		if PROP_SURFACE[ name ] then return PROP_SURFACE[ name ] end
		for _, p in ipairs( PREFIX ) do
			if string.StartWith( name, p[ 1 ] ) then return p[ 2 ] end
		end
	end
	return MAT_SURFACE[ tr.MatType ] or "default"
end

local function waterSurface( tr )
	if not tr.StartPos then return end
	local w = util.TraceLine( { start = tr.StartPos, endpos = tr.HitPos, mask = MASK_WATER } )
	if w.Hit and not w.StartSolid then return w.HitPos end
end

function COD1.ImpactFX( tr, large )
	if not tr.Hit or tr.HitSky or SKIP_IMPACT[ tr.MatType ] then return end
	local e = tr.Entity
	if IsValid( e ) and ( e:IsPlayer() or e:IsNPC() or e.IsCOD1Soldier ) then return end
	return "impacts/" .. ( large and LARGE or SMALL )[ COD1.SurfaceType( tr ) ]
end

local BLAST = { default = "generic", bark = "wood", carpet = "cloth", paper = "cloth", foliage = "grass", rock = "gravel" }

function COD1.ExplosionFX( kind, tr, wet )
	local surf = wet and "water" or tr.Hit and COD1.SurfaceType( tr ) or "default"
	local name = "weapon/explosions/" .. kind .. "_" .. ( BLAST[ surf ] or surf )
	if COD1.EFXIndex[ name ] then return name end
	return "weapon/explosions/" .. kind .. "_generic"
end

function COD1.GrenadeFX( tr, wet )
	if wet then return GRENADE.water end
	if not tr.Hit then return GRENADE.default end
	return GRENADE[ COD1.SurfaceType( tr ) ] or GRENADE.default
end

if SERVER then util.AddNetworkString( "COD1FX" ) end

local function engineImpact( pos, dir )
	local tr = util.TraceLine( { start = pos + dir * 4, endpos = pos - dir * 4, mask = MASK_SHOT } )
	if not tr.Hit then return end
	local ed = EffectData()
	ed:SetOrigin( tr.HitPos )
	ed:SetStart( pos + dir * 32 )
	ed:SetSurfaceProp( tr.SurfaceProps or 0 )
	ed:SetDamageType( DMG_BULLET )
	ed:SetHitBox( tr.HitBox or 0 )
	ed:SetEntity( tr.Entity )
	util.Effect( "Impact", ed )
end

local function playLocal( name, pos, dir, ent, att )
	if not COD1.PlayEFX then return end
	if string.StartWith( name, "impacts/" ) then
		local mode = GetConVar( "cod1_efx_impacts" ):GetInt()
		if mode == 0 then return end
		if mode == 2 then return engineImpact( pos, dir ) end
	end
	COD1.PlayEFX( name, pos, dir, IsValid( ent ) and ent or nil, att and att > 0 and att or nil )
end

function COD1.FX( name, pos, dir, ent, att, predicted )
	if not COD1.EFXIndex[ name ] then return end
	pos = pos or vector_origin
	dir = dir or Vector( 0, 0, 1 )
	if CLIENT then
		if not predicted or IsFirstTimePredicted() then playLocal( name, pos, dir, ent, att ) end
		return
	end
	net.Start( "COD1FX", true )
	net.WriteString( name )
	net.WriteVector( pos )
	net.WriteNormal( dir:GetNormalized() )
	net.WriteEntity( IsValid( ent ) and ent or NULL )
	net.WriteUInt( att or 0, 8 )
	local owner = predicted and not game.SinglePlayer() and GetPredictionPlayer()
	local rf = RecipientFilter()
	rf:AddPVS( pos )
	if IsValid( owner ) then rf:RemovePlayer( owner ) end
	net.Send( rf )
end

if CLIENT then
	net.Receive( "COD1FX", function()
		local name = net.ReadString()
		local pos, dir = net.ReadVector(), net.ReadNormal()
		local ent, att = net.ReadEntity(), net.ReadUInt( 8 )
		playLocal( name, pos, dir, ent, att )
	end )
end

local NO_ENGINE_FX = { effects = false }
local HOLE = { metal = "Impact.Metal", wood = "Impact.Wood", glass = "Impact.Glass", dirt = "Impact.Sand", sand = "Impact.Sand", mud = "Impact.Sand",
	grass = "Impact.Sand", snow = "Impact.Sand", ice = "Impact.Glass", foliage = false, water = false, cloth = false, carpet = false, paper = false }

function COD1.BulletImpactFX( tr, key, predicted, silent )
	local e = tr.Entity
	local living = IsValid( e ) and ( e:IsPlayer() or e:IsNPC() or e:IsNextBot() or e.IsCOD1Soldier )
	if living then return end
	if not silent then
		COD1.PlayBulletImpact( tr, key, predicted )
		if tr.Hit and not tr.HitSky and not waterSurface( tr ) then
			local hole = HOLE[ COD1.SurfaceType( tr ) ]
			if hole ~= false then util.Decal( hole or "Impact.Concrete", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal ) end
		end
	end
	return NO_ENGINE_FX
end

function COD1.PlayBulletImpact( tr, key, predicted )
	local large = COD1.RifleBullet[ key or "" ]
	local water = waterSurface( tr )
	if water then return COD1.FX( large and "impacts/waterhit_large" or "impacts/waterhit_small", water, Vector( 0, 0, 1 ), nil, nil, predicted ) end
	local name = COD1.ImpactFX( tr, large )
	if name then COD1.FX( name, tr.HitPos, tr.HitNormal, nil, nil, predicted ) end
end

local FX_SPAWN = {
	{ "fire_small", "Fire (small)", "fire/firesmall", 0.3 }, { "fire_medium", "Fire (medium)", "fire/medfire", 0.3 },
	{ "fire_inferno", "Fire (inferno)", "fire/inferno_medium", 0.35 }, { "fire_barrel", "Barrel fire", "fire/barrelfire", 0.3 },
	{ "fire_bonfire", "Bonfire", "fire/smallbon", 0.3 }, { "fire_tank", "Burning tank", "fire/tank_burn", 0.35 },
	{ "fire_window", "Window fire", "fire/smallfirewindow", 0.3 }, { "fire_stalingrad", "Stalingrad blaze", "fire/extreme_stalingrad", 0.4 },
	{ "fire_distant", "Distant fire", "fire/distantfire", 0.5 }, { "smoke_black", "Black smoke column", "smoke/blacksmoke2", 1.5 },
	{ "smoke_fire", "Fire smoke column", "smoke/firesmoke_col", 1.2 }, { "smoke_white", "White smoke", "smoke/whitesmoke", 1.2 },
	{ "smoke_chimney", "Chimney smoke", "smoke/chimneysmoke", 1.2 }, { "smoke_crater", "Smoking crater", "smoke/cratersmoke", 1.5 },
	{ "smoke_drifting", "Drifting ground smoke", "smoke/low_drifting1", 2 }, { "smoke_huge", "Huge smoke plume", "smoke/gigantor", 3 },
	{ "smoke_ash", "Falling ash", "smoke/ash_smoke", 1.5 }, { "smoke_linger", "Lingering battle smoke", "smoke/linger_smoke", 2.5 },
	{ "water_froth", "Water froth", "water/froth", 1 }, { "misc_sparks", "Sparking wires", "misc/sparker", 0.8 },
}
for _, f in ipairs( FX_SPAWN ) do
	list.Set( "SpawnableEntities", "cod1_fx_" .. f[ 1 ], { PrintName = f[ 2 ], ClassName = "cod1_fx", Category = "Call of Duty 1: Effects",
		KeyValues = { cod1_fx = f[ 3 ], cod1_fx_rate = tostring( f[ 4 ] ) } } )
end
list.Set( "ContentCategoryIcons", "Call of Duty 1: Effects", "cod1/ui/star16.png" )

if SERVER then
	util.AddNetworkString( "COD1Burn" )
	COD1.Burning = COD1.Burning or {}

	local function send( ent, untilT )
		net.Start( "COD1Burn" )
		net.WriteEntity( ent )
		net.WriteFloat( untilT )
		net.Broadcast()
	end

	function COD1.Burn( ent, time, attacker )
		if not IsValid( ent ) or ent:WaterLevel() >= 2 then return end
		local b = COD1.Burning[ ent ]
		local untilT = CurTime() + time
		if b then
			if IsValid( attacker ) then b.attacker = attacker end
			if untilT <= b.untilT then return end
			b.untilT = untilT
			if untilT - b.sent < 0.5 then return end
		else
			b = { untilT = untilT, attacker = attacker, nextPain = CurTime() + math.Rand( 0, 0.5 ) }
			COD1.Burning[ ent ] = b
		end
		b.sent = untilT
		send( ent, untilT )
	end

	function COD1.Extinguish( ent )
		if not COD1.Burning[ ent ] then return end
		COD1.Burning[ ent ] = nil
		if IsValid( ent ) then send( ent, 0 ) end
	end

	hook.Add( "Think", "COD1Burn", function()
		local now = CurTime()
		for ent, b in pairs( COD1.Burning ) do
			if not IsValid( ent ) or now > b.untilT then
				COD1.Burning[ ent ] = nil
			elseif ent:WaterLevel() >= 2 or ( ent:IsPlayer() and not ent:Alive() ) then
				COD1.Extinguish( ent )
			elseif now >= b.nextPain and ent:Health() > 0 then
				b.nextPain = now + math.Rand( 0.5, 1 )
				local dmg = DamageInfo()
				dmg:SetDamage( math.random( 2, 9 ) )
				dmg:SetDamageType( DMG_BURN )
				dmg:SetAttacker( IsValid( b.attacker ) and b.attacker or game.GetWorld() )
				dmg:SetInflictor( IsValid( b.attacker ) and b.attacker or game.GetWorld() )
				dmg:SetDamagePosition( ent:WorldSpaceCenter() )
				ent:TakeDamageInfo( dmg )
			end
		end
	end )

	hook.Add( "CreateEntityRagdoll", "COD1Burn", function( owner, rag )
		local b = COD1.Burning[ owner ]
		if b then COD1.Burn( rag, math.max( b.untilT - CurTime(), 0 ) + 2 ) end
	end )

	hook.Add( "PlayerSpawn", "COD1Burn", function( ply ) COD1.Extinguish( ply ) end )
else
	local burning, bones, loops = {}, {}, {}

	net.Receive( "COD1Burn", function()
		local ent, untilT = net.ReadEntity(), net.ReadFloat()
		if not IsValid( ent ) then return end
		local b = burning[ ent ]
		if untilT <= 0 then
			if b then b.untilT = math.min( b.untilT, CurTime() ) end
			return
		end
		if b then b.untilT = untilT else burning[ ent ] = { untilT = untilT, nextFx = 0 } end
	end )

	local function bodyBones( ent )
		local mdl = ent:GetModel() or ""
		local list = bones[ mdl ]
		if list then return list end
		list = {}
		for i = 0, ent:GetBoneCount() - 1 do
			local n = string.lower( ent:GetBoneName( i ) or "" )
			if ( n:find( "bip01", 1, true ) ) and not n:find( "finger", 1, true ) and not n:find( "toe", 1, true ) and not n:find( "nub", 1, true ) then
				list[ #list + 1 ] = i
			end
		end
		bones[ mdl ] = list
		return list
	end

	local function firePoint( ent, rising )
		local list = not ( ent == LocalPlayer() and not ent:ShouldDrawLocalPlayer() ) and bodyBones( ent ) or {}
		if #list > 0 then
			local p = ent:GetBonePosition( list[ math.random( #list ) ] )
			if p and p ~= ent:GetPos() then return p + VectorRand() * 5 end
		end
		local lo, hi = ent:OBBMins(), ent:OBBMaxs()
		local z0 = rising and lo.z + ( hi.z - lo.z ) * 0.22 or lo.z
		return ent:LocalToWorld( Vector( math.Rand( lo.x, hi.x ) * 0.8, math.Rand( lo.y, hi.y ) * 0.8, math.Rand( z0, hi.z * 0.95 ) ) )
	end

	hook.Add( "Think", "COD1Burn", function()
		local now = CurTime()
		for ent, b in pairs( burning ) do
			local over = now - b.untilT
			if not IsValid( ent ) or over > 1 then
				if loops[ ent ] then loops[ ent ]:Stop() loops[ ent ] = nil end
				burning[ ent ] = nil
			else
				if not loops[ ent ] then
					loops[ ent ] = CreateSound( ent, "cod1/cine/fire_loop.wav" )
					loops[ ent ]:SetSoundLevel( 70 )
					loops[ ent ]:PlayEx( 0.55, 100 )
				end
				if over > 0 then loops[ ent ]:ChangeVolume( 0.55 * ( 1 - over ), 0 ) end
				if now >= b.nextFx then
					b.nextFx = now + ( over > 0 and 0.1 + over * 0.4 or 0.1 )
					COD1.PlayEFX( "fire/fire_trail_25", firePoint( ent, over > 0 ), Vector( 0, 0, 1 ) )
					if over <= 0 and GetConVar( "cod1_efx_lights" ):GetBool() then
						local d = DynamicLight( ent:EntIndex() + 4096 )
						if d then
							d.pos = ent:WorldSpaceCenter()
							d.r, d.g, d.b = 255, 130, 40
							d.brightness = math.Rand( 1.2, 2 )
							d.size = 180
							d.decay = 600
							d.dietime = now + 0.2
						end
					end
				end
			end
		end
	end )
end

--effects setup, the fun part
