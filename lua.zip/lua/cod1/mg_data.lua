COD1.MGGunner = {
	mg42s = { yaw = 45, feet = Vector( -11.9, 6.0, -47.5 ) },
	mg42p = { yaw = 40, feet = Vector( -13.0, 5.2, -10.6 ) },
	b30s = { yaw = 45, feet = Vector( -16.6, -1.1, -36.5 ) },
}

--mg gunner offsets, took ages to line them up
