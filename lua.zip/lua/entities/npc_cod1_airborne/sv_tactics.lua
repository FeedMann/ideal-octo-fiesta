local U = COD1.AI
local flat, groundAt, hullClear = U.flat, U.groundAt, U.hullClear

COD1.Intel = COD1.Intel or { allies = {}, axis = {} }
COD1.Losses = COD1.Losses or { allies = {}, axis = {} }

local INTEL_LIFE = 45
local BAD_RADIUS = 96

local function note( team, enemy, pos )
	local t = COD1.Intel[ team ]
	if t then t[ enemy ] = { pos = pos, t = CurTime() } end
end

function COD1.NoteContact( team, enemy, pos )
	if IsValid( enemy ) then note( team, enemy, pos or enemy:GetPos() ) end
end

local baseUpdate = ENT.UpdateEnemy
function ENT:UpdateEnemy()
	local e = baseUpdate( self )
	if IsValid( e ) and self.LastSeen == CurTime() then note( self.COD1Team, e, e:GetPos() ) end
	return e
end

local baseHear = ENT.HearShot
function ENT:HearShot( shooter, src, dir )
	baseHear( self, shooter, src, dir )
	if IsValid( shooter ) and self:IsHostileTo( shooter ) then note( self.COD1Team, shooter, self.HeardAt or src ) end
end

hook.Add( "OnNPCKilled", "COD1Losses", function( npc )
	if not IsValid( npc ) or not npc.IsCOD1Soldier then return end
	local l = COD1.Losses[ npc.COD1Team ]
	if l then table.insert( l, { pos = npc:GetPos(), t = CurTime() } ) end
	for _, list in pairs( COD1.Intel ) do list[ npc ] = nil end
end )

function ENT:IsBadSpot( p )
	local list = self.BadSpots
	if not list then return false end
	local now = CurTime()
	for i = #list, 1, -1 do
		local b = list[ i ]
		if now > b.t then
			table.remove( list, i )
		elseif b.pos:DistToSqr( p ) < BAD_RADIUS * BAD_RADIUS then
			return true
		end
	end
	return false
end

function ENT:MarkBadSpot( p )
	self.BadSpots = self.BadSpots or {}
	table.insert( self.BadSpots, { pos = Vector( p.x, p.y, p.z ), t = CurTime() + 15 } )
	if #self.BadSpots > 12 then table.remove( self.BadSpots, 1 ) end
end

local LEASH = 300

function ENT:SetupPost()
	self.PostInfo = false
	if self.Role or self.HasFlag or self.Unarmed or self.GunPass or self.Undercover or self.Parachuting or self.TruckRide
		or self.Riding or self.Manning or self.Downed then
		return
	end
	local p = self:GetPos()
	local up = util.TraceLine( { start = p + Vector( 0, 0, 72 ), endpos = p + Vector( 0, 0, 640 ), mask = MASK_SOLID_BRUSHONLY } )
	local kind = up.Hit and not up.HitSky and "inside"
	local drops = 0
	for i = 0, 7 do
		local d = Angle( 0, i * 45, 0 ):Forward()
		local prev = 0
		for r = 40, 200, 40 do
			local s = p + d * r + Vector( 0, 0, 24 )
			if util.TraceLine( { start = p + Vector( 0, 0, 24 ), endpos = s, mask = MASK_SOLID_BRUSHONLY } ).Hit then break end
			local tr = util.TraceLine( { start = s, endpos = s - Vector( 0, 0, 2000 ), mask = MASK_SOLID_BRUSHONLY } )
			local drop = tr.Hit and not tr.StartSolid and p.z - tr.HitPos.z or 0
			if drop > 90 and prev < 30 then
				drops = drops + 1
				break
			end
			if drop > 90 then break end
			prev = drop
		end
	end
	if drops >= 2 then kind = "high" end
	if not kind then
		for i = 0, 7 do
			local d = Angle( 0, i * 45, 0 ):Forward()
			local low = util.TraceLine( { start = p + Vector( 0, 0, 24 ), endpos = p + Vector( 0, 0, 24 ) + d * 44, mask = MASK_SOLID, filter = self } )
			if low.Hit and not low.StartSolid and math.abs( low.HitNormal.z ) < 0.4 and not ( IsValid( low.Entity ) and low.Entity.IsCOD1Soldier )
				and not util.TraceLine( { start = p + Vector( 0, 0, 70 ), endpos = p + Vector( 0, 0, 70 ) + d * 64, mask = MASK_SOLID, filter = self } ).Hit then
				kind = "wall"
				break
			end
		end
	end
	if kind then self.PostInfo = { pos = p, kind = kind, misses = 0 } end
end

function ENT:StrongPost()
	if IsValid( self.Follow ) or self.Role or self.HasFlag or self.Unarmed then
		self.PostInfo = nil
		return false
	end
	if not GetConVar( "cod1_npc_hold_posts" ):GetBool() then return false end
	if self.PostInfo == nil then self:SetupPost() end
	return self.PostInfo or false
end

function ENT:Holding()
	if self:Classic() then return false end
	return self:StrongPost()
end

function ENT:OnPost( p )
	local post = self:Holding()
	if not post then return true end
	local dx, dy = p.x - post.pos.x, p.y - post.pos.y
	return dx * dx + dy * dy < LEASH * LEASH and math.abs( p.z - post.pos.z ) < 64
end

function ENT:ReturnToPost( stop )
	local post = self:Holding()
	if not post or self:GetPos():DistToSqr( post.pos ) < 48 * 48 then return false end
	local ok = self:MoveTo( post.pos, self.RunSpeed, 8, stop, true )
	if not ok and self:GetPos():DistToSqr( post.pos ) > 64 * 64 then
		post.misses = post.misses + 1
		if post.misses >= 3 and self:OnPost( self:GetPos() ) then post.pos = self:GetPos() end
	end
	return true
end

local function intelNear( self, range )
	local best, bd
	local me = self:GetPos()
	for e, info in pairs( COD1.Intel[ self.COD1Team ] or {} ) do
		if CurTime() - info.t < INTEL_LIFE and IsValid( e ) then
			local d = me:DistToSqr( info.pos )
			if d < range * range and ( not bd or d < bd ) then best, bd = info.pos, d end
		end
	end
	return best
end

local baseCandidates = ENT.CoverCandidates
function ENT:CoverCandidates( radius )
	local out = baseCandidates( self, radius )
	if not self:Holding() then return out end
	local kept = {}
	for _, p in ipairs( out ) do
		if self:OnPost( p ) then kept[ #kept + 1 ] = p end
	end
	return kept
end

local function tactical( self )
	return IsValid( self.Enemy ) or self.Seeking
end

local baseMoveTo = ENT.MoveTo
function ENT:MoveTo( pos, speed, maxTime, stop, crouchrun, noShoot )
	if self.PostInfo == nil then self:StrongPost() end
	local watch = tactical( self )
	if watch and self:IsBadSpot( pos ) then
		self.MoveBlocked = true
		self.Moving = false
		self.Fails = ( self.Fails or 0 ) + 1
		self.LastFailAt = CurTime()
		coroutine.yield()
		return false
	end
	local start, t0 = self:GetPos(), CurTime()
	local ok = baseMoveTo( self, pos, speed, maxTime, stop, crouchrun, noShoot )
	if not watch or self.Dead then return ok end
	local moved = self:GetPos():Distance( start )
	if self.MoveBlocked or ( not ok and CurTime() - t0 > 1.5 and moved < 32 and not ( stop and stop() ) ) then
		self:MarkBadSpot( pos )
		self.Fails = ( self.Fails or 0 ) + 1
		self.LastFailAt = CurTime()
	elseif moved > 48 then
		self.Fails = 0
	end
	return ok
end

function ENT:HoldPosition( enemy, visible )
	self.Fails = 1
	local lkp = self.LastKnownPos or enemy:GetPos()
	if not self:InCover() and ( self.NextHoldCover or 0 ) < CurTime() then
		self.NextHoldCover = CurTime() + 6
		local spot = self:FindCover( lkp + Vector( 0, 0, 40 ), { lowOnly = true, radius = 400 } )
		if spot and not self:IsBadSpot( spot ) then
			COD1.Cover[ self ] = spot
			self:MoveTo( spot, self.RunSpeed, 3, nil, true )
			if self:InCover() then self:Hide() return true end
		end
	end
	if visible then
		self:Engage( enemy )
		return true
	end
	if not self.Crouched and not self.HasFlag then self:SetStance( true ) end
	if math.random() < 0.25 and self:CanThrowGrenade( lkp ) then return self:ThrowGrenade( lkp ) end
	self:PlaySeq( "crouch_aim" )
	self:Wait( math.Rand( 1.2, 2.5 ), lkp )
	return true
end

function ENT:Frozen()
	local w = self.FreezeWatch
	local now = CurTime()
	local pos = self:GetPos()
	if not w or pos:DistToSqr( w.pos ) > 64 * 64 or ( self.LastFired or 0 ) > w.at then
		self.FreezeWatch = { pos = pos, at = now }
		return false
	end
	return now - w.at > 20
end

function ENT:Unfreeze( enemy )
	self.FreezeWatch = nil
	if self:TakeCorner( enemy, { radius = 600 } ) then return true end
	if self:Flank( enemy ) then return true end
	if self:Reposition( enemy ) then return true end
	return self:TakeCover( enemy, { radius = 900 }, true )
end

function ENT:RecentLosses( radius, window )
	local l = COD1.Losses[ self.COD1Team ]
	if not l then return 0 end
	local now, me, n = CurTime(), self:GetPos(), 0
	for i = #l, 1, -1 do
		local x = l[ i ]
		if now - x.t > 60 then
			table.remove( l, i )
		elseif now - x.t < window and x.pos:DistToSqr( me ) < radius * radius then
			n = n + 1
		end
	end
	return n
end

function ENT:Outnumbered( radius )
	local mates = #U.teammates( self, radius ) + 1
	local foes, me, now = 0, self:GetPos(), CurTime()
	local intel = COD1.Intel[ self.COD1Team ] or {}
	for s in pairs( COD1.Soldiers ) do
		if IsValid( s ) and not s.Dead and s.COD1Team ~= self.COD1Team and self:IsHostileTo( s ) then
			local known = ( self.Aware[ s ] or 0 ) > now and s:GetPos() or intel[ s ] and now - intel[ s ].t < 20 and intel[ s ].pos
			if known and known:DistToSqr( me ) < radius * radius then foes = foes + 1 end
		end
	end
	return foes >= mates * 2 and foes >= 3
end

function ENT:FallBack( enemy )
	self.NextFallBack = CurTime() + 40
	self:Say( "giveupposition", 1, true )
	local away = flat( self:GetPos() - enemy:GetPos() )
	if away:LengthSqr() < 1 then away = -self:GetForward() end
	away:Normalize()
	local goal
	for _, turn in ipairs( { 0, 30, -30, 60, -60 } ) do
		local p = groundAt( self:GetPos() + Angle( 0, away:Angle().y + turn, 0 ):Forward() * 600 )
		if p and hullClear( p, self ) and not self:IsBadSpot( p ) then goal = p break end
	end
	if goal then
		self:CallCoverFire( enemy )
		self:MoveTo( goal, self.RunSpeed, 5, nil, true )
	end
	if not self.Dead and self:TakeCover( enemy, { lowOnly = true, radius = 500 } ) then self:Hide() end
	return true
end

COD1.Breaches = COD1.Breaches or {}

function ENT:EnemyIndoors( enemy )
	local lkp = self.LastKnownPos or enemy:GetPos()
	return not U.underSky( lkp ) and U.underSky( self:GetPos() )
end

function ENT:FindEntry( lkp )
	local route = self:ComputeRoute( lkp )
	if not route then return end
	local prev = self:GetPos()
	for _, p in ipairs( route.points ) do
		if p.type ~= 0 then return end
		if not U.underSky( p.pos ) then
			local dir = flat( p.pos - prev )
			if dir:LengthSqr() < 1 then return end
			dir:Normalize()
			return p.pos, dir
		end
		prev = p.pos
	end
end

function ENT:RoomAssault( enemy )
	self.NextAssault = CurTime() + math.Rand( 18, 28 )
	local lkp = self.LastKnownPos or enemy:GetPos()
	local entry, dir = self:FindEntry( IsValid( enemy ) and enemy:GetPos() or lkp )
	if not entry or entry:Distance( self:GetPos() ) > 1100 then return false end
	local key = math.floor( entry.x / 48 ) .. ":" .. math.floor( entry.y / 48 ) .. ":" .. math.floor( entry.z / 48 )
	local b = COD1.Breaches[ key ]
	if not b or CurTime() > b.expire then
		b = { stack = {}, expire = CurTime() + 20 }
		COD1.Breaches[ key ] = b
	end
	local side = Vector( -dir.y, dir.x, 0 )
	local spot
	for _, s in ipairs( { 1, -1 } ) do
		local taken = false
		for o, os in pairs( b.stack ) do
			if o ~= self and IsValid( o ) and not o.Dead and os == s then taken = true end
		end
		if not taken then
			local p = groundAt( entry - dir * 44 + side * s * 40 )
			if p and U.underSky( p ) and hullClear( p, self ) and math.abs( p.z - entry.z ) < 40 then
				spot = p
				b.stack[ self ] = s
				break
			end
		end
	end
	if not spot then return false end
	self:Say( "misccombat", 0.6 )
	self:CallCoverFire( enemy, true )
	self:MoveTo( spot, self.RunSpeed, 6, function() return IsValid( enemy ) and self:CanSee( enemy ) end, true )
	if self.Dead or not IsValid( enemy ) or self:CanSee( enemy ) or self:GetPos():Distance2D( spot ) > 48 then
		b.stack[ self ] = nil
		return true
	end
	self:SetStance( true )
	self:TurnTo( entry, 0.4 )
	local room = groundAt( entry + dir * 170 ) or entry + dir * 170
	local nadeAt = CurTime() - self.LastSeen < 3 and lkp or room
	if not b.nadeAt and self:CanThrowGrenade( nadeAt ) then
		b.nadeAt = CurTime()
		self:Say( "grenadeattack", 1, true )
		self:ThrowGrenade( nadeAt )
	end
	local ready = ( b.nadeAt or CurTime() ) + ( b.nadeAt and 2.6 or 1.5 )
	while CurTime() < ready and not self.Dead and not self.PendingPain and not self.GrenadeThreat do
		if IsValid( enemy ) and self:CanSee( enemy ) then
			b.stack[ self ] = nil
			return true
		end
		self:PlaySeq( "crouch_aim" )
		self:Wait( 0.3, entry )
	end
	if self.Dead or self.PendingPain or self.GrenadeThreat then return true end
	self:Say( "meleecharge", 0.5 )
	local inside = entry + dir * 120
	local g = groundAt( inside )
	self:MoveTo( g and hullClear( g, self ) and g or entry + dir * 30, self.RunSpeed, 4, function() return IsValid( enemy ) and self:CanSee( enemy ) end )
	b.stack[ self ] = nil
	return true
end

function ENT:Leads()
	return self.Officer or self.VariantData.fixedName ~= nil and not self.VariantData.undercover
end

function ENT:OrderAdvance( enemy )
	self.NextOrder = CurTime() + math.Rand( 20, 35 )
	COD1.Push = COD1.Push or {}
	COD1.Push[ self.COD1Team ] = { pos = self:GetPos(), target = self.LastKnownPos or enemy:GetPos(), untilT = CurTime() + 14 }
	if self.Crouched or self.Hiding then self:SetStance( false ) end
	self:TurnTo( enemy:GetPos(), 0.4 )
	self:Say( "misccombat", 1, true )
	local seq = math.random( 2 ) == 1 and "wave_go" or "wave_gogo"
	self:Wait( self:PlaySeq( seq ), nil, true )
	return true
end

function ENT:Pushing()
	local p = COD1.Push and COD1.Push[ self.COD1Team ]
	return p and CurTime() < p.untilT and p.pos:DistToSqr( self:GetPos() ) < 1500 * 1500 and p
end

local baseMay = ENT.MayAdvance
function ENT:MayAdvance()
	if self:Classic() then return baseMay( self ) end
	if self:Holding() then return false end
	if not self:Pushing() then return baseMay( self ) end
	local mates = U.teammates( self, 1000 )
	local moving = 0
	for _, s in ipairs( mates ) do
		if s.Advancing then moving = moving + 1 end
	end
	return moving < math.max( 2, math.ceil( ( #mates + 1 ) * 0.6 ) )
end

local baseRole = ENT.RoleCombat
function ENT:RoleCombat( enemy, visible, dist )
	if baseRole( self, enemy, visible, dist ) then return true end
	if self:Classic() then return false end
	if self.NoGun or self.Role or self.HasFlag or self.Manning then return false end
	local post = self:Holding()
	if post and not visible and CurTime() - self.LastSeen > 3 and not self:OnPost( self:GetPos() ) then
		return self:ReturnToPost( function() return IsValid( enemy ) and self:CanSee( enemy ) end )
	end
	if ( self.Fails or 0 ) >= 2 and CurTime() - ( self.LastFailAt or 0 ) < 6 then return self:HoldPosition( enemy, visible ) end
	if post then return false end
	if not visible and dist < 1100 and CurTime() >= ( self.NextAssault or 0 ) and CurTime() - self.LastSeen > 2
		and self.WeaponType ~= "rocket" and self:EnemyIndoors( enemy ) and self:MayAdvance() and self:RoomAssault( enemy ) then
		return true
	end
	if self:Frozen() and self:Unfreeze( enemy ) then return true end
	if CurTime() >= ( self.NextFallBack or 0 ) and self:RecentLosses( 900, 20 ) >= 3 and self:Outnumbered( 1400 ) and dist < 1600 then
		return self:FallBack( enemy )
	end
	if visible and self:Leads() and CurTime() >= ( self.NextOrder or 0 ) and dist > 500 and #U.teammates( self, 1000 ) >= 2
		and CurTime() > self.Suppressed and not self:Outnumbered( 1400 ) then
		return self:OrderAdvance( enemy )
	end
	return false
end

function ENT:MaySeek()
	local mode = GetConVar( "cod1_npc_advance" ):GetInt()
	if mode == 0 or ( mode == 2 and self:EnemySide() ) or ( mode == 3 and not self:EnemySide() ) or self:Holding() then return false end
	if IsValid( self.Follow ) or self.Role or self.GunPass or self.Undercover or self.Surrendered or self.NoGun or self.Manning
		or self.HasFlag or self.Downed or self.Treatment or self.WantTurret or self.TruckRide or self.Riding then
		return false
	end
	return true
end

function ENT:SeekTarget()
	local now, me = CurTime(), self:GetPos()
	local best, bd, who
	for e, info in pairs( COD1.Intel[ self.COD1Team ] or {} ) do
		if now - info.t > INTEL_LIFE or not IsValid( e ) or not U.alive( e ) then
			COD1.Intel[ self.COD1Team ][ e ] = nil
		else
			local d = me:DistToSqr( info.pos )
			if d < 7000 * 7000 and ( not bd or d < bd ) then best, bd, who = info.pos, d, e end
		end
	end
	if best then return best, true, who end
	return COD1.PatrolPoint( self ), false, nil
end

COD1.Patrols = COD1.Patrols or { allies = {}, axis = {} }

local function patrolOf( ent )
	return ent.IsCOD1Tank and ent.Patrol or ent.PatrolGoal
end

local function anyFoes( ent )
	local hostile = ent.IsCOD1Tank and ent.Hostile or ent.IsHostileTo
	for s in pairs( COD1.Soldiers ) do
		if IsValid( s ) and not s.Dead and s.COD1Team ~= ent.COD1Team and hostile( ent, s ) then return true end
	end
	for t in pairs( COD1.Tanks or {} ) do
		if IsValid( t ) and not t.Dead and t.COD1Team ~= ent.COD1Team and hostile( ent, t ) then return true end
	end
	for _, p in ipairs( player.GetAll() ) do
		if p:Alive() and hostile( ent, p ) then return true end
	end
	return false
end

function COD1.PatrolPoint( ent )
	local team = ent.COD1Team
	local seen = COD1.Patrols[ team ]
	if not seen or not anyFoes( ent ) then return end
	local me, now = ent:GetPos(), CurTime()
	local own = patrolOf( ent )
	if own and now < own.expires and me:DistToSqr( own.pos ) > 260 * 260 then return own.pos end
	if own then seen[ #seen + 1 ] = { pos = own.pos, t = now } end
	for i = #seen, 1, -1 do
		if now - seen[ i ].t > 240 then table.remove( seen, i ) end
	end
	for s in pairs( COD1.Soldiers ) do
		local p = IsValid( s ) and s ~= ent and not s.Dead and s.COD1Team == team and s.PatrolGoal
		if p and now < p.expires and s:GetPos():DistToSqr( me ) < 700 * 700 and me:DistToSqr( p.pos ) > 260 * 260 then
			ent.PatrolGoal = { pos = p.pos, expires = p.expires }
			return p.pos
		end
	end
	local best, bestScore
	local function rate( p )
		local d = math.sqrt( me:DistToSqr( p ) )
		if d < 700 or d > 3200 then return end
		local fresh = 1600
		for _, v in ipairs( seen ) do fresh = math.min( fresh, v.pos:Distance( p ) ) end
		local score = fresh + math.random() * 400 - math.abs( d - 1600 ) * 0.2
		if not bestScore or score > bestScore then best, bestScore = p, score end
	end
	if navmesh.IsLoaded() then
		local areas = navmesh.Find( me, 3200, 300, 300 )
		for _ = 1, math.min( 40, #areas ) do
			local a = areas[ math.random( #areas ) ]
			if IsValid( a ) and a:GetSizeX() > 40 and a:GetSizeY() > 40 and not a:IsUnderwater() then rate( a:GetCenter() ) end
		end
	else
		for i = 1, 16 do
			local ang = math.rad( i * 22.5 + math.random( -10, 10 ) )
			local p = groundAt( me + Vector( math.cos( ang ), math.sin( ang ), 0 ) * math.Rand( 900, 2400 ) )
			if p then rate( p ) end
		end
	end
	local goal = best and { pos = best, expires = now + 70 }
	if ent.IsCOD1Tank then ent.Patrol = goal else ent.PatrolGoal = goal end
	return best
end

function ENT:SeekEnemy()
	if not self:MaySeek() or CurTime() < ( self.SeekRest or 0 ) then return false end
	local goal, fresh, who = self:SeekTarget()
	if not goal then return false end
	local me = self:GetPos()
	local dist = me:Distance( goal )
	local patrol = not fresh and not IsValid( who )
	if patrol and dist < 300 then
		if self.PatrolGoal then self.PatrolGoal.expires = 0 end
		self.SeekRest = CurTime() + math.Rand( 2, 5 )
		return false
	end
	if dist < 650 and not patrol then
		local target = goal
		if IsValid( who ) and CurTime() >= ( self.NextAssault or 0 ) and self.WeaponType ~= "rocket"
			and not U.underSky( target ) and U.underSky( me ) and self:MayAdvance() then
			self.LastKnownPos = target
			self.Seeking = true
			local did = self:RoomAssault( who )
			self.Seeking = nil
			if did then return true end
		end
		if IsValid( who ) and me:Distance( target ) > 260 and self:MayAdvance() and CurTime() >= ( self.NextCloseIn or 0 ) then
			self.NextCloseIn = CurTime() + math.Rand( 3, 6 )
			self.Seeking = true
			self.Advancing = true
			self:CallCoverFire( who, true )
			self:MoveTo( self:SquadSpot( me + ( target - me ):GetNormalized() * math.min( 300, me:Distance( target ) - 200 ) ), self.WalkSpeed * 2.2, 4,
				function() return IsValid( self:UpdateEnemy() ) end, true )
			self.Advancing = false
			self.Seeking = nil
			return true
		end
		self.SeekRest = CurTime() + 4
		return false
	end
	self.Seeking = true
	if not self:MayAdvance() then
		if not self.Crouched then self:SetStance( true ) end
		self:PlaySeq( "crouch_aim" )
		self:Wait( math.Rand( 0.8, 1.8 ), goal )
		self.Seeking = nil
		return true
	end
	local to = flat( goal - me )
	to:Normalize()
	local step = patrol and math.min( dist, math.Rand( 380, 700 ) ) or math.min( dist - 450, math.Rand( 380, 700 ) )
	local spot
	for _, turn in ipairs( { 0, 25, -25, 50, -50 } ) do
		local p = groundAt( me + Angle( 0, to:Angle().y + turn, 0 ):Forward() * step )
		if p and hullClear( p, self ) and not self:IsBadSpot( p ) then spot = self:SquadSpot( p ) break end
	end
	if not spot then
		self.SeekRest = CurTime() + 3
		self.Seeking = nil
		return false
	end
	if self:Leads() and CurTime() >= ( self.NextSeekWave or 0 ) then
		self.NextSeekWave = CurTime() + 25
		self:TurnTo( goal, 0.4 )
		self:Say( "misccombat", 0.7 )
		self:Wait( self:PlaySeq( "wave_comeon" ), nil, true )
	end
	self.Advancing = true
	self:MoveTo( spot, fresh and self.RunSpeed or self.RunSpeed * 0.75, 5, function() return IsValid( self:UpdateEnemy() ) end, fresh )
	self.Advancing = false
	if not self.Dead and not IsValid( self.Enemy ) then
		local cover = fresh and self:FindCover( goal + Vector( 0, 0, 40 ), { lowOnly = true, radius = 260 } )
		if cover and not self:IsBadSpot( cover ) then
			COD1.Cover[ self ] = cover
			self:MoveTo( cover, self.RunSpeed, 2.5, function() return IsValid( self:UpdateEnemy() ) end, true )
			if self:InCover() and not IsValid( self.Enemy ) then self:Hide() end
		elseif not IsValid( self.Enemy ) then
			self:SetStance( true )
		end
		if not IsValid( self.Enemy ) then
			self:PlaySeq( self.Hiding and "hide_look" or "crouch_aim" )
			self:Wait( math.Rand( 0.6, 1.6 ), goal )
		end
	end
	self.Seeking = nil
	return true
end

local WATCH = { 0, 55, -55, 110, -110, 165, -165, 180 }

function ENT:WatchSector()
	local now = CurTime()
	if now < ( self.NextWatch or 0 ) or ( self.LookPos and now < ( self.LookUntil or 0 ) ) then return end
	self.NextWatch = now + math.Rand( 5, 9 )
	if self.LastSeen <= 0 and self.LastAlert <= 0 or now - math.max( self.LastSeen, self.LastAlert ) > 45 then return end
	if self.Role or self.HasFlag or self.Treatment or self.GunPass then return end
	local me = self:GetPos()
	local mates = {}
	for _, s in ipairs( U.teammates( self, 450 ) ) do
		if not s.Moving and not IsValid( s.Enemy ) and not IsValid( s.Follow ) then mates[ #mates + 1 ] = s end
	end
	if #mates == 0 then return end
	local base
	local seen = intelNear( self, 5000 )
	if seen then
		base = flat( seen - me ):Angle().y
	else
		local c = Vector( me.x, me.y, 0 )
		for _, s in ipairs( mates ) do c = c + flat( s:GetPos() ) end
		c = c / ( #mates + 1 )
		local away = flat( me - c )
		if away:LengthSqr() < 64 then return end
		base = away:Angle().y
	end
	local rank = 0
	for _, s in ipairs( mates ) do
		if s:EntIndex() < self:EntIndex() then rank = rank + 1 end
	end
	local yaw = base + WATCH[ rank % #WATCH + 1 ] + math.Rand( -12, 12 )
	self.LookPos = me + Angle( 0, yaw, 0 ):Forward() * 600 + Vector( 0, 0, 50 )
	self.LookUntil = now + 1
end

local baseIdle = ENT.Idle
function ENT:Idle()
	if self:Classic() then
		if not self.Unarmed and self.Mag >= ( self.Weapon.clip or 0 ) and self:ClassicIdle() then return end
		return baseIdle( self )
	end
	if not IsValid( self.Follow ) and not self.Unarmed and self.Mag >= ( self.Weapon.clip or 0 ) then
		if self:Holding() then
			if self:ReturnToPost( function() return IsValid( self:UpdateEnemy() ) end ) then return end
			if CurTime() >= ( self.NextPostLook or 0 ) then
				self.NextPostLook = CurTime() + math.Rand( 4, 8 )
				local seen = intelNear( self, 6000 )
				if seen then
					self.LookPos = seen
					self.LookUntil = CurTime() + 1
					self.LastAlert = CurTime()
				end
			end
		elseif self:SeekEnemy() then
			return
		else
			self:WatchSector()
		end
	end
	return baseIdle( self )
end

local baseReload = ENT.Reload
function ENT:Reload()
	if not self:Classic() and IsValid( self.Enemy ) and CurTime() - self.LastSeen < 3 and not ( self.Prone or self.Crouched or self.Hiding or self.HasFlag or self.Moving ) then
		self:SetStance( true )
		if self.Dead then return end
	end
	return baseReload( self )
end

--flanking and covering eachother, the smart part
