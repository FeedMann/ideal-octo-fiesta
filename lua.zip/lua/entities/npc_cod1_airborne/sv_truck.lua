local U = COD1.AI

local function motionStart( name )
	local m = COD1.Motion and COD1.Motion[ name ]
	local o = m and m[ 1 ]
	if not o then return vector_origin, 0 end
	return Vector( o[ 1 ], o[ 2 ], o[ 3 ] ), o[ 4 ]
end

function ENT:TruckSeat()
	local r = self.TruckRide
	local truck = r.truck
	local tag = COD1.VehicleTags.opel_truck[ r.tag ]
	local off, yaw = motionStart( r.out )
	local seatYaw = tag[ 2 ]
	local rotated = Vector( off.x, off.y, off.z )
	rotated:Rotate( Angle( 0, seatYaw, 0 ) )
	local pos = truck:LocalToWorld( tag[ 1 ] + rotated )
	return pos, truck:GetAngles().y + seatYaw + yaw
end

function ENT:StartTruckRide()
	self.Riding = true
	self.loco:SetGravity( 0 )
	self:SetCollisionBounds( Vector( -2, -2, 0 ), Vector( 2, 2, 8 ) )
	local r = self.TruckRide
	self:SetNWEntity( "COD1Truck", r.truck )
	self:CollisionRulesChanged()
	self:PlaySeq( r.seq )
	if r.seq ~= "truck_drive" then self:SetPlaybackRate( 0 ) end
end

function ENT:HoldTruckSeat()
	local pos, yaw = self:TruckSeat()
	self:SetPos( pos )
	self:SetAngles( Angle( 0, yaw, 0 ) )
	self.loco:SetVelocity( vector_origin )
end

function ENT:UpdateTruckRide()
	local r = self.TruckRide
	self:FrameAdvance()
	if not IsValid( r.truck ) then
		self:EndTruckRide()
		return
	end
	self.loco:SetVelocity( vector_origin )
	if not r.exit then
		self:HoldTruckSeat()
		if r.go and CurTime() >= r.go then
			local start, y = self:TruckSeat()
			r.exit = { t0 = CurTime(), start = start, yaw = y, m = COD1.Motion and COD1.Motion[ r.out ] }
			self:PlaySeq( r.out )
		end
		return
	end
	local e, m = r.exit, r.exit.m
	if not m or #m < 2 then
		if CurTime() - e.t0 >= self:SequenceDuration() then self:EndTruckRide() end
		return
	end
	local last = #m - 1
	local f = math.min( ( CurTime() - e.t0 ) * m.fps, last )
	local i = math.Clamp( math.floor( f ), 0, last - 1 )
	local a, b, k = m[ i + 1 ], m[ i + 2 ], math.Clamp( f - i, 0, 1 )
	local o = m[ 1 ]
	local fwd, left = Angle( 0, e.yaw, 0 ):Forward(), Angle( 0, e.yaw + 90, 0 ):Forward()
	self:SetPos( e.start + fwd * ( Lerp( k, a[ 1 ], b[ 1 ] ) - o[ 1 ] ) + left * ( Lerp( k, a[ 2 ], b[ 2 ] ) - o[ 2 ] )
		+ Vector( 0, 0, Lerp( k, a[ 3 ], b[ 3 ] ) - o[ 3 ] ) )
	self:SetAngles( Angle( 0, e.yaw + Lerp( k, a[ 4 ], b[ 4 ] ) - o[ 4 ], 0 ) )
	if f >= last then self:EndTruckRide() end
end

function ENT:EndTruckRide()
	local truck = self.TruckRide and self.TruckRide.truck
	self.Riding = false
	self.TruckRide = nil
	self.PendingPain = nil
	self:SetNWEntity( "COD1Truck", NULL )
	self:CollisionRulesChanged()
	self.loco:SetGravity( 1000 )
	self:SetCollisionBounds( U.HULL_MINS, U.HULL_MAXS )
	local ground = U.groundAt( self:GetPos() )
	if ground and math.abs( ground.z - self:GetPos().z ) < 24 then
		self:SetPos( ground )
	elseif IsValid( truck ) then
		local p = self:GetPos()
		self:SetPos( Vector( p.x, p.y, truck:GetPos().z ) )
	end
	self.loco:ClearStuck()
	if not self.Dead then self:PlaySeq( self:IdleSeq() ) end
end

--getting in and out of the truck
