local U = COD1.AI

local RUNS = { "run", "run2", "run3" }
local CROUCHRUNS = { "crouchrun", "crouchrun2", "crouchrun3", "crouchrun4" }
local PISTOL_SEQ = {
	aim = "p_aim", crouch_aim = "p_crouch_aim", shoot_semi = "p_shoot", crouch_shoot_semi = "p_crouch_shoot",
	shoot_auto = "p_shoot", crouch_shoot_auto = "p_crouch_shoot", reload = "p_reload", crouch_reload = "p_crouch_reload",
	idle = "p_aim", idle2 = "p_aim", idle3 = "p_aim", idle_relaxed = "p_aim", idle_twitch = "p_aim",
	crouch_idle = "p_crouch_aim", crouch_idle2 = "p_crouch_aim", crouch_idle3 = "p_crouch_aim", crouch_twitch = "p_crouch_aim",
	crouch_twitch2 = "p_crouch_aim",
}
local UA_WALKS = { "ua_walk_cower", "ua_walk_dazed", "ua_walk_stiff" }
local UA_CROUCHRUNS = { "ua_crouchrun", "ua_crouchrun2", "ua_crouchrun3" }
local UNARMED_SEQ = {
	idle = "ua_idle", idle2 = "ua_idle", idle3 = "ua_idle", idle_relaxed = "ua_idle", idle_twitch = "ua_idle_twitch", aim = "ua_idle",
	crouch_idle = "ua_crouch_idle", crouch_idle2 = "ua_crouch_idle", crouch_idle3 = "ua_crouch_idle", crouch_twitch = "ua_crouch_twitch",
	crouch_twitch2 = "ua_crouch_twitch", crouch_aim = "ua_crouch_idle", hide_idle = "ua_cower", hide_idle2 = "ua_cower",
	hide_look = "ua_cower", hide_twitch = "ua_cower", hide_twitch2 = "ua_cower", hideb_idle = "ua_cower", hideb_twitch = "ua_cower",
}
local UNARMED_MOVE = { run = "ua_run", run2 = "ua_run", run3 = "ua_run", walk = "ua_walk", crouchrun = "ua_crouchrun",
	crouchrun2 = "ua_crouchrun", crouchrun3 = "ua_crouchrun", crouchrun4 = "ua_crouchrun", p_crouchrun = "ua_crouchrun" }
local MOVE_SEQS = {}
for _, n in ipairs( { "run", "run2", "run3", "walk", "crouchrun", "crouchrun2", "crouchrun3", "crouchrun4", "p_crouchrun",
	"ua_walk", "ua_walk_cower", "ua_walk_dazed", "ua_walk_stiff", "ua_run", "ua_crouchrun", "ua_crouchrun2", "ua_crouchrun3",
	"gp_gunwalk", "gp_ammowalk",
	"run_hurt", "run_hurt2", "run_hurt_left", "run_hurt_right", "walk_hurt", "flag_run", "flag_run_indoor",
	"run_shoot", "run_shoot_back", "run_shoot_left", "run_shoot_right", "crouch_shoot_run", "crouch_shoot_run_back",
	"crouch_shoot_run_left", "crouch_shoot_run_right", "walk_shoot_left", "walk_shoot_right", "walk_shoot_back" } ) do
	MOVE_SEQS[ n ] = true
end
U.MOVE_SEQS = MOVE_SEQS

function ENT:KeyValue( k, v )
	if k == "cod1_weapon" then self.WeaponKey = v
	elseif k == "cod1_variant" then self.Variant = v
	elseif k == "cod1_officer" then self.Officer = v == "1"
	elseif k == "cod1_parachute" then self.WantParachute = v == "1"
	elseif k == "cod1_para_from" then self.ParaFromZ = tonumber( v ) end
end

function ENT:SetGroup( name, value )
	local id = self:FindBodygroupByName( name )
	if id >= 0 then self:SetBodygroup( id, value ) end
end

function ENT:ApplyLooks()
	local v = self.VariantData
	local w = self.WeaponKey
	local off = self.Officer and v.officer
	self:SetModel( v.model )
	local look = v.looks and v.looks[ math.random( #v.looks ) ]
	self.LookMaterials = look and look.materials or v.materials

	local body
	if off and off.bodyList then body = off.bodyList[ math.random( #off.bodyList ) ]
	elseif off and off.body then body = off.body
	elseif look and look.bodyList then body = look.bodyList[ math.random( #look.bodyList ) ]
	elseif v.bodyList then body = v.bodyList[ math.random( #v.bodyList ) ]
	else body = math.random( 0, v.bodies - 1 ) end
	self:SetGroup( "body", body )
	self:SetGroup( "head", v.headList and v.headList[ math.random( #v.headList ) ] or math.random( 0, v.heads - 1 ) )
	self:SetSkin( math.random( 0, v.skins - 1 ) )

	local helmets = look and look.helmets or v.helmets
	self.HelmetIndex = off and off.helmet or helmets[ math.random( #helmets ) ]
	self:SetGroup( "helmet", self.HelmetIndex )
	self.HelmetSide = math.random() < ( v.helmetSide and v.helmetSide[ self.HelmetIndex ] or 0 )
	self:SetGroup( "helmetside", self.HelmetSide and 1 or 0 )
	local bandolier = v.bandolier and math.random() < ( v.bandolier[ w ] or 0 )
	local load = math.random( 0, v.loads - 1 )
	if bandolier and v.bandolierLoads then load = v.bandolierLoads[ math.random( #v.bandolierLoads ) ] end
	if off and off.belt and v.loads > 1 then load = v.loads end
	if v.blankLoad and v.blankLoad[ w ] then load = v.loads end
	self:SetGroup( "load", load )
	local front = v.fronts and ( bandolier and v.fronts or math.random( 0, v.fronts ) )
	if front then self:SetGroup( "front", front ) end
	self:SetGroup( "pocket", ( self.HelmetSide and not ( front and v.frontCompass and v.frontCompass[ front ] ) ) and 1 or 0 )
	local belt = off and off.belt or v.belts[ w ] or 0
	if v.ammoBelt and ( w == "garand" or w == "carbine" ) and math.random() < 0.3 then belt = v.ammoBelt end
	if bandolier and v.bandolierBelt then belt = v.bandolierBelt end
	self:SetGroup( "belt", belt )
	if v.bandolier then self:SetGroup( "bandolier", bandolier and 1 or 0 ) end
	for i, key in ipairs( v.weapons ) do
		if key == w then self:SetGroup( "weapon", i - 1 ) end
	end
	if v.extra then v.extra( self, body, w, off ) end
	self:PaintMaterials( self )
	if self.Undercover then self:ShowWeapon( false ) end
end

function ENT:PaintMaterials( ent )
	local mats = self.LookMaterials
	if not mats then return end
	for i, path in ipairs( ent:GetMaterials() ) do
		local sub = mats[ string.GetFileFromFilename( path ) ]
		if sub then ent:SetSubMaterial( i - 1, sub ) end
	end
end

hook.Add( "CreateEntityRagdoll", "COD1PaintMaterials", function( owner, rag )
	if owner.PaintMaterials then owner:PaintMaterials( rag ) end
end )

function ENT:Initialize()
	self.VariantData = COD1.Variants[ self.Variant or "" ] or COD1.Variants[ self.DefaultVariant ]
	local v = self.VariantData
	self.COD1Team = v.team
	self.Undercover = v.undercover or nil
	self.Role = v.role
	if self.Officer and not v.officer then self.Officer = false end
	if self.Officer then
		local list = v.officer.weapons
		if not ( list and table.HasValue( list, self.WeaponKey ) ) then
			self.WeaponKey = list and list[ math.random( #list ) ] or v.officer.weapon
		end
	end
	if not self.WeaponKey or self.WeaponKey == "random" or not table.HasValue( v.weapons, self.WeaponKey ) then
		self.WeaponKey = v.random[ math.random( #v.random ) ]
	end
	self.Weapon = COD1.Weapons[ self.WeaponKey ]
	self.WeaponType = U.WEAPON_TYPE[ self.WeaponKey ] or "rifle"
	self:ApplyLooks()

	local hp = GetConVar( "cod1_npc_health" ):GetInt()
	if v.medic then hp = math.floor( hp * 3.5 ) end
	self:SetMaxHealth( hp )
	self:SetHealth( hp )
	self:SetBloodColor( DONT_BLEED )
	self:AddFlags( FL_OBJECT )
	self:SetCollisionBounds( U.HULL_MINS, U.HULL_MAXS )
	self:SetCustomCollisionCheck( true )
	self:SetSurroundingBoundsType( BOUNDS_HITBOXES )
	self:SetUseType( SIMPLE_USE )

	self.loco:SetStepHeight( 20 )
	self.loco:SetJumpHeight( 60 )
	self.loco:SetAcceleration( 2000 )
	self.loco:SetDeceleration( 2600 )
	self.loco:SetMaxYawRate( 450 )
	self.loco:SetDeathDropHeight( 300 )

	self.Mag = self.Weapon.clip
	self.Grenades = ( self.WeaponType == "pistol" or v.medic or self.Role ) and 0 or 2
	self.MuzzleAtt = self:LookupAttachment( "muzzle_" .. self.WeaponKey )
	self.BrassAtt = self:LookupAttachment( "brass_" .. self.WeaponKey )
	self.VoiceNat = v.voice
	self.Voice = math.random( 1, v.voices )
	self.RunSeq = RUNS[ math.random( #RUNS ) ]
	self.CrouchRunSeq = self.WeaponType == "pistol" and "p_crouchrun" or CROUCHRUNS[ math.random( #CROUCHRUNS ) ]
	self.Grudges = {}
	self.Aware = {}
	self.Greeted = {}
	self.NextScan = 0
	self.LastSeen = 0
	self.LastAlert = 0
	self.Crouched = false
	self.NextGrenade = CurTime() + math.Rand( 4, 10 )
	self.NextTalk = 0
	self.Suppressed = 0
	self.LastHurt = 0
	self.Unarmed = false
	if self.Role == "flag" then self:TakeFlag() end
	if self.Role == "megaphone" then self.Unarmed = true end

	if self.COD1Team == "axis" then
		self:SetNWString( "COD1Name", v.fixedName or COD1.GermanName( self.Officer and v.officer and v.officer.rank or nil ) )
		self:SetNWString( "COD1Role", v.roleName or COD1.GermanRoles[ self.WeaponKey ] or self.Weapon.role )
	else
		self:SetNWString( "COD1Name", v.fixedName or COD1.RandomName( ( self.Officer and v.officer.rank ) or v.rank, v.names, self.WeaponKey ) )
		self:SetNWString( "COD1Role", v.roleName or ( v.medic and "Medic" ) or self.Weapon.role )
	end
	self:SetNWString( "COD1Team", self.COD1Team )
	if v.unarmed or self.GunPass then self:Disarm() end
	COD1.Soldiers[ self ] = true
	if self.WantParachute then self:StartParachute() end
	if self.TruckRide then self:StartTruckRide() end
end

function ENT:Disarm()
	self.NoGun = true
	self.Unarmed = true
	self.Grenades = 0
	self.Mag = 0
	self:SetGroup( "weapon", self.VariantData.blankWeapon or 0 )
	self.CrouchRunSeq = UA_CROUCHRUNS[ math.random( #UA_CROUCHRUNS ) ]
	self.RunSeq = self.CrouchRunSeq
	self.WalkSeq = UA_WALKS[ math.random( #UA_WALKS ) ]
	local gp = self.GunPass
	self:SetNWString( "COD1Role", gp and gp.part ~= "queue" and "Quartermaster" or "Conscript" )
end

function ENT:ArmWith( key )
	local v = self.VariantData
	self.NoGun, self.Clips, self.WalkSeq = nil, nil, nil
	self.Unarmed = false
	self.WeaponKey = key
	self.Weapon = COD1.Weapons[ key ]
	self.WeaponType = U.WEAPON_TYPE[ key ] or "rifle"
	self.Mag = self.Weapon.clip
	self.MuzzleAtt = self:LookupAttachment( "muzzle_" .. key )
	self.BrassAtt = self:LookupAttachment( "brass_" .. key )
	for i, k in ipairs( v.weapons ) do
		if k == key then self:SetGroup( "weapon", i - 1 ) end
	end
	self.RunSeq = RUNS[ math.random( #RUNS ) ]
	self.CrouchRunSeq = self.WeaponType == "pistol" and "p_crouchrun" or CROUCHRUNS[ math.random( #CROUCHRUNS ) ]
	self:DropHandProp( "clips" )
	self:SetNWString( "COD1Role", self.Weapon.role )
	self:EmitSound( "cod1/misc/pu_weapon01.wav", 65 )
end

function ENT:OnRemove()
	self:ClearHandProps()
	if IsValid( self.Chute ) and self.Parachuting then self.Chute:SetParent( NULL ) self.Chute:Land() end
	if IsValid( self.ClaimedFlag ) then self.ClaimedFlag.Claimant = nil end
	if IsValid( self.LaidGun ) then SafeRemoveEntityDelayed( self.LaidGun, 60 ) end
	if IsValid( self.Dressing ) then self.Dressing:Remove() end
	COD1.Soldiers[ self ] = nil
	COD1.Cover[ self ] = nil
end

local PARA_SPEED = 230
local LAND_TAG = { x = -37.6, y = 13.5, yaw = -23.3 }
local LAND_END = { x = -25.1, y = 14.7, yaw = -23.3 }

local function landable( ent )
	if not IsValid( ent ) then return true end
	if ent:IsPlayer() or ent:IsNPC() or ent.IsCOD1Soldier then return false end
	local g = ent:GetCollisionGroup()
	if g == COLLISION_GROUP_DEBRIS or g == COLLISION_GROUP_DEBRIS_TRIGGER or g == COLLISION_GROUP_WEAPON then return false end
	if ent:GetClass() == "prop_ragdoll" or ent:IsWeapon() then return false end
	return true
end

function ENT:StartParachute()
	local ground = self:GetPos()
	local up = util.TraceLine( { start = ground + Vector( 0, 0, 20 ), endpos = ground + Vector( 0, 0, 6000 ), mask = MASK_SOLID_BRUSHONLY } )
	local room = up.HitPos.z - ground.z - 420
	local h = self.ParaFromZ and ( self.ParaFromZ - ground.z ) or GetConVar( "cod1_para_height" ):GetFloat()
	h = math.min( h, room )
	if h < 200 then return end
	local start = ground + Vector( 0, 0, h )
	self:SetPos( start )

	local chute = ents.Create( "cod1_parachute" )
	if not IsValid( chute ) then return end
	chute:SetPos( start )
	chute:SetAngles( Angle( 0, self:GetAngles().y, 0 ) )
	chute:Spawn()
	chute:SetParent( self )
	chute:SetLocalPos( vector_origin )
	chute:SetLocalAngles( angle_zero )

	self.Chute = chute
	self.Parachuting = true
	self.ParaDrift = Vector( math.Rand( -1, 1 ), math.Rand( -1, 1 ), 0 ) * 25
	self.loco:SetGravity( 0 )
	self:PlaySeq( "para_idle" )
end

function ENT:UpdateParachute()
	self:FrameAdvance()
	if self.Dead and self.ChuteLimpAt and CurTime() >= self.ChuteLimpAt then
		self.ChuteLimpAt = nil
		self:PlaySeq( "chute_dead" )
	end
	if self.ParaLanding then
		if CurTime() >= self.ParaLandEnd then self:EndParachute() end
		return
	end
	local pos = self:GetPos()
	local chute = self.Chute
	local tr = util.TraceHull( { start = pos + Vector( 0, 0, 2 ), endpos = pos - Vector( 0, 0, 6000 ), mins = Vector( -12, -12, 0 ), maxs = Vector( 12, 12, 8 ),
		filter = function( e ) return e ~= self and e ~= chute and landable( e ) end, mask = MASK_PLAYERSOLID } )
	if tr.StartSolid then tr.Hit = false end
	local now = CurTime()
	local dt = math.Clamp( now - ( self.ParaStepAt or now ), 0, 0.25 )
	self.ParaStepAt = now
	local newPos = pos + self.ParaDrift * dt - Vector( 0, 0, PARA_SPEED * dt )
	self.loco:SetVelocity( vector_origin )
	if tr.Hit and newPos.z > tr.HitPos.z then
		self:SetPos( newPos )
		return
	end

	self:SetPos( tr.Hit and tr.HitPos or newPos )
	if not self.Dead then
		local yaw = self:GetAngles().y - LAND_TAG.yaw
		local off = Vector( LAND_TAG.x, LAND_TAG.y, 0 )
		off:Rotate( Angle( 0, yaw, 0 ) )
		self:SetPos( self:GetPos() - off )
		self:SetAngles( Angle( 0, yaw, 0 ) )
		self.ParaLandBase = { pos = self:GetPos(), yaw = yaw }
	end
	if IsValid( chute ) then
		chute:SetParent( NULL )
		chute:SetPos( self:GetPos() )
		chute:SetAngles( Angle( 0, self:GetAngles().y, 0 ) )
		if self.Dead then chute:Deflate() else chute:Land() end
	end
	if self.Dead then
		self:EndParachute()
		if GetConVar( "cod1_npc_ragdolls" ):GetBool() then
			self:BecomeRagdoll( DamageInfo() )
		else
			self:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
			self.DeathEnd = CurTime() + self:PlaySeq( "death_run_crumple" ) - 0.05
		end
		return
	end
	self.ParaLanding = true
	self:SetSurroundingBounds( Vector( -96, -96, 0 ), Vector( 96, 96, 96 ) )
	self.ParaLandEnd = CurTime() + self:PlaySeq( "para_land" )
	self:EmitSound( "COD1.ParaLand" )
end

function ENT:ChuteDeath()
	local dur = self:PlaySeq( "chute_death" )
	if dur <= 0 then dur = self:PlaySeq( "para_idle" ) end
	if IsValid( self.Chute ) then self.Chute:PlayAnim( "idle" ) end
	self.ChuteLimpAt = CurTime() + dur
end

function ENT:EndParachute()
	if self.ParaLanding then self:SetSurroundingBoundsType( BOUNDS_HITBOXES ) end
	self.Parachuting = false
	self.ParaLanding = false
	self.PendingPain = nil
	self.loco:SetGravity( 1000 )
	if IsValid( self.Chute ) and self.Chute:GetParent() == self then
		self.Chute:SetParent( NULL )
		self.Chute:Land()
	end
	local base = self.ParaLandBase
	self.ParaLandBase = nil
	if base and not self.Dead then
		local off = Vector( LAND_END.x, LAND_END.y, 0 )
		off:Rotate( Angle( 0, base.yaw, 0 ) )
		self:SetPos( base.pos + off )
		self:SetAngles( Angle( 0, base.yaw + LAND_END.yaw, 0 ) )
	end
	if not self.Dead then self:PlaySeq( self:IdleSeq() ) end
end

function ENT:PlaySeq( name, rate )
	if self.NoGun then name = UNARMED_SEQ[ name ] or name
	elseif self.WeaponHidden and UNARMED_SEQ[ name ] and self:LookupSequence( UNARMED_SEQ[ name ] ) >= 0 then name = UNARMED_SEQ[ name ]
	elseif self.WeaponType == "pistol" then name = PISTOL_SEQ[ name ] or name end
	local seq = self:LookupSequence( name )
	if seq < 0 then return 0 end
	self:ResetSequence( seq )
	self:SetCycle( 0 )
	self:SetPlaybackRate( rate or 1 )
	return self:SequenceDuration( seq ) / ( rate or 1 )
end

function ENT:IdleSeq()
	if self.HasFlag then return self.Crouched and "flag_crouch" or "flag_wave" end
	return ( self.Crouched or self.Hiding ) and "crouch_idle" or "idle"
end

function ENT:Wait( t, face, noInterrupt )
	local e = CurTime() + t
	while CurTime() < e do
		if self.Dead then return false end
		if not noInterrupt and ( self.PendingPain or self.GrenadeThreat ) then return false end
		if IsValid( face ) then
			self.loco:FaceTowards( face:GetPos() )
			self:UpdateAim( face )
		elseif isvector( face ) then
			self.loco:FaceTowards( face )
		end
		coroutine.yield()
	end
	return true
end

function ENT:UpdateAim( ent )
	local target = isvector( ent ) and ent or self:AimPoint( ent )
	local from = self:GetPos() + Vector( 0, 0, U.POSE_HEIGHT[ self:PoseName() ] )
	local pitch = math.NormalizeAngle( ( target - from ):Angle().p )
	self:SetPoseParameter( "aim_pitch", math.Clamp( pitch, -58, 61 ) )
end

function ENT:FacingDelta( pos )
	local want = ( pos - self:GetPos() ):Angle().y
	return math.AngleDifference( want, self:GetAngles().y )
end

function ENT:TurnTo( pos, limit )
	local delta = self:FacingDelta( pos )
	if math.abs( delta ) > 50 and not self.Crouched and not self.Hiding and not self.Moving and not self.HasFlag then
		self:PlaySeq( delta > 0 and "turn_left" or "turn_right", 1.3 )
	end
	local t = CurTime() + ( limit or 1 )
	while math.abs( self:FacingDelta( pos ) ) > 15 and CurTime() < t and not self.Dead do
		self.loco:FaceTowards( pos )
		coroutine.yield()
	end
end

function ENT:SetStance( crouch )
	if self.Prone then self:LeaveProne() end
	if crouch == self.Crouched and not self.Hiding then return end
	if self.HasFlag then
		self.Crouched = crouch
		self.Hiding = false
		if crouch then self:Wait( self:PlaySeq( "flag_run2crouch" ), nil, true ) end
		return
	end
	if self.Hiding then
		self.Hiding = false
		if crouch then
			self.Crouched = true
			self:Wait( self:PlaySeq( "hide2aim" ), nil, true )
			return
		end
		self.Crouched = false
		self:Wait( self:PlaySeq( "hide2stand", 1.3 ), nil, true )
		return
	end
	self.Crouched = crouch
	self:Wait( self:PlaySeq( crouch and "stand2crouch" or "crouch2stand", 1.4 ), nil, true )
end

function ENT:GoProne()
	if self.Prone then return end
	if self.Hiding or not self.Crouched then self:SetStance( true ) end
	self:EmitSound( "COD1.GoProne" )
	self:Wait( self:PlaySeq( "crouch2prone" ), nil, true )
	self.Prone = true
	self.Crouched = false
	self.Hiding = false
end

function ENT:LeaveProne()
	if not self.Prone then return end
	self.Prone = false
	self.Crouched = true
	self:Wait( self:PlaySeq( "prone2crouch" ), nil, true )
end

function ENT:Hide()
	if self.Hiding or self.HasFlag then return end
	if self.Prone then self:LeaveProne() end
	self:Wait( self:PlaySeq( self.Crouched and "aim2hide" or "stand2hide" ), nil, true )
	self.Crouched = true
	self.Hiding = true
end

function ENT:FaceGesture( name, autokill )
	local seq = self:LookupSequence( name )
	if seq < 0 then return end
	return self:AddGestureSequence( seq, autokill ~= false )
end

function ENT:UpdateFace()
	if CurTime() >= ( self.NextBlink or 0 ) then
		self.NextBlink = CurTime() + math.Rand( 2, 5 )
		self:FaceGesture( "face_blink" )
	end
	if self.TalkUntil and CurTime() > self.TalkUntil then
		self.TalkUntil = nil
		if self.TalkLayer and self:IsValidLayer( self.TalkLayer ) then self:RemoveLayer( self.TalkLayer ) end
	end
	local squinting = self.SquintLayer and self:IsValidLayer( self.SquintLayer )
	if IsValid( self.Enemy ) and not squinting then
		self.SquintLayer = self:FaceGesture( "face_squint", false )
	elseif not IsValid( self.Enemy ) and squinting then
		self:RemoveLayer( self.SquintLayer )
		self.SquintLayer = nil
	end
end

function ENT:IsHurt()
	return self:Health() < self:GetMaxHealth() * 0.5
end

function ENT:StartMoveAnim( running, crouchrun )
	local seqName
	if self.Carrying then
		seqName = "rescue_walk"
	elseif self.HasFlag then
		seqName = running and "flag_run" or "flag_run_indoor"
	elseif self:IsHurt() then
		if running then
			seqName = self.HurtLeg == HITGROUP_LEFTLEG and "run_hurt_left"
				or self.HurtLeg == HITGROUP_RIGHTLEG and "run_hurt_right"
				or ( self:EntIndex() % 2 == 0 and "run_hurt" or "run_hurt2" )
		else
			seqName = "walk_hurt"
		end
	elseif self.MoveSeq then
		seqName = self.MoveSeq
	elseif crouchrun then
		seqName = self.CrouchRunSeq
	else
		seqName = running and self.RunSeq or self.WalkSeq or "walk"
	end
	if self.WeaponHidden and UNARMED_MOVE[ seqName ] and self:LookupSequence( UNARMED_MOVE[ seqName ] ) >= 0 then seqName = UNARMED_MOVE[ seqName ] end
	local seq = self:LookupSequence( seqName )
	if self:GetSequence() ~= seq then
		self:StartActivity( running and ACT_RUN or ACT_WALK )
		self:ResetSequence( seq )
	end
	return self:GetSequenceGroundSpeed( seq )
end

function ENT:StopMoveAnim()
	local cur = self:GetSequenceName( self:GetSequence() )
	if not MOVE_SEQS[ cur ] then return end
	self.IdleUntil = nil
	self:StartActivity( self.Crouched and ACT_CROUCHIDLE or ACT_IDLE )
	if IsValid( self.Enemy ) and not self.HasFlag then
		self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
	else
		self:PlaySeq( self:IdleSeq() )
	end
end

function ENT:PlayMotion( name, goal, height, onFrame )
	local m = COD1.Motion and COD1.Motion[ name ]
	local dur = self:PlaySeq( name )
	if not m or #m < 2 then
		self:Wait( dur, nil, true )
		if goal and not self.Dead then self:SetPos( goal ) end
		return
	end
	local start, yaw0 = self:GetPos(), self:GetAngles().y
	local fwd, left = Angle( 0, yaw0, 0 ):Forward(), Angle( 0, yaw0 + 90, 0 ):Forward()
	local last = #m - 1
	local o = m[ 1 ]
	local zscale = 1
	if height then
		local peak = 0
		for _, k in ipairs( m ) do peak = math.max( peak, k[ 3 ] - o[ 3 ] ) end
		if peak > 1 then zscale = math.Clamp( ( height + 4 ) / peak, 0.4, 1.3 ) end
	end
	local rc, rs = math.cos( math.rad( -o[ 4 ] ) ), math.sin( math.rad( -o[ 4 ] ) )
	local function at( f )
		local i = math.Clamp( math.floor( f ), 0, last - 1 )
		local a, b, k = m[ i + 1 ], m[ i + 2 ], math.Clamp( f - i, 0, 1 )
		local dx, dy = Lerp( k, a[ 1 ], b[ 1 ] ) - o[ 1 ], Lerp( k, a[ 2 ], b[ 2 ] ) - o[ 2 ]
		return start + fwd * ( dx * rc - dy * rs ) + left * ( dx * rs + dy * rc )
			+ Vector( 0, 0, ( Lerp( k, a[ 3 ], b[ 3 ] ) - o[ 3 ] ) * zscale ), Lerp( k, a[ 4 ], b[ 4 ] ) - o[ 4 ]
	end
	local fix = goal and ( goal - at( last ) ) or Vector()
	local grav = self.loco:GetGravity()
	self.loco:SetGravity( 0 )
	self:SetCollisionBounds( Vector( -2, -2, 0 ), Vector( 2, 2, 8 ) )
	local t0 = CurTime()
	while not self.Dead do
		local f = math.min( ( CurTime() - t0 ) * m.fps, last )
		local pos, yaw = at( f )
		self:SetPos( pos + fix * ( f / last ) )
		self:SetAngles( Angle( 0, yaw0 + yaw, 0 ) )
		self.loco:SetVelocity( vector_origin )
		if onFrame then onFrame( CurTime() - t0 ) end
		if f >= last then break end
		coroutine.yield()
	end
	self:SetCollisionBounds( U.HULL_MINS, U.HULL_MAXS )
	self.loco:SetGravity( grav )
	self.loco:ClearStuck()
end

function ENT:DoMantle( seq, dir, landPos, height )
	self.Moving = false
	self.loco:SetDesiredSpeed( 0 )
	self.loco:SetVelocity( vector_origin )
	self:SetAngles( Angle( 0, dir:Angle().y, 0 ) )
	self:EmitSound( "COD1.Scrape" )
	self:PlayMotion( seq, landPos, height )
	if self.Dead then return end
	self:EmitSound( "COD1.Land." .. COD1.SurfaceUnder( self ) )
	self:EmitSound( "COD1.Gear" )
	self.Crouched = false
	self.Hiding = false
end

function ENT:Stumble( name )
	local dur = self:PlaySeq( name )
	local speed = self:GetSequenceGroundSpeed( self:LookupSequence( name ) )
	local e = CurTime() + dur
	self.loco:SetDesiredSpeed( speed )
	while CurTime() < e and not self.Dead do
		self.loco:Approach( self:GetPos() + self:GetForward() * 100, 1 )
		coroutine.yield()
	end
	self.loco:SetDesiredSpeed( 0 )
end

--bodies and death animations
