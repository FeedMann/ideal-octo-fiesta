local U = COD1.AI
local flat, groundAt, hullClear, blocked = U.flat, U.groundAt, U.hullClear, U.blocked

U.RANGES.sniper = { 600, 5000 }
for _, k in ipairs( { "kar98_sniper", "mosin_sniper", "springfield" } ) do U.WEAPON_TYPE[ k ] = "sniper" end

function ENT:Sniper()
	return self.Weapon and self.Weapon.sniper and not self.NoGun
end

local baseInit = ENT.Initialize
function ENT:Initialize()
	baseInit( self )
	if self:Sniper() then
		self.SightRange = 8000
		self.Grenades = 1
	end
end

local baseHit = ENT.HitChance
function ENT:HitChance( enemy, dist )
	if not self:Sniper() then return baseHit( self, enemy, dist ) end
	local k = 0.8 * math.Clamp( 1.3 - dist / 7000, 0.55, 1.15 )
	k = k * math.Clamp( 0.5 + ( CurTime() - ( self.EnemyTime or CurTime() ) ) * 0.25, 0.5, 1 )
	if CurTime() < self.Suppressed then k = k * 0.6 end
	if self.Moving then k = k * 0.3 end
	if not self:Fair() then k = k * ( self:EnemySide() and 0.8 or 1.1 ) end
	if IsValid( enemy ) then
		local vel = enemy.IsCOD1Soldier and enemy.loco:GetVelocity() or enemy:GetVelocity()
		k = k * math.Clamp( 1.1 - vel:Length2D() / 350, 0.4, 1.1 )
		if enemy:IsPlayer() and enemy:Crouching() then k = k * 0.85 end
		if enemy.IsCOD1Soldier then
			if enemy.Prone then k = k * 0.7 elseif enemy.Hiding then k = k * 0.5 end
		end
	end
	if self.AccuracyMult then k = k * math.max( self.AccuracyMult, 0.05 ) end
	return math.Clamp( k * GetConVar( "cod1_npc_accuracy" ):GetFloat(), 0.02, 0.95 )
end

local baseAim = ENT.AimTime
function ENT:AimTime()
	local t = baseAim( self )
	if self:Sniper() then t = t + 0.7 end
	return t
end

local baseGunMoving = ENT.CanGunWhileMoving
function ENT:CanGunWhileMoving( enemy )
	if self:Sniper() then return false end
	return baseGunMoving( self, enemy )
end

local baseMay = ENT.MayAdvance
function ENT:MayAdvance()
	if self:Sniper() then return false end
	return baseMay( self )
end

local baseSeek = ENT.MaySeek
function ENT:MaySeek()
	if self:Sniper() then return false end
	return baseSeek( self )
end

function ENT:SniperRelocate( enemy, lkp )
	self.NextRelocate = CurTime() + math.Rand( 10, 16 )
	self.SniperShots = 0
	local me = self:GetPos()
	local aim = lkp or ( IsValid( enemy ) and enemy:GetPos() ) or me
	local best, bs
	for _ = 1, 14 do
		local ang = math.rad( math.random( 0, 359 ) )
		local d = math.random( 160, 420 )
		local p = groundAt( me + Vector( math.cos( ang ) * d, math.sin( ang ) * d, 0 ) )
		if p and math.abs( p.z - me.z ) < 120 and hullClear( p, self ) and self:OnPost( p ) and not self:IsBadSpot( p ) then
			local sees
			if IsValid( enemy ) and not lkp then
				sees = self:CanShootFrom( "prone", enemy, p ) or self:CanShootFrom( "crouch", enemy, p )
			else
				sees = not blocked( p + Vector( 0, 0, 40 ), aim + Vector( 0, 0, 40 ) )
			end
			if sees then
				local away = flat( p - aim ):Length() - flat( me - aim ):Length()
				local score = math.abs( away ) * 0.3 + p:Distance( me ) * 0.2 - ( away > 0 and 60 or 0 )
				if not bs or score < bs then best, bs = p, score end
			end
		end
	end
	if not best then return false end
	self:Say( "misccombat", 0.3 )
	COD1.Cover[ self ] = nil
	self:MoveTo( best, self.RunSpeed, 4, nil, true, true )
	if not self.Dead then self:SetStance( true ) end
	return true
end

function ENT:SniperCombat( enemy, visible, dist )
	if dist < 350 then return nil end
	if self.Mag <= 0 then
		if visible and not self.Prone then self:SetStance( true ) end
		self:Reload()
		return true
	end
	if visible then
		self.SniperShots = self.SniperShots or 0
		if self.SniperShots >= ( self.SniperMoveAfter or 3 ) and CurTime() >= ( self.NextRelocate or 0 ) and self:SniperRelocate( enemy ) then
			return true
		end
		local stance = ( dist > 900 and self:CanShootFrom( "prone", enemy ) and "prone" )
			or ( self:CanShootFrom( "crouch", enemy ) and "crouch" ) or ( self:CanShootFrom( "stand", enemy ) and "stand" )
		if not stance then return nil end
		if stance == "prone" then
			if not self.Prone then self:GoProne() end
			if self.Dead or not IsValid( enemy ) then return true end
			self:PlaySeq( "prone_aim" )
		else
			if self.Prone then self:LeaveProne() end
			self:SetStance( stance == "crouch" )
			self:TurnTo( enemy:GetPos(), 0.8 )
			if self.Dead or not IsValid( enemy ) then return true end
			self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
		end
		self:Wait( self:AimTime() + math.Rand( 0, 0.4 ), enemy )
		if self.Dead or not IsValid( enemy ) then return true end
		if not self:LineOfFireClear( self:AimPoint( enemy ) ) then return nil end
		if self:ShootVolley( enemy, 1 ) then
			self.SniperShots = self.SniperShots + 1
			if self.SniperShots == 1 then self.SniperMoveAfter = math.random( 2, 4 ) end
		end
		return true
	end
	local lkp = self.LastKnownPos or enemy:GetPos()
	if CurTime() - self.LastSeen > 8 and CurTime() >= ( self.NextRelocate or 0 ) and self:SniperRelocate( enemy, lkp ) then return true end
	if not self.Prone and not self.Crouched then self:SetStance( true ) end
	self:PlaySeq( self.Prone and "prone_aim" or "crouch_aim" )
	self:Wait( math.Rand( 0.8, 1.8 ), lkp + Vector( 0, 0, 40 ) )
	return true
end

local baseRole = ENT.RoleCombat
function ENT:RoleCombat( enemy, visible, dist )
	if self:Sniper() and not self:Classic() and not ( self.Role or self.HasFlag or self.Manning ) then
		local r = self:SniperCombat( enemy, visible, dist )
		if r ~= nil then return r end
	end
	return baseRole( self, enemy, visible, dist )
end

--one shot one kill, unless he misses, which is alot
