local U = COD1.AI
local flat, groundAt = U.flat, U.groundAt

COD1.FallenGuns = COD1.FallenGuns or {}

local MOSIN = "models/cod1/props/sov_mosin.mdl"
local CLIPS = "models/cod1/props/sov_clips.mdl"
local STEPS = { "gp_step1", "gp_step2", "gp_step3" }
local CROWD = { "gp_crowd1", "gp_crowd2" }
local GIVERS = {
	front = { wait = "gp_front_wait", give = "gp_front_give", hand = "anim_attachment_RH", model = MOSIN,
		events = { { 1 / 30, true }, { 15 / 30, false }, { 42 / 30, true } } },
	back = { wait = "gp_back_wait", give = "gp_back_give", hand = "anim_attachment_LH", model = MOSIN,
		events = { { 1 / 30, true }, { 42 / 30, false } } },
	ammo = { wait = "gp_ammo_wait", give = "gp_ammo_give", hand = "anim_attachment_RH", model = CLIPS, events = {} },
}

function ENT:HandProp( key, model, att )
	self.HandProps = self.HandProps or {}
	local p = self.HandProps[ key ]
	if IsValid( p ) then return p end
	local id = self:LookupAttachment( att )
	if not id or id <= 0 then return end
	p = ents.Create( "prop_dynamic" )
	if not IsValid( p ) then return end
	p:SetModel( model )
	p:Spawn()
	p:SetSolid( SOLID_NONE )
	p:SetParent( self, id )
	p:SetLocalPos( vector_origin )
	p:SetLocalAngles( angle_zero )
	self.HandProps[ key ] = p
	return p
end

function ENT:DropHandProp( key )
	local p = self.HandProps and self.HandProps[ key ]
	if IsValid( p ) then p:Remove() end
	if self.HandProps then self.HandProps[ key ] = nil end
end

function ENT:ClearHandProps()
	for key in pairs( self.HandProps or {} ) do self:DropHandProp( key ) end
end

function ENT:HoldClips()
	self.Clips = true
	self.WalkSeq = "gp_ammowalk"
	self:HandProp( "clips", CLIPS, "anim_attachment_RH" )
	self:SetNWString( "COD1Role", "Ammo Bearer" )
	self:EmitSound( "COD1.Gear" )
end

local function playEvents( self, seq, events )
	local dur = self:PlaySeq( seq )
	local tick = U.runEvents( events )
	local t0 = CurTime()
	while CurTime() - t0 < dur and not self.Dead do
		tick( CurTime() - t0 )
		coroutine.yield()
	end
	tick( dur )
end

function ENT:GiverThink( gp, st )
	local d = GIVERS[ gp.part ]
	local spot = st:GiverSpot( gp.part )
	if self:GetPos():DistToSqr( spot.pos ) > 16 then self:SetPos( spot.pos ) end
	self:SetAngles( Angle( 0, spot.yaw, 0 ) )
	self.loco:SetVelocity( vector_origin )
	local prop = self:HandProp( "giver", d.model, d.hand )
	if gp.holding == nil then gp.holding = true end
	if IsValid( prop ) then prop:SetNoDraw( not gp.holding ) end
	if gp.give then
		gp.give = nil
		gp.busy = true
		local events = {}
		for _, e in ipairs( d.events ) do
			events[ #events + 1 ] = { e[ 1 ], function()
				gp.holding = e[ 2 ]
				if IsValid( prop ) then prop:SetNoDraw( not e[ 2 ] ) end
			end }
		end
		playEvents( self, d.give, events )
		gp.busy = false
		self:PlaySeq( d.wait )
		return
	end
	if self:GetSequence() ~= self:LookupSequence( d.wait ) then self:PlaySeq( d.wait ) end
	coroutine.yield()
end

function ENT:QueueThink( gp, st )
	if not gp.tag then return self:LeaveGunPass() end
	if gp.state == "join" then
		local pos = st:TagPos( gp.tag )
		local far = self:GetPos():Distance( pos )
		if far > 14 then
			gp.tries = ( gp.tries or 0 ) + 1
			if gp.tries > 4 then return self:LeaveGunPass() end
			if far > 90 then
				self:MoveTo( pos, far > 350 and self.RunSpeed or self.WalkSpeed, 8, function()
					return self.GunPass ~= gp or self:GetPos():Distance2D( pos ) < 10
				end, nil, true )
			end
			if self.GunPass ~= gp or self.Dead then return end
			if self:GetPos():Distance2D( pos ) < 140 then self:WalkTo( pos, 3 ) end
			if self.GunPass ~= gp or self.Dead or self:GetPos():Distance( pos ) > 30 then return end
		end
		self:SetPos( pos )
		gp.tries = nil
		gp.state = "wait"
		return
	end
	if gp.state == "wait" then
		local pos = st:TagPos( gp.tag )
		if self:GetPos():Distance( pos ) > 20 then
			gp.state = "join"
			return
		end
		local order = gp.order
		if order then
			gp.order = nil
			if order.kind == "step" then return self:QueueStep( gp, st, order.to ) end
			return self:QueueGet( gp, st, order.kind )
		end
		self.loco:FaceTowards( pos + Angle( 0, st:TagYaw( gp.tag ), 0 ):Forward() * 60 )
		if CurTime() >= ( gp.idleUntil or 0 ) then
			gp.idleUntil = CurTime() + math.max( self:PlaySeq( CROWD[ math.random( #CROWD ) ] ), 1 )
		end
		coroutine.yield()
	end
end

function ENT:QueueStep( gp, st, to )
	local from = gp.tag
	local a, b = st:TagPos( from ), st:TagPos( to )
	self:SetPos( a )
	self:SetAngles( Angle( 0, flat( b - a ):Angle().y, 0 ) )
	gp.state = "step"
	self:PlayMotion( STEPS[ math.random( #STEPS ) ], b )
	if self.GunPass ~= gp or self.Dead then return end
	gp.tag, gp.to = to, nil
	gp.state = "wait"
	gp.idleUntil = nil
	st:StepDone( self, from )
end

function ENT:QueueGet( gp, st, item )
	local walk, grab = item == "gun" and "gp_getgun" or "gp_getammo", item == "gun" and "gp_gun" or "gp_ammo"
	local mw, mg = COD1.Motion[ walk ], COD1.Motion[ grab ]
	gp.state = "get"
	self:SetPos( st:GroundSpot( mw[ 1 ] ) )
	self:SetAngles( Angle( 0, st:GetAngles().y + mw[ 1 ][ 4 ], 0 ) )
	self:PlayMotion( walk, st:GroundSpot( mw[ #mw ] ) )
	if self.GunPass ~= gp or self.Dead then return end
	st:Hand( item )
	local events
	if item == "gun" then
		events = {
			{ 15 / 30, function() self:HandProp( "rifle", MOSIN, "anim_attachment_LH" ) end },
			{ 51 / 30, function()
				self:DropHandProp( "rifle" )
				self:ArmWith( "mosin" )
			end },
		}
	else
		events = { { 35 / 30, function() self:HoldClips() end } }
	end
	local tick = U.runEvents( events )
	self:PlayMotion( grab, st:GroundSpot( mg[ #mg ] ), nil, tick )
	if self.Dead then return end
	tick( 99 )
	gp.state = "leave"
	self.MoveSeq = item == "gun" and "gp_gunwalk" or "gp_ammowalk"
	local ahead = self:GetPos() + self:GetForward() * math.Rand( 260, 380 )
	self:MoveTo( groundAt( ahead ) or ahead, self.WalkSpeed, 7, nil, nil, true )
	self.MoveSeq = nil
	if self.GunPass == gp then self.GunPass = nil end
	self.IdleUntil = nil
end

function ENT:GunPassThink()
	local gp = self.GunPass
	local st = gp.station
	if not IsValid( st ) then return self:LeaveGunPass() end
	if gp.part == "queue" then return self:QueueThink( gp, st ) end
	return self:GiverThink( gp, st )
end

function ENT:LeaveGunPass()
	local gp = self.GunPass
	if not gp then return end
	self.GunPass = nil
	self.MoveSeq = nil
	self:DropHandProp( "giver" )
	self:DropHandProp( "rifle" )
	if IsValid( gp.station ) then gp.station:Release( self ) end
	self.NextGunLook = CurTime() + 6
	self.IdleUntil = nil
end

function ENT:GunPassHurt()
	local gp = self.GunPass
	if gp and gp.part == "queue" and ( gp.state == "wait" or gp.state == "join" ) then self:LeaveGunPass() end
end

local SWEP_KEY = { garand = "m1garand", carbine = "m1carbine", kar98 = "kar98k", mosin = "mosin_nagant", kar98_sniper = "kar98k_sniper", mosin_sniper = "mosin_nagant_sniper" }
COD1.DroppedGuns = COD1.DroppedGuns or {}

function ENT:DropGun()
	if self.NoGun or self.Unarmed or self.WeaponHidden or self.Manning or not self.WeaponKey then return end
	if not GetConVar( "cod1_npc_drop_guns" ):GetBool() then return end
	local class = "weapon_cod1_" .. ( SWEP_KEY[ self.WeaponKey ] or self.WeaponKey )
	if not ( weapons and weapons.GetStored and weapons.GetStored( class ) ) then return end
	local id = self:LookupAttachment( "anim_attachment_RH" )
	local att = id and id > 0 and self:GetAttachment( id )
	if not att then return end
	local w = ents.Create( class )
	if not IsValid( w ) then return end
	w:SetPos( att.Pos )
	w:SetAngles( att.Ang )
	w:Spawn()
	if COD1.PlaceWorldGun then COD1.PlaceWorldGun( w, att.Pos, att.Ang ) end
	local ph = w:GetPhysicsObject()
	if IsValid( ph ) then
		ph:Wake()
		ph:SetVelocity( self.loco:GetVelocity() * 0.5 + self:GetForward() * math.Rand( 20, 60 ) + Vector( 0, 0, math.Rand( 30, 80 ) ) )
		ph:AddAngleVelocity( VectorRand() * 120 )
	end
	self:ShowWeapon( false )
	self.GunDropped = true
	local list = COD1.DroppedGuns
	list[ #list + 1 ] = w
	for i = #list, 1, -1 do
		if not IsValid( list[ i ] ) or IsValid( list[ i ]:GetOwner() ) then table.remove( list, i ) end
	end
	while #list > 30 do
		local old = table.remove( list, 1 )
		if IsValid( old ) and not IsValid( old:GetOwner() ) then old:Remove() end
	end
	timer.Simple( 120, function()
		if IsValid( w ) and not IsValid( w:GetOwner() ) then w:Remove() end
	end )
	return w
end

function ENT:GunPassDied()
	self:ClearHandProps()
	if self.GunPass then self:LeaveGunPass() end
	if not self.NoGun and not self.Unarmed and self.WeaponKey then
		local dropped = self:DropGun()
		table.insert( COD1.FallenGuns, { key = self.WeaponKey, body = IsValid( dropped ) and dropped or self, at = CurTime(), blank = self.VariantData.blankWeapon or 0 } )
	end
end

hook.Add( "CreateEntityRagdoll", "COD1FallenGuns", function( owner, rag )
	for _, g in ipairs( COD1.FallenGuns ) do
		if g.body == owner then g.body = rag end
	end
	if owner.GunDropped and owner.WeaponKey then
		local pre = string.lower( owner.WeaponKey ) .. "_"
		for i = 0, rag:GetBoneCount() - 1 do
			local n = rag:GetBoneName( i )
			if n and string.StartWith( string.lower( n ), pre ) then rag:ManipulateBoneScale( i, vector_origin ) end
		end
	end
end )

function ENT:GunPassUse( ply )
	local gp = self.GunPass
	if gp.busy or CurTime() < ( self.NextHandout or 0 ) or self:IsHostileTo( ply ) then return end
	self.NextHandout = CurTime() + 2.5
	if gp.part == "ammo" then
		local wep = ply:GetActiveWeapon()
		local ammo = IsValid( wep ) and wep.CoDKey and wep.Primary and wep.Primary.Ammo or "cod1_mosin_nagant"
		ply:GiveAmmo( 10, ammo )
	elseif ply:HasWeapon( "weapon_cod1_mosin_nagant" ) then
		ply:GiveAmmo( 5, "cod1_mosin_nagant" )
	else
		ply:Give( "weapon_cod1_mosin_nagant" )
		ply:SelectWeapon( "weapon_cod1_mosin_nagant" )
	end
	gp.give, gp.busy = true, true
	self:EmitSound( "COD1.Gear" )
end

local function gunSpot( body )
	local id = body:LookupAttachment( "anim_attachment_RH" )
	local att = id and id > 0 and body:GetAttachment( id )
	local p = att and att.Pos or body:GetPos()
	return groundAt( p ) or p
end

function ENT:FindFallenGun( radius )
	local me, best, bd = self:GetPos(), nil, radius * radius
	local list = COD1.FallenGuns
	for i = #list, 1, -1 do
		local g = list[ i ]
		if not IsValid( g.body ) or CurTime() - g.at > 180 then
			table.remove( list, i )
		elseif not IsValid( g.claim ) and CurTime() - g.at > 1 and table.HasValue( self.VariantData.weapons, g.key ) and not ( g.body:IsWeapon() and IsValid( g.body:GetOwner() ) ) then
			local d = g.body:GetPos():DistToSqr( me )
			if d < bd then best, bd = g, d end
		end
	end
	return best
end

function ENT:TakeFallenGun( radius )
	local g = self:FindFallenGun( radius )
	if not g then return false end
	g.claim = self
	local function lost() return not IsValid( g.body ) or g.claim ~= self end
	local spot = gunSpot( g.body )
	local hand = COD1.FlagPickup and COD1.FlagPickup.hand or Vector( 16, 18, 0 )
	local from = flat( spot - self:GetPos() )
	if from:LengthSqr() < 1 then from = self:GetForward() end
	local ang = Angle( 0, from:Angle().y, 0 )
	local start = spot - ang:Forward() * hand.x + ang:Right() * hand.y
	start = groundAt( start ) or start
	self:MoveTo( start, self.RunSpeed, 6, lost, true, true )
	if self.Dead or lost() or self:GetPos():Distance2D( start ) > 40 then
		if g.claim == self then g.claim = nil end
		return true
	end
	self:SetAngles( ang )
	self.Crouched, self.Hiding = false, false
	local took = false
	local function take()
		if took or lost() then return end
		took = true
		local body = g.body
		if body:IsWeapon() then
			body:Remove()
		else
			local bg = body:FindBodygroupByName( "weapon" )
			if bg >= 0 then body:SetBodygroup( bg, g.blank ) end
		end
		table.RemoveByValue( COD1.FallenGuns, g )
		self:ArmWith( g.key )
	end
	local t = COD1.FlagPickup and COD1.FlagPickup.time or 0.27
	self:PlayMotion( "flag_pickup", nil, nil, function( el ) if el >= t then take() end end )
	if not self.Dead then take() end
	if g.claim == self and not took then g.claim = nil end
	self.IdleUntil = nil
	return true
end

function ENT:JoinGunPass( radius )
	if self.Clips or self.GunPass then return false end
	local station, bd
	for _, st in ipairs( ents.FindByClass( "cod1_gunpass" ) ) do
		local d = st:GetPos():DistToSqr( self:GetPos() )
		if st:IsOpen() and d < radius * radius and ( not bd or d < bd ) then station, bd = st, d end
	end
	return station and station:Join( self ) or false
end

function ENT:ArmedLead( radius )
	local best, bd
	for _, s in ipairs( U.teammates( self, radius ) ) do
		if not s.Unarmed and not s.GunPass then
			local d = s:GetPos():DistToSqr( self:GetPos() )
			if not bd or d < bd then best, bd = s, d end
		end
	end
	return best
end

function ENT:UnarmedIdle()
	if CurTime() < ( self.NextGunLook or 0 ) then return false end
	self.NextGunLook = CurTime() + 2
	if self:TakeFallenGun( 1200 ) then return true end
	return self:JoinGunPass( 3000 )
end

function ENT:UnarmedCombat( enemy, visible, dist )
	if CurTime() >= ( self.NextGunLook or 0 ) then
		self.NextGunLook = CurTime() + 1.5
		if self:TakeFallenGun( 900 ) then return end
		if dist > 700 and self:JoinGunPass( 2500 ) then return end
	end
	local lkp = self.LastKnownPos or enemy:GetPos()
	local lead = self:ArmedLead( 1400 )
	if lead and CurTime() >= self.Suppressed and math.random() < 0.7 then
		local away = flat( lead:GetPos() - lkp ):GetNormalized()
		local spot = groundAt( lead:GetPos() + away * math.Rand( 70, 130 ) + away:Angle():Right() * math.Rand( -70, 70 ) )
		if spot and spot:Distance( self:GetPos() ) > 90 then
			self:MoveTo( spot, self.RunSpeed, 2.5, nil, true, true )
			return
		end
	end
	self.Crouched = true
	self.Hiding = false
	self:PlaySeq( ( CurTime() < self.Suppressed or visible ) and "ua_cower" or "ua_crouch_idle" )
	if math.random() < 0.15 then self:Say( "undersuppression", 0.5 ) end
	self:Wait( math.Rand( 1.2, 2.6 ), lkp )
end

--stalingrad supply line stuff
