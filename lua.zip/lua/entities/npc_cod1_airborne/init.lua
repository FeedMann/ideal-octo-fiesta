AddCSLuaFile( "shared.lua" )
AddCSLuaFile( "cl_init.lua" )
include( "shared.lua" )

COD1.Soldiers = COD1.Soldiers or {}
COD1.Cover = COD1.Cover or {}
COD1.NavBlocked = COD1.NavBlocked or {}
COD1.NavBlockedEdges = COD1.NavBlockedEdges or {}
COD1.DroppedFlags = COD1.DroppedFlags or {}
if not istable( COD1.NextSquadTalk ) then COD1.NextSquadTalk = {} end

local U = {}
COD1.AI = U

U.POSE_HEIGHT = { stand = 58, crouch = 38, prone = 12 }
U.MELEE_RANGE = 64
U.CHARGE_RANGE = 200
U.BACKPEDAL_RANGE = 200
U.DODGE_RANGE = 300
U.STAND_RANGE = 503
U.PRONE_RANGE = 1000
U.HULL_MINS = Vector( -10, -10, 0 )
U.HULL_MAXS = Vector( 10, 10, 72 )

U.RANGES = { smg = { 150, 650 }, rifle = { 300, 1500 }, lmg = { 400, 1900 }, pistol = { 100, 600 }, rocket = { 350, 2200 }, flame = { 60, 420 } }
U.WEAPON_TYPE = { thompson = "smg", mp40 = "smg", sten = "smg", ppsh = "smg", bar = "lmg", bren = "lmg", luger = "pistol", colt = "pistol",
	stensd = "smg", mg34 = "lmg", dp28 = "lmg", mg30cal = "lmg", tt33 = "pistol", webley = "pistol",
	pschreck = "rocket", bazooka = "rocket", pfaust = "rocket", flamer = "flame" }

function U.flat( v )
	return Vector( v.x, v.y, 0 )
end

function U.groundAt( pos )
	local tr = util.TraceLine( { start = pos + Vector( 0, 0, 48 ), endpos = pos - Vector( 0, 0, 96 ), mask = MASK_PLAYERSOLID_BRUSHONLY } )
	if tr.Hit and not tr.StartSolid and tr.HitNormal.z > 0.7 then return tr.HitPos end
end

function U.blocked( a, b )
	return util.TraceLine( { start = a, endpos = b, mask = MASK_SOLID_BRUSHONLY } ).Hit
end

function U.occupied( pos, ent, r )
	r = r or 26
	local team = IsValid( ent ) and ent.COD1Team
	for s in pairs( COD1.Soldiers ) do
		if s ~= ent and IsValid( s ) and not s.Dead and ( not team or s.COD1Team == team ) then
			local p = s.MoveGoal or s:GetPos()
			if math.abs( p.z - pos.z ) < 50 and ( p.x - pos.x ) ^ 2 + ( p.y - pos.y ) ^ 2 < r * r then return true end
		end
	end
	return false
end

function U.hullClear( pos, ent )
	if U.occupied( pos, ent ) then return false end
	return not util.TraceHull( { start = pos + Vector( 0, 0, 4 ), endpos = pos + Vector( 0, 0, 4 ),
		mins = Vector( -13, -13, 0 ), maxs = Vector( 13, 13, 68 ), filter = ent, mask = MASK_PLAYERSOLID } ).Hit
end

local SKY = Vector( 0, 0, 4096 )

function U.underSky( p )
	local tr = util.TraceLine( { start = p + Vector( 0, 0, 60 ), endpos = p + SKY, mask = MASK_SOLID_BRUSHONLY } )
	return not tr.Hit or tr.HitSky
end

function U.near( a, b, r, dz )
	return a:Distance2D( b ) <= r and math.abs( a.z - b.z ) <= ( dz or 40 )
end

function U.levelFilter( me )
	local open
	return function( p )
		local dz = math.abs( p.z - me.z )
		if dz <= 48 then return true end
		if dz > 200 then return false end
		if open == nil then open = U.underSky( me ) end
		return open and U.underSky( p )
	end
end

function U.alive( e )
	if not IsValid( e ) then return false end
	if e:IsPlayer() then return e:Alive() end
	if e.IsCOD1Soldier then return not e.Dead end
	return e:Health() > 0
end

function U.teammates( self, radius )
	local out, me, r2 = {}, self:GetPos(), radius * radius
	for s in pairs( COD1.Soldiers ) do
		if s ~= self and IsValid( s ) and not s.Dead and s.COD1Team == self.COD1Team and s:GetPos():DistToSqr( me ) < r2 then
			out[ #out + 1 ] = s
		end
	end
	return out
end

include( "sv_body.lua" )
include( "sv_senses.lua" )
include( "sv_geneva.lua" )
include( "sv_nav.lua" )
include( "sv_cover.lua" )
include( "sv_combat.lua" )
include( "sv_roles.lua" )
include( "sv_life.lua" )
include( "sv_truck.lua" )
include( "sv_treat.lua" )
include( "sv_mg.lua" )
include( "sv_rescue.lua" )
include( "sv_disguise.lua" )
include( "sv_gunpass.lua" )
include( "sv_uo.lua" )
include( "sv_classic.lua" )
include( "sv_tactics.lua" )
include( "sv_sniper.lua" )

--the main soldier brain, good luck reading this
