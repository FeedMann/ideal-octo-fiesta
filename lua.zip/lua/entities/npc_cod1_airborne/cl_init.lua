include( "shared.lua" )

function ENT:CODStep()
	self:EmitSound( "COD1.Step." .. COD1.SurfaceUnder( self ) )
	self.StepCount = ( self.StepCount or 0 ) + 1
	if self.StepCount % 3 == 0 and math.random() < 0.6 then self:EmitSound( "COD1.Gear" ) end
end

function ENT:FireAnimationEvent( pos, ang, event, name )
	if name == "COD1.Footstep" then
		self.StepEventAt = CurTime()
		self:CODStep()
		return true
	elseif name == "COD1.BodyFall" then
		self:EmitSound( "COD1.Fall." .. COD1.FallSurface( COD1.SurfaceUnder( self ) ) )
		self:EmitSound( "COD1.Gear" )
		return true
	end
end

function ENT:Think()
	local pos = self:GetPos()
	local last = self.StepPos
	self.StepPos = pos
	if not last or self:IsDormant() then return end
	local d = math.sqrt( ( pos.x - last.x ) ^ 2 + ( pos.y - last.y ) ^ 2 )
	if d < 0.05 or d > 40 then
		self.StepDist = 0
		return
	end
	local seq = self:GetSequenceName( self:GetSequence() ) or ""
	self.StepDist = ( self.StepDist or 0 ) + d
	if string.find( seq, "prone", 1, true ) then
		if self.StepDist > 40 then
			self.StepDist = 0
			self:EmitSound( "COD1.Crawl" )
		end
		return
	end
	self.Feet = self.Feet or { self:LookupBone( "bip01 l foot" ), self:LookupBone( "bip01 r foot" ) }
	local bl, br = self.Feet[ 1 ], self.Feet[ 2 ]
	local pl, pr = bl and self:GetBonePosition( bl ), br and self:GetBonePosition( br )
	if not pl or not pr then return end
	local zl, zr = pl.z, pr.z
	local plant = self.StepPlant
	if not plant then
		self.StepPlant = zl < zr and 1 or 2
	elseif plant == 1 and zr < zl - 2 then
		self.StepPlant = 2
	elseif plant == 2 and zl < zr - 2 then
		self.StepPlant = 1
	end
	if plant and plant ~= self.StepPlant and CurTime() - ( self.StepEventAt or 0 ) >= 0.9 then self:CODStep() end
end

language.Add( "npc_cod1_airborne", "Allied Soldier" )

--footsteps and stuff on the client side
