local U = COD1.AI

local function treatData()
	local d = COD1.TreatData or {}
	local ev = d.events or {}
	return d.fps or 30, { gun_down = ev.gun_down or 8, dressing_out = ev.dressing_out or 26, dressing_on = ev.dressing_on or 98, gun_up = ev.gun_up or 122 },
		d.medicSpot or Vector( 6, -31, 0 ), d.medicTurn or 90
end

local GUN_BONES = { "tag_weapon", "tag_weapon_right" }
local WORLD_MODELS = { carbine = "m1carbine", garand = "m1garand", kar98 = "kar98k", mosin = "mosin_nagant" }
local DRESSING = "models/cod1/props/bandage.mdl"

function ENT:GunBones( scale )
	for _, name in ipairs( GUN_BONES ) do
		local b = self:LookupBone( name )
		if b then self:ManipulateBoneScale( b, scale ) end
	end
	for i = 0, self:GetBoneCount() - 1 do
		local n = self:GetBoneName( i )
		if n and string.StartWith( n, self.WeaponKey .. "_" ) then self:ManipulateBoneScale( i, scale ) end
	end
end

function ENT:LayDownGun( right, forward )
	if self.NoGun or self.Unarmed or self.WeaponHidden or not self.WeaponKey then return false end
	local mdl = "models/cod1/weapons/w_" .. ( WORLD_MODELS[ self.WeaponKey ] or self.WeaponKey ) .. ".mdl"
	if not util.IsValidModel( mdl ) then return false end
	local yaw = self:GetAngles().y
	local ang = Angle( 0, yaw, 0 )
	local ground = U.groundAt( self:GetPos() + ang:Right() * ( right or 15 ) + ang:Forward() * ( forward or 10 ) )
	if not ground then return false end
	local gun = ents.Create( "prop_dynamic" )
	if not IsValid( gun ) then return false end
	gun:SetModel( mdl )
	COD1.PlaceWorldGun( gun, ground + Vector( 0, 0, 1.5 ), Angle( 0, yaw - 90, 90 ) )
	gun:Spawn()
	gun:SetSolid( SOLID_NONE )
	self.LaidGun = gun
	self:GunBones( vector_origin )
	self:EmitSound( "cod1/misc/equip_rifle02.wav", 65 )
	return true
end

function ENT:PickUpGun()
	if IsValid( self.LaidGun ) then
		if self.Dead then SafeRemoveEntityDelayed( self.LaidGun, 60 ) else self.LaidGun:Remove() end
	end
	self.LaidGun = nil
	if self.Dead then return end
	self:GunBones( Vector( 1, 1, 1 ) )
	self:EmitSound( "cod1/misc/pu_weapon01.wav", 65 )
end

function ENT:BeginTreatment( medic )
	self.Moving = false
	self.Crouched, self.Hiding = false, false
	self.loco:SetDesiredSpeed( 0 )
	self.loco:SetVelocity( vector_origin )
	local dur = math.max( self:PlaySeq( "wounded_down" ), 0.1 )
	self.Treatment = { medic = medic, phase = "down", readyAt = CurTime() + dur, gunAt = CurTime() + dur * 0.6, timeout = CurTime() + 25 }
	self:Say( "pain", 1, true )
end

function ENT:UpdateTreatment()
	local tr = self.Treatment
	self:FrameAdvance()
	self.loco:SetVelocity( vector_origin )
	local now = CurTime()
	if tr.phase ~= "up" and ( not IsValid( tr.medic ) or tr.medic.Dead or now > tr.timeout ) then
		self:EndTreatment()
		return
	end
	if tr.gunAt and now >= tr.gunAt then
		tr.gunAt = nil
		tr.laid = self:LayDownGun( -14, 12 )
	end
	if tr.phase == "down" and now >= tr.readyAt then
		tr.phase = "hold"
		self:PlaySeq( "wounded_hold" )
	elseif tr.phase == "up" then
		if tr.gunUpAt and now >= tr.gunUpAt then
			tr.gunUpAt = nil
			if tr.laid then self:PickUpGun() end
		end
		if now >= tr.doneAt then
			self.Treatment = nil
			self.ShakenUntil = now + 3
			if not self.Dead then self:PlaySeq( self:IdleSeq() ) end
		end
	end
end

function ENT:EndTreatment()
	local tr = self.Treatment
	if not tr or tr.phase == "up" then return end
	tr.phase = "up"
	tr.gunAt = nil
	self.NextTreatable = CurTime() + 10
	local dur = math.max( self:PlaySeq( "wounded_up" ), 0.1 )
	tr.doneAt = CurTime() + dur
	tr.gunUpAt = CurTime() + dur * 0.3
end

local function patientYaw( p )
	return p:IsPlayer() and p:EyeAngles().y or p:GetAngles().y
end

function ENT:HoldDressing()
	local hand = self:LookupBone( "bip01 r hand" )
	if not hand then return end
	local d = ents.Create( "prop_dynamic" )
	if not IsValid( d ) then return end
	d:SetModel( DRESSING )
	d:SetPos( self:GetPos() )
	d:Spawn()
	d:SetSolid( SOLID_NONE )
	d:FollowBone( self, hand )
	d:SetLocalPos( Vector( 4, 0.5, 0 ) )
	d:SetLocalAngles( Angle( 0, 0, 90 ) )
	self.Dressing = d
	self:EmitSound( "physics/cardboard/cardboard_box_impact_soft" .. math.random( 1, 4 ) .. ".wav", 55, 120 )
end

function ENT:Treat( p )
	local holster = self.WeaponType == "pistol" and not self.WeaponHidden
	if holster then self:ShowWeapon( false ) end
	self:TreatPatient( p )
	if holster and not self.Dead then self:ShowWeapon( true ) end
end

function ENT:TreatPatient( p )
	local FPS, EV, MEDIC_SPOT, MEDIC_TURN = treatData()
	local function alive() return U.alive( p ) and not ( p.Downed and p.Downed.phase == "carried" ) end
	local joins = p.IsCOD1Soldier and not p.Dead and not p.Downed and not p.Parachuting and not p.Riding and not p.Treatment and not IsValid( p.Enemy ) and CurTime() >= ( p.NextTreatable or 0 )
	if joins then p:BeginTreatment( self ) end
	local yaw = patientYaw( p )
	local off = Vector( MEDIC_SPOT.x, MEDIC_SPOT.y, 0 )
	off:Rotate( Angle( 0, yaw, 0 ) )
	local spot = U.groundAt( p:GetPos() + off )
	local face = yaw + MEDIC_TURN
	if not spot or U.blocked( p:GetPos() + Vector( 0, 0, 30 ), spot + Vector( 0, 0, 30 ) ) then
		spot, face = nil, nil
	end
	if spot then
		self:MoveTo( spot, self.WalkSpeed * 2, 4, function()
			return not alive() or self:GetPos():Distance( spot ) < 10 or CurTime() < self.Suppressed
		end, true, true )
	end
	local function release()
		if joins and IsValid( p ) and p.Treatment and p.Treatment.medic == self then p:EndTreatment() end
	end
	if self.Dead or not alive() or CurTime() < self.Suppressed then release() return end
	if spot and self:GetPos():Distance( spot ) < 24 then self:SetPos( spot ) end
	if face then self:SetAngles( Angle( 0, face, 0 ) ) else self:TurnTo( p:GetPos(), 0.6 ) end
	local kneel = self:PlaySeq( "medic_kneel" )
	if kneel > 0 and ( not self:Wait( kneel ) or not alive() ) then
		release()
		return
	end
	if joins then
		local wait = CurTime() + 3
		while IsValid( p ) and p.Treatment and p.Treatment.phase == "down" and CurTime() < wait and not self.Dead do coroutine.yield() end
	end
	local dur = self:PlaySeq( "medic_heal" )
	if joins and IsValid( p ) and p.Treatment and p.Treatment.medic == self and p.Treatment.phase == "hold" then p:PlaySeq( "wounded_hold" ) end
	if dur <= 0 then
		self:SetStance( true )
		self:PlaySeq( "crouch_idle" )
		local ok = self:Wait( 2.5 ) and alive()
		if ok then self:HealPatient( p ) end
		release()
		return
	end
	local t0 = CurTime()
	local function upTo( frame ) return self:Wait( math.max( t0 + frame / FPS - CurTime(), 0 ) ) and alive() end
	local animGun = COD1.TreatData and COD1.TreatData.gunInAnim
	local laid, healed = false, false
	if upTo( EV.gun_down ) then
		if not animGun then laid = self:LayDownGun( 15, 10 ) end
		if upTo( EV.dressing_out ) then
			self:HoldDressing()
			if upTo( EV.dressing_on ) then
				if IsValid( self.Dressing ) then self.Dressing:Remove() end
				self.Dressing = nil
				self:HealPatient( p )
				healed = true
				if upTo( EV.gun_up ) and laid then
					self:PickUpGun()
					laid = false
				end
				self:Wait( math.max( t0 + dur - CurTime(), 0 ) )
			end
		end
	end
	if IsValid( self.Dressing ) then self.Dressing:Remove() end
	self.Dressing = nil
	if laid then self:PickUpGun() end
	release()
	if self.Dead then return end
	local stand = healed and self:PlaySeq( "medic_stand" ) or 0
	if stand > 0 and self:Wait( stand ) then
		self.Crouched = false
		self:PlaySeq( self:IdleSeq() )
		return
	end
	self.Crouched = true
	self:PlaySeq( "crouch_idle" )
end

function ENT:HealPatient( p )
	if not U.alive( p ) then return end
	p:SetHealth( math.min( p:GetMaxHealth(), p:Health() + ( p:IsPlayer() and 50 or p:GetMaxHealth() ) ) )
	if not p:IsPlayer() then p.HurtLeg = nil end
	if p.Downed and p.COD1Team and p.COD1Team ~= self.COD1Team and not self.Surrendered then p:BecomePOW()
	elseif p.Downed then p:Recover() end
	p:EmitSound( "items/smallmedkit1.wav", 60 )
end

--medic! MEDIC!
