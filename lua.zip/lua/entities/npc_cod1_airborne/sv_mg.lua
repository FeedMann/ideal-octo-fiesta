local U = COD1.AI

function ENT:MountTurret( t )
	if not IsValid( t ) or IsValid( t.User ) or IsValid( t.Gunner ) and t.Gunner ~= self and not t.Gunner.Dead then return false end
	self.WantTurret = nil
	self.Manning = t
	t.Gunner = self
	t.Claimed = nil
	self.Moving = false
	self.Crouched, self.Hiding = false, false
	self.Prone = t:Def().prone or nil
	self.loco:SetDesiredSpeed( 0 )
	self.loco:SetVelocity( vector_origin )
	self.loco:SetGravity( 0 )
	self:SetCollisionBounds( Vector( -2, -2, 0 ), Vector( 2, 2, 8 ) )
	self:SetSurroundingBoundsType( BOUNDS_HITBOXES )
	self:GunBones( vector_origin )
	self:SetPos( t:GripWorld() )
	self:SetAngles( Angle( 0, t:GetAngles().y + ( t.Yaw or 0 ), 0 ) )
	self.MGSeq = nil
	self:SetNWEntity( "COD1Turret", t )
	self:SetNWString( "COD1Role", t:Def().team == "axis" and "MG42 Gunner" or "Machine Gunner" )
	return true
end

function ENT:Dismount( keepPose )
	local t = self.Manning
	self.Manning = nil
	self.MGSeq = nil
	self:SetNWEntity( "COD1Turret", NULL )
	if IsValid( t ) then
		local feet = t:FeetWorld()
		local ground = U.groundAt( feet )
		self:SetPos( ground or feet )
		self:SetAngles( Angle( 0, t:GetAngles().y + ( t.Yaw or 0 ), 0 ) )
		if t.Gunner == self then t.Gunner = nil end
		if t.Firing then t:StopBurst() end
	end
	self.loco:SetGravity( 1000 )
	self:SetCollisionBounds( U.HULL_MINS, U.HULL_MAXS )
	self:SetSurroundingBoundsType( BOUNDS_COLLISION )
	if not self.Dead then
		self:GunBones( Vector( 1, 1, 1 ) )
		self.Prone = nil
		if not keepPose then self:PlaySeq( self:IdleSeq() ) end
	end
end

function ENT:UpdateManning()
	local t = self.Manning
	self:FrameAdvance()
	self.loco:SetVelocity( vector_origin )
	if not IsValid( t ) then
		self:Dismount()
		return
	end
	if GetConVar( "ai_disabled" ):GetBool() then
		if t.Firing then t:StopBurst() end
		self:SetPos( t:GripWorld() )
		return
	end
	self.PendingPain = nil
	local enemy = self:UpdateEnemy()
	if IsValid( enemy ) and self:CanSee( enemy ) and not t:InArc( enemy:GetPos() ) then
		self.FlankedAt = self.FlankedAt or CurTime()
		if CurTime() - self.FlankedAt > 2.5 then
			self.FlankedAt = nil
			self.LeftTurret = CurTime() + 15
			self:Dismount()
			return
		end
	else
		self.FlankedAt = nil
	end
	local yaw, pitch, firing = t:Operate( self, enemy )
	self:SetPos( t:GripWorld() )
	self:SetAngles( Angle( 0, t:GetAngles().y + yaw, 0 ) )
	local seq = t:Def().grid .. ( firing and "_fire" or "_aim" )
	if seq ~= self.MGSeq then
		self.MGSeq = seq
		local cycle = self:GetCycle()
		self:PlaySeq( seq )
		self:SetCycle( cycle % 1 )
	end
	self:SetPoseParameter( "mg_yaw", yaw )
	self:SetPoseParameter( "mg_pitch", math.Clamp( pitch * ( t:Def().pitchAnim or -1 ), -15, 15 ) )
end

function ENT:GoToTurret()
	local t = self.WantTurret
	self.WantTurret = nil
	if not IsValid( t ) or IsValid( t.User ) or IsValid( t.Gunner ) and not t.Gunner.Dead and t.Gunner.Manning == t then return end
	local spot, yaw = t:MountSpot()
	local ground = U.groundAt( spot ) or spot
	self:MoveTo( ground, self.RunSpeed, 8, function()
		return not IsValid( t ) or IsValid( t.User ) or ( IsValid( t.Gunner ) and t.Gunner ~= self and t.Gunner.Manning == t ) or self:GetPos():Distance( ground ) < 16
	end, true, true )
	if self.Dead or not IsValid( t ) or IsValid( t.Gunner ) and t.Gunner ~= self and t.Gunner.Manning == t then return end
	if self:GetPos():Distance( ground ) > 40 then return end
	self:TurnTo( self:GetPos() + Angle( 0, yaw, 0 ):Forward() * 100, 0.3 )
	self:MountTurret( t )
end

--manning the machine guns
