local U = COD1.AI
local flat, groundAt, hullClear = U.flat, U.groundAt, U.hullClear

local GOAL_RADIUS = 1500
local HUNT_RADIUS = 768
local AMBUSH_WAIT = 3

function ENT:Classic()
	return GetConVar( "cod1_npc_ai" ):GetString() == "cod1"
end

function ENT:ClassicAttacks()
	local mode = GetConVar( "cod1_npc_advance" ):GetInt()
	return mode == 1 or ( mode == 2 and not self:EnemySide() ) or ( mode == 3 and self:EnemySide() )
end

function ENT:ClassicHuntTarget()
	if CurTime() < ( self.NextHuntScan or 0 ) then return self.HuntPos end
	self.NextHuntScan = CurTime() + 5
	local now, me, bd = CurTime(), self:GetPos()
	self.HuntPos = nil
	for e, info in pairs( COD1.Intel[ self.COD1Team ] or {} ) do
		if IsValid( e ) and U.alive( e ) and now - info.t < 45 then
			local d = me:DistToSqr( info.pos )
			if not bd or d < bd then self.HuntPos, bd = info.pos, d end
		end
	end
	if not self.HuntPos then
		self.HuntPos = COD1.PatrolPoint( self )
		if self.HuntPos and me:DistToSqr( self.HuntPos ) < 300 * 300 and self.PatrolGoal then self.PatrolGoal.expires = 0 end
	end
	return self.HuntPos
end

function ENT:ClassicGoal()
	self.ClassicHome = self.ClassicHome or self:GetPos()
	if IsValid( self.Follow ) then return self.Follow:GetPos(), 256 end
	local post = self.StrongPost and self:StrongPost()
	if post then return post.pos, 360 end
	if self:ClassicAttacks() and not self.Role then
		local target = IsValid( self.Enemy ) and ( self.LastKnownPos or self.Enemy:GetPos() ) or self:ClassicHuntTarget()
		if target then return target, HUNT_RADIUS end
	end
	return self.ClassicHome, GOAL_RADIUS
end

function ENT:ClassicBadNode( n )
	local b = self.BadNodes and self.BadNodes[ n ]
	return b and b > CurTime()
end

function ENT:ClassicNodeCovers( n, from )
	local to = flat( from - n.pos )
	local d = to:Length()
	return d > U.CHARGE_RANGE and n.fwd:Dot( to / math.max( d, 1 ) ) > 0.4
end

function ENT:ClassicFindNode( enemy )
	local goal, radius = self:ClassicGoal()
	local me = self:GetPos()
	local from = self.LastKnownPos or enemy:GetPos()
	if not ( COD1.NodesReady and COD1.NodesReady() ) then
		local spot, kind = self:FindCover( self:AimPoint( enemy ), { radius = 700 } )
		if spot and spot:Distance( goal ) < radius then
			local fwd = flat( from - spot ):GetNormalized()
			return { pos = spot, fwd = fwd, yaw = fwd:Angle().y, kind = kind == "stand" and "stand" or "crouch" }, spot:Distance( me )
		end
		return
	end
	local eye = self:AimPoint( enemy )
	local best, bs
	for _, n in ipairs( COD1.NodesNear( goal, radius ) ) do
		if n.kind ~= "corner" and not self:ClassicBadNode( n ) and self:ClassicNodeCovers( n, from )
			and n.pos:Distance( from ) < 2600 and not COD1.NodeTaken( n, self ) and not U.occupied( n.pos, self, 24 ) then
			local score = n.pos:Distance( me )
			if score < 2000 and ( not bs or score - 220 < bs ) then
				local peek = n.pos + Vector( 0, 0, n.kind == "crouch" and 46 or 62 )
				if not util.TraceLine( { start = peek, endpos = eye, mask = MASK_SOLID_BRUSHONLY } ).Hit then score = score - 220 end
				if not bs or score < bs then best, bs = n, score end
			end
		end
	end
	return best, bs
end

function ENT:ClassicRelease()
	if self.ClassicNode then COD1.Cover[ self ] = nil end
	self.ClassicNode = nil
end

function ENT:ClassicAtNode( n )
	return U.near( self:GetPos(), n.pos, 40, 30 )
end

function ENT:ClassicGoToNode( n, enemy )
	self:ClassicRelease()
	self.ClassicNode = n
	COD1.Cover[ self ] = n.pos
	self.CoverType = n.kind
	if not self:ClassicAtNode( n ) then
		self:MoveTo( n.pos, self.RunSpeed, 6, nil, CurTime() < self.Suppressed )
		if self.Dead then return end
		if not self:ClassicAtNode( n ) then
			self.BadNodes = self.BadNodes or {}
			self.BadNodes[ n ] = CurTime() + 20
			self:ClassicRelease()
			return
		end
		if self:GetPos():Distance2D( n.pos ) > 8 then self:WalkTo( n.pos, 0.5 ) end
	end
	self:SetAngles( Angle( 0, n.yaw, 0 ) )
	self:Hide()
end

function ENT:ClassicWaitForAmbush( enemy, t )
	local waited = 0
	while waited < t and not self.Dead and IsValid( enemy ) and CurTime() >= self.Suppressed do
		if self:CanSee( enemy ) then return true end
		if not self:Wait( 0.25, self.LastKnownPos ) then return false end
		waited = waited + 0.25
	end
	return IsValid( enemy ) and self:CanSee( enemy )
end

function ENT:ClassicTryGrenade( enemy )
	local lkp = self.LastKnownPos or ( IsValid( enemy ) and enemy:GetPos() )
	if lkp and self:CanThrowGrenade( lkp ) then
		self:ThrowGrenade( lkp )
		return true
	end
	return false
end

function ENT:ClassicReload( fraction )
	if self.Mag <= math.floor( self.Weapon.clip * fraction ) then
		self:Reload()
		return true
	end
	return false
end

function ENT:ClassicCover( n, enemy )
	local stand = n.kind == "stand"
	local w = self.Weapon
	if self.Hiding and CurTime() < self.Suppressed then
		while CurTime() < self.Suppressed and not self.Dead and not self.PendingPain and not self.GrenadeThreat do
			self:Say( "undersuppression", 0.3 )
			self:PlaySeq( self.VariantData.medic and "medic_hide" or U.HIDE_IDLES[ math.random( #U.HIDE_IDLES ) ] )
			if not self:Wait( math.Rand( 0.8, 1.6 ) ) then return end
			self:ClassicTryGrenade( enemy )
		end
		return
	end
	if self.Mag > 0 and CurTime() >= self.Suppressed then
		self:SetStance( not stand )
		self:TurnTo( self.LastKnownPos or enemy:GetPos(), 0.5 )
		if self.Dead or not IsValid( enemy ) then return end
		self:PlaySeq( stand and "aim" or "crouch_aim" )
		self:Wait( self:AimTime(), enemy )
		if self:ClassicWaitForAmbush( enemy, AMBUSH_WAIT ) then
			if not self:ShootVolley( enemy ) then self:Wait( 0.1, enemy ) end
			if stand then
				COD1.CoverStandShots = ( COD1.CoverStandShots or 0 ) + 1
				if COD1.CoverStandShots > 10 then
					COD1.CoverStandShots = 0
					self:ShootVolley( enemy )
				end
				self:ClassicTryGrenade( enemy )
			end
		elseif stand and w.auto and math.random() < 0.7 and self.LastKnownPos and CurTime() - self.LastSeen < 10 then
			while self.Mag > 0 and not self.Dead and not self.PendingPain and not self.GrenadeThreat and CurTime() >= self.Suppressed do
				self:Say( "doingsuppression", 0.5 )
				self:Wait( math.Rand( 0.2, 0.9 ), self.LastKnownPos )
				if not self:Suppress( self.LastKnownPos ) then break end
				self:ClassicTryGrenade( enemy )
			end
		end
		if self.Dead then return end
	end
	local suppressed = CurTime() < self.Suppressed
	local duck
	if stand then
		duck = not ( self:EnemySide() and not suppressed and math.random() > 0.5 )
	else
		duck = not self:EnemySide() or suppressed or math.random() < 0.5
	end
	if duck then
		self:Hide()
		self:ClassicTryGrenade( enemy )
		self:ClassicReload( 0.2 )
		if self.NeedRechamber then self:Rechamber( enemy ) end
		if not self.Dead and CurTime() >= self.Suppressed then
			self:PlaySeq( U.HIDE_IDLES[ math.random( #U.HIDE_IDLES ) ] )
			self:Wait( math.Rand( 0.4, 1.0 ) )
		end
	else
		self:ClassicTryGrenade( enemy )
		self:ClassicReload( 0.2 )
	end
end

function ENT:ClassicMeleeCharge( enemy )
	if math.random() >= 0.5 then return false end
	self.Charging = enemy
	self:Say( "meleecharge", 0.8 )
	self:MoveTo( enemy:GetPos(), 230, 1.2, function() return not IsValid( enemy ) or self:GetPos():Distance( enemy:GetPos() ) < 70 end, nil, true )
	self.Charging = nil
	if IsValid( enemy ) and self:GetPos():Distance( enemy:GetPos() ) < 85 then self:Melee( enemy ) end
	return true
end

function ENT:ClassicExposed( enemy, dist )
	if self.Prone and dist < U.PRONE_RANGE * 0.8 then self:LeaveProne() end
	if self:ClassicReload( 0 ) then return end
	if dist <= U.BACKPEDAL_RANGE and dist > U.MELEE_RANGE and self:Backpedal( enemy ) then return end
	if dist > ( self.Weapon.proneRange or U.PRONE_RANGE ) and self.WeaponType ~= "pistol" and not self:IsHurt() and self:CanShootFrom( "prone", enemy ) then
		return self:ProneCombat( enemy )
	end
	local stance
	if dist < U.STAND_RANGE then
		stance = self:CanShootFrom( "stand", enemy ) and "stand" or self:CanShootFrom( "crouch", enemy ) and "crouch"
	else
		stance = self:CanShootFrom( "crouch", enemy ) and "crouch" or self:CanShootFrom( "stand", enemy ) and "stand"
	end
	if not stance then
		if self:EnemySide() and self:TrySideStep( enemy, true ) then return end
		self:TurnTo( enemy:GetPos(), 0.5 )
		self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
		self:Wait( 0.1, enemy )
		self:ClassicTryGrenade( enemy )
		return
	end
	self:SetStance( stance == "crouch" )
	self:TurnTo( enemy:GetPos(), 0.8 )
	if self.Dead or not IsValid( enemy ) then return end
	self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
	self:Wait( self:AimTime(), enemy )
	if stance == "stand" and self:EnemySide() and dist < U.DODGE_RANGE then
		local chance = ( U.DODGE_RANGE ^ 2 - dist ^ 2 ) / ( U.DODGE_RANGE ^ 2 - U.MELEE_RANGE ^ 2 )
		if math.random() < chance then self:TrySideStep( enemy, true ) end
	end
	if self.Dead or not IsValid( enemy ) then return end
	self:ShootVolley( enemy )
	if self.Dead then return end
	self:ClassicTryGrenade( enemy )
end

function ENT:ClassicReacquire( enemy )
	local lkp = self.LastKnownPos or enemy:GetPos()
	local since = CurTime() - self.LastSeen
	if self.Prone and since > 3 then self:LeaveProne() end
	if since < 8 and self:ClassicTryGrenade( enemy ) then return end
	local goal, radius = self:ClassicGoal()
	local spot = self:SquadSpot( lkp )
	if since > 1.5 and spot:Distance( goal ) < radius and spot:Distance( self:GetPos() ) > 48 then
		local t0 = CurTime()
		self:MoveTo( spot, self.RunSpeed, 3, function() return IsValid( enemy ) and self:CanSee( enemy ) end, CurTime() < self.Suppressed )
		if CurTime() - t0 > 0.3 or self.Dead then return end
	end
	self:SetStance( self.Crouched )
	self:TurnTo( lkp, 0.5 )
	self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
	self:Wait( math.Rand( 0.5, 1.0 ), lkp )
end

function ENT:ClassicCombat( enemy )
	local visible = self:CanSee( enemy )
	if visible then
		self.LastSeen = CurTime()
		self.LastKnownPos = enemy:GetPos()
	end
	local dist = self:GetPos():Distance( enemy:GetPos() )
	if self.RoleCombat and self:RoleCombat( enemy, visible, dist ) then return end
	if self.NoGun then return self:UnarmedCombat( enemy, visible, dist ) end
	if self:TryFlagPickup() then return end
	if visible and dist <= U.MELEE_RANGE + 10 then return self:Melee( enemy ) end
	if visible and dist <= U.CHARGE_RANGE and not self.Prone and self:OkToMelee( enemy ) and self:ClassicMeleeCharge( enemy ) then return end

	if self.Corner then
		if self.AtCorner and self:CornerStillGood( enemy, visible, dist ) then return self:CornerFight( enemy ) end
		self:LeaveCorner( true )
	end
	local n = self.ClassicNode
	if n then
		local from = self.LastKnownPos or enemy:GetPos()
		local goal, radius = self:ClassicGoal()
		if self:ClassicAtNode( n ) and self:ClassicNodeCovers( n, from ) and n.pos:Distance( goal ) < radius + 200
			and CurTime() - self.LastSeen < 12 then
			return self:ClassicCover( n, enemy )
		end
		self:ClassicRelease()
	end
	if CurTime() >= ( self.NextNodeSearch or 0 ) then
		self.NextNodeSearch = CurTime() + math.Rand( 1.2, 2 )
		local wall, ws = self:ClassicFindNode( enemy )
		local corner = ( COD1.NodesReady and COD1.NodesReady() ) and self:FindCorner( enemy, { radius = 900 } )
		local goal, radius = self:ClassicGoal()
		if corner and corner.pos:Distance( goal ) > radius then corner = nil end
		if corner and ( not wall or self:GetPos():Distance( corner.pos ) < ws ) then
			if self:TakeCorner( enemy, { radius = 900 } ) then return end
		elseif wall then
			return self:ClassicGoToNode( wall, enemy )
		end
	end
	if not visible then return self:ClassicReacquire( enemy ) end
	return self:ClassicExposed( enemy, dist )
end

function ENT:ClassicIdle()
	local goal, radius = self:ClassicGoal()
	if not IsValid( self.Follow ) and not self.Unarmed and goal then
		local d = self:GetPos():Distance( goal )
		if self:ClassicAttacks() and self.HuntPos and goal == self.HuntPos and d > 128 then
			self:MoveTo( self:SquadSpot( goal ), self.RunSpeed, 5, function() return IsValid( self:UpdateEnemy() ) end )
			return true
		end
		if d > radius then
			self:MoveTo( goal, self.RunSpeed, 6, function() return IsValid( self:UpdateEnemy() ) end )
			return true
		end
	end
	return false
end

--the old school cod1 ai, take cover and fight
