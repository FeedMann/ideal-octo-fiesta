local U = COD1.AI
local flat, groundAt = U.flat, U.groundAt

local COMMISSAR_SPEECHES = { "com_52", "com_50", "com_51b", "com_41", "com_51", "com_49", "com_building" }
local MEGA_SPEECH = { "mega_42", "mega_43", "mega_44" }
local MEGA_SHOUTS = { "mega_shout_a", "mega_shout_b", "mega_shout_c" }
local SHOTS = { com_40 = { 25 / 30, 41 / 30, 50 / 30 }, com_building = { 44 / 30, 48 / 30 } }
local SHOUT_EVENTS = { enemysighted = true, misccombat = true, doingsuppression = true, undersuppression = true, coverme = true,
	flankleft = true, flankright = true, meleecharge = true, giveupposition = true, grenadedanger = true }
local CHARGE_EVENTS = { enemysighted = true, misccombat = true, meleecharge = true }

function ENT:Inspired()
	if self.HasFlag then return true end
	if CurTime() < ( self.InspiredCheck or 0 ) then return self.IsInspired end
	self.InspiredCheck = CurTime() + 1
	self.IsInspired = false
	for _, s in ipairs( U.teammates( self, 700 ) ) do
		if s.HasFlag or s.Role == "commissar" or s.Role == "megaphone" then
			self.IsInspired = true
			break
		end
	end
	return self.IsInspired
end

function ENT:RoleLine( event )
	local r = self.Role
	if r == "commissar" or r == "megaphone" then
		if event == "pain" and COD1.CommissarPain then return COD1.CommissarPain[ math.random( #COD1.CommissarPain ) ] end
		if event == "death" and COD1.CommissarDeath then return COD1.CommissarDeath[ math.random( #COD1.CommissarDeath ) ] end
		if SHOUT_EVENTS[ event ] and COD1.CommissarShouts then
			local s = COD1.CommissarShouts[ math.random( #COD1.CommissarShouts ) ]
			return s.snd
		end
		return false
	end
	if r == "flag" and CHARGE_EVENTS[ event ] and COD1.CommissarCharge and self.VoiceNat == "russian" then
		return COD1.CommissarCharge[ math.random( #COD1.CommissarCharge ) ]
	end
end

function ENT:FlagCry()
	local lines = COD1.CommissarCharge
	if self.VoiceNat ~= "russian" or not lines or #lines == 0 or CurTime() < self.NextTalk then return end
	self:SpeakLine( lines[ math.random( #lines ) ], 95 )
end

function ENT:TakeFlag()
	local g = self.VariantData.flagGroup
	if not g then return end
	self.HasFlag = true
	self.Unarmed = true
	self.Role = "flag"
	self.Grenades = 0
	self.Crouched = false
	self.Hiding = false
	self:SetGroup( "weapon", g )
	self:SetNWString( "COD1Role", "Flag Bearer" )
end

function ENT:DropFlag( physics )
	if not self.HasFlag then return end
	self.HasFlag = false
	self:SetGroup( "weapon", self.VariantData.blankWeapon or 0 )
	local att = self:GetAttachment( self:LookupAttachment( "anim_attachment_RH" ) )
	local flag = ents.Create( "prop_physics" )
	if not IsValid( flag ) then return end
	local pos = att and att.Pos or self:GetPos()
	local ground = util.TraceLine( { start = pos + Vector( 0, 0, 48 ), endpos = pos - Vector( 0, 0, 200 ), mask = MASK_SOLID_BRUSHONLY } )
	if ground.Hit then pos.z = math.max( pos.z, ground.HitPos.z + 30 ) end
	flag:SetModel( "models/cod1/props/sov_flag.mdl" )
	flag:SetPos( pos )
	flag:SetAngles( Angle( -90, ( att and att.Ang.y or self:GetAngles().y ) + math.Rand( -30, 30 ), 0 ) )
	flag:Spawn()
	flag:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
	local phys = flag:GetPhysicsObject()
	if IsValid( phys ) then
		phys:Wake()
		if physics then phys:SetVelocity( self:GetVelocity() * 0.5 ) end
		timer.Simple( 4, function()
			if IsValid( flag ) and IsValid( flag:GetPhysicsObject() ) and not flag.Claimant then flag:GetPhysicsObject():EnableMotion( false ) end
		end )
	end
	COD1.DroppedFlags[ flag ] = { team = self.COD1Team, at = CurTime() }
	flag:CallOnRemove( "COD1Flag", function( e ) COD1.DroppedFlags[ e ] = nil end )
end

function ENT:DropMegaphone()
	if self.Role ~= "megaphone" or self.DroppedProp then return end
	self.DroppedProp = true
	self:SetGroup( "weapon", self.VariantData.blankWeapon or 0 )
	self:SetGroup( "left", 0 )
	local att = self:GetAttachment( self:LookupAttachment( "anim_attachment_RH" ) )
	if not att then return end
	local m = ents.Create( "prop_physics" )
	if not IsValid( m ) then return end
	m:SetModel( "models/cod1/props/sov_megaphone.mdl" )
	m:SetPos( att.Pos )
	m:SetAngles( att.Ang )
	m:Spawn()
	m:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
	local phys = m:GetPhysicsObject()
	if IsValid( phys ) then phys:SetVelocity( self:GetForward() * 60 + Vector( 0, 0, 40 ) ) end
	SafeRemoveEntityDelayed( m, 120 )
end

function ENT:CanCarryFlag()
	local v = self.VariantData
	return v.flagGroup and not self.HasFlag and not self.Role and not v.fixedName and not v.medic and self:LookupSequence( "flag_pickup" ) >= 0
end

function ENT:TryFlagPickup()
	if CurTime() < ( self.NextFlagLook or 0 ) then return false end
	self.NextFlagLook = CurTime() + 1
	if not next( COD1.DroppedFlags ) or not self:CanCarryFlag() then return false end
	for _, s in ipairs( U.teammates( self, 1500 ) ) do
		if s.HasFlag or IsValid( s.ClaimedFlag ) then return false end
	end
	local best, bd
	for f, info in pairs( COD1.DroppedFlags ) do
		if IsValid( f ) and info.team == self.COD1Team and not IsValid( f.Claimant ) and CurTime() - info.at > 1.5 then
			local d = f:GetPos():DistToSqr( self:GetPos() )
			if d < 900 * 900 and ( not bd or d < bd ) then best, bd = f, d end
		end
	end
	if not best then return false end
	return self:PickUpFlag( best )
end

function ENT:PickUpFlag( flag )
	flag.Claimant = self
	self.ClaimedFlag = flag
	local fp = flag:GetPos()
	local hand = COD1.FlagPickup and COD1.FlagPickup.hand or Vector( 16, 18, 0 )
	local from = flat( fp - self:GetPos() )
	if from:LengthSqr() < 1 then from = self:GetForward() end
	local ang = Angle( 0, from:Angle().y, 0 )
	local start = fp - ang:Forward() * hand.x + ang:Right() * hand.y
	start = groundAt( start ) or start
	local function lost() return not IsValid( flag ) or flag.Claimant ~= self end
	self:MoveTo( start, self.RunSpeed, 6, lost, nil, true )
	if self.Dead or lost() or self:GetPos():Distance2D( start ) > 40 then
		if IsValid( flag ) and flag.Claimant == self then flag.Claimant = nil end
		self.ClaimedFlag = nil
		return true
	end
	self:WalkTo( start, 0.5 )
	self:SetAngles( ang )
	self.Crouched, self.Hiding = false, false
	self:SetGroup( "weapon", self.VariantData.blankWeapon or 0 )
	local t = COD1.FlagPickup and COD1.FlagPickup.time or 0.27
	local took = false
	local function take()
		if took then return end
		took = true
		if IsValid( flag ) then flag:Remove() end
		self:TakeFlag()
	end
	self:PlayMotion( "flag_pickup", nil, nil, function( el ) if el >= t then take() end end )
	self.ClaimedFlag = nil
	if self.Dead then return true end
	take()
	self:FlagCry()
	return true
end

function ENT:FlagAdvance( enemy )
	local lkp = self.LastKnownPos or enemy:GetPos()
	local me = self:GetPos()
	local to = flat( lkp - me )
	local dist = to:Length()
	if dist > 450 and CurTime() >= ( self.FlagRestUntil or 0 ) then
		to:Normalize()
		local step = math.min( dist - 380, math.Rand( 350, 600 ) )
		local goal = groundAt( me + to * step + to:Angle():Right() * math.Rand( -150, 150 ) ) or ( me + to * step )
		if math.random() < 0.6 then self:FlagCry() end
		self:MoveTo( goal, self.RunSpeed, 4, nil, false, true )
		self.FlagRestUntil = CurTime() + math.Rand( 2, 4 )
		return true
	end
	if not self.Crouched then self:SetStance( true ) end
	self:PlaySeq( math.random() < 0.3 and "flag_crouch_twitch" or "flag_crouch" )
	self:Wait( math.Rand( 1.5, 3 ), lkp )
	return true
end

function ENT:Speech( name, face )
	local sp = COD1.Speeches and COD1.Speeches[ name ]
	local dur = self:PlaySeq( name )
	if dur <= 0 then return false end
	if face then self.loco:FaceTowards( face ) end
	local said = not sp
	local shots = SHOTS[ name ]
	local nextShot = 1
	local t0 = CurTime()
	while CurTime() - t0 < dur and not self.Dead and not self.PendingPain and not self.GrenadeThreat do
		local el = CurTime() - t0
		if not said and el >= sp.at then
			said = true
			self:SpeakLine( sp.snd, self.Role == "megaphone" and 100 or 90 )
		end
		if shots and shots[ nextShot ] and el >= shots[ nextShot ] then
			nextShot = nextShot + 1
			if self.WeaponKey == "luger" and self.Mag > 0 then
				local enemy = self.Enemy
				local aim = IsValid( enemy ) and math.abs( self:FacingDelta( enemy:GetPos() ) ) < 35 and self:AimPoint( enemy )
				self:FireAt( aim or ( self:MuzzlePos() + self:GetForward() * 600 + Vector( 0, 0, -20 ) ), aim and enemy or nil )
			end
		end
		coroutine.yield()
	end
	return true
end

function ENT:Listeners( radius )
	local me, r2 = self:GetPos(), radius * radius
	local sum, n = Vector(), 0
	for _, s in ipairs( U.teammates( self, radius ) ) do
		sum = sum + s:GetPos()
		n = n + 1
	end
	for _, p in ipairs( player.GetAll() ) do
		if p:Alive() and not self:IsHostileTo( p ) and p:GetPos():DistToSqr( me ) < r2 then
			sum = sum + p:GetPos()
			n = n + 1
		end
	end
	if n == 0 then return nil end
	return sum / n
end

function ENT:CommissarIdle()
	if CurTime() < ( self.NextSpeech or 0 ) then return false end
	local center = self:Listeners( 900 )
	if not center then
		self.NextSpeech = CurTime() + 3
		return false
	end
	self:TurnTo( center, 0.6 )
	self:Speech( COMMISSAR_SPEECHES[ math.random( #COMMISSAR_SPEECHES ) ] )
	self.NextSpeech = CurTime() + math.Rand( 7, 14 )
	return true
end

function ENT:MegaphoneIdle( enemy )
	local center = IsValid( enemy ) and ( self.LastKnownPos or enemy:GetPos() ) or self:Listeners( 1200 )
	if center then self:TurnTo( center, 0.5 ) end
	if not IsValid( enemy ) and center and CurTime() >= ( self.NextLongSpeech or 0 ) then
		self.NextLongSpeech = CurTime() + math.Rand( 50, 80 )
		for _, name in ipairs( MEGA_SPEECH ) do
			if not self:Speech( name ) or IsValid( self.Enemy ) then break end
		end
		return true
	end
	local seq = MEGA_SHOUTS[ math.random( #MEGA_SHOUTS ) ]
	local dur = self:PlaySeq( seq )
	if center and CurTime() >= self.NextTalk and COD1.CommissarShouts then
		local s = COD1.CommissarShouts[ math.random( #COD1.CommissarShouts ) ]
		self:SpeakLine( s.snd, 100 )
	end
	self:Wait( math.max( dur, 1 ) )
	if not IsValid( self.Enemy ) then
		self:PlaySeq( "idle" )
		self:Wait( math.Rand( 1, 3 ) )
	end
	return true
end

function ENT:RoleCombat( enemy, visible, dist )
	local r = self.Role
	if r == "flag" then return self:FlagAdvance( enemy ) end
	if r == "megaphone" then return self:MegaphoneIdle( enemy ) end
	if r == "commissar" then
		if visible and dist < 900 and dist > 150 and self.Mag >= 3 and math.random() < 0.18 and CurTime() >= ( self.NextTraitor or 0 ) then
			self.NextTraitor = CurTime() + 12
			if self.Crouched or self.Hiding then self:SetStance( false ) end
			self:TurnTo( enemy:GetPos(), 0.5 )
			return self:Speech( "com_40" )
		end
		if not visible and CurTime() >= ( self.NextSpeech or 0 ) and self:Listeners( 700 ) then
			self.NextSpeech = CurTime() + math.Rand( 10, 18 )
			return self:Speech( math.random() < 0.5 and "com_52" or "com_51" )
		end
	end
	return false
end

function ENT:RoleIdle()
	local r = self.Role
	if r == "commissar" then return self:CommissarIdle() end
	if r == "megaphone" then return self:MegaphoneIdle() end
	return false
end

function ENT:FindPatient()
	local lull = self:Lull()
	local range = lull and 3000 or 1200
	local best, bestDist = nil, range * range
	local function consider( e, hp, max )
		local d = e.Downed
		if d and ( d.phase ~= "lying" and d.phase ~= "rescued" or IsValid( d.rescuer ) or d.pow ) then return end
		if hp < max * 0.75 and not IsValid( e.BeingHealed ) then
			local d = e:GetPos():DistToSqr( self:GetPos() )
			if d < bestDist then best, bestDist = e, d end
		end
	end
	for _, s in ipairs( U.teammates( self, range ) ) do consider( s, s:Health(), s:GetMaxHealth() ) end
	if lull and self:Geneva() then
		for e in pairs( COD1.Downed ) do
			if IsValid( e ) and e.COD1Team ~= self.COD1Team and not self:EasternFront( e ) then consider( e, e:Health(), e:GetMaxHealth() ) end
		end
	end
	if not self:EnemySide() then
		for _, p in ipairs( player.GetAll() ) do
			if p:Alive() and not self:IsHostileTo( p ) then consider( p, p:Health(), p:GetMaxHealth() ) end
		end
	end
	return best
end

function ENT:MedicWork()
	if CurTime() < ( self.NextPatientCheck or 0 ) or CurTime() < self.Suppressed then return false end
	self.NextPatientCheck = CurTime() + 1
	local p = self:FindPatient()
	if not p then return false end
	local d = p.Downed
	if d and not d.safe and d.phase == "lying" and p.COD1Team == self.COD1Team then
		d.rescuer = self
		self.WantRescue = p
		self:GoRescue()
		return true
	end
	p.BeingHealed = self
	self.MedicBusy = true
	local function alive() return U.alive( p ) end
	self:MoveTo( p:GetPos(), self.RunSpeed, 6, function()
		return not alive() or self:GetPos():Distance( p:GetPos() ) < 70 or CurTime() < self.Suppressed
	end, true, true )
	if alive() and not self.Dead and self:GetPos():Distance( p:GetPos() ) < 90 and CurTime() >= self.Suppressed then
		self:Treat( p )
	end
	self.MedicBusy = nil
	if IsValid( p ) and p.BeingHealed == self then p.BeingHealed = nil end
	return true
end

--who does what, riflemen, gunners, officers
