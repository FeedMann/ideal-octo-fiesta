local U = COD1.AI

COD1.Gunfire = COD1.Gunfire or {}
COD1.GenevaBroken = COD1.GenevaBroken or {}

local SEEN, FORFEIT, BROKEN = 4000, 20, 120
local QUIET_RANGE, QUIET_TIME = 2500, 25
local FAR = 1500
local GUARD_RANGE, FREE_AFTER = 1500, 8
local EYE = Vector( 0, 0, 60 )
local SIDE_NAME = { allies = "The Allies", axis = "The Germans" }

function COD1.NoteGunfire( pos )
	local g = COD1.Gunfire
	g[ #g + 1 ] = { pos = pos, t = CurTime() }
	if #g > 96 then table.remove( g, 1 ) end
end

function COD1.Quiet( pos, range, secs )
	local now, r2, g = CurTime(), range * range, COD1.Gunfire
	for i = #g, 1, -1 do
		local s = g[ i ]
		if now - s.t > secs then break end
		if s.pos:DistToSqr( pos ) < r2 then return false end
	end
	return true
end

hook.Add( "EntityFireBullets", "COD1Gunfire", function( ent )
	if IsValid( ent ) and ent:IsPlayer() then COD1.NoteGunfire( ent:GetPos() ) end
end )

function COD1.BreakGeneva( side, ply )
	local was = ( COD1.GenevaBroken[ side ] or 0 ) > CurTime()
	COD1.GenevaBroken[ side ] = CurTime() + BROKEN
	if was or not IsValid( ply ) then return end
	local other = SIDE_NAME[ side == "allies" and "axis" or "allies" ]
	ply:ChatPrint( other .. " saw you fire on a medic. They won't spare your medics for the next two minutes." )
end

function ENT:Geneva()
	return self.VariantData.medic and GetConVar( "cod1_geneva" ):GetBool()
end

function ENT:RedCross()
	return self:Geneva() and not self.Surrendered and CurTime() - ( self.LastFired or -1e9 ) > FORFEIT
		and ( COD1.GenevaBroken[ self.COD1Team ] or 0 ) < CurTime()
end

function ENT:Soviet()
	return string.find( self.VariantData.model, "/russian/", 1, true ) ~= nil
end

function ENT:EasternFront( ent )
	return ( self:Soviet() and ent.COD1Team == "axis" ) or ( self.COD1Team == "axis" and ent.Soviet and ent:Soviet() )
end

function ENT:Spares( ent )
	return ent.IsCOD1Soldier and ent.RedCross and ent:RedCross() and not self:EasternFront( ent )
		and self:GetPos():DistToSqr( ent:GetPos() ) < SEEN * SEEN
end

function ENT:HoldsFire( ent )
	if not self:Geneva() then return false end
	if ent.IsCOD1Soldier and ent.Enemy == self then return false end
	return not ( ent:IsPlayer() and ( self.Grudges[ ent ] or 0 ) > CurTime() )
end

function ENT:Lull()
	return GetConVar( "cod1_geneva" ):GetBool() and CurTime() - self.LastSeen > QUIET_TIME
		and COD1.Quiet( self:GetPos(), QUIET_RANGE, QUIET_TIME )
end

function ENT:MedicShotAt( att )
	if not ( IsValid( att ) and att:IsPlayer() and self:RedCross() ) then return end
	local side = COD1.PlayerSide()
	if side ~= self.COD1Team then COD1.BreakGeneva( side, att ) end
end

function ENT:POWFreed()
	local d = self.Downed
	if not ( d and d.pow and d.phase == "lying" ) or not self:Unguarded() then return end
	d.pow, d.safe = nil, nil
	d.recoverAt = CurTime() + math.Rand( 4, 10 )
	self.Unarmed = self.PreSurrender and self.PreSurrender.unarmed or nil
	self:ShowWeapon( true )
	self.UnguardedSince = nil
end

function ENT:BecomePOW()
	local d = self.Downed
	if not d then return end
	d.pow, d.safe, d.rescuer = true, true, nil
	d.recoverAt = math.huge
	self.PreSurrender = { unarmed = self.Unarmed }
	self.UnguardedSince = nil
	self.Unarmed = true
	self:ShowWeapon( false )
end

function ENT:Threat()
	return U.alive( self ) and not ( self.Dead or self.Downed or self.Surrendered or self.Unarmed or self:Geneva() )
end

function ENT:WatchedBy()
	local out = {}
	for s in pairs( COD1.Soldiers ) do
		if s.COD1Team ~= self.COD1Team and s:Threat()
			and s:GetPos():DistToSqr( self:GetPos() ) < SEEN * SEEN and s:CanSee( self ) then
			out[ #out + 1 ] = s
		end
	end
	for _, p in ipairs( player.GetAll() ) do
		if self:IsHostileTo( p ) and p:GetPos():DistToSqr( self:GetPos() ) < SEEN * SEEN and self:CanSee( p ) then out[ #out + 1 ] = p end
	end
	return out
end

function ENT:Cornered( radius )
	for _, s in ipairs( U.teammates( self, 800 ) ) do
		if not ( s.Downed or s.Surrendered or s.Unarmed or s.VariantData.medic ) then return false end
	end
	local me, r2 = self:GetPos(), radius * radius
	for s in pairs( COD1.Soldiers ) do
		if s.COD1Team ~= self.COD1Team and s:Threat() and s:GetPos():DistToSqr( me ) < r2 then return true end
	end
	for _, p in ipairs( player.GetAll() ) do
		if self:IsHostileTo( p ) and p:GetPos():DistToSqr( me ) < r2 then return true end
	end
	return false
end

function ENT:PrisonerSeq( name, fallback )
	return self:LookupSequence( name ) >= 0 and name or fallback
end

function ENT:Guarded( radius )
	local me, r2 = self:GetPos(), radius * radius
	for s in pairs( COD1.Soldiers ) do
		if s.COD1Team ~= self.COD1Team and s:Threat() and s:GetPos():DistToSqr( me ) < r2 then return true end
	end
	if COD1.PlayerSide() ~= self.COD1Team then
		for _, p in ipairs( player.GetAll() ) do
			if p:Alive() and p:GetPos():DistToSqr( me ) < r2 then return true end
		end
	end
	return false
end

function ENT:Unguarded()
	if CurTime() < ( self.NextGuardCheck or 0 ) then return false end
	self.NextGuardCheck = CurTime() + 1
	local rescued = false
	for _, f in ipairs( U.teammates( self, 2000 ) ) do
		if f:Threat() then rescued = true break end
	end
	if self:Guarded( rescued and GUARD_RANGE or GUARD_RANGE * 2.5 ) then
		self.UnguardedSince = nil
		return false
	end
	self.UnguardedSince = self.UnguardedSince or CurTime()
	return CurTime() - self.UnguardedSince >= FREE_AFTER
end

function ENT:Freed()
	local pre = self.PreSurrender or {}
	self.Surrendered, self.Interned, self.MarchTo, self.Captor, self.HoldSpot = nil, nil, nil, nil, nil
	self.UnguardedSince, self.PreSurrender = nil, nil
	self.Unarmed, self.NoGun = pre.unarmed, pre.nogun
	self.WalkSeq, self.RunSeq = pre.walk, pre.run
	if not pre.hidden then self:ShowWeapon( true ) end
	self:RemoveFlags( FL_NOTARGET )
	self:SetNWString( "COD1Role", pre.role or "" )
	self.Crouched = false
	self.ShakenUntil = CurTime() + 3
	self:PlaySeq( self:IdleSeq() )
end

function ENT:Surrender()
	self.PreSurrender = { unarmed = self.Unarmed, nogun = self.NoGun, walk = self.WalkSeq, run = self.RunSeq,
		hidden = self.WeaponHidden, role = self:GetNWString( "COD1Role" ) }
	self.UnguardedSince = nil
	self.Surrendered = true
	self.Enemy, self.Moving = nil, false
	self.Unarmed, self.NoGun = true, true
	self:ShowWeapon( false )
	self:AddFlags( FL_NOTARGET )
	self.loco:SetDesiredSpeed( 0 )
	self:SetNWString( "COD1Role", "Prisoner" )
	self.Crouched = true
	self.WalkSeq = self:PrisonerSeq( "ua_walk_cower", "walk" )
	self.RunSeq = self.WalkSeq
	self:PlaySeq( self:PrisonerSeq( "ua_cower", self:PrisonerSeq( "medic_hide", "crouch_idle" ) ) )
end

function ENT:PrisonerIdle()
	if self:Unguarded() then
		self:Freed()
		return
	end
	local dest = self.MarchTo
	if dest and IsValid( self.Captor ) then
		if self:GetPos():Distance2D( dest ) > 40 then
			self.Crouched = false
			self:MoveTo( dest, self.WalkSpeed, 2, function()
				return not IsValid( self.Captor ) or self:GetPos():Distance2D( dest ) < 30
			end, false, true )
			return
		end
		self.MarchTo, self.Interned = nil, true
		self.HoldSpot = self:GetPos()
		self:TurnTo( self:GetPos() + ( self:GetPos() - self.Captor:GetPos() ), 1 )
	end
	if not self.MarchTo and self:PrisonerTreats() then return end
	self.Crouched = true
	local seq = self.Interned and self:PrisonerSeq( "ua_crouch_idle", "crouch_idle" )
		or self:PrisonerSeq( "ua_cower", self:PrisonerSeq( "medic_hide", "crouch_idle" ) )
	if self:GetSequenceName( self:GetSequence() ) ~= seq or self:GetCycle() >= 0.98 then self:PlaySeq( seq ) end
	self:Wait( 1 )
end

function ENT:PrisonerPatient()
	local me, best, bd = self:GetPos(), nil, 1200 * 1200
	for e in pairs( COD1.Soldiers ) do
		if e.COD1Team ~= self.COD1Team and IsValid( e ) and not e.Dead and not e.Surrendered and not IsValid( e.BeingHealed ) and not self:EasternFront( e ) then
			local d = e.Downed
			local lying = d and d.phase == "lying" and not d.pow and not IsValid( d.rescuer )
			if ( lying or not d ) and e:Health() < e:GetMaxHealth() * 0.75 then
				local dist = e:GetPos():DistToSqr( me )
				if dist < bd then best, bd = e, dist end
			end
		end
	end
	return best
end

function ENT:PrisonerTreats()
	if not self:Geneva() or CurTime() < ( self.NextPatientCheck or 0 ) then return false end
	self.NextPatientCheck = CurTime() + 2
	if not COD1.Quiet( self:GetPos(), QUIET_RANGE, 10 ) then return false end
	local p = self:PrisonerPatient()
	if not p then return false end
	p.BeingHealed = self
	self.Crouched = false
	self:MoveTo( p:GetPos(), self.WalkSpeed, 20, function()
		return not U.alive( p ) or self:GetPos():Distance( p:GetPos() ) < 70
	end, false, true )
	if U.alive( p ) and not self.Dead and self:GetPos():Distance( p:GetPos() ) < 90 then self:Treat( p ) end
	if IsValid( p ) and p.BeingHealed == self then p.BeingHealed = nil end
	local home = self.HoldSpot
	if home and not self.Dead and self:GetPos():Distance2D( home ) > 40 then
		self:MoveTo( home, self.WalkSpeed, 20, function() return self:GetPos():Distance2D( home ) < 30 end, false, true )
	end
	return true
end

COD1.PrisonPoints = COD1.PrisonPoints or {}

function COD1.PrisonPoint( captor, p )
	local team = captor.COD1Team
	local held = 0
	for s in pairs( COD1.Soldiers ) do
		if s.Surrendered and not s.Dead and s.COD1Team ~= team and ( s.Interned or s.MarchTo ) then held = held + 1 end
	end
	local base = COD1.PrisonPoints[ team ]
	if not base or held == 0 then
		local sum, n = Vector( 0, 0, 0 ), 0
		for s in pairs( COD1.Soldiers ) do
			if s.COD1Team == team and not s.Dead and not s.Downed then sum = sum + s:GetPos() n = n + 1 end
		end
		local c = n > 0 and sum / n or captor:GetPos()
		local away = U.flat( c - p:GetPos() )
		away = away:LengthSqr() > 1 and away:GetNormalized() or -captor:GetForward()
		base = U.groundAt( c + away * 450 ) or ( c + away * 450 )
		COD1.PrisonPoints[ team ] = base
	end
	local a = held * 1.1
	local spot = base + Vector( math.cos( a ), math.sin( a ), 0 ) * ( held > 0 and 45 + held * 8 or 0 )
	return U.groundAt( spot ) or spot
end

function ENT:TakePrisoner()
	if self.VariantData.medic or self.Role or self.Unarmed or self.Surrendered or CurTime() < ( self.NextPrisonerCheck or 0 ) then return false end
	self.NextPrisonerCheck = CurTime() + 2
	if CurTime() - self.LastSeen < 10 then return false end
	local me, best, bd = self:GetPos(), nil, 2500 * 2500
	for s in pairs( COD1.Soldiers ) do
		if s.Surrendered and not s.Interned and not s.Dead and s.COD1Team ~= self.COD1Team and not IsValid( s.Captor ) then
			local d = s:GetPos():DistToSqr( me )
			if d < bd then best, bd = s, d end
		end
	end
	if not best then return false end
	self:Escort( best )
	return true
end

function ENT:Escort( p )
	p.Captor = self
	local function ok() return IsValid( p ) and not p.Dead and p.Surrendered and p.Captor == self and not self.Dead end
	local function release() if IsValid( p ) and p.Captor == self then p.Captor, p.MarchTo = nil, nil end end
	self:MoveTo( p:GetPos(), self.RunSpeed, 15, function() return not ok() or self:GetPos():Distance( p:GetPos() ) < 130 end, false, true )
	if not ok() or self:GetPos():Distance( p:GetPos() ) > 200 then release() return end
	self:TurnTo( p:GetPos(), 0.6 )
	self:Wait( 1, p )
	if not ok() then release() return end
	p.MarchTo = COD1.PrisonPoint( self, p )
	local give = CurTime() + 60
	while ok() and p.MarchTo and CurTime() < give do
		local back = p:GetPos() - p.MarchTo
		back = U.flat( back ):LengthSqr() > 1 and U.flat( back ):GetNormalized() or -p:GetForward()
		local behind = p:GetPos() + back * 110
		if self:GetPos():Distance2D( behind ) > 60 then
			self:MoveTo( behind, self.WalkSpeed, 1, function() return not ok() end, false, true )
		else
			self:Wait( 0.3, p:GetPos() )
		end
	end
	if ok() and p.Interned then self:Wait( 1.5, p:GetPos() ) end
	release()
	if not self.Dead then self:PlaySeq( self:IdleSeq() ) end
end

function ENT:MedicWary()
	if not self:Geneva() or CurTime() < ( self.NextWary or 0 ) then return false end
	local watchers = self:WatchedBy()
	if #watchers == 0 then
		if self.WaryAt then
			self.WaryAt, self.WaryFrom = nil, nil
			self.Crouched = false
			self:PlaySeq( self:IdleSeq() )
		end
		return false
	end
	self.NextWary = CurTime() + 1
	local me, nearest, nd = self:GetPos(), nil, math.huge
	for _, w in ipairs( watchers ) do
		local d = w:GetPos():Distance( me )
		if d < nd then nearest, nd = w, d end
	end
	if nd < 450 and self:Cornered( 450 ) then
		self:Surrender()
		return true
	end
	local look = nearest:GetPos() + EYE
	self.WaryAt = CurTime()
	if nd > FAR then
		self:LookTowards( look, 3 )
		if math.abs( self:FacingDelta( look ) ) > 25 then self:TurnTo( look, 1 ) end
		if self:GetSequenceName( self:GetSequence() ) ~= self:IdleSeq() then self:PlaySeq( self:IdleSeq() ) end
		self:Wait( 2.5, look )
		return true
	end
	local threats = {}
	for _, w in ipairs( watchers ) do threats[ #threats + 1 ] = w:GetPos() + EYE end
	if not self.WaryFrom or CurTime() - ( self.WaryAt or 0 ) > 30 then self.WaryFrom = me end
	self.WaryAt = CurTime()
	local spot = CurTime() >= ( self.NextHide or 0 ) and self:HideSpot( threats )
	if spot and spot:Distance( me ) > 40 and spot:Distance( self.WaryFrom ) < 700 then
		self.NextHide = CurTime() + 6
		self:MoveTo( spot, self.RunSpeed, 6, function() return self:GetPos():Distance2D( spot ) < 30 end, true, true )
	end
	if self.Dead then return true end
	self.Crouched = true
	self:LookTowards( look, 3 )
	local scared = nd < 700 and self:LookupSequence( "medic_hide" ) >= 0
	local seq = scared and "medic_hide" or "crouch_idle"
	if self:GetSequenceName( self:GetSequence() ) ~= seq then self:PlaySeq( seq ) end
	self:Wait( 2.5, look )
	return true
end

--geneva convention rules, dont shoot the medic
