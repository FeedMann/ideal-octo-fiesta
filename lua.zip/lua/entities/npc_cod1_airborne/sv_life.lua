local U = COD1.AI
local flat, groundAt, blocked, hullClear = U.flat, U.groundAt, U.blocked, U.hullClear
local BaseClass = baseclass.Get( "base_nextbot" )

local IDLES = { "idle", "idle", "idle2", "idle3", "idle_relaxed", "idle_twitch" }
local CROUCH_IDLES = { "crouch_idle", "crouch_idle2", "crouch_idle3", "crouch_twitch", "crouch_twitch2" }
local PAINS = { "pain_lshoulder", "pain_rshoulder", "pain_hunch", "pain_falltohand" }
local DEATHS = { "death_frontspin", "death_topple", "death_lowerback", "death_lowertorso", "death_nerve",
	"death_dropinplace", "death_neck", "death_legs", "death_neck_thrash" }
local CROUCH_DEATHS = { "crouch_death", "crouch_death2", "crouch_death3", "crouch_death4" }
local TEST_DROPS = { jump_down_low = 56, jump_down_high = 96 }

hook.Add( "EntityTakeDamage", "COD1Invulnerable", function( ent, dmg )
	if ent.COD1Invulnerable then return true end
	if ent.IsCOD1Soldier and dmg:IsBulletDamage() then
		local att = dmg:GetAttacker()
		if IsValid( att ) and att.IsCOD1Soldier and att ~= ent and att.COD1Team == ent.COD1Team then return true end
	end
	if ent.IsCOD1Soldier and not ent.Dead and not ent.Downed and dmg:GetDamage() >= ent:Health() and ent:CanGoDown( dmg ) then
		ent:GoDown( dmg )
		return true
	end
end )

function ENT:Use( activator )
	if not activator:IsPlayer() or self.Dead then return end
	if self.PhysgunHeld or CurTime() < ( self.UseBlockedUntil or 0 ) then return end
	local wep = activator:GetActiveWeapon()
	if IsValid( wep ) and wep:GetClass() == "weapon_physgun" and activator:KeyDown( IN_ATTACK ) then return end
	if self:EnemySide() or self:IsHostileTo( activator ) or self.Role == "megaphone" then return end
	if self.GunPass and self.GunPass.part ~= "queue" then return self:GunPassUse( activator ) end
	if not GetConVar( "cod1_npc_follow" ):GetBool() then
		if CurTime() > ( self.NextRefusal or 0 ) then
			self.NextRefusal = CurTime() + 3
			self:Quick( "no_sir" )
		end
		return
	end
	if self.Follow == activator then
		self.Follow = nil
		self.WantWave = "wave_what"
		self:Quick( math.random( 2 ) == 1 and "in_position" or "hold_position" )
	else
		self.Follow = activator
		self.WantWave = math.random( 2 ) == 1 and "wave_comeon" or "wave_go"
		if not self:Quick( math.random( 2 ) == 1 and "yes_sir" or "on_my_way" ) then self:Say( "greetplayerloud", 1, true ) end
	end
end

local function sameFloor( a, b ) return math.abs( a.z - b.z ) < 40 end

function ENT:FollowSpot( ply )
	local idx, n = 0, 0
	for s in pairs( COD1.Soldiers ) do
		if IsValid( s ) and s.Follow == ply and not s.Dead then
			n = n + 1
			if s:EntIndex() < self:EntIndex() then idx = idx + 1 end
		end
	end
	local away = self:GetPos() - ply:GetPos()
	away.z = 0
	if away:LengthSqr() < 1 or not sameFloor( self:GetPos(), ply:GetPos() ) then away = -ply:GetForward() end
	local base = away:Angle().y + ( idx - ( n - 1 ) / 2 ) * 25
	local dist = 90 + math.floor( idx / 6 ) * 55
	local pp = ply:GetPos()
	for _, turn in ipairs( { 0, 40, -40, 80, -80, 140, -140, 180 } ) do
		local spot = groundAt( pp + Angle( 0, base + turn, 0 ):Forward() * dist )
		if spot and math.abs( spot.z - pp.z ) < 24 and hullClear( spot, self )
			and not blocked( pp + Vector( 0, 0, 32 ), spot + Vector( 0, 0, 32 ) ) then
			return spot
		end
	end
	return pp
end

function ENT:Idle()
	if self:PapersIdle() then return end
	if self.Corner then self:LeaveCorner() end
	if self.Hiding then self.Hiding = false self.Crouched = true end
	local alert = self.LastSeen > 0 and CurTime() - math.max( self.LastSeen, self.LastAlert ) < 20
	if not alert and self.Crouched then self:SetStance( false ) end
	COD1.Cover[ self ] = nil

	if self.LookPos and CurTime() < ( self.LookUntil or 0 ) then
		local pos = self.LookPos
		self.LookPos = nil
		if not self.Crouched and not self.HasFlag then self:SetStance( true ) end
		self:TurnTo( pos, 0.8 )
	end

	if not GetConVar( "cod1_npc_follow" ):GetBool() then self.Follow = nil self.WantWave = nil end
	local ply = self.Follow
	if self.WantWave and IsValid( ply ) then
		local wave = self.WantWave
		self.WantWave = nil
		if self.Crouched then self:SetStance( false ) end
		self:TurnTo( ply:GetPos(), 0.6 )
		if self.HasFlag then self:FlagCry() else self:Wait( self:PlaySeq( wave ) ) end
		return
	end
	if IsValid( ply ) and ply:Alive() and CurTime() > ( self.FollowWait or 0 ) then
		local toPly = self:GetPos():Distance2D( ply:GetPos() )
		local up = not sameFloor( self:GetPos(), ply:GetPos() )
		if toPly > 170 or up then
			local spot = self:FollowSpot( ply )
			self:MoveTo( spot, ( toPly > 400 or up ) and self.RunSpeed or self.WalkSpeed * 2, 3, function()
				local me = self:GetPos()
				return sameFloor( me, ply:GetPos() ) and ( me:Distance2D( ply:GetPos() ) < 110 or me:Distance( spot ) < 35 )
					or IsValid( self:UpdateEnemy() )
			end )
			if self.MoveBlocked then
				self.FollowWait = CurTime() + 3
				self:StartActivity( ACT_IDLE )
				self:PlaySeq( self:IdleSeq() )
			end
			return
		end
	end

	if self:TryFlagPickup() then return end
	if self.NoGun and self:UnarmedIdle() then return end
	if self.RoleIdle and self:RoleIdle() then return end
	if self:DisguiseIdle() then return end

	for _, p in ipairs( player.GetAll() ) do
		if not self:EnemySide() and not self.Greeted[ p ] and p:Alive() and p:GetPos():DistToSqr( self:GetPos() ) < 160 * 160 and not self:IsHostileTo( p ) then
			self.Greeted[ p ] = true
			self:Say( "greetplayerquiet", 0.7 )
		end
	end
	if not self.Unarmed and self.Mag < self.Weapon.clip then self:Reload() return end
	if alert and not self.Crouched and not self.HasFlag then self:SetStance( true ) end
	if not self.IdleUntil or CurTime() > self.IdleUntil then
		self:StartActivity( self.Crouched and ACT_CROUCHIDLE or ACT_IDLE )
		local seq
		if self.HasFlag or self.Role == "megaphone" then
			seq = self:IdleSeq()
		else
			local list = self.Crouched and CROUCH_IDLES or IDLES
			seq = list[ math.random( #list ) ]
		end
		local dur = self:PlaySeq( seq )
		self.IdleUntil = CurTime() + math.max( dur, 2 )
	end
	self:SetPoseParameter( "aim_pitch", 0 )
	self:Wait( 0.3 )
end

function ENT:FaceNearestPlayer( maxDist )
	local best, bestDist = nil, maxDist * maxDist
	for _, ply in ipairs( player.GetAll() ) do
		local d = ply:GetPos():DistToSqr( self:GetPos() )
		if ply:Alive() and d < bestDist then best, bestDist = ply, d end
	end
	if not best then return end
	local t = CurTime() + 1
	while CurTime() < t and math.abs( self:FacingDelta( best:GetPos() ) ) > 5 do
		self.loco:FaceTowards( best:GetPos() )
		coroutine.yield()
	end
end

function ENT:TestMove( seq )
	for _, ply in ipairs( player.GetAll() ) do ply:PrintMessage( HUD_PRINTCENTER, "CoD1 move: " .. seq ) end
	self.Moving = false
	self.Crouched = false
	self.Hiding = false
	self.loco:SetDesiredSpeed( 0 )
	self.loco:SetVelocity( vector_origin )
	local home = self.TestHome or self:GetPos()
	self.TestHome = home
	self:SetPos( home + Vector( 0, 0, TEST_DROPS[ seq ] or 0 ) )
	if self.TestYaw then self:SetAngles( Angle( 0, self.TestYaw, 0 ) ) end
	self:PlaySeq( "idle" )
	if not self:Wait( 0.6, nil, true ) then return end
	self:PlayMotion( seq )
	if self.Dead then return end
	self:PlaySeq( "idle" )
	self:Wait( 1, nil, true )
	if #self.TestQueue == 0 then self.TestQueue = nil end
	self:SetPos( home )
end

function ENT:RunBehaviour()
	self:StartActivity( ACT_IDLE )
	self:PlaySeq( self:IdleSeq() )
	self:FaceNearestPlayer( 600 )
	while true do
		if self.Dead then return end
		local ok, err = pcall( self.BehaveStep, self )
		if not ok then
			ErrorNoHalt( "[CoD1] soldier recovered from: " .. tostring( err ) .. "\n" )
			self.Enemy = nil
			self.Moving = false
			if self.loco then self.loco:SetDesiredSpeed( 0 ) end
		end
		coroutine.yield()
	end
end

function ENT:BehaveStep()
	local nade = self.GrenadeThreat or self:FindGrenadeThreat()
	if self.Surrendered then
		self.GrenadeThreat, self.PendingPain = nil, nil
		self:PrisonerIdle()
	elseif self.GunPass then
		self.GrenadeThreat, self.PendingPain = nil, nil
		self:GunPassThink()
	elseif IsValid( self.WantRescue ) then
		self:GoRescue()
	elseif IsValid( self.WantTurret ) then
		self:GoToTurret()
	elseif self.TestQueue and #self.TestQueue > 0 then
		self:TestMove( table.remove( self.TestQueue, 1 ) )
	elseif IsValid( nade ) then
		self:ReactToGrenade( nade )
	elseif self.PendingPain then
		local seq = self.PendingPain
		self.PendingPain = nil
		if string.StartWith( seq, "stumble" ) then
			self:Stumble( seq )
		elseif string.StartWith( seq, "prone_pain" ) then
			self:Wait( self:PlaySeq( seq ), nil, true )
		else
			self.Hiding = false
			self:Wait( self:PlaySeq( seq ), nil, true )
			self.Crouched = seq == "pain_falltohand" or seq == "crouch_pain"
		end
	else
		self.GrenadeThreat = nil
		local enemy = self:UpdateEnemy()
		if self:Decrowd() then
			self.IdleUntil = nil
		elseif IsValid( enemy ) then
			self.IdleUntil = nil
			if self:Classic() then self:ClassicCombat( enemy ) else self:Combat( enemy ) end
		elseif not ( self.VariantData.medic and ( self:MedicWork() or self:MedicWary() ) ) and not self:TakePrisoner() then
			self:Idle()
		end
	end
end

function ENT:OnTraceAttack( dmginfo, dir, trace )
	self.LastHitGroup = trace.HitGroup
	if trace.HitGroup == HITGROUP_HEAD then dmginfo:ScaleDamage( 2 ) end
	self:Bleed( trace.HitPos, dir, trace.HitGroup == HITGROUP_HEAD or dmginfo:GetDamage() >= 60 )
end

function ENT:Bleed( pos, dir, big )
	local ed = EffectData()
	ed:SetOrigin( pos )
	ed:SetNormal( dir )
	ed:SetFlags( big and 1 or 0 )
	util.Effect( "cod1_blood", ed, true, true )
	self:EmitSound( big and "COD1.ImpactFlesh" or "COD1.ImpactFleshSmall" )
	if GetConVar( "cod1_npc_blood_decals" ):GetBool() then
		local tr = util.TraceLine( { start = pos, endpos = pos + dir * 140, filter = self, mask = MASK_SOLID_BRUSHONLY } )
		if tr.Hit then util.Decal( "Blood", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal, self ) end
	end
end

function ENT:BlowCover()
	if not self.Undercover then return end
	self.Undercover = nil
	self.NextScan = 0
	self:ShowWeapon( true )
	for _, e in ipairs( ents.FindInSphere( self:GetPos(), 2500 ) ) do
		if e.IsCOD1Soldier and e.COD1Team ~= self.COD1Team and e.Grudges then e.Grudges[ self ] = CurTime() + 30 end
	end
end

function ENT:OnInjured( dmginfo )
	if self.Dead or self.Downed then return end
	self:BlowCover()
	for _, e in ipairs( ents.FindInSphere( self:GetPos(), 1500 ) ) do
		if e.Undercover and e.COD1Team == self.COD1Team and e ~= self then e:BlowCover() end
	end
	if self.Treatment then self:EndTreatment() end
	if self.GunPass then self:GunPassHurt() end
	self.LastHurt = CurTime()
	self.Suppressed = CurTime() + ( self:Inspired() and 1.5 or 3 )
	local att = dmginfo:GetAttacker()
	if dmginfo:IsBulletDamage() then self:MedicShotAt( att ) end
	if IsValid( att ) and att:IsPlayer() and not self:EnemySide() and not self:IsHostileTo( att ) and CurTime() > ( self.NextCrazy or 0 ) then
		self.NextCrazy = CurTime() + 4
		if dmginfo:GetDamage() < self:Health() then self:Quick( "crazy" ) end
	end
	if IsValid( att ) and att ~= self and ( att:IsPlayer() or att:IsNPC() or att:IsNextBot() ) and att.COD1Team ~= self.COD1Team then
		if not att:IsPlayer() or self:EnemySide() or GetConVar( "cod1_npc_hostile_players" ):GetBool() then
			self.Grudges[ att ] = CurTime() + 20
			self:Alert( att, att:GetPos() )
		end
	end
	if self.LastHitGroup == HITGROUP_LEFTLEG or self.LastHitGroup == HITGROUP_RIGHTLEG then
		self.HurtLeg = self.LastHitGroup
	end
	if dmginfo:GetDamage() < self:Health() and ( self.NextPain or 0 ) < CurTime() then
		self.NextPain = CurTime() + 1.2
		self:Say( "pain", 1, true )
		self:FaceGesture( "face_pain" )
		if self.Parachuting or self.AtCorner or self.Rambo or self.HasFlag or self.Carrying or self.GunPass then return end
		local moving = self.loco:GetVelocity():Length2D()
		if moving > 100 and math.random() < 0.4 then
			self.PendingPain = math.random( 2 ) == 1 and "stumble1" or "stumble2"
		elseif math.random() < 0.3 and moving < 50 and not self.Hiding then
			if self.Prone then
				self.PendingPain = math.random( 2 ) == 1 and "prone_pain" or "prone_pain2"
			elseif self.Crouched then
				self.PendingPain = "crouch_pain"
			else
				self.PendingPain = ( self.LastHitGroup == HITGROUP_LEFTLEG or self.LastHitGroup == HITGROUP_RIGHTLEG ) and "pain_leg"
					or PAINS[ math.random( #PAINS ) ]
			end
		end
	end
end

function ENT:HitSide( dmginfo )
	local from = dmginfo:GetDamagePosition()
	local att = dmginfo:GetAttacker()
	if IsValid( att ) and ( from == vector_origin or from:DistToSqr( self:GetPos() ) < 1 ) then from = att:GetPos() end
	local dir = ( from - self:GetPos() ):GetNormalized()
	local f, r = dir:Dot( self:GetForward() ), dir:Dot( self:GetRight() )
	if math.abs( f ) > math.abs( r ) then return f > 0 and "front" or "back" end
	return r > 0 and "right" or "left"
end

function ENT:PickDeath( dmginfo )
	if self.ForcedDeath then return self.ForcedDeath end
	local hg = self.LastHitGroup
	local speed = self.loco:GetVelocity():Length2D()
	if dmginfo:IsExplosionDamage() then
		return ( { front = "death_explode_back", back = "death_explode_forward", left = "death_explode_right", right = "death_explode_left" } )[ self:HitSide( dmginfo ) ]
			or "death_explode_up"
	end
	if self.HasFlag and speed > 80 and self:LookupSequence( "death_flag" ) >= 0 then return "death_flag" end
	if self.AtCorner and not self.Rambo and self.Corner and self.Corner.set == "a" then
		return "cn_death_" .. self.Corner.pose .. "_" .. self.Corner.side
	end
	if self.Prone then return "death_prone" end
	if self.Crouched or self.Hiding then
		if hg == HITGROUP_HEAD then return "crouch_death_head" end
		if speed > 60 then return math.random( 2 ) == 1 and "death_crouchrun_crumple" or "death_crouchrun_drop" end
		return CROUCH_DEATHS[ math.random( #CROUCH_DEATHS ) ]
	end
	if speed > 100 then
		local v = self.loco:GetVelocity():GetNormalized()
		local f, r = v:Dot( self:GetForward() ), v:Dot( self:GetRight() )
		if f < -0.5 then return "death_run_back" end
		if r > 0.6 then return "death_run_right" end
		if r < -0.6 then return "death_run_left" end
		local runs = { "death_run_crumple", "death_run_stumble", "death_run_onfront", "death_run_onleft" }
		return runs[ math.random( #runs ) ]
	end
	if hg == HITGROUP_HEAD then
		if self.VariantData.medic then return "death_medic" end
		return math.random( 2 ) == 1 and "death_headcollapse" or "death_neck"
	end
	if hg == HITGROUP_LEFTLEG or hg == HITGROUP_RIGHTLEG then return "death_leghit" end
	if self:HitSide( dmginfo ) == "back" then return math.random( 2 ) == 1 and "death_lowerback" or "death_run_crumple" end
	return DEATHS[ math.random( #DEATHS ) ]
end

function ENT:PopHelmet( dmginfo )
	local v = self.VariantData
	local prop = v.helmetProps and v.helmetProps[ self.HelmetIndex ]
	if not prop then return end
	local att = self:GetAttachment( self:LookupAttachment( prop[ 2 ] ) )
	if not att then return end
	local side = self.HelmetSide and self:GetAttachment( self:LookupAttachment( "helmetside" ) )
	self:SetGroup( "helmet", v.blankHelmet )
	local h = ents.Create( "prop_physics" )
	if not IsValid( h ) then return end
	h:SetModel( prop[ 1 ] )
	h:SetPos( att.Pos )
	h:SetAngles( att.Ang )
	h:Spawn()
	self:PaintMaterials( h )
	h:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
	local phys = h:GetPhysicsObject()
	if IsValid( phys ) then
		phys:SetVelocity( dmginfo:GetDamageForce():GetNormalized() * 160 + Vector( 0, 0, 200 ) )
		phys:AddAngleVelocity( VectorRand() * 400 )
	end
	SafeRemoveEntityDelayed( h, 60 )
	if side then
		self:SetGroup( "helmetside", 0 )
		local pouch = ents.Create( "prop_dynamic" )
		if IsValid( pouch ) then
			pouch:SetModel( "models/cod1/props/helmet_pouch.mdl" )
			pouch:SetPos( side.Pos )
			pouch:SetAngles( side.Ang )
			pouch:Spawn()
			pouch:SetSolid( SOLID_NONE )
			pouch:SetParent( h )
			h:CallOnRemove( "COD1Pouch", function() if IsValid( pouch ) then pouch:Remove() end end )
		end
	end
end

function ENT:AlertSquad( attacker )
	if not IsValid( attacker ) then return end
	for _, s in ipairs( U.teammates( self, 1500 ) ) do s:Alert( attacker, attacker:GetPos() ) end
end

function ENT:OnKilled( dmginfo )
	if self.Dead then return end
	self.Dead = true
	COD1.Cover[ self ] = nil
	if IsValid( self.ClaimedFlag ) and self.ClaimedFlag.Claimant == self then self.ClaimedFlag.Claimant = nil end
	hook.Run( "OnNPCKilled", self, dmginfo:GetAttacker(), dmginfo:GetInflictor() )
	self:Say( "death", 1, true )
	self:SetNWBool( "COD1Dead", true )
	self:AlertSquad( dmginfo:GetAttacker() )
	if self.SquintLayer and self:IsValidLayer( self.SquintLayer ) then self:RemoveLayer( self.SquintLayer ) end
	if self.TalkLayer and self:IsValidLayer( self.TalkLayer ) then self:RemoveLayer( self.TalkLayer ) end
	self:FaceGesture( "face_dead", false )
	self:AddFlags( FL_NOTARGET )
	if self.LastHitGroup == HITGROUP_HEAD and math.random() < 0.6 then self:PopHelmet( dmginfo ) end
	self:DropMegaphone()
	self:GunPassDied()

	self.Treatment = nil
	if IsValid( self.Dressing ) then self.Dressing:Remove() end
	if self.Downed then
		local seq = self:DownedDeath()
		if seq == false then
			self.loco:SetDesiredSpeed( 0 )
			self.Moving = false
			return
		end
		self.ForcedDeath = seq
	end
	self:CarrierDied()
	if IsValid( self.Rescuing ) and self.Rescuing.Downed and self.Rescuing.Downed.rescuer == self and self.Rescuing.Downed.phase ~= "carried" then self.Rescuing.Downed.rescuer = nil end
	self.Rescuing, self.WantRescue = nil, nil
	if self.Manning then self:Dismount( true ) end
	if self.Riding then
		self.Riding = false
		self.TruckRide = nil
		self:SetNWEntity( "COD1Truck", NULL )
		self:BecomeRagdoll( dmginfo )
		return
	end

	if self.Parachuting then
		if self.ParaLanding then
			self:EndParachute()
			self:BecomeRagdoll( dmginfo )
		else
			self:ChuteDeath()
		end
		return
	end


	local ragdolls = GetConVar( "cod1_npc_ragdolls" ):GetBool()
	local huge = dmginfo:GetDamage() >= 150 or ( dmginfo:IsExplosionDamage() and dmginfo:GetDamage() >= 90 )
	if ragdolls and not self.ForcedDeath and ( huge or not GetConVar( "cod1_npc_death_anims" ):GetBool() or not self.loco:IsOnGround() ) then
		self:DropFlag( true )
		self:BecomeRagdoll( dmginfo )
		return
	end
	self.loco:SetDesiredSpeed( 0 )
	self.Moving = false
	self:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
	self.DeathEnd = CurTime() + self:PlaySeq( self:PickDeath( dmginfo ) ) - 0.05
	self.loco:SetVelocity( vector_origin )
end

local SINK_DEPTH, SINK_TIME = 70, 6

local function sinkOn() return GetConVar( "cod1_npc_corpse_sink" ):GetBool() end
local function sinkDelay() return GetConVar( "cod1_npc_corpse_sink_time" ):GetFloat() end
local function eased( k ) return k * k * ( 3 - 2 * k ) end

function ENT:StartSink()
	if self.Sinking then return end
	self.Sinking = { t0 = CurTime(), pos = self:GetPos() }
	self.SinkAt, self.AlignStop = nil, nil
	self:SetSolid( SOLID_NONE )
	self.loco:SetGravity( 0 )
	self.loco:SetVelocity( vector_origin )
end

function ENT:UpdateSink()
	local s = self.Sinking
	local k = math.Clamp( ( CurTime() - s.t0 ) / SINK_TIME, 0, 1 )
	self:SetPos( s.pos - Vector( 0, 0, SINK_DEPTH * eased( k ) ) )
	if k >= 1 then self:Remove() end
end

COD1.SinkRagdolls = COD1.SinkRagdolls or {}
hook.Add( "CreateEntityRagdoll", "COD1SinkRagdolls", function( owner, rag )
	if owner.IsCOD1Soldier and sinkOn() then COD1.SinkRagdolls[ rag ] = { at = CurTime() + sinkDelay() } end
end )
hook.Add( "Think", "COD1SinkRagdolls", function()
	local now = CurTime()
	for rag, s in pairs( COD1.SinkRagdolls ) do
		if not IsValid( rag ) then
			COD1.SinkRagdolls[ rag ] = nil
		elseif now >= s.at then
			if not s.bones then
				s.bones, s.t0 = {}, now
				rag:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
				for i = 0, rag:GetPhysicsObjectCount() - 1 do
					local p = rag:GetPhysicsObjectNum( i )
					if IsValid( p ) then
						p:EnableMotion( false )
						p:EnableCollisions( false )
						s.bones[ i ] = p:GetPos()
					end
				end
			end
			local k = math.Clamp( ( now - s.t0 ) / SINK_TIME, 0, 1 )
			local drop = Vector( 0, 0, SINK_DEPTH * eased( k ) )
			for i, start in pairs( s.bones ) do
				local p = rag:GetPhysicsObjectNum( i )
				if IsValid( p ) then p:SetPos( start - drop ) end
			end
			if k >= 1 then
				COD1.SinkRagdolls[ rag ] = nil
				rag:Remove()
			end
		end
	end
end )

function ENT:AlignCorpse()
	if CurTime() < ( self.NextAlign or 0 ) then return end
	self.NextAlign = CurTime() + 0.05
	local pel, head = self:LookupBone( "bip01 pelvis" ), self:LookupBone( "bip01 head" )
	if not pel or not head then return end
	local pp, hp = self:GetBonePosition( pel ), self:GetBonePosition( head )
	if not pp or not hp then return end
	local base = self:GetPos()
	if hp.z - base.z > 40 then return end
	local function ground( p )
		local tr = util.TraceLine( { start = Vector( p.x, p.y, base.z + 40 ), endpos = Vector( p.x, p.y, base.z - 60 ), mask = MASK_SOLID_BRUSHONLY } )
		return tr.Hit and not tr.StartSolid and tr.HitPos
	end
	local axis = flat( hp - pp )
	if axis:LengthSqr() < 16 then axis = flat( self:GetForward() ) end
	axis:Normalize()
	local left = Vector( -axis.y, axis.x, 0 )
	local gh, gf, gl, gr = ground( pp + axis * 30 ), ground( pp - axis * 30 ), ground( pp + left * 15 ), ground( pp - left * 15 )
	if not ( gh and gf and gl and gr ) then return end
	local n = ( gh - gf ):Cross( gl - gr )
	if n:LengthSqr() < 1 then return end
	n:Normalize()
	if n.z < 0 then n = -n end
	if n.z < 0.6 then return end
	local f = Angle( 0, self:GetAngles().y, 0 ):Forward()
	f = f - n * f:Dot( n )
	self:SetAngles( LerpAngle( 0.35, self:GetAngles(), f:AngleEx( n ) ) )
	local gp = ground( pp )
	if gp and pp.z < gp.z + 2 then self:SetPos( base + Vector( 0, 0, gp.z + 2 - pp.z ) ) end
end

function ENT:UpdateLOD()
	if CurTime() < ( self.NextLOD or 0 ) then return end
	self.NextLOD = CurTime() + 1
	local me, far = self:GetPos(), true
	for _, p in ipairs( player.GetAll() ) do
		if p:GetPos():DistToSqr( me ) < 3500 * 3500 then far = false break end
	end
	self.FarFromPlayers = far
end

function ENT:BehaveUpdate( interval )
	if self.Downed then
		self:UpdateDowned()
		if not self.Dead and self.Downed then
			self:UpdateFace()
			self:SetNWFloat( "COD1HP", math.Clamp( self:Health() / self:GetMaxHealth(), 0, 1 ) )
		end
		return
	end
	if self.Manning then
		self:UpdateManning()
		if not self.Dead then
			self:UpdateFace()
			self:SetNWFloat( "COD1HP", math.Clamp( self:Health() / self:GetMaxHealth(), 0, 1 ) )
		end
		return
	end
	if self.Treatment then
		self:UpdateTreatment()
		if not self.Dead then
			self:UpdateFace()
			self:SetNWFloat( "COD1HP", math.Clamp( self:Health() / self:GetMaxHealth(), 0, 1 ) )
		end
		return
	end
	if self.Riding then
		self:UpdateTruckRide()
		if not self.Dead then
			self:UpdateFace()
			self:SetNWFloat( "COD1HP", math.Clamp( self:Health() / self:GetMaxHealth(), 0, 1 ) )
		end
		return
	end
	if self.Parachuting then
		self:UpdateParachute()
		if not self.Dead then
			self:UpdateFace()
			self:SetNWFloat( "COD1HP", math.Clamp( self:Health() / self:GetMaxHealth(), 0, 1 ) )
		end
		return
	end
	if self.Dead then
		if self.Sinking then return self:UpdateSink() end
		if self.Corpse and not self.SinkAt and sinkOn() then self.SinkAt = CurTime() + sinkDelay() end
		if self.SinkAt and CurTime() >= self.SinkAt then return self:StartSink() end
		if self.CarriedCorpse and self:UpdateCarriedCorpse() then return end
		if self.DeathEnd and CurTime() >= self.DeathEnd then
			self.DeathEnd = nil
			self:DropFlag( false )
			if GetConVar( "cod1_npc_ragdolls" ):GetBool() then
				self:BecomeRagdoll( DamageInfo() )
			else
				self.Corpse = true
				self.AlignStop = CurTime() + 3
				local t = GetConVar( "cod1_npc_corpse_time" ):GetFloat()
				if sinkOn() then self.SinkAt = CurTime() + sinkDelay()
				elseif t > 0 then SafeRemoveEntityDelayed( self, t ) end
				COD1.Bodies = COD1.Bodies or {}
				table.insert( COD1.Bodies, self )
				local max = GetConVar( "cod1_npc_max_bodies" ):GetInt()
				while max > 0 and #COD1.Bodies > max do
					local old = table.remove( COD1.Bodies, 1 )
					if IsValid( old ) and old ~= self then
						if sinkOn() then old:StartSink() else old:Remove() end
					end
				end
			end
		end
		if IsValid( self ) and self.DeathEnd or ( self.AlignStop and CurTime() < self.AlignStop ) then self:AlignCorpse() end
		return
	end
	if GetConVar( "ai_disabled" ):GetBool() then
		if not self.AIFrozen then
			self.AIFrozen = { speed = self.loco:GetDesiredSpeed(), moving = self.Moving }
			self.loco:SetDesiredSpeed( 0 )
			self.loco:SetVelocity( vector_origin )
			self.Moving = false
			self:PlaySeq( self:IdleSeq() )
		end
		self:UpdateFace()
		return
	elseif self.AIFrozen then
		self.loco:SetDesiredSpeed( self.AIFrozen.speed )
		self.Moving = self.AIFrozen.moving
		self.AIFrozen = nil
	end
	self:UpdateLOD()
	if not self.GrenadeThreat and not self.ReactingGrenade and ( self.NextNadeCheck or 0 ) < CurTime() then
		self.NextNadeCheck = CurTime() + ( self.FarFromPlayers and 0.6 or 0.2 )
		local n = self:FindGrenadeThreat()
		if n then self.GrenadeThreat = n end
	end
	if not self.Moving and self.StoppedAt and CurTime() - self.StoppedAt > 0.12 then
		self.StoppedAt = nil
		self:StopMoveAnim()
	end
	if not self.FarFromPlayers then self:UpdateFace() end
	self:SetNWFloat( "COD1HP", math.Clamp( self:Health() / self:GetMaxHealth(), 0, 1 ) )
	BaseClass.BehaveUpdate( self, interval )
end

function ENT:BodyUpdate()
	if self.Parachuting then return end
	if self.Moving and not self.Dead then
		self:BodyMoveXY()
		return
	end
	self:FrameAdvance()
end

--idle stuff so they look alive when nothing is happening
