local U = COD1.AI

local OFFICER_START = { x = 29.3, y = 4.6 }
local PRICE_START = { x = -15.8, y = -4.1 }

local function soldbuch( owner, att )
	local id = owner:LookupAttachment( att )
	if not id or id <= 0 then return end
	local p = ents.Create( "prop_dynamic" )
	if not IsValid( p ) then return end
	p:SetModel( "models/cod1/props/soldbuch.mdl" )
	p:Spawn()
	p:SetSolid( SOLID_NONE )
	p:SetParent( owner, id )
	p:SetLocalPos( vector_origin )
	p:SetLocalAngles( angle_zero )
	return p
end

local function looksOfficer( e )
	return e:IsPlayer() or ( e.VariantData and e.VariantData.officerLook ) or false
end

function U.runEvents( events )
	local i = 1
	return function( el )
		while events[ i ] and el >= events[ i ][ 1 ] do
			events[ i ][ 2 ]()
			i = i + 1
		end
	end
end

function ENT:ShowWeapon( on )
	local pre = string.lower( self.WeaponKey or "" ) .. "_"
	for i = 0, self:GetBoneCount() - 1 do
		local n = self:GetBoneName( i )
		if n and string.StartWith( string.lower( n ), pre ) then
			self:ManipulateBoneScale( i, on and Vector( 1, 1, 1 ) or vector_origin )
		end
	end
	self.WeaponHidden = not on
end

function ENT:Line( sound, face )
	self:EmitSound( sound )
	if face then self:FaceGesture( face ) end
end

function ENT:Salute( t )
	if self.Crouched then self:SetStance( false ) end
	self:StartActivity( ACT_IDLE )
	self:TurnTo( t:GetPos(), 0.8 )
	if not IsValid( t ) or not self:Wait( self:PlaySeq( "attention_ease" ), t ) then return end
	if self.WeaponType ~= "pistol" and not self:Wait( self:PlaySeq( "present_arms" ), t ) then return end
	self:PlaySeq( "attention" )
	self:Wait( 2.5, t )
	self.IdleUntil = nil
end

function ENT:CheckPapers( t )
	self.Moving = false
	self.loco:SetDesiredSpeed( 0 )
	if self.Crouched then self:SetStance( false ) end
	t.PapersWith = self
	self:StartActivity( ACT_IDLE )
	self:TurnTo( t:GetPos(), 1 )
	if not IsValid( t ) or self.Dead then return end
	local yaw = ( t:GetPos() - self:GetPos() ):Angle().y
	local fwd, left = Angle( 0, yaw, 0 ):Forward(), Angle( 0, yaw + 90, 0 ):Forward()
	local dx, dy = OFFICER_START.x - PRICE_START.x, OFFICER_START.y - PRICE_START.y
	local spot = self:GetPos() + fwd * dx + left * dy
	spot = U.groundAt( spot ) or spot
	t.PapersSpot = { pos = spot, yaw = yaw + 180 }
	local limit = CurTime() + 10
	while IsValid( t ) and not t.PapersReady and CurTime() < limit and not self.Dead do
		self.loco:FaceTowards( t:GetPos() )
		coroutine.yield()
	end
	if not IsValid( t ) or not t.PapersReady or self.Dead then
		if IsValid( t ) then t.PapersWith, t.PapersSpot = nil, nil end
		return
	end
	self:SetAngles( Angle( 0, yaw, 0 ) )
	self:ShowWeapon( false )
	t.PapersGo = true
	local book
	local events = {
		{ 5.2, function() self:Line( "COD1.Ship.WarrantPapers", "face_ship_papers" ) end },
		{ 7.5, function()
			book = soldbuch( self, "anim_attachment_LH" )
			self:EmitSound( "COD1.Paper" )
		end },
		{ 8.8, function() self:Line( "COD1.Ship.WarrantSchmidt", "face_ship_schmidt" ) end },
		{ 10.9, function()
			if IsValid( book ) then book:Remove() end
			self:EmitSound( "COD1.Paper" )
		end },
		{ 15.3, function() self:Line( "COD1.Ship.WarrantWelcome", "face_ship_welcome" ) end },
	}
	self:PlayMotion( "papers_officer", nil, nil, U.runEvents( events ) )
	if IsValid( book ) then book:Remove() end
	if not self.Dead then self:ShowWeapon( true ) end
	if IsValid( t ) then
		t.PapersWith, t.PapersSpot = nil, nil
		t.PapersCleared = CurTime() + 300
		for _, e in ipairs( ents.FindInSphere( self:GetPos(), 450 ) ) do
			if e ~= self and e.IsCOD1Soldier and e.COD1Team == self.COD1Team and not e.Dead and not e.Officer then e.SaluteFor = t end
		end
	end
	self.IdleUntil = nil
	if not self.Dead then
		self:StartActivity( ACT_IDLE )
		self:PlaySeq( self:IdleSeq() )
	end
end

function ENT:DisguiseIdle()
	if self.COD1Team ~= "axis" or self.HasFlag or self.Unarmed then return false end
	if IsValid( self.SaluteFor ) then
		local t = self.SaluteFor
		self.SaluteFor = nil
		self:Salute( t )
		return true
	end
	self.SaluteFor = nil
	if CurTime() < ( self.NextDisguiseScan or 0 ) then return false end
	self.NextDisguiseScan = CurTime() + 0.4
	local target, best
	for _, e in ipairs( ents.FindInSphere( self:GetPos(), 320 ) ) do
		if e ~= self and COD1.IsUndercover( e ) and not e.Dead then
			local d = e:GetPos():Distance( self:GetPos() )
			if ( not best or d < best ) and not U.blocked( self:EyePos(), e:EyePos() ) then target, best = e, d end
		end
	end
	if not target then return false end
	local wantsPapers = target.VariantData and target.VariantData.papers
	if self.Officer and wantsPapers and not IsValid( target.PapersWith ) and ( target.PapersCleared or 0 ) < CurTime() then
		self:CheckPapers( target )
		return true
	end
	if looksOfficer( target ) and not self.Officer and best < 260 and ( self.SaluteUntil or 0 ) < CurTime() then
		self.SaluteUntil = CurTime() + 40
		self:Salute( target )
		return true
	end
	return false
end

function ENT:PapersIdle()
	local o = self.PapersWith
	if not IsValid( o ) or not self.Undercover then
		self.PapersReady, self.PapersGo, self.PapersSpot = nil, nil, nil
		return false
	end
	local spot = self.PapersSpot
	if not spot then
		self:StartActivity( ACT_IDLE )
		self.loco:FaceTowards( o:GetPos() )
		self:Wait( 0.2 )
		return true
	end
	if self.Crouched then self:SetStance( false ) end
	if self:GetPos():Distance( spot.pos ) > 12 then
		self:MoveTo( spot.pos, self.WalkSpeed, 8, function() return not IsValid( o ) or self:GetPos():Distance( spot.pos ) < 12 end )
	end
	if not IsValid( o ) or self.Dead then return true end
	self:SetPos( spot.pos )
	self:SetAngles( Angle( 0, spot.yaw, 0 ) )
	self:StartActivity( ACT_IDLE )
	self:PlaySeq( "idle" )
	self.PapersReady = true
	local limit = CurTime() + 6
	while IsValid( o ) and not o.Dead and not self.PapersGo and CurTime() < limit and not self.Dead do coroutine.yield() end
	self.PapersReady = nil
	if not self.PapersGo then return true end
	self.PapersGo = nil
	local book
	local events = {
		{ 6.37, function() book = soldbuch( self, "anim_attachment_RH" ) end },
		{ 7.5, function() if IsValid( book ) then book:Remove() end end },
		{ 10.9, function() book = soldbuch( self, "anim_attachment_RH" ) end },
		{ 11.23, function() if self.VoiceNat == "price" then self:Line( "COD1.Ship.PriceDonitz", "face_ship_donitz" ) end end },
		{ 11.43, function() if IsValid( book ) then book:Remove() end end },
	}
	self:PlayMotion( "papers_price", nil, nil, U.runEvents( events ) )
	if IsValid( book ) then book:Remove() end
	self.IdleUntil = nil
	return true
end

local function alliesGoLoud( ply )
	for _, s in ipairs( ents.FindInSphere( ply:GetPos(), 3000 ) ) do
		if s.IsCOD1Soldier and s.Undercover and not s.Dead and s.COD1Team ~= "axis" then s:BlowCover() end
	end
end

local function blowCover( ply )
	if not IsValid( ply ) or not ply:IsPlayer() then return end
	alliesGoLoud( ply )
	if ply:GetNWBool( "COD1CoverBlown" ) or not GetConVar( "cod1_player_undercover" ):GetBool() then return end
	ply:SetNWBool( "COD1CoverBlown", true )
	ply:PrintMessage( HUD_PRINTCENTER, "Your cover is blown!" )
	for _, s in ipairs( ents.FindInSphere( ply:GetPos(), 3000 ) ) do
		if s.IsCOD1Soldier and s.COD1Team == "axis" and s.Grudges then s.Grudges[ ply ] = CurTime() + 30 end
	end
end

hook.Add( "EntityTakeDamage", "COD1CoverBlown", function( target, dmg )
	local att = dmg:GetAttacker()
	if IsValid( att ) and att:IsPlayer() and target.IsCOD1Soldier and target.COD1Team == "axis" then blowCover( att ) end
end )

hook.Add( "EntityFireBullets", "COD1CoverBlown", function( ent )
	if not IsValid( ent ) or not ent:IsPlayer() then return end
	for _, s in ipairs( ents.FindInSphere( ent:GetPos(), 1500 ) ) do
		if s.IsCOD1Soldier and s.COD1Team == "axis" and not s.Dead then
			blowCover( ent )
			return
		end
	end
end )

hook.Add( "PlayerSpawn", "COD1CoverBlown", function( ply )
	ply:SetNWBool( "COD1CoverBlown", false )
end )

--undercover mode, act natural
