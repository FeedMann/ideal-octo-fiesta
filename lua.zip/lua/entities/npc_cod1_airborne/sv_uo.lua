local U = COD1.AI
local groundAt = U.groundAt

COD1.SmokeClouds = COD1.SmokeClouds or {}

local SIDEARMS = { "luger", "colt", "webley", "tt33" }
local LONGARMS = { "kar98", "garand", "enfield", "mosin", "mp40", "thompson", "sten", "ppsh" }
local LMG_SEQ = { crouch2prone = "lmg_prone", prone_aim = "lmg_prone_idle", prone_shoot_auto = "lmg_fire", prone_shoot = "lmg_fire" }
local LMG_KEYS = { mg34 = true, dp28 = true, mg30cal = true }
local AT_DAMAGE = { pfaust = 800, pschreck = 600, bazooka = 600 }

local function firstOf( list, have )
	for _, k in ipairs( list ) do
		if table.HasValue( have, k ) then return k end
	end
end

function ENT:CanFightTanks()
	return ( self.Launcher and ( self.Rockets or 0 ) > 0 ) or ( self.Satchels or 0 ) > 0
end

function ENT:UOWeaponState()
	self.LmgAnims = LMG_KEYS[ self.WeaponKey ] and self:LookupSequence( "lmg_prone" ) >= 0 or nil
end

local baseInit = ENT.Initialize
function ENT:Initialize()
	baseInit( self )
	local v, w = self.VariantData, self.Weapon
	self.Launcher = w.rocket and self.WeaponKey or nil
	self.Rockets = w.rocket and w.rockets or 0
	self.Fuel = w.flame and w.clip or 0
	if w.flame and v.flameTank then self:SetGroup( "tank", 1 ) end
	if w.rocket or w.flame then self.Grenades = 0 end
	self.Smokes = math.random() < ( v.smokes or 0 ) and 1 or 0
	self.Satchels = v.satchels or 0
	self.Binoc = self.Officer and v.officer and v.officer.binoc and table.HasValue( v.weapons, "binoc" ) or nil
	self:UOWeaponState()
end

local baseArm = ENT.ArmWith
function ENT:ArmWith( key )
	baseArm( self, key )
	if self.Weapon.rocket then self.Mag = math.min( self.Rockets or 0, 1 ) end
	self:UOWeaponState()
end

local baseReload = ENT.Reload
function ENT:Reload()
	if self.WeaponType ~= "rocket" then return baseReload( self ) end
	if self.Rockets <= 0 then return self:SwitchFrom( "empty" ) end
	self:EmitSound( "COD1.Reload." .. self.WeaponKey )
	if self:Wait( self:PlaySeq( "rocket_reload" ), nil, true ) then self.Mag = 1 end
end

local basePlay = ENT.PlaySeq
function ENT:PlaySeq( name, rate )
	if self.LmgAnims and LMG_SEQ[ name ] then name = LMG_SEQ[ name ] end
	return basePlay( self, name, rate )
end

function ENT:Specialist()
	return self.WeaponType == "flame" or self.WeaponType == "rocket"
end

local baseFireAt = ENT.FireAt
function ENT:FireAt( target, enemy )
	if self.WeaponType == "flame" then
		if IsValid( enemy ) and self:GetPos():Distance( enemy:GetPos() ) < U.RANGES.flame[ 2 ] then self:FlameTick( enemy ) end
		return
	end
	if self.WeaponType == "rocket" then return end
	return baseFireAt( self, target, enemy )
end

local baseGunMoving = ENT.CanGunWhileMoving
function ENT:CanGunWhileMoving( enemy )
	if self:Specialist() or self.LmgAnims then return false end
	return baseGunMoving( self, enemy )
end

for _, name in ipairs( { "StrafeShoot", "Backpedal", "TakeCorner" } ) do
	local base = ENT[ name ]
	ENT[ name ] = function( self, ... )
		if self:Specialist() or self.LmgAnims then return false end
		return base( self, ... )
	end
end

local baseVolley = ENT.ShootVolley
function ENT:ShootVolley( enemy, maxShots )
	if self.LmgAnims and not self.Prone then
		if not IsValid( enemy ) or not self:CanShootFrom( "prone", enemy ) then return false end
		self:GoProne()
		if self.Dead or not IsValid( enemy ) then return false end
		self:PlaySeq( "prone_aim" )
		if not self:Wait( 0.3, enemy ) then return false end
	end
	return baseVolley( self, enemy, maxShots )
end

local baseSuppress = ENT.Suppress
function ENT:Suppress( pos )
	if self.LmgAnims and not self.Prone then
		self:TurnTo( pos, 0.6 )
		self:GoProne()
		if self.Dead then return true end
	end
	return baseSuppress( self, pos )
end

local baseEngage = ENT.Engage
function ENT:Engage( enemy )
	if not IsValid( enemy ) then return end
	if not self.LmgAnims then return baseEngage( self, enemy ) end
	if self.Mag <= 0 then return self:Reload() end
	if self:CanShootFrom( "prone", enemy ) then return self:ProneCombat( enemy ) end
	if self.Prone then self:LeaveProne() end
	if self:Reposition( enemy ) then return end
	if self:TakeCover( enemy, { lowOnly = true }, true ) then self:Hide() return end
	self:TurnTo( enemy:GetPos(), 0.5 )
	self:Wait( 0.5, enemy )
end

local baseThreat = ENT.ThreatScore
function ENT:ThreatScore( ent, d2 )
	local s = baseThreat( self, ent, d2 )
	if ent.IsCOD1Tank then s = s + ( self:CanFightTanks() and 1.5 or -1.2 ) end
	return s
end

local function cloudBlocks( a, b, now )
	for i = #COD1.SmokeClouds, 1, -1 do
		local c = COD1.SmokeClouds[ i ]
		if now > c.t1 then
			table.remove( COD1.SmokeClouds, i )
		elseif now > c.t0 then
			local d = b - a
			local len = d:Length()
			if len > 1 then
				d:Div( len )
				local t = math.Clamp( ( c.pos - a ):Dot( d ), 0, len )
				if ( a + d * t ):DistToSqr( c.pos ) < c.r * c.r then return true end
			end
		end
	end
	return false
end
COD1.SmokeBlocks = cloudBlocks

local baseLOS = ENT.LineOfSight
function ENT:LineOfSight( from, ent )
	if not baseLOS( self, from, ent ) then return false end
	if #COD1.SmokeClouds > 0 and IsValid( ent ) and cloudBlocks( from, self:AimPoint( ent ), CurTime() ) then return false end
	return true
end

function ENT:ShowBinoculars( on )
	local v = self.VariantData
	for i, k in ipairs( v.weapons ) do
		if k == ( on and "binoc" or self.WeaponKey ) then self:SetGroup( "weapon", i - 1 ) end
	end
	self.Spotting = on or nil
	self.SightRange = on and 6500 or 4000
end

function ENT:SpotterIdle()
	if self.Crouched or self.Hiding or math.random() < 0.4 then return false end
	self:ShowBinoculars( true )
	local seq = self:LookupSequence( "binoc_idle" )
	if seq < 0 then self:ShowBinoculars( false ) return false end
	self:StartActivity( ACT_IDLE )
	self:PlaySeq( "binoc_idle" )
	local done = CurTime() + math.Rand( 4, 9 )
	while CurTime() < done and not self.Dead and not IsValid( self:UpdateEnemy() ) and not self.PendingPain and not self.GrenadeThreat do
		coroutine.yield()
	end
	self:ShowBinoculars( false )
	if IsValid( self.Enemy ) then self:Say( "enemysighted", 1, true ) end
	return true
end

function ENT:RadioIdle()
	if CurTime() < ( self.NextRadio or 0 ) then return false end
	self.NextRadio = CurTime() + math.Rand( 25, 50 )
	self:Say( "radio", 1 )
	return false
end

local baseRoleIdle = ENT.RoleIdle
function ENT:RoleIdle()
	if self.Binoc and self:SpotterIdle() then return true end
	if self.VariantData.radio then self:RadioIdle() end
	return baseRoleIdle( self )
end

function ENT:HostileTank( range )
	local best, bd
	local me = self:GetPos()
	for t in pairs( COD1.Tanks or {} ) do
		if IsValid( t ) and not t.Dead and t.COD1Team ~= self.COD1Team then
			local d = me:DistToSqr( t:GetPos() )
			if d < range * range and ( not bd or d < bd ) and self:CanSee( t ) then best, bd = t, d end
		end
	end
	return best
end

function ENT:Sidearm()
	return firstOf( SIDEARMS, self.VariantData.weapons ) or firstOf( LONGARMS, self.VariantData.weapons )
end

function ENT:DropTube()
	local att = self:GetAttachment( self:LookupAttachment( "anim_attachment_RH" ) )
	if not att then return end
	local p = ents.Create( "prop_physics" )
	if not IsValid( p ) then return end
	p:SetModel( "models/cod1/weapons/w_pfaust.mdl" )
	if not util.IsValidModel( p:GetModel() ) then p:Remove() return end
	COD1.PlaceWorldGun( p, att.Pos, att.Ang )
	p:Spawn()
	p:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
	SafeRemoveEntityDelayed( p, 60 )
end

function ENT:SwitchFrom( reason )
	local long = reason == "spent" or self.WeaponKey == "pfaust"
	local key = long and ( firstOf( LONGARMS, self.VariantData.weapons ) or self:Sidearm() ) or self:Sidearm()
	if not key or key == self.WeaponKey then return false end
	self:ArmWith( key )
	self.Grenades = math.max( self.Grenades, 1 )
	return true
end

function ENT:RocketHitChance( target, dist )
	local k = target.IsCOD1Tank and math.Clamp( 1.15 - dist / 3500, 0.35, 0.95 ) or math.Clamp( 0.8 - dist / 3000, 0.15, 0.6 )
	if self.Moving then k = k * 0.6 end
	if not self:Fair() then k = k * ( self:EnemySide() and 0.85 or 1.1 ) end
	return k * GetConVar( "cod1_npc_accuracy" ):GetFloat()
end

function ENT:FireRocket( target )
	local w = self.Weapon
	local src = self:MuzzlePos()
	local aim = target.IsCOD1Tank and target:WorldSpaceCenter() or self:AimPoint( target ) - Vector( 0, 0, 20 )
	local dist = src:Distance( aim )
	if math.random() > self:RocketHitChance( target, dist ) then
		local off = VectorRand()
		off.z = off.z * 0.4
		aim = aim + off:GetNormalized() * math.Rand( 70, 180 ) * ( 1 + dist / 2500 )
	end
	local dir = ( aim - src ):GetNormalized()
	local r = ents.Create( "cod1_rocket" )
	if not IsValid( r ) then return end
	r:SetPos( src + dir * 24 )
	r:SetAngles( dir:Angle() )
	r.Shooter = self
	r.Kind = self.WeaponKey
	r.TankDamage = AT_DAMAGE[ self.WeaponKey ] or 600
	r.Speed = w.speed or 2800
	r:SetOwner( self )
	r:Spawn()
	self.Rockets = self.Rockets - 1
	self.Mag = math.max( self.Rockets, 0 )
	self.LastFired = CurTime()
	COD1.NoteGunfire( self:GetPos() )
	self:EmitSound( "COD1.Fire." .. self.WeaponKey )
	local ed = EffectData()
	ed:SetEntity( self )
	ed:SetAttachment( self.MuzzleAtt or 0 )
	ed:SetFlags( 0 )
	ed:SetDamageType( COD1.WeaponFXIndex[ self.WeaponKey ] or 0 )
	util.Effect( "cod1npc_muzzleflash", ed, true, true )
	COD1.FX( "smoke/smoke_panzerfaust", src - dir * 40, -dir )
	util.ScreenShake( src, 3, 40, 0.4, 300 )
	self:MarkBattle()
end

function ENT:RocketAttack( target )
	if self.Rockets <= 0 then return self:SwitchFrom( "empty" ) or true end
	if self.Prone then self:LeaveProne() end
	if self.Hiding then self.Hiding = false end
	self:TurnTo( target:GetPos(), 0.7 )
	if self.Dead or not IsValid( target ) then return true end
	if not self.Crouched or not self.RocketReady then
		self.Crouched = true
		self.RocketReady = true
		if not self:Wait( self:PlaySeq( "rocket_ready" ), target, true ) then return true end
	end
	if target.IsCOD1Tank then self:Say( "bazooka", 0.5 ) end
	self:PlaySeq( "rocket_aim" )
	self:UpdateAim( target )
	if not self:Wait( 0.5 + self:AimTime() * 2, target ) then return true end
	if self.Dead or not IsValid( target ) or not self:CanSee( target ) then return true end
	local aim = target.IsCOD1Tank and target:WorldSpaceCenter() or self:AimPoint( target )
	if not self:LineOfFireClear( aim ) or ( not target.IsCOD1Tank and self:AlliesNear( target:GetPos(), 260 ) ) then
		self:Wait( 0.4, target )
		return self:TrySideStep( target, true ) or true
	end
	self:UpdateAim( target )
	self:PlaySeq( "rocket_fire" )
	self:FireRocket( target )
	self:Wait( 0.6, nil, true )
	if self.Dead then return true end
	if self.Weapon.oneShot then
		self:DropTube()
		self.RocketReady = nil
		self:SwitchFrom( "spent" )
		return true
	end
	if self.Rockets > 0 then
		self:EmitSound( "COD1.Reload." .. self.WeaponKey )
		self:Wait( self:PlaySeq( "rocket_reload" ), nil, true )
		self.Mag = 1
	else
		self.RocketReady = nil
		self:SwitchFrom( "empty" )
	end
	return true
end

function ENT:CloseIn( enemy, want, crouch )
	local lkp = self.LastKnownPos or enemy:GetPos()
	if not self:MayAdvance() and ( self:Holding() or self:GetPos():Distance( lkp ) < want * 2.5 ) then
		if not self.Crouched then self:SetStance( true ) end
		self:PlaySeq( "crouch_idle" )
		self:Wait( math.Rand( 0.6, 1.2 ), lkp )
		return
	end
	self.Advancing = true
	self:MoveTo( self:SquadSpot( lkp ), self.RunSpeed, 2.5, function()
		return not IsValid( enemy ) or ( self:CanSee( enemy ) and self:GetPos():Distance( enemy:GetPos() ) < want )
	end, crouch )
	self.Advancing = false
end

function ENT:WorthARocket( enemy )
	if enemy.Manning then return true end
	local n = 0
	for s in pairs( COD1.Soldiers ) do
		if IsValid( s ) and s ~= enemy and not s.Dead and s.COD1Team == enemy.COD1Team and s:GetPos():DistToSqr( enemy:GetPos() ) < 230 * 230 then
			n = n + 1
		end
	end
	return n >= 2
end

function ENT:RocketCombat( enemy, visible, dist )
	if visible and dist > U.RANGES.rocket[ 1 ] and dist < U.RANGES.rocket[ 2 ] then
		if self:WorthARocket( enemy ) then return self:RocketAttack( enemy ) end
		self.RocketReady = nil
		if self:SwitchFrom( "infantry" ) then return true end
	end
	if visible and dist <= U.RANGES.rocket[ 1 ] then
		self.RocketReady = nil
		if self:SwitchFrom( "close" ) then return true end
	end
	if CurTime() < self.Suppressed and not self:InCover() then
		if self:TakeCover( enemy, { lowOnly = true }, true ) then self:Hide() return true end
	end
	self.RocketReady = nil
	self:CloseIn( enemy, U.RANGES.rocket[ 2 ] * 0.7, true )
	return true
end

function ENT:FlameTargets( src, dir, range )
	local hit = {}
	for _, e in ipairs( ents.FindInSphere( src, range ) ) do
		if e ~= self and IsValid( e ) and ( e:IsPlayer() or e:IsNPC() or e:IsNextBot() or e.IsCOD1Soldier or e:GetClass() == "prop_physics" ) then
			local p = e:WorldSpaceCenter()
			local to = p - src
			local d = to:Length()
			if d > 1 and to:GetNormalized():Dot( dir ) > 0.9 - math.min( d, 200 ) / 1000
				and not util.TraceLine( { start = src, endpos = p, mask = MASK_SOLID_BRUSHONLY } ).Hit then
				hit[ #hit + 1 ] = e
			end
		end
	end
	return hit
end

function ENT:FlameTick( enemy )
	local att = self.MuzzleAtt and self.MuzzleAtt > 0 and self:GetAttachment( self.MuzzleAtt )
	local src = att and att.Pos or self:EyePosition()
	local aim = IsValid( enemy ) and self:AimPoint( enemy ) or src + self:GetForward() * 300
	local dir = ( aim - src ):GetNormalized()
	local ed = EffectData()
	ed:SetEntity( self )
	ed:SetAttachment( self.MuzzleAtt or 0 )
	ed:SetOrigin( src )
	ed:SetNormal( dir )
	util.Effect( "cod1_flame", ed, true, true )
	for _, e in ipairs( self:FlameTargets( src, dir, 420 ) ) do
		if not ( e.IsCOD1Soldier and e.COD1Team == self.COD1Team ) and not ( e:IsPlayer() and not self:IsHostileTo( e ) ) then
			local dmg = DamageInfo()
			dmg:SetDamage( e:IsPlayer() and 5 or 14 )
			dmg:SetDamageType( DMG_BURN )
			dmg:SetAttacker( self )
			dmg:SetInflictor( self )
			dmg:SetDamagePosition( e:WorldSpaceCenter() )
			dmg:SetDamageForce( dir * 200 )
			e:TakeDamageInfo( dmg )
			if IsValid( e ) and ( e:Health() > 0 or e:GetClass() == "prop_physics" ) then COD1.Burn( e, 3, self ) end
		end
	end
	local tr = util.TraceLine( { start = src, endpos = src + dir * 420, mask = MASK_SOLID_BRUSHONLY } )
	if tr.Hit and math.random() < 0.3 then util.Decal( "Scorch", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal ) end
	COD1.NoteGunfire( self:GetPos() )
end

function ENT:FlameAttack( enemy )
	if self.Prone then self:LeaveProne() end
	if self.Crouched or self.Hiding then self:SetStance( false ) end
	self:TurnTo( enemy:GetPos(), 0.5 )
	self:PlaySeq( "flame_aim" )
	self:UpdateAim( enemy )
	if not self:Wait( 0.25 + self:AimTime(), enemy ) then return true end
	self:EmitSound( "COD1.Flame.Start" )
	local loop = CreateSound( self, "COD1.Flame.Loop" )
	loop:Play()
	self:PlaySeq( "flame_shoot" )
	local stop = CurTime() + math.Rand( 1.2, 2.6 )
	while CurTime() < stop and not self.Dead and IsValid( enemy ) and not self.PendingPain and self.Fuel > 0 do
		self.loco:FaceTowards( enemy:GetPos() )
		self:UpdateAim( enemy )
		self:FlameTick( enemy )
		self.Fuel = self.Fuel - 1
		self:MarkBattle()
		local t = CurTime() + 0.1
		while CurTime() < t and not self.Dead do coroutine.yield() end
	end
	loop:Stop()
	self:EmitSound( "COD1.Flame.Stop" )
	if self.Dead then return true end
	if self.Fuel <= 0 then
		self:EmitSound( "COD1.Flame.Empty" )
		self:SwitchFrom( "empty" )
		return true
	end
	self:PlaySeq( "flame_aim" )
	self:Wait( math.Rand( 0.2, 0.5 ), enemy )
	return true
end

function ENT:FlameCombat( enemy, visible, dist )
	if visible and dist < U.RANGES.flame[ 2 ] then return self:FlameAttack( enemy ) end
	if CurTime() < self.Suppressed and dist > 700 and not self:InCover() then
		if self:TakeCover( enemy, { lowOnly = true, closer = true, radius = 600 }, true ) then self:Hide() return true end
	end
	self:CloseIn( enemy, U.RANGES.flame[ 2 ] * 0.8, dist > 600 )
	return true
end

function ENT:PlantSatchel( tank )
	local side = ( self:GetPos() - tank:GetPos() )
	side.z = 0
	if side:LengthSqr() < 1 then side = -tank:GetForward() end
	side:Normalize()
	local mins, maxs = tank:OBBMins(), tank:OBBMaxs()
	local reach = math.max( maxs.x - mins.x, maxs.y - mins.y ) * 0.5 + 34
	local spot = groundAt( tank:GetPos() + side * reach ) or ( tank:GetPos() + side * reach )
	self:Say( "grenadeattack", 0.8 )
	self:MoveTo( spot, self.RunSpeed, 6, function()
		return not IsValid( tank ) or tank.Dead or self:GetPos():Distance2D( spot ) < 30
	end, true, true )
	if self.Dead or not IsValid( tank ) or tank.Dead or self:GetPos():Distance2D( spot ) > 60 then return true end
	self:SetAngles( Angle( 0, ( -side ):Angle().y, 0 ) )
	self.Crouched, self.Hiding = false, false
	local planted = false
	local function plant()
		if planted or not IsValid( tank ) then return end
		planted = true
		self.Satchels = self.Satchels - 1
		local hand = self:GetAttachment( self:LookupAttachment( "anim_attachment_RH" ) )
		local s = ents.Create( "cod1_satchel" )
		if not IsValid( s ) then return end
		local p = hand and hand.Pos or self:GetPos() + self:GetForward() * 20 + Vector( 0, 0, 30 )
		local tr = util.TraceLine( { start = p, endpos = p - side * 90, filter = self } )
		s:SetPos( tr.Hit and tr.HitPos or p )
		s:SetAngles( Angle( 0, self:GetAngles().y, 0 ) )
		s.Thrower = self
		s:Spawn()
		s:Stick( tr.Entity == tank and tank or ( IsValid( tr.Entity ) and tr.Entity or nil ) )
		self:EmitSound( "COD1.SatchelPlant" )
	end
	self:PlayMotion( "plant_bomb", nil, nil, function( el ) if el >= 1.2 then plant() end end )
	plant()
	if self.Dead then return true end
	local away = self:GetPos() + side * 500
	self:MoveTo( groundAt( away ) or away, self.RunSpeed, 4, nil, false, true )
	if not self.Dead then self:Hide() end
	return true
end

function ENT:AvoidTank( tank )
	if ( self.NextTankDuck or 0 ) > CurTime() then return false end
	self.NextTankDuck = CurTime() + 5
	if self:InCover() and self.Hiding then return false end
	if self:TakeCover( tank, { radius = 900 }, true ) then self:Hide() return true end
	return false
end

function ENT:ThrowSmoke( enemy )
	self.Smokes = self.Smokes - 1
	local to = enemy:GetPos() - self:GetPos()
	local target = self:GetPos() + to * math.Clamp( 260 / math.max( to:Length(), 1 ), 0.25, 0.5 )
	target = groundAt( target ) or target
	self:TurnTo( target, 0.6 )
	self:Say( "smoke", 1, true )
	local crouch = self.Crouched or self.Hiding
	local seqName, fireFrame = crouch and "crouch_grenade_throw" or "grenade_throw", crouch and 46 or 47
	local dur = self:PlaySeq( seqName )
	if not self:Wait( fireFrame / 30, target, true ) then return true end
	local hand = self:GetAttachment( self:LookupAttachment( "anim_attachment_RH" ) )
	local from = hand and hand.Pos or self:EyePosition()
	local nade = ents.Create( "cod1_grenade" )
	if IsValid( nade ) then
		nade.Smoke = true
		nade:SetPos( from )
		nade.Thrower = self
		nade.ThrownAt = CurTime()
		nade:SetOwner( self )
		nade:Spawn()
		nade:SetFuse( 2.5 )
		local phys = nade:GetPhysicsObject()
		local vel = ( target - from ):GetNormalized() * 520 + Vector( 0, 0, 220 )
		if IsValid( phys ) then phys:SetVelocity( vel ) phys:AddAngleVelocity( VectorRand() * 400 ) end
		timer.Simple( 0.3, function() if IsValid( nade ) then nade:SetOwner( NULL ) end end )
		self:EmitSound( "COD1.GrenadeThrow" )
	end
	self:Wait( dur - fireFrame / 30, nil, true )
	return true
end

function ENT:RadioCall( pos )
	if self:LookupSequence( "radio_in" ) < 0 then
		self:Say( "radio", 1, true )
		if self.Crouched or self.Hiding then self:SetStance( false ) end
		return self:Wait( 1.5, pos )
	end
	self:SetStance( true )
	self:TurnTo( pos, 0.5 )
	local function hangUp()
		self:SetGroup( "left", 0 )
		self.OnRadio = nil
	end
	self.OnRadio = true
	local dur = self:PlaySeq( "radio_in" )
	if not self:Wait( 1, nil, true ) then return hangUp() end
	self:SetGroup( "left", 1 )
	if not self:Wait( dur - 1 ) then return hangUp() end
	self:PlaySeq( "radio_talk" )
	self:Say( "radio", 1, true )
	if not self:Wait( math.Rand( 3.5, 5 ) ) then return hangUp() end
	dur = self:PlaySeq( "radio_out" )
	if not self:Wait( 0.8, nil, true ) then return hangUp() end
	hangUp()
	self:Wait( dur - 0.8, nil, true )
	self:PlaySeq( "crouch_aim" )
	return not self.Dead
end

function ENT:CallFireMission( pos )
	self.NextFireMission = CurTime() + math.Rand( 50, 80 )
	if not self:RadioCall( pos ) then
		self.NextFireMission = CurTime() + math.Rand( 8, 15 )
		return true
	end
	COD1.ArtilleryStrike( pos, self, math.random( 3, 5 ), 260, 4 )
	return true
end

function ENT:UOCombat( enemy, visible, dist )
	if self.Spotting then self:ShowBinoculars( false ) end
	local tank = enemy.IsCOD1Tank and enemy or self:HostileTank( 1800 )
	if tank then
		if not self.SawTank or self.SawTank ~= tank then
			self.SawTank = tank
			self:Say( "tanksighted", 1, true )
		end
		if self.Launcher and self.Rockets > 0 and self:GetPos():Distance( tank:GetPos() ) < U.RANGES.rocket[ 2 ] then
			if self.WeaponKey ~= self.Launcher then
				self:ArmWith( self.Launcher )
				self:Say( "bazooka", 0.8 )
			end
			return self:RocketAttack( tank )
		end
		if self.Satchels > 0 and self:GetPos():Distance( tank:GetPos() ) < 1100 then
			return self:PlantSatchel( tank )
		end
		if enemy == tank then
			if self:AvoidTank( tank ) then return true end
			self:SetStance( true )
			self:Wait( 0.6, tank:GetPos() )
			return true
		end
	end
	if self.WeaponType == "rocket" then return self:RocketCombat( enemy, visible, dist ) end
	if self.WeaponType == "flame" then return self:FlameCombat( enemy, visible, dist ) end
	if self.Smokes > 0 and visible and dist > 450 and CurTime() < self.Suppressed and not self:AlliesNear( enemy:GetPos(), 200 ) then
		return self:ThrowSmoke( enemy )
	end
	if self.VariantData.radio and visible and dist > 900 and CurTime() >= ( self.NextFireMission or 0 )
		and not self:AlliesNear( enemy:GetPos(), 700 ) then
		return self:CallFireMission( enemy:GetPos() )
	end
	return false
end

function ENT:DoTankBail()
	local b = self.TankBail
	self.TankBail = nil
	local grav = self.loco:GetGravity()
	self.loco:SetGravity( 0 )
	self:SetCollisionBounds( Vector( -2, -2, 0 ), Vector( 2, 2, 8 ) )
	self:SetAngles( Angle( 0, b.yaw, 0 ) )
	local function hold( pos, t )
		local done = CurTime() + t
		while CurTime() < done and not self.Dead do
			self:SetPos( pos )
			self.loco:SetVelocity( vector_origin )
			coroutine.yield()
		end
	end
	hold( b.climb, self:PlaySeq( "tank_climb_out" ) )
	if not self.Dead then
		self:PlaySeq( "tank_jump_off", 0 )
		local t0, from = CurTime(), b.climb
		while CurTime() - t0 < 0.45 and not self.Dead do
			local k = ( CurTime() - t0 ) / 0.45
			self:SetPos( LerpVector( k * k * ( 3 - 2 * k ), from, b.jump ) )
			self.loco:SetVelocity( vector_origin )
			coroutine.yield()
		end
	end
	self:SetCollisionBounds( U.HULL_MINS, U.HULL_MAXS )
	self.loco:SetGravity( grav )
	if self.Dead then return end
	self:SetPos( b.jump )
	if b.burning then COD1.Burn( self, 8 ) end
	self:PlayMotion( "tank_jump_off", b.land )
	if self.Dead then return end
	self:EmitSound( "COD1.Land." .. COD1.SurfaceUnder( self ) )
	self.Crouched = true
	self:Say( "misccombat", 0.5 )
end

local baseRun = ENT.RunBehaviour
function ENT:RunBehaviour()
	if self.TankBail then self:DoTankBail() end
	return baseRun( self )
end

local baseRole = ENT.RoleCombat
function ENT:RoleCombat( enemy, visible, dist )
	if self:UOCombat( enemy, visible, dist ) then return true end
	return baseRole( self, enemy, visible, dist )
end

--all the united offensive stuff, bazookas flamethrowers satchels
