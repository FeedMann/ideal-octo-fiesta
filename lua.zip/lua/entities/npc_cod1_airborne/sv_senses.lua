local U = COD1.AI

local FRIENDLY_CLASSES = {
	[ CLASS_PLAYER ] = true, [ CLASS_PLAYER_ALLY ] = true, [ CLASS_PLAYER_ALLY_VITAL ] = true,
	[ CLASS_CITIZEN_PASSIVE ] = true, [ CLASS_CITIZEN_REBEL ] = true, [ CLASS_VORTIGAUNT ] = true,
	[ CLASS_HACKED_ROLLERMINE ] = true, [ CLASS_NONE ] = true, [ CLASS_BULLSEYE ] = true,
	[ CLASS_EARTH_FAUNA ] = true, [ CLASS_MISSILE ] = true, [ CLASS_FLARE ] = true,
}
local NEUTRAL_CLASSES = {
	[ CLASS_NONE ] = true, [ CLASS_BULLSEYE ] = true, [ CLASS_EARTH_FAUNA ] = true, [ CLASS_MISSILE ] = true, [ CLASS_FLARE ] = true,
}

COD1.OtherNPCs = COD1.OtherNPCs or {}
hook.Add( "OnEntityCreated", "COD1TrackNPCs", function( ent )
	timer.Simple( 0, function()
		if IsValid( ent ) and not ent.IsCOD1Soldier and not ent.COD1Bullseye and ( ent:IsNPC() or ent:IsNextBot() ) then COD1.OtherNPCs[ ent ] = true end
	end )
end )
hook.Add( "EntityRemoved", "COD1TrackNPCs", function( ent ) COD1.OtherNPCs[ ent ] = nil end )
for _, e in ipairs( ents.GetAll() ) do
	if not e.IsCOD1Soldier and not e.COD1Bullseye and e:GetClass() ~= "npc_bullseye" and ( e:IsNPC() or e:IsNextBot() ) then COD1.OtherNPCs[ e ] = true end
end

local function hasClass( ent, name )
	local c = ent.VJ_NPC_Class
	if not istable( c ) then return false end
	for _, v in ipairs( c ) do
		if v == name then return true end
	end
	return false
end

local function isVJ( ent )
	return ent.IsVJBaseSNPC == true
end

local BULL_FLAGS = 65536 + 131072

local function bullHeight( s )
	if s.Prone then return 12 end
	if s.Crouched or s.Hiding then return 32 end
	return 48
end

local function targetable( s )
	return IsValid( s ) and not s.Dead and not s.Downed and not s.Surrendered and not s:IsFlagSet( FL_NOTARGET )
end

local function dropBullseye( s )
	if IsValid( s.COD1Bull ) then s.COD1Bull:Remove() end
	s.COD1Bull = nil
end

local function bullseye( s )
	local b = s.COD1Bull
	if not IsValid( b ) then
		b = ents.Create( "npc_bullseye" )
		if not IsValid( b ) then return nil end
		b.COD1Bullseye = true
		b.COD1Owner = s
		b:SetKeyValue( "spawnflags", tostring( BULL_FLAGS ) )
		b:SetKeyValue( "health", "9999" )
		b:SetPos( s:GetPos() + Vector( 0, 0, bullHeight( s ) ) )
		b:Spawn()
		b:Activate()
		b:SetParent( s )
		s.COD1Bull = b
		s:DeleteOnRemove( b )
	end
	b:SetLocalPos( Vector( 0, 0, bullHeight( s ) ) )
	return b
end

timer.Create( "COD1VanillaFight", 0.5, 0, function()
	if not next( COD1.Soldiers ) then return end
	local vanilla = {}
	for npc in pairs( COD1.OtherNPCs ) do
		if IsValid( npc ) and npc:IsNPC() and npc:Health() > 0 and not isVJ( npc ) and not npc.COD1Bullseye then vanilla[ #vanilla + 1 ] = npc end
	end
	for s in pairs( COD1.Soldiers ) do
		if not targetable( s ) or not s.IsHostileTo then
			if IsValid( s ) then dropBullseye( s ) end
		elseif #vanilla > 0 then
			local b = bullseye( s )
			local pos = s:GetPos()
			for _, npc in ipairs( vanilla ) do
				if npc:GetPos():DistToSqr( pos ) < 4000 * 4000 then
					local rel = s:IsHostileTo( npc ) and D_HT or D_LI
					if IsValid( b ) then npc:AddEntityRelationship( b, rel, 99 ) end
					npc:AddEntityRelationship( s, rel, 99 )
				end
			end
		end
	end
end )

function ENT:Say( event, chance, force )
	if self.Dead and event ~= "death" then return end
	if not force and not GetConVar( "cod1_npc_chatter" ):GetBool() then return end
	if chance and math.random() > chance then return end
	local team = self.COD1Team
	if not force and ( CurTime() < self.NextTalk or CurTime() < ( COD1.NextSquadTalk[ team ] or 0 ) ) then return end
	local line = self.RoleLine and self:RoleLine( event )
	if line == false then return end
	if not line then
		local nat = COD1.Voices[ self.VoiceNat ]
		local lines = nat and nat[ self.Voice ] and nat[ self.Voice ][ event ]
		if not lines or #lines == 0 then return end
		if event == "enemysighted" and self.VoiceNat == "german" then lines = self:CalloutLines( lines ) end
		line = lines[ math.random( #lines ) ]
	end
	self:SpeakLine( line )
end

local CALLOUTS = {
	[ 1 ] = { russian = { "cod1/voiceovers/generic/axis/a/es_ger_a_004alt_russen.wav" },
		british = { "cod1/voiceovers/generic/axis/a/es_ger_a_003alt_englander.wav" } },
	[ 2 ] = { russian = { "cod1/voiceovers/generic/axis/b/es_ger_b_004_russen.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_004 alt_russen.wav" },
		british = { "cod1/voiceovers/generic/axis/b/es_ger_b_003_englander.wav", "cod1/voiceovers/generic/axis/b/es_ger_b_003 alt_englander.wav" } },
}

function ENT:CalloutLines( lines )
	local e = self.Enemy
	local model = IsValid( e ) and e.VariantData and e.VariantData.model or ""
	local side = model:find( "/russian/", 1, true ) and "russian" or model:find( "/british/", 1, true ) and "british"
		or model:find( "/american/", 1, true ) and "american"
	if side == "american" then return lines end
	local out = {}
	for _, l in ipairs( lines ) do
		if not l:find( "amerikaner", 1, true ) and not l:find( "dieami", 1, true ) then out[ #out + 1 ] = l end
	end
	for _, l in ipairs( side and CALLOUTS[ self.Voice ] and CALLOUTS[ self.Voice ][ side ] or {} ) do
		out[ #out + 1 ] = l
		out[ #out + 1 ] = l
	end
	return #out > 0 and out or lines
end

function ENT:Quick( event )
	if self.Dead or self.VariantData.fixedName then return false end
	local set = COD1.QuickChat and COD1.QuickChat[ self.VoiceNat ]
	local lines = set and set[ event ]
	if not lines or #lines == 0 then return false end
	self:SpeakLine( lines[ math.random( #lines ) ] )
	return true
end

function ENT:SpeakLine( path, level )
	local team = self.COD1Team
	local dur = COD1.SoundLen and COD1.SoundLen[ path ] or SoundDuration( path )
	if dur <= 0 then dur = 1.5 end
	if self.LastLine then self:StopSound( self.LastLine ) end
	self.LastLine = path
	self:EmitSound( path, level or 85, 100, 1, CHAN_VOICE )
	self.NextTalk = CurTime() + dur + math.Rand( 2, 5 )
	COD1.NextSquadTalk[ team ] = CurTime() + dur * 0.8
	if self.TalkLayer and self:IsValidLayer( self.TalkLayer ) then self:RemoveLayer( self.TalkLayer ) end
	self.TalkLayer = self:FaceGesture( "face_talk", false )
	self.TalkUntil = CurTime() + dur
	return dur
end

function ENT:IsAlly( ent )
	if not IsValid( ent ) or ent == self then return false end
	if ent.IsCOD1Soldier then return ent.COD1Team == self.COD1Team end
	if ent:IsPlayer() or ent:IsNPC() then return not self:IsHostileTo( ent ) end
	return false
end

function COD1.VJSide( ent )
	if ent.COD2Faction then
		if ent.AlliedWithPlayerAllies then return COD1.PlayerSide() end
		local side = ent.COD2Faction == "de" and "axis" or "allies"
		if side == COD1.PlayerSide() then return nil end
		return side
	end
	if ent.PlayerFriendly or hasClass( ent, "CLASS_PLAYER_ALLY" ) then return COD1.PlayerSide() end
	return nil
end

function ENT:HandlePerceivedRelationship( other )
	if self.Dead or self.Downed or not IsValid( other ) then return end
	return self:IsHostileTo( other ) and D_HT or D_LI
end

function ENT:IsHostileTo( ent )
	if not IsValid( ent ) or ent == self or self.Surrendered or ent.Surrendered then return false end
	if ent:IsPlayer() then
		if not ent:Alive() or GetConVar( "ai_ignoreplayers" ):GetBool() or ent:IsFlagSet( FL_NOTARGET ) then return false end
		if ( self.Grudges[ ent ] or 0 ) > CurTime() then return true end
		if self.COD1Team == "axis" and COD1.IsUndercover( ent ) then return false end
		return GetConVar( self:EnemySide() and "cod1_axis_hostile_players" or "cod1_npc_hostile_players" ):GetBool()
	end
	if self.Undercover and ( self.Grudges[ ent ] or 0 ) <= CurTime() then return false end
	if ent.Undercover and ( self.Grudges[ ent ] or 0 ) <= CurTime() then return false end
	if ent.COD1Team then return ent.COD1Team ~= self.COD1Team and ent:Health() > 0 and not ent.Dead and not ent.Downed end
	if ( self.Grudges[ ent ] or 0 ) > CurTime() then return true end
	if ent:IsNPC() and isVJ( ent ) then
		if ent:Health() <= 0 or ent.Dead then return false end
		if VJ_BEHAVIOR_PASSIVE_NATURE and ent.Behavior == VJ_BEHAVIOR_PASSIVE_NATURE then return false end
		local side = COD1.VJSide( ent )
		return side ~= self.COD1Team
	end
	if ent:IsNPC() then
		if ent:Health() <= 0 or ent:GetNPCState() == NPC_STATE_DEAD then return false end
		return not ( self:EnemySide() and NEUTRAL_CLASSES or FRIENDLY_CLASSES )[ ent:Classify() ]
	end
	if ent:IsNextBot() then return ent:Health() > 0 end
	return false
end

function ENT:EnemySide()
	return self.COD1Team ~= COD1.PlayerSide()
end

function ENT:Fair()
	return GetConVar( "cod1_npc_fair" ):GetBool()
end

function ENT:AimTime()
	if self:Fair() then return 0.3 end
	return self:EnemySide() and 0.5 or 0.1
end

function ENT:PoseName()
	if self.Prone then return "prone" end
	if self.Crouched or self.Hiding then return "crouch" end
	return "stand"
end

function ENT:EyePosition()
	local h = 64
	if self.Prone then h = 14 elseif self.Hiding then h = 28 elseif self.Crouched then h = 40 end
	return self:GetPos() + Vector( 0, 0, h )
end

function ENT:AimPoint( ent )
	if ent:IsPlayer() then return ent:GetPos() + Vector( 0, 0, ent:Crouching() and 28 or 44 ) end
	if ent.IsCOD1Soldier then
		return ent:GetPos() + Vector( 0, 0, ent.Prone and 10 or ( ent.Hiding and 26 or ( ent.Crouched and 32 or 46 ) ) )
	end
	return ent:WorldSpaceCenter()
end

local SIGHT_MASK = bit.bor( MASK_SHOT, CONTENTS_BLOCKLOS )

function ENT:LineOfSight( from, ent )
	local tr = util.TraceLine( { start = from, endpos = self:AimPoint( ent ), filter = self, mask = SIGHT_MASK } )
	return tr.Entity == ent or tr.Fraction >= 0.99
end

function ENT:CanSee( ent )
	if not IsValid( ent ) then return false end
	if self:LineOfSight( self:EyePosition(), ent ) then return true end
	if self.Crouched or self.Hiding or self.Prone then return self:LineOfSight( self:GetPos() + Vector( 0, 0, 64 ), ent ) end
	return false
end

function ENT:CanShootFrom( pose, ent, from )
	from = ( from or self:GetPos() ) + Vector( 0, 0, U.POSE_HEIGHT[ pose ] )
	local tr = util.TraceLine( { start = from, endpos = self:AimPoint( ent ), filter = self, mask = MASK_SHOT } )
	return tr.Entity == ent or tr.Fraction > 0.98
end

function ENT:InFOV( ent )
	local to = ( ent:GetPos() - self:GetPos() ):GetNormalized()
	return to:Dot( self:GetForward() ) >= self.FOV
end

function ENT:Alert( ent, pos )
	if self.Dead or not IsValid( ent ) or not self:IsHostileTo( ent ) or self:Spares( ent ) then return end
	self.Aware[ ent ] = CurTime() + 10
	self.LastAlert = CurTime()
	if not IsValid( self.Enemy ) then
		self.Enemy = ent
		self.EnemyTime = CurTime()
		self.LastSeen = CurTime() - 1
		self.LastKnownPos = pos or ent:GetPos()
		self.ReactUntil = CurTime() + math.Rand( 0.3, 0.8 )
	end
end

function ENT:LookTowards( pos, t )
	self.LookPos = pos
	self.LookUntil = CurTime() + ( t or 3 )
	self.LastAlert = CurTime()
end

local function guess( from, pos, k )
	local r = VectorRand()
	r.z = 0
	return pos + r:GetNormalized() * math.Rand( 0, math.min( from:Distance( pos ) * k, 450 ) )
end

function ENT:HearShot( shooter, src, dir )
	if self.Dead or self.Parachuting then return end
	if self:IsHostileTo( shooter ) then
		self.HeardAt = guess( self:GetPos(), src, 0.15 )
		self:Alert( shooter, self.HeardAt )
	elseif not IsValid( self.Enemy ) then
		if shooter.IsCOD1Soldier and IsValid( shooter.Enemy ) then
			self:Alert( shooter.Enemy, shooter.LastKnownPos )
		else
			self:LookTowards( src + dir * 700, 3 )
		end
	end
end

function ENT:HearExplosion( pos, attacker )
	if self.Dead or self.Parachuting then return end
	if IsValid( attacker ) and self:IsHostileTo( attacker ) and attacker:GetPos():DistToSqr( self:GetPos() ) < 1100 * 1100 then
		self:Alert( attacker, guess( self:GetPos(), attacker:GetPos(), 0.25 ) )
	end
	if not IsValid( self.Enemy ) then self:LookTowards( pos, 3 ) end
	self.Suppressed = math.max( self.Suppressed, CurTime() + 1.5 )
end

function ENT:ShareEnemy( enemy )
	for _, s in ipairs( U.teammates( self, 1600 ) ) do
		if not IsValid( s.Enemy ) then
			timer.Simple( math.Rand( 0.3, 1.0 ), function()
				if IsValid( s ) and IsValid( enemy ) then s:Alert( enemy, enemy:GetPos() ) end
			end )
		end
	end
end

function ENT:ThreatScore( ent, d2 )
	local s = 2 * ( 1 - math.min( math.sqrt( d2 ) / self.SightRange, 1 ) )
	if ent == self.Enemy then s = s + 0.7 end
	if ( self.Grudges[ ent ] or 0 ) > CurTime() then s = s + 0.6 end
	if ent.IsCOD1Soldier then
		if ent.Enemy == self then s = s + 0.5 end
		if ent.Hiding or ent.Prone then s = s - 0.3 end
		if ent.Unarmed then s = s - 0.4 end
	end
	if ent:IsPlayer() then s = s + 0.25 end
	if d2 < 350 * 350 then s = s + 0.8 end
	return s
end

function ENT:HearsMoving( ent, d2 )
	local speed, reach
	if ent:IsPlayer() then
		if not ent:OnGround() or ent:Crouching() or ent:GetMoveType() == MOVETYPE_NOCLIP then return false end
		speed = ent:GetVelocity():Length2D()
		reach = ent:KeyDown( IN_SPEED ) and speed > 230 and 750 or 450
	elseif ent.IsCOD1Soldier then
		if not ent.Moving or ent.Crouched or ent.Prone or ent.Parachuting then return false end
		speed = ent.loco:GetVelocity():Length2D()
		reach = 500
	else
		return false
	end
	return speed > 140 and d2 < reach * reach
end

function ENT:Scan()
	local myPos = self:GetPos()
	local range2 = self.SightRange * self.SightRange
	local cands = {}
	local heard
	local function consider( ent )
		if ent == self or not IsValid( ent ) then return end
		local d2 = myPos:DistToSqr( ent:GetPos() )
		if d2 > range2 then return end
		local hostile = self:IsHostileTo( ent )
		if ent:IsNPC() and not isVJ( ent ) then ent:AddEntityRelationship( self, hostile and D_HT or D_LI, 99 ) end
		if hostile and self:Spares( ent ) and not IsValid( self.Enemy ) and math.random() < 0.1 and self:InFOV( ent ) then
			self:LookTowards( ent:GetPos() + Vector( 0, 0, 50 ), 3 )
		end
		if not hostile or self:Spares( ent ) or self:HoldsFire( ent ) then return end
		if ent == self.Enemy or d2 < 350 * 350 or ( self.Aware[ ent ] or 0 ) > CurTime() or self:InFOV( ent ) then
			cands[ #cands + 1 ] = { ent, self:ThreatScore( ent, d2 ) }
		elseif d2 < 750 * 750 and self:HearsMoving( ent, d2 ) then
			cands[ #cands + 1 ] = { ent, self:ThreatScore( ent, d2 ) - 0.3 }
			if not heard or d2 < heard[ 2 ] then heard = { ent, d2 } end
		end
	end
	for s in pairs( COD1.Soldiers ) do consider( s ) end
	for _, p in ipairs( player.GetAll() ) do consider( p ) end
	for e in pairs( COD1.OtherNPCs ) do consider( e ) end
	table.sort( cands, function( a, b ) return a[ 2 ] > b[ 2 ] end )
	local cur, curScore = self.Enemy, nil
	for _, c in ipairs( cands ) do
		if c[ 1 ] == cur then curScore = c[ 2 ] break end
	end
	for i = 1, math.min( #cands, 6 ) do
		local e, score = cands[ i ][ 1 ], cands[ i ][ 2 ]
		if curScore and e ~= cur and score < curScore + 0.6 and self:CanSee( cur ) then return cur end
		if self:CanSee( e ) then return e end
	end
	if heard and not IsValid( self.Enemy ) and CurTime() > ( self.LookUntil or 0 ) then
		self:LookTowards( heard[ 1 ]:GetPos() + Vector( 0, 0, 50 ), 2 )
	end
end

function ENT:UpdateEnemy()
	if CurTime() >= self.NextScan then
		self.NextScan = CurTime() + ( self.FarFromPlayers and 0.8 or 0.3 )
		local e = self:Scan()
		if IsValid( e ) then
			if e ~= self.Enemy then
				local fresh = not IsValid( self.Enemy ) or CurTime() - self.LastSeen > 5
				self.Enemy = e
				self.EnemyTime = CurTime()
				self.ReactUntil = CurTime() + math.Rand( 0.25, 0.6 )
				if fresh then
					self:Say( "enemysighted", 0.8 )
					self:ShareEnemy( e )
				end
			end
			self.LastSeen = CurTime()
			self.LastKnownPos = e:GetPos()
		end
	end
	local e = self.Enemy
	if not IsValid( e ) or not self:IsHostileTo( e ) or CurTime() - self.LastSeen > 15 or self:Spares( e ) or self:HoldsFire( e ) then
		if IsValid( e ) and not U.alive( e ) then self:Say( "misccombat", 0.4 ) end
		self.Enemy = nil
	end
	return self.Enemy
end

function ENT:OnSuppressed( shooter )
	local t = self:Inspired() and 1.2 or 2.5
	self.Suppressed = CurTime() + t
	self:Alert( shooter, guess( self:GetPos(), shooter:GetPos(), 0.1 ) )
	if self.VariantData.medic and self.VoiceNat == "american" and COD1.MedicLines and math.random() < 0.15 and CurTime() > self.NextTalk then
		self:SpeakLine( COD1.MedicLines[ math.random( #COD1.MedicLines ) ] )
		return
	end
	self:Say( "undersuppression", 0.25 )
end

--they can only see and hear you now, no more wallhacks
