local U = COD1.AI
local flat, groundAt, blocked, hullClear = U.flat, U.groundAt, U.blocked, U.hullClear

local GRENADE_CLASSES = { cod1_grenade = true, npc_grenade_frag = true }
local MELEE = { { "melee_hit1", 4 }, { "melee_hit2", 6 }, { "melee_hit3", 3 }, { "melee_hit4", 5 } }
local HIDE_IDLES = U.HIDE_IDLES

function ENT:MuzzlePos()
	local att = self.MuzzleAtt and self.MuzzleAtt > 0 and self:GetAttachment( self.MuzzleAtt )
	return att and att.Pos or self:EyePosition()
end

function ENT:LineOfFireClear( target )
	local src = self:MuzzlePos()
	if util.TraceLine( { start = src, endpos = target, mask = MASK_SOLID_BRUSHONLY } ).Hit then return false end
	local tr = util.TraceHull( { start = src, endpos = target, mins = Vector( -6, -6, -6 ), maxs = Vector( 6, 6, 6 ),
		filter = self, mask = MASK_SHOT } )
	return not ( IsValid( tr.Entity ) and self:IsAlly( tr.Entity ) )
end

function ENT:HitChance( enemy, dist )
	local w = self.Weapon
	local k = w.auto and 0.3 or ( w.bolt and 0.7 or 0.5 )
	k = k * math.Clamp( 1.25 - dist / 2500, 0.25, 1.2 )
	k = k * math.Clamp( 0.4 + ( CurTime() - ( self.EnemyTime or CurTime() ) ) * 0.25, 0.4, 1 )
	if CurTime() < self.Suppressed then k = k * 0.75 end
	if self.Moving then k = k * 0.7 end
	if self:Inspired() then k = k * 1.15 end
	if not self:Fair() then k = k * ( self:EnemySide() and 0.85 or 1.15 ) end
	if IsValid( enemy ) then
		local vel = enemy.IsCOD1Soldier and enemy.loco:GetVelocity() or enemy:GetVelocity()
		k = k * math.Clamp( 1.15 - vel:Length2D() / 400, 0.55, 1.15 )
		if enemy:IsPlayer() then
			if enemy:Crouching() then k = k * 0.8 end
			if self:EnemySide() and not self:Fair() then k = k * 0.8 end
		elseif enemy.IsCOD1Soldier then
			if enemy.Prone then k = k * 0.65 elseif enemy.Hiding then k = k * 0.45 elseif enemy.Crouched then k = k * 0.85 end
		end
	end
	if self.AccuracyMult then k = k * math.max( self.AccuracyMult, 0.05 ) end
	return math.Clamp( k * GetConVar( "cod1_npc_accuracy" ):GetFloat(), 0.02, 0.95 )
end

function ENT:FireAt( target, enemy )
	self.LastFired = CurTime()
	COD1.NoteGunfire( self:GetPos() )
	local w = self.Weapon
	local src = self:MuzzlePos()
	local dist = src:Distance( target )
	local dir = ( target - src ):GetNormalized()
	local spread = w.spread * 0.3
	if not IsValid( enemy ) then
		spread = w.spread * ( 1 + dist / 1500 ) * 2
	elseif math.random() > self:HitChance( enemy, dist ) then
		local right = dir:Cross( Vector( 0, 0, 1 ) )
		if right:LengthSqr() < 0.01 then right = Vector( 1, 0, 0 ) end
		right:Normalize()
		local up = right:Cross( dir )
		local a = math.Rand( 0, math.pi * 2 )
		local r = math.Rand( 22, 60 ) * ( 1 + dist / 3000 )
		dir = ( target + right * math.cos( a ) * r + up * math.sin( a ) * r * 0.7 - src ):GetNormalized()
		spread = 0
	end
	self:FireBullets( {
		Attacker = self, Inflictor = self,
		Damage = GetConVar( "cod1_npc_damage" ):GetFloat() * w.damage, Force = 4 * w.damage, Num = 1,
		Src = src, Dir = dir, Spread = Vector( spread, spread, 0 ),
		Tracer = w.auto and 2 or 1, TracerName = "Tracer", IgnoreEntity = self,
		Callback = function( _, tr ) return COD1.BulletImpactFX( tr, self.WeaponKey ) end,
	} )
	self:EmitSound( "COD1.Fire." .. self.WeaponKey )
	local ed = EffectData()
	ed:SetEntity( self )
	ed:SetAttachment( self.MuzzleAtt )
	ed:SetFlags( w.auto and 1 or 0 )
	ed:SetDamageType( COD1.WeaponFXIndex[ self.WeaponKey ] or 0 )
	util.Effect( "cod1npc_muzzleflash", ed, true, true )
	if not w.bolt then self:EjectShell() end
	self.Mag = self.Mag - 1
	if self.Mag <= 0 and w.ping then self:EmitSound( "COD1.GarandPing" ) end
	self:MarkBattle()
end

function ENT:MarkBattle()
	if CurTime() < ( self.NextBattleMark or 0 ) then return end
	self.NextBattleMark = CurTime() + 1
	local me = self:GetPos()
	for _, p in ipairs( player.GetAll() ) do
		if p:GetPos():DistToSqr( me ) < 2500 * 2500 then p:SetNW2Float( "COD1Battle", CurTime() ) end
	end
end

function ENT:FireShot( enemy )
	self:FireAt( self:AimPoint( enemy ), enemy )
end

function ENT:EjectShell()
	local fx = COD1.WeaponFX[ self.WeaponKey ]
	if not fx or not fx[ 3 ] or not self.BrassAtt or self.BrassAtt <= 0 then return end
	COD1.FX( fx[ 3 ], self:GetPos(), self:GetForward(), self, self.BrassAtt )
end

function ENT:Rechamber( enemy )
	self:EmitSound( "COD1.Rechamber." .. self.WeaponKey )
	local seq = self.Prone and "prone_rechamber" or self.Hiding and "hide_rechamber"
		or self.Crouched and "crouch_rechamber" or "rechamber"
	local dur = self:PlaySeq( seq )
	timer.Simple( 0.35, function() if IsValid( self ) and not self.Dead then self:EjectShell() end end )
	self:Wait( dur, enemy, true )
end

function ENT:Reload()
	local snd = "COD1.Reload." .. self.WeaponKey
	self:EmitSound( snd )
	if IsValid( self.Enemy ) then
		self:Say( "coverme", 0.5 )
		self:CallCoverFire( self.Enemy, true )
	end
	local seq = self.Prone and "prone_reload" or ( self.Crouched or self.Hiding ) and "crouch_reload" or "reload"
	if self.Hiding then self.Hiding = false self.Crouched = true end
	local ok = self:Wait( self:PlaySeq( seq ), nil, true )
	self:StopSound( snd )
	if ok and not self.Dead then self.Mag = self.Weapon.clip end
end

function ENT:ShootVolley( enemy, maxShots )
	local w = self.Weapon
	if self.Mag <= 0 or not IsValid( enemy ) then return false end
	local pose = self:PoseName()
	local function ok()
		return not self.Dead and IsValid( enemy ) and self:IsHostileTo( enemy ) and self.Mag > 0
			and not self:Spares( enemy ) and not self:HoldsFire( enemy ) and math.abs( self:FacingDelta( enemy:GetPos() ) ) < 20 and self:LineOfFireClear( self:AimPoint( enemy ) )
	end
	if w.auto then
		self:PlaySeq( pose == "prone" and "prone_shoot_auto" or pose == "crouch" and "crouch_shoot_auto" or "shoot_auto" )
		local n = math.min( math.random( 6, 13 ), self.Mag, maxShots or 99 )
		if n >= 9 then self:Say( "doingsuppression", 0.15 ) end
		for i = 1, n do
			if not ok() then break end
			self:UpdateAim( enemy )
			self:FireShot( enemy )
			if not self:Wait( w.delay, enemy ) then break end
		end
	elseif w.bolt then
		if not ok() then return false end
		self:PlaySeq( pose == "prone" and "prone_shoot" or pose == "crouch" and "crouch_shoot_semi" or "shoot_semi" )
		self:UpdateAim( enemy )
		self:FireShot( enemy )
		self:Wait( 0.25, enemy )
		if self.Mag > 0 and not self.Dead then self:Rechamber( enemy ) end
	else
		local n = math.min( math.random( 2, 3 ), self.Mag, maxShots or 99 )
		for i = 1, n do
			if not ok() then break end
			self:PlaySeq( pose == "prone" and "prone_shoot" or pose == "crouch" and "crouch_shoot_semi" or "shoot_semi" )
			self:UpdateAim( enemy )
			self:FireShot( enemy )
			if not self:Wait( math.max( w.delay, 0.25 ) + math.Rand( 0, 0.15 ), enemy ) then break end
		end
	end
	return true
end

function ENT:Suppress( pos )
	local w = self.Weapon
	if self.Mag <= 0 then self:Reload() return true end
	self:TurnTo( pos, 0.6 )
	local target = pos + Vector( 0, 0, 40 )
	if not self:LineOfFireClear( target ) or blocked( self:EyePosition(), target ) then return false end
	self:Say( "doingsuppression", 0.4 )
	local shots = math.min( self.Mag, w.auto and math.random( 5, 12 ) or ( w.bolt and 1 or 3 ) )
	if w.auto then self:PlaySeq( self.Crouched and "crouch_shoot_auto" or "shoot_auto" ) end
	for i = 1, shots do
		if self.Dead then return true end
		if not w.auto then self:PlaySeq( self.Crouched and "crouch_shoot_semi" or "shoot_semi" ) end
		self:UpdateAim( target )
		self:FireAt( target + VectorRand() * 30 )
		if not self:Wait( w.auto and w.delay or w.delay * 1.5, pos ) then break end
	end
	if w.bolt and self.Mag > 0 and not self.Dead then self:Rechamber() end
	return true
end

function ENT:StrafeShoot( enemy, forceDir, forceRun )
	if self.WeaponType == "pistol" then return false end
	local run = forceRun
	if run == nil then run = self.WeaponType == "smg" and math.random() < 0.7 or math.random() < 0.35 end
	local options = run and {
		{ "run_shoot_left", self:GetRight() * -1 }, { "run_shoot_right", self:GetRight() }, { "run_shoot_back", self:GetForward() * -1 },
	} or {
		{ "walk_shoot_left", self:GetRight() * -1 }, { "walk_shoot_right", self:GetRight() }, { "walk_shoot_back", self:GetForward() * -1 },
	}
	local pick = forceDir and options[ forceDir ] or options[ math.random( #options ) ]
	local seq = self:LookupSequence( pick[ 1 ] )
	local goal = self:GetPos() + pick[ 2 ] * ( run and 260 or 140 )
	if not self:DirectWalk( self:GetPos(), goal ) then return false end
	self:StartActivity( run and ACT_RUN or ACT_WALK )
	self:ResetSequence( seq )
	self.Moving = true
	self.loco:SetDesiredSpeed( self:GetSequenceGroundSpeed( seq ) )
	local w = self.Weapon
	local e = CurTime() + ( run and math.Rand( 1.0, 1.8 ) or math.Rand( 1.2, 2.2 ) )
	local nextShot = CurTime() + 0.2
	while CurTime() < e and not self.Dead and IsValid( enemy ) and self.Mag > 0 and not self.PendingPain and not self.GrenadeThreat do
		self.loco:Approach( goal, 1 )
		self.loco:FaceTowards( enemy:GetPos() )
		self:UpdateAim( enemy )
		if CurTime() >= nextShot and not w.bolt then
			if self:LineOfFireClear( self:AimPoint( enemy ) ) then self:FireShot( enemy ) end
			nextShot = CurTime() + ( w.auto and w.delay * 1.6 or w.delay * math.Rand( 1.1, 1.8 ) )
		end
		coroutine.yield()
	end
	self.Moving = false
	self.StoppedAt = CurTime()
	self.loco:SetDesiredSpeed( 0 )
	return true
end

local function launchVelocity( from, to, angleDeg )
	local g = physenv.GetGravity():Length()
	local delta = to - from
	local d = Vector( delta.x, delta.y, 0 ):Length()
	local th = math.rad( angleDeg )
	local denom = 2 * math.cos( th ) ^ 2 * ( d * math.tan( th ) - delta.z )
	if denom <= 0 or d < 1 then return nil end
	local v = math.sqrt( g * d * d / denom )
	return Vector( delta.x, delta.y, 0 ):GetNormalized() * v * math.cos( th ) + Vector( 0, 0, v * math.sin( th ) )
end

function ENT:AlliesNear( pos, radius )
	for s in pairs( COD1.Soldiers ) do
		if IsValid( s ) and s ~= self and not s.Dead and s.COD1Team == self.COD1Team and s:GetPos():DistToSqr( pos ) < radius * radius then return true end
	end
	for _, p in ipairs( player.GetAll() ) do
		if p:Alive() and not self:IsHostileTo( p ) and p:GetPos():DistToSqr( pos ) < radius * radius then return true end
	end
	return false
end

local NADE_MINS, NADE_MAXS = Vector( -3, -3, -3 ), Vector( 3, 3, 3 )

local function solidOnly( e ) return not ( e:IsPlayer() or e:IsNPC() or e:IsNextBot() ) end

local function arcLands( self, from, target, vel )
	local p, v = from, vel
	local g = physenv.GetGravity()
	for i = 1, 60 do
		local dt = 0.05
		local np = p + v * dt + g * ( 0.5 * dt * dt )
		local tr = util.TraceHull( { start = p, endpos = np, mins = NADE_MINS, maxs = NADE_MAXS, filter = solidOnly, mask = MASK_SOLID } )
		if tr.Hit then
			local hit = tr.HitPos
			return flat( hit - target ):Length() < 140 and math.abs( hit.z - target.z ) < 90 and tr.HitNormal.z > 0.5
		end
		p, v = np, v + g * dt
		if p.z < target.z - 200 then return false end
	end
	return false
end

function ENT:GrenadeArc( target )
	local from = self:GetPos() + Vector( 0, 0, self.Crouched and 44 or 64 )
	for _, ang in ipairs( { 35, 50, 22, 62 } ) do
		local vel = launchVelocity( from, target, ang )
		if vel and vel:Length() < 1300 and arcLands( self, from, target, vel ) then return ang end
	end
end

function ENT:CanThrowGrenade( target )
	if not GetConVar( "cod1_npc_grenades" ):GetBool() or self.Grenades <= 0 or CurTime() < self.NextGrenade then return false end
	local d = self:GetPos():Distance( target )
	local minD = target.z - self:GetPos().z > 60 and 110 or 300
	if d <= minD or d >= 1100 or self:AlliesNear( target, 320 ) then return false end
	local key = math.floor( target.x / 64 ) .. ":" .. math.floor( target.y / 64 ) .. ":" .. math.floor( target.z / 64 )
	local c = self.ArcCache
	if c and c.key == key and CurTime() < c.t and c.from:DistToSqr( self:GetPos() ) < 32 * 32 then
		self.GrenadeAngle = c.ang
		return c.ang ~= nil
	end
	local ang = self:GrenadeArc( target )
	self.ArcCache = { key = key, t = CurTime() + 2, from = self:GetPos(), ang = ang }
	self.GrenadeAngle = ang
	return ang ~= nil
end

function ENT:LaunchGrenade( target, att )
	local hand = self:GetAttachment( self:LookupAttachment( att ) )
	local from = hand and hand.Pos or self:EyePosition()
	local nade = ents.Create( "cod1_grenade" )
	if not IsValid( nade ) then return end
	nade.Model = COD1.GrenadeModels[ string.match( self.VariantData.model, "models/cod1/(%a+)/" ) or "" ] or nade.Model
	nade:SetPos( from )
	nade.Thrower = self
	nade.ThrownAt = CurTime()
	nade:SetOwner( self )
	nade:Spawn()
	nade:SetFuse( math.Rand( 2.8, 3.4 ) )
	self:EmitSound( "COD1.GrenadeThrow" )
	local vel = launchVelocity( from, target + VectorRand() * 20, self.GrenadeAngle or 35 ) or ( target - from ):GetNormalized() * 700
	local phys = nade:GetPhysicsObject()
	if IsValid( phys ) then phys:SetVelocity( vel ) phys:AddAngleVelocity( VectorRand() * 500 ) end
	timer.Simple( 0.3, function() if IsValid( nade ) then nade:SetOwner( NULL ) end end )
end

function ENT:ThrowGrenade( target )
	self.Grenades = self.Grenades - 1
	self.NextGrenade = CurTime() + math.Rand( 15, 25 )
	self:TurnTo( target, 0.8 )
	self:Say( "grenadeattack", 0.9 )
	self:EmitSound( "COD1.GrenadePin" )
	local crouch = self.Crouched or self.Hiding
	local seqName, fireFrame = crouch and "crouch_grenade_throw" or "grenade_throw", crouch and 46 or 47
	local dur = self:PlaySeq( seqName )
	if not self:Wait( fireFrame / 30, target, true ) then return end
	self:LaunchGrenade( target, "anim_attachment_RH" )
	self:Wait( dur - fireFrame / 30, nil, true )
end

local NADE_WORDS = { "grenade", "nade", "frag", "thrown", "molotov", "dynamite", "pipebomb" }
local NOT_NADE = { "weapon_", "item_", "ammo", "smoke", "flare", "flash", "stun", "gas", "bugbait", "spawn", "crate", "box",
	"knife", "blade", "axe", "spear", "ball", "decal", "fragment", "gib" }
local nadeClass = {}

local function looksLikeGrenade( c )
	local known = nadeClass[ c ]
	if known ~= nil then return known end
	known = GRENADE_CLASSES[ c ] or false
	if not known then
		local lc = string.lower( c )
		for _, w in ipairs( NADE_WORDS ) do
			if string.find( lc, w, 1, true ) then known = true break end
		end
		if known then
			for _, bad in ipairs( NOT_NADE ) do
				if string.find( lc, bad, 1, true ) then known = false break end
			end
		end
	end
	nadeClass[ c ] = known
	return known
end

function ENT:FindGrenadeThreat()
	for _, e in ipairs( ents.FindInSphere( self:GetPos(), 300 ) ) do
		local c = e:GetClass()
		if looksLikeGrenade( c ) and not e.HeldBy and not e.Smoke and not IsValid( e:GetParent() ) then
			if GRENADE_CLASSES[ c ] then
				local friendly = IsValid( e.Thrower ) and e.Thrower.COD1Team == self.COD1Team
				if not ( friendly and CurTime() - ( e.ThrownAt or 0 ) < 1.0 ) then return e end
			elseif not e:IsWeapon() and not e:IsNPC() and not e:IsPlayer() and e:GetMoveType() ~= MOVETYPE_NONE
				and CurTime() - ( e.COD1NadeSeen or CurTime() ) < 12 then
				e.COD1NadeSeen = e.COD1NadeSeen or CurTime()
				local owner = e:GetOwner()
				local friendly = IsValid( owner ) and ( owner == self or self:IsAlly( owner ) )
				if not ( friendly and CurTime() - e:GetCreationTime() < 1.0 ) then return e end
			end
		end
	end
end

function ENT:ReactToGrenade( nade )
	self.GrenadeThreat = nil
	if not IsValid( nade ) then return end
	self.ReactingGrenade = true
	self:DoReactToGrenade( nade )
	self.ReactingGrenade = false
	self.GrenadeThreat = nil
end

function ENT:DoReactToGrenade( nade )
	self:Say( "grenadedanger", 1, true )
	if self.Hiding then self.Hiding = false self.Crouched = true end
	local d = self:GetPos():Distance( nade:GetPos() )
	local timeLeft = nade.TimeLeft and nade:TimeLeft() or 1.5
	local enemy = self.Enemy

	if d < 110 and timeLeft > 1.6 and math.random() < 0.6 and not self.HasFlag and not self.Unarmed then
		self:MoveTo( nade:GetPos(), self.RunSpeed, 0.6, function() return not IsValid( nade ) or self:GetPos():Distance2D( nade:GetPos() ) < 40 end, nil, true )
		if not IsValid( nade ) then return end
		if self:GetPos():Distance2D( nade:GetPos() ) < 30 and math.random() < 0.4 then
			self:TurnTo( nade:GetPos(), 0.3 )
			local dur = self:PlaySeq( "grenade_kick" )
			self:Wait( 5 / 30, nil, true )
			if IsValid( nade ) and nade:GetPos():Distance( self:GetPos() ) < 80 then
				local phys = nade:GetPhysicsObject()
				if IsValid( phys ) then phys:SetVelocity( self:GetForward() * 450 + Vector( 0, 0, 120 ) ) end
			end
			self:Wait( dur - 5 / 30, nil, true )
			return
		end
		local crouch = self.Crouched
		local seqName = crouch and "crouch_grenade_return" or "grenade_return"
		local pickup, fire = crouch and 12 or 13, crouch and 32 or 37
		self:TurnTo( nade:GetPos(), 0.3 )
		local dur = self:PlaySeq( seqName )
		self:Wait( pickup / 30, nil, true )
		if not IsValid( nade ) or nade:GetPos():Distance( self:GetPos() ) > 100 then return end
		if nade.PickUp then
			nade:PickUp( self )
		else
			local phys = nade:GetPhysicsObject()
			if IsValid( phys ) then phys:EnableMotion( false ) end
		end
		local target = IsValid( enemy ) and enemy:GetPos() or ( self:GetPos() + self:GetForward() * 600 )
		local t = CurTime() + ( fire - pickup ) / 30
		while CurTime() < t and not self.Dead do
			self.loco:FaceTowards( target )
			if IsValid( nade ) and not nade.PickUp then
				local hand = self:GetAttachment( self:LookupAttachment( "anim_attachment_RH" ) )
				if hand then nade:SetPos( hand.Pos ) end
			end
			coroutine.yield()
		end
		if IsValid( nade ) then
			local hand = self:GetAttachment( self:LookupAttachment( "anim_attachment_RH" ) )
			local from = hand and hand.Pos or self:EyePosition()
			nade:SetPos( from )
			local vel = launchVelocity( from, target, 35 ) or self:GetForward() * 700
			if nade.Release then
				nade:Release( vel )
			else
				local phys = nade:GetPhysicsObject()
				if IsValid( phys ) then phys:EnableMotion( true ) phys:Wake() phys:SetVelocity( vel ) end
			end
			nade.Thrower = self
			nade.ThrownAt = CurTime()
			self:EmitSound( "COD1.GrenadeThrow" )
		end
		self:Wait( dur - fire / 30, nil, true )
		return
	end

	local away = self:GetPos() - nade:GetPos()
	away.z = 0
	if away:LengthSqr() < 1 then away = -self:GetForward() end
	away:Normalize()
	local goal = self:GetPos() + away * 380
	if navmesh.IsLoaded() then
		local best, bestD
		for _, a in ipairs( navmesh.Find( self:GetPos(), 450, 40, 40 ) ) do
			local p = a:GetCenter()
			local dn = p:Distance( nade:GetPos() )
			if dn > 300 and ( p - self:GetPos() ):Dot( away ) > 0 then
				local score = p:Distance( self:GetPos() ) - dn * 0.5
				if not bestD or score < bestD then best, bestD = p, score end
			end
		end
		if best then goal = best end
	end
	self:MoveTo( goal, self.RunSpeed, 2.5, function() return not IsValid( nade ) end, nil, true )
	if IsValid( nade ) and nade:GetPos():Distance( self:GetPos() ) < 300 and not self.HasFlag then
		local left = math.random( 2 ) == 1
		self:Wait( self:PlaySeq( left and "grenadehide_left_in" or "grenadehide_right_in" ), nil, true )
		self:PlaySeq( left and "grenadehide_left" or "grenadehide_right" )
		local t = CurTime() + 2
		while IsValid( nade ) and CurTime() < t and not self.Dead do coroutine.yield() end
		if self.Dead then return end
		self:Wait( self:PlaySeq( left and "grenadehide_left_out" or "grenadehide_right_out" ), nil, true )
		self.Crouched = true
	end
end

function ENT:Melee( enemy )
	self:Say( "meleeattack", 0.7, true )
	self:TurnTo( enemy:GetPos(), 0.25 )
	local m = MELEE[ math.random( #MELEE ) ]
	local seqName, hit = m[ 1 ], m[ 2 ]
	if self.Crouched then seqName, hit = "crouch_melee", 8 end
	local dur = self:PlaySeq( seqName )
	if not self:Wait( hit / 30, enemy, true ) then return end
	if IsValid( enemy ) and enemy:GetPos():Distance( self:GetPos() ) < 85 then
		local to = ( enemy:GetPos() - self:GetPos() ):GetNormalized()
		if to:Dot( self:GetForward() ) > 0.3 then
			local dmg = DamageInfo()
			dmg:SetDamage( enemy:IsPlayer() and 45 or 150 )
			dmg:SetDamageType( DMG_CLUB )
			dmg:SetAttacker( self )
			dmg:SetInflictor( self )
			dmg:SetDamageForce( to * 6000 )
			dmg:SetDamagePosition( enemy:WorldSpaceCenter() )
			enemy:TakeDamageInfo( dmg )
			self:EmitSound( "COD1.MeleeHit" )
			if enemy:IsPlayer() then enemy:ViewPunch( Angle( -10, math.random( -15, 15 ), 0 ) ) end
		end
	end
	self:Wait( dur - hit / 30, nil, true )
end

function ENT:TrySideStep( enemy, needShot )
	local opts = {
		{ kind = "dodge", seq = "dodge_left", side = -1, dist = 81 }, { kind = "dodge", seq = "dodge_right", side = 1, dist = 81 },
		{ kind = "walk", side = -1, dist = 40 }, { kind = "walk", side = 1, dist = 40 },
		{ kind = "run", side = -1, dist = 130 }, { kind = "run", side = 1, dist = 130 },
	}
	local start = math.random( #opts )
	for i = 0, #opts - 1 do
		local o = opts[ ( start + i - 1 ) % #opts + 1 ]
		if not ( o.kind == "dodge" and not self:EnemySide() and not self:Fair() ) then
			local dest = self:GetPos() + self:GetRight() * o.side * o.dist
			local ground = self:DirectWalk( self:GetPos(), dest ) and groundAt( dest )
			if ground and math.abs( ground.z - self:GetPos().z ) < 20 and ( not needShot or self:CanShootFrom( "stand", enemy, ground ) ) then
				if self.Crouched or self.Hiding or self.Prone then self:SetStance( false ) end
				if o.kind == "dodge" then
					self:DoMantle( o.seq, self:GetForward(), ground )
				else
					self:StrafeShoot( enemy, o.side < 0 and 1 or 2, o.kind == "run" )
				end
				return true
			end
		end
	end
	return false
end

function ENT:Backpedal( enemy )
	local w = self.Weapon
	local seq = self:LookupSequence( "run_shoot_back" )
	local did = false
	local nextShot = CurTime()
	while IsValid( enemy ) and not self.Dead and not self.PendingPain and not self.GrenadeThreat do
		local d = self:GetPos():Distance( enemy:GetPos() )
		if d > U.BACKPEDAL_RANGE or d <= U.MELEE_RANGE then break end
		local back = self:GetPos() - self:GetForward() * 60
		if not self:DirectWalk( self:GetPos(), back ) then break end
		if not did then
			if self.Prone then self:LeaveProne() end
			if self.Crouched or self.Hiding then self:SetStance( false ) end
			self:StartActivity( ACT_RUN )
			self:ResetSequence( seq )
			self.Moving = true
			self.loco:SetDesiredSpeed( self:GetSequenceGroundSpeed( seq ) )
			did = true
		end
		self.loco:Approach( back, 1 )
		self.loco:FaceTowards( enemy:GetPos() )
		self:UpdateAim( enemy )
		if CurTime() >= nextShot and not w.bolt and self.Mag > 0 then
			if self:LineOfFireClear( self:AimPoint( enemy ) ) then self:FireShot( enemy ) end
			nextShot = CurTime() + w.delay * ( w.auto and 1.4 or 1.8 )
		end
		coroutine.yield()
	end
	self.Moving = false
	self.StoppedAt = CurTime()
	self.loco:SetDesiredSpeed( 0 )
	return did
end

function ENT:Reposition( enemy )
	local me = self:GetPos()
	for i = 1, 12 do
		local ang = math.rad( math.random( 0, 359 ) )
		local d = math.random( 120, 320 )
		local p = groundAt( me + Vector( math.cos( ang ) * d, math.sin( ang ) * d, 0 ) )
		if p and hullClear( p, self ) and self:OnPost( p ) and self:CanShootFrom( "stand", enemy, p ) then
			self:MoveTo( p, self.RunSpeed, 2.5, function() return IsValid( enemy ) and self:CanSee( enemy ) end )
			return true
		end
	end
	return false
end

function ENT:ProneCombat( enemy )
	if not self.Prone then self:GoProne() end
	if self.Dead or not IsValid( enemy ) then return end
	self:PlaySeq( "prone_aim" )
	self:Wait( self:AimTime() + 0.2, enemy )
	if self.Mag <= 0 then return self:Reload() end
	self:ShootVolley( enemy )
	if not self.Dead then
		self:PlaySeq( "prone_aim" )
		self:Wait( math.Rand( 0.3, 0.8 ), enemy )
	end
end

function ENT:Engage( enemy )
	if not IsValid( enemy ) then return end
	local dist = self:GetPos():Distance( enemy:GetPos() )
	if self.Prone and dist < U.PRONE_RANGE * 0.8 then self:LeaveProne() end
	if self.Mag <= 0 then return self:Reload() end

	if dist > ( self.Weapon.proneRange or U.PRONE_RANGE ) and self.WeaponType ~= "smg" and self.WeaponType ~= "pistol" and not self:IsHurt() and self:CanShootFrom( "prone", enemy ) then
		return self:ProneCombat( enemy )
	end
	if dist <= U.BACKPEDAL_RANGE and dist > U.MELEE_RANGE and self:Backpedal( enemy ) then return end

	local stance
	if dist < U.STAND_RANGE then
		stance = self:CanShootFrom( "stand", enemy ) and "stand" or self:CanShootFrom( "crouch", enemy ) and "crouch"
	else
		stance = self:CanShootFrom( "crouch", enemy ) and "crouch" or self:CanShootFrom( "stand", enemy ) and "stand"
	end
	if not stance then
		if self:TrySideStep( enemy, true ) then return end
		if self:Reposition( enemy ) then return end
		if not IsValid( enemy ) then return end
		self:TurnTo( enemy:GetPos(), 0.5 )
		self:Wait( 0.3, enemy )
		return
	end
	self:SetStance( stance == "crouch" )
	if self.Dead or not IsValid( enemy ) then return end
	self:TurnTo( enemy:GetPos(), 0.8 )
	if self.Dead or not IsValid( enemy ) then return end
	self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
	local aim = self:AimTime()
	if self.ReactUntil and CurTime() < self.ReactUntil then aim = math.max( aim, self.ReactUntil - CurTime() ) end
	self:Wait( aim, enemy )
	if self.Dead or not IsValid( enemy ) then return end

	if not self:LineOfFireClear( self:AimPoint( enemy ) ) then
		if not self:TrySideStep( enemy, true ) then self:Wait( 0.4, enemy ) end
		return
	end
	if ( self:EnemySide() or self:Fair() ) and stance == "stand" and dist < U.DODGE_RANGE then
		local chance = ( U.DODGE_RANGE ^ 2 - dist ^ 2 ) / ( U.DODGE_RANGE ^ 2 - U.MELEE_RANGE ^ 2 )
		if math.random() < chance and self:TrySideStep( enemy, true ) then return end
	end
	if not self.Crouched and not self.Weapon.bolt and dist > 250 and dist < 1300 and math.random() < 0.12 then
		if self:StrafeShoot( enemy ) then return end
	end
	if not IsValid( enemy ) then return end
	self:ShootVolley( enemy )
	if self.Dead or not IsValid( enemy ) then return end
	if dist > 400 and math.random() < 0.08 and self:CanThrowGrenade( enemy:GetPos() ) then return self:ThrowGrenade( enemy:GetPos() ) end
	self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
	self:Wait( math.Rand( 0.15, 0.5 ), enemy )
end

function ENT:CoverFight( enemy )
	local w = self.Weapon
	local crouchCover = self.CoverType ~= "stand"
	if self.Mag <= 0 or self.Mag < w.clip * 0.2 then
		self:Hide()
		return self:Reload()
	end
	if self.Hiding then
		local lkp = self.LastKnownPos
		while CurTime() < self.Suppressed and not self.Dead and not self.PendingPain and not self.GrenadeThreat and not self:CoverFireRequested() do
			self:Say( "undersuppression", 0.3 )
			self:PlaySeq( self.VariantData.medic and "medic_hide" or HIDE_IDLES[ math.random( #HIDE_IDLES ) ] )
			if not self:Wait( math.Rand( 0.8, 1.5 ) ) then return end
			if lkp and math.random() < 0.3 and self:CanThrowGrenade( lkp ) then self:ThrowGrenade( lkp ) end
		end
		if self.Dead or self.PendingPain or self.GrenadeThreat then return end
		self:SetStance( crouchCover )
	elseif self.Crouched ~= crouchCover then
		self:SetStance( crouchCover )
	end
	if not IsValid( enemy ) then return end
	self:TurnTo( enemy:GetPos(), 0.5 )
	if self:CanSee( enemy ) then
		self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
		self:Wait( self:AimTime(), enemy )
		self:ShootVolley( enemy )
	elseif self.LastKnownPos and CurTime() - self.LastSeen < 4 and ( self.WeaponType ~= "smg" or self:CoverFireRequested() ) then
		self.CoverFireUntil = nil
		self:Suppress( self.LastKnownPos )
	else
		self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
		self:Wait( math.Rand( 0.4, 1.0 ), enemy )
	end
	if self.Dead then return end
	local duck = self:Fair() and 0.75 or ( self:EnemySide() and 0.5 or 1 )
	if CurTime() < self.Suppressed or math.random() < duck then
		self:Hide()
		self:PlaySeq( HIDE_IDLES[ math.random( #HIDE_IDLES ) ] )
		self:Wait( math.Rand( 0.4, 1.2 ) )
	end
end

function ENT:SquadOn( enemy )
	local n = 0
	for _, s in ipairs( U.teammates( self, 3000 ) ) do
		if s.Enemy == enemy then n = n + 1 end
	end
	return n
end

function ENT:OkToMelee( enemy )
	for s in pairs( COD1.Soldiers ) do
		if IsValid( s ) and s ~= self and s.Charging == enemy then return false end
	end
	return true
end

function ENT:CallCoverFire( enemy, quiet )
	if not IsValid( enemy ) then return end
	local n = 0
	for _, s in ipairs( U.teammates( self, 900 ) ) do
		if n >= 2 then break end
		if not s.Moving and not s.Unarmed and not s.HasFlag and s.Mag > 0 and not s.Weapon.bolt
			and ( s.Enemy == enemy or ( IsValid( s.Enemy ) and s.LastKnownPos ) ) then
			s.CoverFireUntil = CurTime() + 2.5
			n = n + 1
		end
	end
	if n > 0 and not quiet then self:Say( "coverme", 0.7 ) end
end

function ENT:CoverFireRequested()
	return ( self.CoverFireUntil or 0 ) > CurTime()
end

function ENT:MayAdvance()
	local mates = U.teammates( self, 1000 )
	local moving = 0
	for _, s in ipairs( mates ) do
		if s.Advancing then moving = moving + 1 end
	end
	return moving < math.max( 1, math.ceil( ( #mates + 1 ) * 0.4 ) )
end

function ENT:DeadGround( from, radius )
	local me = self:GetPos()
	local best, bs
	for _, p in ipairs( self:CoverCandidates( radius ) ) do
		if hullClear( p, self ) and blocked( p + Vector( 0, 0, 64 ), from ) and blocked( p + Vector( 0, 0, 36 ), from ) then
			local score = p:Distance( me ) + flat( from - p ):Length() * 0.6
			if not bs or score < bs then best, bs = p, score end
		end
	end
	return best
end

function ENT:FiringSpot( aim, radius )
	local me = self:GetPos()
	local best, bs
	for _, p in ipairs( self:CoverCandidates( radius ) ) do
		local d = flat( aim - p ):Length()
		if d > 140 and hullClear( p, self ) and not blocked( p + Vector( 0, 0, 60 ), aim ) then
			local score = p:Distance( me ) - math.min( d, 400 ) * 0.3
			if not bs or score < bs then best, bs = p, score end
		end
	end
	return best
end

function ENT:OverheadFight( enemy, visible, epos )
	local aim = epos + Vector( 0, 0, 50 )
	if visible then
		local pressed = CurTime() < self.Suppressed or CurTime() - self.LastHurt < 3 or self:IsHurt()
		local spot = pressed and CurTime() >= ( self.NextDeadGround or 0 ) and self:DeadGround( aim, 320 )
		if not spot then
			self:Engage( enemy )
			return true
		end
		self.NextDeadGround = CurTime() + 4
		COD1.Cover[ self ] = spot
		self.CoverType = "full"
		self:MoveTo( spot, self.RunSpeed, 3, nil, true )
		if not self.Dead then self:SetStance( true ) end
		return true
	end
	local since = CurTime() - self.LastSeen
	if since < 20 and self:CanThrowGrenade( epos ) then return self:ThrowGrenade( epos ) end
	if self:EnemyIndoors( enemy ) and CurTime() >= ( self.NextAssault or 0 ) and self:MayAdvance() and self.WeaponType ~= "rocket"
		and self:RoomAssault( enemy ) then
		return true
	end
	if not U.underSky( self:GetPos() ) and self:MayAdvance() then return false end
	if since < 4 and self.WeaponType ~= "smg" and math.random() < 0.5 and self:Suppress( epos ) then return true end
	if since > 3 and CurTime() >= ( self.NextPeek or 0 ) then
		self.NextPeek = CurTime() + math.Rand( 5, 8 )
		local spot = self:FiringSpot( aim, 350 )
		if spot then
			self:MoveTo( spot, self.RunSpeed, 3, function() return self:CanSee( enemy ) end, true )
			return true
		end
	end
	self:SetStance( true )
	self:PlaySeq( "crouch_aim" )
	self:Wait( math.Rand( 0.6, 1.2 ), aim )
	return true
end

function ENT:Combat( enemy )
	local visible = self:CanSee( enemy )
	if visible then
		if self.ContactWith ~= enemy or CurTime() - ( self.ContactSeen or 0 ) > 8 then
			self.ContactAt = CurTime()
			self.NextCoverSearch = 0
		end
		self.ContactWith, self.ContactSeen = enemy, CurTime()
		self.LastSeen = CurTime()
		self.LastKnownPos = enemy:GetPos()
	end
	local epos = visible and enemy:GetPos() or self.LastKnownPos or enemy:GetPos()
	local dist = self:GetPos():Distance( epos )
	local range = U.RANGES[ self.WeaponType ]
	local rise = epos.z - self:GetPos().z
	local above = rise > 80 and flat( epos - self:GetPos() ):Length() < 700

	if self.RoleCombat and self:RoleCombat( enemy, visible, dist ) then return end
	if self.NoGun then return self:UnarmedCombat( enemy, visible, dist ) end
	if CurTime() < ( self.ShakenUntil or 0 ) and dist > 300 then
		if ( self.NextCoverSearch or 0 ) < CurTime() then
			self.NextCoverSearch = CurTime() + 4
			if self:TakeCover( enemy, { lowOnly = true }, true ) then self:Hide() return end
		end
		self:SetStance( true )
		self:Wait( 0.5, enemy:GetPos() )
		return
	end
	if self:TryFlagPickup() then return end

	if visible and dist <= U.MELEE_RANGE + 10 and math.abs( rise ) < 48 then return self:Melee( enemy ) end
	if visible and dist <= U.CHARGE_RANGE and math.abs( rise ) < 48 and not self.Prone and self:OkToMelee( enemy ) and math.random() < 0.5 then
		self.Charging = enemy
		self:Say( "meleecharge", 0.8 )
		self:MoveTo( enemy:GetPos(), 230, 1.2, function() return not IsValid( enemy ) or self:GetPos():Distance( enemy:GetPos() ) < 70 end, nil, true )
		self.Charging = nil
		if IsValid( enemy ) and self:GetPos():Distance( enemy:GetPos() ) < 85 then return self:Melee( enemy ) end
		return
	end

	if self.Corner then
		if self.AtCorner and self:CornerStillGood( enemy, visible, dist ) then return self:CornerFight( enemy ) end
		self:LeaveCorner( true )
	end

	if self:CoverFireRequested() and not visible and self.LastKnownPos and CurTime() - self.LastSeen < 6 then
		self.CoverFireUntil = nil
		if self:Suppress( self.LastKnownPos ) then return end
	end

	if self:Health() < self:GetMaxHealth() * 0.3 and not self.Retreated and visible then
		self.Retreated = true
		self:Say( "giveupposition", 0.9 )
		if self:TakeCover( enemy, { radius = 900 } ) then self:Hide() return end
	end

	if above and self:OverheadFight( enemy, visible, epos ) then return end

	if not visible then
		if self.Prone and CurTime() - self.LastSeen > 3 then self:LeaveProne() end
		local lkp = self.LastKnownPos or enemy:GetPos()
		local since = CurTime() - self.LastSeen
		if self.VariantData.medic and since > 3 and self:MedicWork() then return end
		if since < 8 and math.random() < 0.5 and self:CanThrowGrenade( lkp ) then return self:ThrowGrenade( lkp ) end
		if self.Hiding or self:InCover() then
			if since < 5 then return self:CoverFight( enemy ) end
			COD1.Cover[ self ] = nil
		end
		if since < 10 and ( self.NextCornerSearch or 0 ) < CurTime() then
			self.NextCornerSearch = CurTime() + 3
			if self:TakeCorner( enemy, { radius = 500 } ) then return end
		end
		if since > 2 and not above and self:SquadOn( enemy ) > 0 and math.random() < 0.4 and self:MayAdvance() and self:Flank( enemy ) then return end
		if self.WeaponType ~= "smg" and since < 3 and math.random() < 0.4 and self:Suppress( lkp ) then return end
		if not self:MayAdvance() then
			self:PlaySeq( self.Crouched and "crouch_aim" or "aim" )
			self:Wait( math.Rand( 0.5, 1.0 ), lkp )
			return
		end
		self:Say( "misccombat", 0.15 )
		self:CallCoverFire( enemy, true )
		self.Advancing = true
		self:MoveTo( self:SquadSpot( lkp ), self.RunSpeed, 2.5, function()
			return IsValid( enemy ) and self:CanSee( enemy )
		end, CurTime() < self.Suppressed )
		self.Advancing = false
		if self.MoveBlocked and not self.Dead then
			self.NextCornerSearch = CurTime() + 3
			self:TakeCorner( enemy, { radius = 300 } )
		end
		return
	end

	if self:InCover() then
		if self.WeaponType == "smg" and dist > range[ 2 ] and ( self.NextAdvance or 0 ) < CurTime() and self:MayAdvance() then
			self.NextAdvance = CurTime() + 6
			if self:TakeCover( enemy, { lowOnly = true, closer = true, radius = 600 }, true ) then self:Hide() return end
		end
		return self:CoverFight( enemy )
	end

	if self.WeaponType == "smg" and dist > range[ 1 ] + 100 and dist < range[ 2 ] * 1.4 and math.random() < 0.25
		and CurTime() > self.Suppressed and not self:IsHurt() and self:MayAdvance() then
		local to = ( enemy:GetPos() - self:GetPos() ):GetNormalized()
		local goal = groundAt( self:GetPos() + to * math.min( dist - range[ 1 ], 350 ) + to:Angle():Right() * math.Rand( -120, 120 ) )
		if goal and math.abs( goal.z - self:GetPos().z ) < 48 and self:CanShootFrom( "stand", enemy, goal ) then
			self:Say( "meleecharge", 0.25 )
			self:CallCoverFire( enemy, true )
			self.Advancing = true
			self:MoveTo( goal, self.RunSpeed, 2.5, function() return not IsValid( enemy ) end )
			self.Advancing = false
			return
		end
	end

	if dist > range[ 2 ] and ( self.NextAdvance or 0 ) < CurTime() and self:MayAdvance() then
		self.NextAdvance = CurTime() + 4
		if self:TakeCover( enemy, { lowOnly = true, closer = true, radius = 700 }, true ) then self:Hide() return end
		if self:TakeCorner( enemy, { closer = true, radius = 700 } ) then return end
		if dist > range[ 2 ] * 1.5 then
			self.Advancing = true
			self:MoveTo( self:SquadSpot( enemy:GetPos() ), self.RunSpeed, 2, function()
				return not IsValid( enemy ) or self:GetPos():Distance( enemy:GetPos() ) < range[ 2 ]
			end, CurTime() < self.Suppressed )
			self.Advancing = false
			return
		end
	end
	if dist < range[ 1 ] and self.WeaponType ~= "smg" and math.random() < 0.4 then
		if self:StrafeShoot( enemy, 3 ) then return end
	end

	local wantCover = CurTime() < self.Suppressed or CurTime() - self.LastHurt < 3 or CurTime() - ( self.ContactAt or 0 ) < 3
		or ( dist > 500 and math.random() < 0.35 )
	if wantCover and ( self.NextCoverSearch or 0 ) < CurTime() then
		self.NextCoverSearch = CurTime() + 4
		local cornerFirst = math.random() < 0.5
		if cornerFirst and self:TakeCorner( enemy, { radius = 500 } ) then return end
		if self:TakeCover( enemy, { lowOnly = true }, true ) then self:Hide() return end
		if not cornerFirst and self:TakeCorner( enemy, { radius = 500 } ) then return end
	end
	if dist > 400 and math.random() < 0.06 and self:CanThrowGrenade( enemy:GetPos() ) then return self:ThrowGrenade( enemy:GetPos() ) end
	self:Engage( enemy )
end

--shooting, aiming and dying basically
