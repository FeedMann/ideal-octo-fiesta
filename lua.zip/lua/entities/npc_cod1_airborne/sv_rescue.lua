local U = COD1.AI

COD1.Downed = COD1.Downed or {}

local CARRY_SPEED = 50
local CARRY_SEQ = { rescue_walk = "rescued_walk", rescue_putdown = "rescued_putdown", rescue_death = "carried_fall" }

local function layout( key, x, y, yaw )
	local l = COD1.RescueLayout and COD1.RescueLayout[ key ]
	if l then return l[ 1 ], l[ 2 ], l[ 3 ] end
	return x, y, yaw
end

local function offsetFrom( pos, yaw, x, y, dyaw )
	local off = Vector( x, y, 0 )
	off:Rotate( Angle( 0, yaw, 0 ) )
	return pos + off, yaw + dyaw
end

local function inverse( x, y, yaw )
	local off = Vector( x, y, 0 )
	off:Rotate( Angle( 0, -yaw, 0 ) )
	return -off.x, -off.y, -yaw
end
local POSE = {
	lying = { idle = "downed_idle", pickup = "rescued_pickup", getup = "downed_getup", death = "downed_death" },
	fallen = { idle = "fallen_idle", pickup = "fallen_pickup", getup = "fallen_getup", death = "fallen_death" },
}

function ENT:CanGoDown( dmg )
	if not GetConVar( "cod1_rescue" ):GetBool() or self.Dead or self.Downed or self.WentDown then return false end
	if self.Parachuting or self.Riding or self.HasFlag or self.Carrying or self.Treatment or self.AtCorner or self.Rambo then return false end
	if self.VariantData.fixedName or self.LastHitGroup == HITGROUP_HEAD then return false end
	if dmg:GetDamage() >= 150 or dmg:IsExplosionDamage() and dmg:GetDamage() >= 90 then return false end
	if self:LookupSequence( "downed_fall" ) < 0 then return false end
	return math.random() < GetConVar( "cod1_rescue_chance" ):GetFloat()
end

function ENT:GoDown( dmg )
	if self.Manning then self:Dismount() end
	if IsValid( self.Rescuing ) and self.Rescuing.Downed then self.Rescuing.Downed.rescuer = nil end
	self.WentDown = true
	self.WantTurret, self.WantRescue, self.Rescuing, self.MedicBusy = nil, nil, nil, nil
	self.PendingPain, self.Moving = nil, false
	self.Crouched, self.Hiding, self.Prone = false, false, nil
	self:SetHealth( math.max( 1, math.floor( self:GetMaxHealth() * 0.3 ) ) )
	self.loco:SetDesiredSpeed( 0 )
	self.loco:SetVelocity( vector_origin )
	self.PreDownGroup = self:GetCollisionGroup()
	self:SetCollisionGroup( COLLISION_GROUP_DEBRIS )
	local now = CurTime()
	local att = dmg:GetAttacker()
	self.Downed = {
		phase = "fall", pose = "lying", untilT = now + math.max( self:PlaySeq( "downed_fall" ), 0.1 ),
		recoverAt = now + GetConVar( "cod1_rescue_recover" ):GetFloat(),
		threat = IsValid( att ) and att:GetPos() or nil,
	}
	self:AddFlags( FL_NOTARGET )
	self:SetNWBool( "COD1Downed", true )
	self:Say( "pain", 1, true )
	self:FaceGesture( "face_pain" )
	if IsValid( att ) then self:AlertSquad( att ) end
	COD1.Downed[ self ] = true
end

function ENT:DownedSeq( kind )
	return POSE[ self.Downed and self.Downed.pose or "lying" ][ kind ]
end

function ENT:FindRescuer()
	local best, bestDist
	for _, s in ipairs( U.teammates( self, 1500 ) ) do
		if not ( s.Downed or s.Manning or s.Riding or s.Parachuting or s.Treatment or s.HasFlag or s.Role or s.Carrying
			or s.MedicBusy or IsValid( s.WantRescue ) or IsValid( s.Rescuing ) or IsValid( s.WantTurret ) ) then
			local d = s:GetPos():DistToSqr( self:GetPos() ) * ( s.VariantData.medic and 0.3 or 1 )
			if not bestDist or d < bestDist then best, bestDist = s, d end
		end
	end
	return best
end

function ENT:FollowCarrier( r )
	local d = self.Downed
	self:SetPos( r:GetPos() )
	self:SetAngles( r:GetAngles() )
	if d then d.carrierPos, d.carrierYaw = r:GetPos(), r:GetAngles().y end
	local name = r:GetSequenceName( r:GetSequence() )
	local want = name == "rescue_pickup" and ( d and d.pickupSeq or "rescued_pickup" ) or CARRY_SEQ[ name ]
	if not want then
		self:SetPlaybackRate( 0 )
		return
	end
	local seq = self:LookupSequence( want )
	if self:GetSequence() ~= seq then self:ResetSequence( seq ) end
	self:SetCycle( r:GetCycle() )
	self:SetPlaybackRate( r:GetPlaybackRate() )
end

function ENT:UpdateDowned()
	local d = self.Downed
	self:FrameAdvance()
	local now = CurTime()
	if d.phase == "carried" then
		local r = d.rescuer
		if d.landAt then
			if IsValid( r ) and now < d.landAt then
				self:FollowCarrier( r )
			else
				local x, y, yaw = layout( "fallen", 8.92, 0.06, 0 )
				self:Land( "fallen", x, y, yaw )
			end
		elseif not IsValid( r ) or r.Dead or r.Carrying ~= self then
			self:Land( "lying" )
		else
			self:FollowCarrier( r )
		end
		return
	end
	self.loco:SetVelocity( vector_origin )
	if d.phase == "fall" then
		if now >= d.untilT then
			d.phase = "lying"
			self:PlaySeq( self:DownedSeq( "idle" ) )
		end
	elseif d.phase == "lying" then
		if d.pow then self:POWFreed() end
		local coming = IsValid( d.rescuer ) and not d.rescuer.Dead and ( d.rescuer.WantRescue == self or d.rescuer.Rescuing == self )
		if not d.safe and not coming and not IsValid( self.BeingHealed ) and now >= ( d.nextCall or 0 ) then
			d.nextCall = now + 1.5
			d.rescuer = self:FindRescuer()
			if d.rescuer then
				d.rescuer.WantRescue = self
				coming = true
			end
		end
		if now >= d.recoverAt and not coming and not IsValid( self.BeingHealed ) then self:Recover() end
	elseif d.phase == "getup" and now >= d.untilT then
		self:EndDowned()
	end
end

function ENT:Recover()
	local d = self.Downed
	if not d or d.phase ~= "lying" then return end
	d.phase = "getup"
	d.untilT = CurTime() + math.max( self:PlaySeq( self:DownedSeq( "getup" ) ), 0.1 )
end

function ENT:EndDowned()
	self.Downed = nil
	COD1.Downed[ self ] = nil
	self:SetCollisionGroup( self.PreDownGroup or COLLISION_GROUP_NONE )
	self.PreDownGroup = nil
	self:RemoveFlags( FL_NOTARGET )
	self:SetNWBool( "COD1Downed", false )
	self.Crouched = true
	self.Suppressed = CurTime() + 1
	self.ShakenUntil = CurTime() + math.Rand( 5, 9 )
	self:PlaySeq( "crouch_idle" )
	self.BehaveThread = nil
	if self.BehaveStart then self:BehaveStart() end
	if GetConVar( "cod1_geneva" ):GetBool() and self:Cornered( 500 ) then self:Surrender() end
end

function ENT:CarryPhysics( on )
	if on then
		self.loco:SetGravity( 0 )
		self:SetCollisionBounds( Vector( -2, -2, 0 ), Vector( 2, 2, 8 ) )
		self:SetSurroundingBoundsType( BOUNDS_HITBOXES )
	else
		self.loco:SetGravity( 1000 )
		self:SetCollisionBounds( U.HULL_MINS, U.HULL_MAXS )
		self:SetSurroundingBoundsType( BOUNDS_COLLISION )
		local ground = U.groundAt( self:GetPos() )
		if ground and ground.z < self:GetPos().z + 12 then self:SetPos( ground ) end
	end
end

function ENT:BeginCarried( r )
	local d = self.Downed
	d.phase = "carried"
	d.rescuer = r
	d.landAt = nil
	d.pickupSeq = self:DownedSeq( "pickup" )
	self:CarryPhysics( true )
	self:SetNWEntity( "COD1CarriedBy", r )
	self:SetPos( r:GetPos() )
	self:SetAngles( r:GetAngles() )
	d.carrierPos, d.carrierYaw = r:GetPos(), r:GetAngles().y
	self:ResetSequence( self:LookupSequence( d.pickupSeq ) )
	self:SetCycle( 0 )
	self:SetPlaybackRate( 1 )
end

function ENT:Land( pose, x, y, yaw )
	local d = self.Downed
	if x and d.carrierPos then
		local pos, ang = offsetFrom( d.carrierPos, d.carrierYaw, x, y, yaw )
		self:SetPos( pos )
		self:SetAngles( Angle( 0, ang, 0 ) )
	end
	self:CarryPhysics( false )
	self:SetNWEntity( "COD1CarriedBy", NULL )
	self:SetPlaybackRate( 1 )
	d.phase = "lying"
	d.pose = pose
	d.rescuer = nil
	d.landAt = nil
	d.nextCall = CurTime() + 3
	self:PlaySeq( self:DownedSeq( "idle" ) )
end

function ENT:SetDown()
	local d = self.Downed
	self:Land( "lying", inverse( layout( "start", 34.83, -0.55, 146.34 ) ) )
	d.safe = true
	d.recoverAt = math.max( d.recoverAt, CurTime() + 8 )
end

function ENT:DownedDeath()
	local d = self.Downed
	if not d then return end
	local r = d.rescuer
	if d.phase == "carried" and IsValid( r ) and not r.Dead and r.Carrying == self then
		self.CarriedCorpse = r
		self.Downed = nil
		COD1.Downed[ self ] = nil
		self:SetNWBool( "COD1Downed", false )
		return false
	end
	if d.phase == "carried" then
		self:CarryPhysics( false )
		self:SetNWEntity( "COD1CarriedBy", NULL )
	end
	local seq = d.phase ~= "getup" and self:DownedSeq( "death" ) or nil
	self.Downed = nil
	COD1.Downed[ self ] = nil
	self:SetNWBool( "COD1Downed", false )
	return seq
end

function ENT:UpdateCarriedCorpse()
	local r = self.CarriedCorpse
	if IsValid( r ) and not r.Dead and r.Carrying == self then
		self:FrameAdvance()
		self:FollowCarrier( r )
		return true
	end
	self.CarriedCorpse = nil
	self:SetNWEntity( "COD1CarriedBy", NULL )
	self:CarryPhysics( false )
	self.DeathEnd = CurTime()
	return false
end

function ENT:CarrierDied()
	local w = self.Carrying
	if not ( IsValid( w ) and w.Downed and w.Downed.phase == "carried" ) then return end
	self.ForcedDeath = "rescue_death"
	local seq = self:LookupSequence( "rescue_death" )
	w.Downed.landAt = CurTime() + ( seq >= 0 and self:SequenceDuration( seq ) or 0 )
end

local EYE = Vector( 0, 0, 60 )
local LOW, HIGH = Vector( 0, 0, 20 ), Vector( 0, 0, 52 )

function ENT:RescueThreats( w )
	local me, out = self:GetPos(), {}
	local function add( p ) if p then out[ #out + 1 ] = p end end
	add( w.Downed and w.Downed.threat and w.Downed.threat + EYE )
	add( self.LastKnownPos and self.LastKnownPos + EYE )
	local found = {}
	for _, e in ipairs( ents.FindInSphere( me, 4000 ) ) do
		if e ~= self and e ~= w and ( e:IsPlayer() or e:IsNPC() ) and U.alive( e ) and self:IsHostileTo( e ) then
			found[ #found + 1 ] = e
		end
	end
	local dist = {}
	for _, e in ipairs( found ) do dist[ e ] = ( e:GetPos() - me ):LengthSqr() end
	table.sort( found, function( a, b ) return dist[ a ] < dist[ b ] end )
	for i = 1, math.min( #found, 10 ) do add( found[ i ]:GetPos() + EYE ) end
	return out
end

function ENT:RescueSpot( w )
	local threats = self:RescueThreats( w )
	if #threats == 0 then return U.groundAt( self:GetPos() + self:GetForward() * 150 ) end
	return self:HideSpot( threats )
end

function ENT:HideSpot( threats )
	local me = self:GetPos()
	local cands = self:CoverCandidates( 900 )
	if COD1.NodesReady and COD1.NodesReady() then
		local level = U.levelFilter( me )
		for _, n in ipairs( COD1.NodesNear( me, 900 ) ) do
			if level( n.pos ) then cands[ #cands + 1 ] = n.pos end
		end
	end
	table.sort( cands, function( p1, p2 ) return ( p1 - me ):LengthSqr() < ( p2 - me ):LengthSqr() end )
	local nearest = math.huge
	for _, t in ipairs( threats ) do nearest = math.min( nearest, t:Distance( me ) ) end
	local best, bestScore, fallback, fallbackHidden
	for i = 1, math.min( #cands, 80 ) do
		local p = cands[ i ]
		if U.hullClear( p, self ) then
			local hidden, closest = 0, math.huge
			for _, t in ipairs( threats ) do
				if U.blocked( t, p + LOW ) and U.blocked( t, p + HIGH ) then hidden = hidden + 1 end
				closest = math.min( closest, t:Distance( p ) )
			end
			local score = p:Distance( me ) + ( closest < nearest - 50 and 800 or 0 )
			if hidden == #threats then
				if not bestScore or score < bestScore then best, bestScore = p, score end
			elseif not fallback or hidden > fallbackHidden then
				fallback, fallbackHidden = p, hidden
			end
		end
	end
	if best then return best end
	local away = U.flat( me - threats[ 1 ] )
	if fallback and fallbackHidden > 0 then return fallback end
	if away:LengthSqr() > 1 then return U.groundAt( me + away:GetNormalized() * 400 ) or fallback end
	return fallback
end

local WALL_BACK = 16

local function putdownPose()
	local m = COD1.Motion and COD1.Motion.rescue_putdown
	local ex, ey, eyaw = 0, 0, 0
	if m and #m >= 2 then
		local o, z = m[ 1 ], m[ #m ]
		local rc, rs = math.cos( math.rad( -o[ 4 ] ) ), math.sin( math.rad( -o[ 4 ] ) )
		local dx, dy = z[ 1 ] - o[ 1 ], z[ 2 ] - o[ 2 ]
		ex, ey, eyaw = dx * rc - dy * rs, dx * rs + dy * rc, z[ 4 ] - o[ 4 ]
	end
	return offsetFrom( Vector( ex, ey, 0 ), eyaw, inverse( layout( "start", 34.83, -0.55, 146.34 ) ) )
end

local function notActor( e ) return not ( e.IsCOD1Soldier or e:IsPlayer() or e:IsNPC() or e:IsNextBot() ) end

function ENT:WallPutdown( around )
	local base = around + Vector( 0, 0, 20 )
	local best, bestD
	for i = 0, 15 do
		local dir = Angle( 0, i * 22.5, 0 ):Forward()
		local tr = util.TraceLine( { start = base, endpos = base + dir * 160, filter = notActor, mask = MASK_SOLID } )
		if tr.Hit and not tr.StartSolid and math.abs( tr.HitNormal.z ) < 0.3 and ( not bestD or tr.Fraction < bestD ) then
			local high = util.TraceLine( { start = tr.HitPos + tr.HitNormal * 4 + Vector( 0, 0, 20 ), endpos = tr.HitPos - tr.HitNormal * 8 + Vector( 0, 0, 20 ), filter = notActor, mask = MASK_SOLID } )
			if high.Hit then best, bestD = tr, tr.Fraction end
		end
	end
	if not best then return nil end
	local n = Vector( best.HitNormal.x, best.HitNormal.y, 0 ):GetNormalized()
	local pw = U.groundAt( best.HitPos + n * WALL_BACK )
	if not pw then return nil end
	local local_, lyaw = putdownPose()
	local yw = n:Angle().y
	local yc = yw - lyaw
	local off = Vector( local_.x, local_.y, 0 )
	off:Rotate( Angle( 0, yc, 0 ) )
	local pc = U.groundAt( pw - off )
	if not pc or math.abs( pc.z - pw.z ) > 24 or not U.hullClear( pc, self ) then return nil end
	return pc, yc
end

function ENT:GoRescue()
	local w = self.WantRescue
	self.WantRescue = nil
	local function ok() return IsValid( w ) and not w.Dead and w.Downed and w.Downed.rescuer == self end
	local function waiting() return ok() and w.Downed.phase == "lying" end
	if not waiting() then return end
	self.Rescuing = w
	self:Say( "coverme", 0.8 )
	local x, y, yaw = layout( "start", 34.83, -0.55, 146.34 )
	local spot, face = offsetFrom( w:GetPos(), w:GetAngles().y, x, y, yaw )
	spot = U.groundAt( spot ) or spot
	self:MoveTo( spot, self.RunSpeed, 12, function()
		return not waiting() or self:GetPos():Distance2D( spot ) < 30
	end, false, true )
	if waiting() and self:GetPos():Distance2D( spot ) < 60 then
		self:WalkTo( spot, 1, 60 )
		self:TurnTo( spot + Angle( 0, face, 0 ):Forward() * 100, 0.5 )
	end
	if self.Dead or not waiting() or not U.near( self:GetPos(), spot, 20, 30 ) then
		if ok() then w.Downed.rescuer = nil end
		self.Rescuing = nil
		return
	end
	self:SetPos( spot )
	self:SetAngles( Angle( 0, face, 0 ) )
	local holster = self.WeaponType == "pistol" and not self.WeaponHidden
	if holster then self:ShowWeapon( false ) end
	self.Carrying = w
	w:BeginCarried( self )
	self:PlayMotion( "rescue_pickup" )
	if not self.Dead and ok() then
		local from = self:GetPos()
		local dest = self:RescueSpot( w )
		if dest and dest:Distance( from ) > 120 then self:MoveTo( dest, CARRY_SPEED, 20, function() return not ok() end, false, true ) end
		if not self.Dead and ok() and self:GetPos():Distance( from ) < 60 then
			local threats = self:RescueThreats( w )
			local away = threats[ 1 ] and U.flat( from - threats[ 1 ] ) or -self:GetForward()
			local back = away:LengthSqr() > 1 and U.groundAt( from + away:GetNormalized() * 250 )
			if back then self:MoveTo( back, CARRY_SPEED, 12, function() return not ok() end, false, true ) end
		end
		if not self.Dead and ok() then
			local pc, yc = self:WallPutdown( self:GetPos() )
			if pc then
				self:MoveTo( pc, CARRY_SPEED, 6, function() return not ok() or self:GetPos():Distance2D( pc ) < 12 end, false, true )
				if not self.Dead and ok() and self:GetPos():Distance2D( pc ) < 40 then
					self:SetPos( pc )
					self:SetAngles( Angle( 0, yc, 0 ) )
				end
			end
		end
	end
	if not self.Dead and IsValid( w ) and ( ok() or w.CarriedCorpse == self ) then
		self:PlayMotion( "rescue_putdown" )
		if ok() and w.Downed.phase == "carried" then w:SetDown() end
	end
	if self.Dead then return end
	if holster then self:ShowWeapon( true ) end
	self.Carrying = nil
	self.Rescuing = nil
	if self.VariantData.medic and IsValid( w ) and not w.Dead and w.Downed and w.Downed.phase == "lying" and not IsValid( w.BeingHealed ) then
		w.BeingHealed = self
		self:Treat( w )
		if IsValid( w ) and w.BeingHealed == self then w.BeingHealed = nil end
		return
	end
	self:PlaySeq( self:IdleSeq() )
end

--dragging wounded guys to cover
