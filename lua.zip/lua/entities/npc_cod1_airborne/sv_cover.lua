local U = COD1.AI
local flat, groundAt, blocked, hullClear = U.flat, U.groundAt, U.blocked, U.hullClear

local CORNER_WALL = 26
local CORNER_EDGE = 18
local HIDE_IDLES = { "hideb_idle", "hideb_idle", "hideb_twitch", "hidea_idle1", "hidea_idle2" }
U.HIDE_IDLES = HIDE_IDLES

function ENT:CoverCandidates( radius )
	local out = {}
	local me = self:GetPos()
	local level = U.levelFilter( me )
	if navmesh.IsLoaded() then
		for _, area in ipairs( navmesh.Find( me, radius, 60, 60 ) ) do
			if area:GetSizeX() > 20 and area:GetSizeY() > 20 then
				for _, p in ipairs( { area:GetRandomPoint(), area:GetCenter() } ) do
					if level( p ) then out[ #out + 1 ] = p end
				end
			end
			if #out > 40 then break end
		end
	else
		for i = 1, 32 do
			local ang = math.rad( i * 11.25 + math.random( -5, 5 ) )
			local d = 90 + ( i % 4 ) * ( radius - 90 ) / 3
			local p = groundAt( me + Vector( math.cos( ang ) * d, math.sin( ang ) * d, 0 ) )
			if p and level( p ) and not util.TraceHull( { start = me + Vector( 0, 0, 20 ), endpos = p + Vector( 0, 0, 20 ),
				mins = Vector( -12, -12, 0 ), maxs = Vector( 12, 12, 40 ), mask = MASK_PLAYERSOLID, filter = self } ).Hit then
				out[ #out + 1 ] = p
			end
		end
	end
	return out
end

local function windowAt( p, from )
	local dir = flat( from - p )
	if dir:LengthSqr() < 1 then return false end
	dir:Normalize()
	local s = p + Vector( 0, 0, 96 )
	return util.TraceLine( { start = s, endpos = s + dir * 60, mask = MASK_SOLID_BRUSHONLY } ).Hit
end

local function coverKind( p, from, lowOnly )
	if not blocked( p + Vector( 0, 0, 26 ), from ) then return end
	if not blocked( p + Vector( 0, 0, 44 ), from ) then return not windowAt( p, from ) and "crouch" or nil end
	if not blocked( p + Vector( 0, 0, 64 ), from ) then return not windowAt( p, from ) and "stand" or nil end
	if not lowOnly then return "full" end
end

local function coverScore( self, p, kind, distEnemy, me, opts )
	local score = p:Distance( me ) + ( kind == "crouch" and 0 or kind == "stand" and 60 or 150 )
		- math.min( distEnemy, 1200 ) * ( opts.closer and -0.3 or 0.1 )
	local mates = 0
	for _, s in ipairs( U.teammates( self, 600 ) ) do
		if s:GetPos():DistToSqr( p ) < 140 * 140 then mates = mates + 1 end
	end
	return score + mates * 60
end

function ENT:FindCover( from, opts )
	opts = opts or {}
	if COD1.NodesReady and COD1.NodesReady() then return self:FindCoverNode( from, opts ) end
	local best, bestScore, bestType
	local me = self:GetPos()
	local myDist = me:Distance( from )
	for _, p in ipairs( self:CoverCandidates( opts.radius or 700 ) ) do
		local free = hullClear( p, self ) and not self:CornerTaken( p, 80 )
		local distEnemy = p:Distance( from )
		if free and distEnemy > 220 and ( not opts.closer or distEnemy < myDist - 150 ) then
			local kind = coverKind( p, from, opts.lowOnly )
			if kind then
				local score = coverScore( self, p, kind, distEnemy, me, opts )
				if not bestScore or score < bestScore then best, bestScore, bestType = p, score, kind end
			end
		end
	end
	return best, bestType
end

function ENT:FindCoverNode( from, opts )
	local me = self:GetPos()
	local myDist = me:Distance( from )
	local best, bestScore, bestType
	local level = U.levelFilter( me )
	for _, n in ipairs( COD1.NodesNear( me, opts.radius or 700 ) ) do
		if n.kind ~= "corner" and level( n.pos ) and self:OnPost( n.pos ) and not COD1.NodeTaken( n, self ) then
			local to = flat( from - n.pos )
			local distEnemy = to:Length()
			if distEnemy > 220 and ( not opts.closer or distEnemy < myDist - 150 ) and n.fwd:Dot( to:GetNormalized() ) > 0.5 then
				local kind
				if n.window then
					kind = blocked( n.pos + Vector( 0, 0, 26 ), from ) and n.kind or nil
				else
					kind = coverKind( n.pos, from, opts.lowOnly )
				end
				if kind then
					local score = coverScore( self, n.pos, kind, distEnemy, me, opts )
					if not bestScore or score < bestScore then best, bestScore, bestType = n.pos, score, kind end
				end
			end
		end
	end
	return best, bestType
end

function ENT:InCover()
	local c = COD1.Cover[ self ]
	return c and self:GetPos():DistToSqr( c ) < 50 * 50
end

function ENT:TakeCover( enemy, opts, say )
	local from = self:CanSee( enemy ) and self:AimPoint( enemy ) or ( self.LastKnownPos or enemy:GetPos() ) + Vector( 0, 0, 50 )
	local spot, kind = self:FindCover( from, opts )
	if not spot then return false end
	COD1.Cover[ self ] = spot
	self.CoverType = kind
	if say then
		local side = ( spot - self:GetPos() ):Cross( from - self:GetPos() ).z
		self:Say( side > 0 and "flankright" or "flankleft", 0.6 )
	end
	if opts and opts.closer then self:CallCoverFire( enemy ) end
	self.Advancing = opts and opts.closer
	self:MoveTo( spot, self.RunSpeed, 5, nil, CurTime() < self.Suppressed )
	self.Advancing = false
	return self:InCover()
end

function ENT:SquadSpot( p )
	local to = flat( p - self:GetPos() )
	if to:LengthSqr() < 1 then return p end
	to:Normalize()
	local slot = self:EntIndex() % 5 - 2
	if slot == 0 then return p end
	local spot = groundAt( p + Vector( -to.y, to.x, 0 ) * slot * 50 - to * math.abs( slot ) * 30 )
	if spot and hullClear( spot, self ) and not blocked( p + Vector( 0, 0, 40 ), spot + Vector( 0, 0, 40 ) ) then return spot end
	return p
end

function ENT:Decrowd()
	if CurTime() < ( self.NextDecrowd or 0 ) or self.Rambo or self.Parachuting or self.GunPass then return false end
	self.NextDecrowd = CurTime() + 0.8
	local me = self:GetPos()
	if IsValid( self.Enemy ) and CurTime() - self.LastSeen < 2 then
		local close = false
		for s in pairs( COD1.Soldiers ) do
			if s ~= self and IsValid( s ) and not s.Dead and s.COD1Team == self.COD1Team and s:EntIndex() < self:EntIndex()
				and math.abs( s:GetPos().z - me.z ) < 40 and flat( s:GetPos() - me ):LengthSqr() < 16 * 16 then
				close = true
				break
			end
		end
		if not close then return false end
	end
	local dir
	if not self.AtCorner and not self.Corner then
		for _, p in ipairs( player.GetAll() ) do
			local v = flat( p:GetVelocity() )
			local to = flat( me - p:GetPos() )
			if p:Alive() and math.abs( p:GetPos().z - me.z ) < 50 and to:LengthSqr() < 64 * 64 and v:LengthSqr() > 60 * 60
				and v:GetNormalized():Dot( to:GetNormalized() ) > 0.6 then
				self:MakeRoom( p, v:GetNormalized() )
				break
			end
		end
	end
	if self.MakeRoomDir and CurTime() < ( self.MakeRoomUntil or 0 ) and not self.AtCorner then
		dir = self.MakeRoomDir
		self.MakeRoomDir = nil
	else
		for s in pairs( COD1.Soldiers ) do
			if s ~= self and IsValid( s ) and not s.Dead and not s.Parachuting and s:EntIndex() < self:EntIndex() then
				local d = flat( me - s:GetPos() )
				if d:LengthSqr() < 30 * 30 and math.abs( s:GetPos().z - me.z ) < 40 then
					if d:LengthSqr() < 1 then d = flat( VectorRand() ) end
					dir = d:GetNormalized()
					break
				end
			end
		end
	end
	if not dir then return false end
	local right = dir:Angle():Right()
	for _, d in ipairs( { dir, right, -right, ( dir + right ):GetNormalized(), ( dir - right ):GetNormalized(), -dir } ) do
		local goal = groundAt( me + d * 56 )
		if goal and math.abs( goal.z - me.z ) < 24 and hullClear( goal, self ) and self:OpenToward( d, 56 ) then
			if self.AtCorner or self.Corner then self:LeaveCorner( true ) end
			COD1.Cover[ self ] = nil
			self.Hiding = false
			self:WalkTo( goal, 1.0, self.WalkSpeed * 2 )
			if self:GetPos():DistToSqr( me ) < 12 * 12 then
				self.CrowdFails = ( self.CrowdFails or 0 ) + 1
				if self.CrowdFails >= 2 then
					self.CrowdFails = 0
					self.NextDecrowd = CurTime() + 12
				end
			else
				self.CrowdFails = 0
			end
			return true
		end
	end
	return false
end

function ENT:Flank( enemy )
	local lkp = self.LastKnownPos or enemy:GetPos()
	local to = lkp - self:GetPos()
	to.z = 0
	local dist = to:Length()
	if dist < 300 then return false end
	to:Normalize()
	local side = Vector( -to.y, to.x, 0 ) * ( math.random( 2 ) == 1 and 1 or -1 )
	local goal = groundAt( lkp - to * math.min( dist * 0.5, 500 ) + side * math.Rand( 350, 550 ) )
	if not goal or not hullClear( goal, self ) then return false end
	self:Say( side:Dot( self:GetRight() ) > 0 and "flankright" or "flankleft", 0.8 )
	self:CallCoverFire( enemy )
	self.Advancing = true
	self:MoveTo( goal, self.RunSpeed, 5, function() return IsValid( enemy ) and self:CanSee( enemy ) end, true )
	self.Advancing = false
	return true
end

local function wallAhead( pos, dir, z, dist )
	local s = pos + Vector( 0, 0, z )
	return util.TraceLine( { start = s, endpos = s + dir * dist, mask = MASK_SOLID_BRUSHONLY } )
end

local function openAt( p, fwd, reach )
	return not wallAhead( p, fwd, 16, reach ).Hit and not wallAhead( p, fwd, 50, reach ).Hit and not wallAhead( p, fwd, 84, reach ).Hit
end

local function findEdge( base, fwd, lat, z )
	local up = Vector( 0, 0, z )
	local last = 0
	local reach = CORNER_WALL + 14
	for e = 12, 120, 12 do
		if blocked( base + lat * last + up, base + lat * e + up ) then return end
		if not wallAhead( base + lat * e, fwd, z, reach ).Hit then
			if not openAt( base + lat * e, fwd, reach ) then return end
			for f = e - 8, e - 4, 4 do
				if openAt( base + lat * f, fwd, reach ) then return f end
			end
			return e
		end
		last = e
	end
end

local function cornerPoses( n, target, eye )
	local sign = n.side == "r" and 1 or -1
	local lat = Vector( -n.fwd.y, n.fwd.x, 0 ) * sign
	local head, peek = n.pos + lat * 12 + n.fwd * 8, n.pos + lat * 28 + n.fwd * 22
	local rel = math.AngleDifference( ( target - peek ):Angle().y, n.yaw ) * sign
	if rel <= -40 or rel >= 70 then return end
	local stand = blocked( head + Vector( 0, 0, 62 ), eye ) and not blocked( peek + Vector( 0, 0, 52 ), target )
		and not blocked( n.pos + Vector( 0, 0, 52 ), peek + Vector( 0, 0, 52 ) )
	local crouch = blocked( head + Vector( 0, 0, 40 ), eye ) and not blocked( peek + Vector( 0, 0, 32 ), target )
		and not blocked( n.pos + Vector( 0, 0, 32 ), peek + Vector( 0, 0, 32 ) )
	if stand or crouch then return stand, crouch end
end

function ENT:CornerAt( hit, fwd, target, eye, z )
	local left = Vector( -fwd.y, fwd.x, 0 )
	local base = Vector( hit.x, hit.y, z ) - fwd * CORNER_WALL
	local yaw = fwd:Angle().y
	local first = math.random( 2 ) == 1 and 1 or -1
	for _, side in ipairs( { first, -first } ) do
		local lat = left * side
		local edge = findEdge( base, fwd, lat, 50 )
		local spot = edge and groundAt( base + lat * ( edge - CORNER_EDGE ) )
		if spot and math.abs( spot.z - z ) < 40 and hullClear( spot, self ) then
			local n = { pos = spot, fwd = fwd, yaw = yaw, side = side == 1 and "r" or "l" }
			local stand, crouch = cornerPoses( n, target, eye )
			if stand or crouch then
				n.stand, n.crouch = stand, crouch
				return n
			end
		end
	end
end

function ENT:CornerTarget( enemy )
	if IsValid( enemy ) and self:CanSee( enemy ) then return self:AimPoint( enemy ), enemy:EyePos() end
	local lkp = self.LastKnownPos or ( IsValid( enemy ) and enemy:GetPos() )
	if lkp then return lkp + Vector( 0, 0, 44 ), lkp + Vector( 0, 0, 62 ) end
end

function ENT:CornerTaken( pos, radius )
	radius = radius or 64
	for s, c in pairs( COD1.Cover ) do
		if s ~= self and IsValid( s ) and c:DistToSqr( pos ) < radius * radius then return true end
	end
	for s in pairs( COD1.Soldiers ) do
		if s ~= self and IsValid( s ) and not s.Dead and s:GetPos():DistToSqr( pos ) < 40 * 40 then return true end
	end
	return false
end

function ENT:FindCorner( enemy, opts )
	opts = opts or {}
	local target, eye = self:CornerTarget( enemy )
	if not target then return end
	if COD1.NodesReady and COD1.NodesReady() then return self:FindCornerNode( target, eye, opts ) end
	local me = self:GetPos()
	local myDist = me:Distance( target )
	local cands = { me }
	for _, c in ipairs( self:CoverCandidates( opts.radius or 600 ) ) do cands[ #cands + 1 ] = c end
	local best, bestScore
	local walls, tried = {}, 0
	for _, c in ipairs( cands ) do
		local to = flat( target - c )
		local dist = to:Length()
		if dist > 260 and ( not opts.closer or dist < myDist - 120 ) then
			to:Normalize()
			local tr = wallAhead( c, to, 50, 160 )
			local fwd = flat( -tr.HitNormal ):GetNormalized()
			local fresh = tr.Hit and not tr.StartSolid and math.abs( tr.HitNormal.z ) < 0.3 and fwd:Dot( to ) > 0.45
			if fresh then
				for _, w in ipairs( walls ) do
					if w[ 1 ]:DistToSqr( tr.HitPos ) < 32 * 32 and w[ 2 ]:Dot( fwd ) > 0.9 then fresh = false break end
				end
			end
			if fresh then
				walls[ #walls + 1 ] = { tr.HitPos, fwd }
				local cn = self:CornerAt( tr.HitPos, fwd, target, eye, c.z )
				if cn and self:OnPost( cn.pos ) and not self:CornerTaken( cn.pos ) then
					local score = cn.pos:Distance( me ) + ( cn.stand and 0 or 40 )
						- math.min( cn.pos:Distance( target ), 1500 ) * ( opts.closer and -0.3 or 0.05 )
					if not bestScore or score < bestScore then best, bestScore = cn, score end
				end
				tried = tried + 1
				if tried % 4 == 0 then
					coroutine.yield()
					if self.Dead then return end
				end
			end
		end
	end
	return best
end

function ENT:FindCornerNode( target, eye, opts )
	local me = self:GetPos()
	local myDist = me:Distance( target )
	local best, bestScore
	local level = U.levelFilter( me )
	for _, n in ipairs( COD1.NodesNear( me, opts.radius or 600 ) ) do
		if n.kind == "corner" and level( n.pos ) and self:OnPost( n.pos ) and not COD1.NodeTaken( n, self ) then
			local to = flat( target - n.pos )
			local dist = to:Length()
			if dist > 260 and ( not opts.closer or dist < myDist - 120 ) and n.fwd:Dot( to:GetNormalized() ) > 0.45 then
				local stand, crouch = cornerPoses( n, target, eye )
				if stand or crouch then
					local score = n.pos:Distance( me ) + ( stand and 0 or 40 ) - math.min( dist, 1500 ) * ( opts.closer and -0.3 or 0.05 )
					if not bestScore or score < bestScore then
						best, bestScore = { pos = n.pos, fwd = n.fwd, yaw = n.yaw, side = n.side, stand = stand, crouch = crouch }, score
					end
				end
			end
		end
	end
	return best
end

function ENT:CornerSeq( kind )
	return "cn_" .. self.CornerKey .. "_" .. kind
end

function ENT:CornerPlay( kind, rate )
	local name = self:CornerSeq( kind )
	if ( kind == "alert" or kind == "aim" ) and self:GetSequence() == self:LookupSequence( name ) then return 0 end
	return self:PlaySeq( name, rate )
end

function ENT:TakeCorner( enemy, opts )
	if self.WeaponType ~= "pistol" and not self.Weapon then return false end
	local cn = self:FindCorner( enemy, opts )
	if not cn or self.Dead then return false end
	if self.AtCorner then self:LeaveCorner() end
	self.Corner = cn
	COD1.Cover[ self ] = cn.pos
	cn.set = self.WeaponType == "pistol" and "p" or ( math.random( 2 ) == 1 and "a" or "b" )
	cn.expire = CurTime() + math.Rand( 18, 40 )
	cn.misses = 0
	local ran = false
	if not U.near( self:GetPos(), cn.pos, 12, 24 ) then
		if opts and opts.closer then self:CallCoverFire( enemy ) end
		self.Advancing = opts and opts.closer
		self:MoveTo( cn.pos, self.RunSpeed, 5, nil, CurTime() < self.Suppressed )
		self.Advancing = false
		if self.Dead or self.Corner ~= cn then return false end
		if not U.near( self:GetPos(), cn.pos, 40, 30 ) then self:LeaveCorner() return false end
		if self:GetPos():Distance2D( cn.pos ) > 10 then
			self:WalkTo( cn.pos, 0.7 )
			if self.Dead then return false end
		end
		ran = true
	end
	if not U.near( self:GetPos(), cn.pos, 40, 30 ) then self:LeaveCorner() return false end
	if hullClear( cn.pos, self ) then self:SetPos( cn.pos ) end
	self:EnterCorner( ran )
	return self.AtCorner
end

function ENT:EnterCorner( ran )
	local cn = self.Corner
	if self.Prone then self:LeaveProne() end
	self.Hiding = false
	if cn.stand and cn.crouch then
		local keep = math.random() < 0.9
		cn.pose = ( self.Crouched == keep ) and "c" or "s"
	else
		cn.pose = cn.stand and "s" or "c"
	end
	self.Crouched = cn.pose == "c"
	self.CornerKey = cn.set .. cn.pose .. "_" .. cn.side
	local d = COD1.CornerData and COD1.CornerData[ self.CornerKey ]
	if not d or self:LookupSequence( self:CornerSeq( "alert" ) ) < 0 then self:LeaveCorner() return end
	local left = Vector( -cn.fwd.y, cn.fwd.x, 0 )
	cn.muzzle = cn.pos + cn.fwd * d.muzzle.x + left * d.muzzle.y + Vector( 0, 0, d.muzzle.z )
	self.Moving = false
	self.loco:SetDesiredSpeed( 0 )
	self.loco:SetVelocity( vector_origin )
	local face = Angle( 0, cn.yaw + d.hide, 0 )
	self.AtCorner = true
	self:Say( cn.side == "r" and "flankright" or "flankleft", 0.5 )
	if ran then self:Wait( self:PlaySeq( self:CornerSeq( "enter" ) ), self:GetPos() + face:Forward() * 200, true ) end
	self:SetAngles( face )
	self:CornerPlay( "alert" )
end

function ENT:LeaveCorner( cooldown )
	self.Corner = nil
	self.CornerKey = nil
	self.AtCorner = false
	COD1.Cover[ self ] = nil
	self:SetPoseParameter( "corner_yaw", 0 )
	if cooldown then self.NextCornerSearch = CurTime() + 6 end
end

function ENT:CornerStillGood( enemy, visible, dist )
	local cn = self.Corner
	if CurTime() > cn.expire or cn.misses >= 2 or dist < U.CHARGE_RANGE then return false end
	if visible and self:LineOfSight( self:GetPos() + Vector( 0, 0, cn.pose == "c" and 40 or 62 ), enemy ) then return false end
	if self:GetPos():Distance2D( cn.pos ) > 40 or CurTime() - self.LastSeen > 12 then return false end
	local target = self:CornerAimPos( enemy )
	if not target then return false end
	local rel = math.AngleDifference( ( target - cn.pos ):Angle().y, cn.yaw ) * ( cn.side == "r" and 1 or -1 )
	return rel > -45 and rel < 80
end

function ENT:CornerSees( enemy )
	if not IsValid( enemy ) or not self:LineOfSight( self:MuzzlePos(), enemy ) then return false end
	self.LastSeen = CurTime()
	self.LastKnownPos = enemy:GetPos()
	return true
end

function ENT:CornerAimPos( enemy )
	if IsValid( enemy ) and CurTime() - self.LastSeen < 1 then return self:AimPoint( enemy ) end
	return self.LastKnownPos and self.LastKnownPos + Vector( 0, 0, 44 )
end

function ENT:CornerAim( pos )
	local cn = self.Corner
	local d = cn and COD1.CornerData[ self.CornerKey ]
	if not d or not pos then return end
	local rel = math.AngleDifference( ( pos - cn.muzzle ):Angle().y, cn.yaw )
	local y = d.yaw
	local w
	if ( rel - y[ 2 ] ) * ( y[ 1 ] - y[ 2 ] ) >= 0 then
		w = -math.Clamp( ( rel - y[ 2 ] ) / ( y[ 1 ] - y[ 2 ] ), 0, 1 )
	else
		w = math.Clamp( ( rel - y[ 2 ] ) / ( y[ 3 ] - y[ 2 ] ), 0, 1 )
	end
	self:SetPoseParameter( "corner_yaw", w )
end

function ENT:CornerWait( t, enemy, noInterrupt )
	local e = CurTime() + t
	local nextAim = 0
	while CurTime() < e do
		if self.Dead then return false end
		if not noInterrupt and ( self.PendingPain or self.GrenadeThreat ) then return false end
		if CurTime() >= nextAim then
			nextAim = CurTime() + 0.2
			self:CornerSees( enemy )
			self:CornerAim( self:CornerAimPos( enemy ) )
		end
		coroutine.yield()
	end
	return true
end

function ENT:CornerShot( enemy, acc )
	if self.Mag <= 0 or not IsValid( enemy ) then return false end
	local tp = self:AimPoint( enemy )
	if not self:LineOfFireClear( tp ) then return false end
	self.AccuracyMult = acc
	self:FireAt( tp, enemy )
	self.AccuracyMult = nil
	return true
end

function ENT:CornerAmbush( enemy, t )
	self:CornerPlay( "aim" )
	local e = CurTime() + t
	while CurTime() < e and CurTime() >= self.Suppressed and not self:CornerSees( enemy ) do
		if not self:CornerWait( 0.25, enemy ) then return false end
	end
	return true
end

function ENT:CornerSuppress( enemy, force )
	local w = self.Weapon
	local lkp = self.LastKnownPos
	if w.bolt or not lkp or CurTime() - self.LastSeen > 5 or self.Mag <= 0 or ( not force and math.random() > 0.7 ) then return false end
	local target = lkp + Vector( 0, 0, 40 )
	if blocked( self:MuzzlePos(), target ) or not self:LineOfFireClear( target ) then return false end
	self:Say( "doingsuppression", 0.4 )
	if w.auto then self:PlaySeq( self:CornerSeq( "auto" ) ) end
	for i = 1, math.min( self.Mag, w.auto and math.random( 4, 9 ) or math.random( 2, 3 ) ) do
		if self.Dead then break end
		if not w.auto then self:PlaySeq( self:CornerSeq( "semi" ) ) end
		self:FireAt( target + VectorRand() * 30 )
		if not self:CornerWait( w.auto and w.delay or math.max( w.delay, 0.3 ), enemy ) then break end
	end
	return true
end

function ENT:CornerAttack( enemy )
	local w = self.Weapon
	local cn = self.Corner
	local blind = self:Fair() and 0.3 or ( self:EnemySide() and 0.1 or 0.5 )
	local fired = 0
	self:CornerAim( self:CornerAimPos( enemy ) )
	if not self:CornerWait( self:PlaySeq( self:CornerSeq( "in" ) ), enemy ) then return end
	self:CornerPlay( "aim" )
	if not self:CornerWait( 0.1, enemy ) then return end

	local function burst( n, acc )
		local seq = self:LookupSequence( self:CornerSeq( "auto" ) )
		self:PlaySeq( self:CornerSeq( "auto" ), math.Clamp( self:SequenceDuration( seq ) / 4 / w.delay, 0.5, 3 ) )
		for i = 1, n do
			if not self:CornerShot( enemy, acc ) then break end
			fired = fired + 1
			if not self:CornerWait( w.delay, enemy ) then return false end
		end
		self:CornerPlay( "aim" )
		return true
	end
	local function single( acc )
		self:PlaySeq( self:CornerSeq( "semi" ) )
		if not self:CornerShot( enemy, acc ) then return false end
		fired = fired + 1
		return true
	end

	if w.auto then
		local total, quick = math.random( 7, 15 ), math.random( 3, 4 )
		if self:CornerSees( enemy ) and not burst( quick, blind ) then return end
		if self.Mag > 0 and not self.Dead then
			if not self:CornerAmbush( enemy, 3 ) then return end
			if CurTime() >= self.Suppressed and self:CornerSees( enemy ) then
				if not burst( total - quick, 1 ) then return end
			elseif self:CornerSuppress( enemy ) then
				fired = fired + 1
			end
		end
	elseif w.bolt then
		if ( self:EnemySide() or self:Fair() ) and not self:CornerWait( self:Fair() and 0.2 or 0.4, enemy ) then return end
		if not self:CornerAmbush( enemy, 3 ) then return end
		if self:CornerSees( enemy ) and single( 1 ) then
			self.NeedRechamber = true
			if not self:CornerWait( 0.3, enemy ) then return end
		end
	else
		local total = math.random( 3, 6 )
		local quick = math.random( 0, total - 3 )
		if self:CornerSees( enemy ) then
			for i = 1, quick do
				if not single( blind ) or not self:CornerWait( math.max( w.delay, 0.25 ), enemy ) then break end
			end
		end
		if self.Mag > 0 and not self.Dead then
			if not self:CornerAmbush( enemy, 3 ) then return end
			if self:CornerSees( enemy ) then
				for i = quick + 1, total do
					if self.Dead or not single( 1 ) or not self:CornerWait( math.max( w.delay, 0.25 ), enemy ) then break end
				end
			elseif self:CornerSuppress( enemy ) then
				fired = fired + 1
			end
		end
	end
	if self.Dead or not self.Corner then return end
	if CurTime() >= self.Suppressed then
		self:CornerPlay( "aim" )
		if not self:CornerWait( 0.25, enemy ) then return end
	end
	cn.misses = fired > 0 and 0 or cn.misses + 1
	self:CornerWait( self:PlaySeq( self:CornerSeq( "out" ) ), enemy, true )
	if self.Dead then return end
	if self.NeedRechamber then self:CornerRechamber() end
	self:CornerPlay( "alert" )
end

function ENT:CornerReload()
	local snd = "COD1.Reload." .. self.WeaponKey
	self:EmitSound( snd )
	if IsValid( self.Enemy ) then
		self:Say( "coverme", 0.5 )
		self:CallCoverFire( self.Enemy )
	end
	local ok = self:Wait( self:PlaySeq( self:CornerSeq( "reload" ) ), nil, true )
	self:StopSound( snd )
	if ok and not self.Dead then
		self.Mag = self.Weapon.clip
		self:CornerPlay( "alert" )
	end
end

function ENT:CornerRechamber()
	self.NeedRechamber = false
	self:EmitSound( "COD1.Rechamber." .. self.WeaponKey )
	local dur = self:PlaySeq( self:CornerSeq( "rechamber" ) )
	timer.Simple( 0.35, function() if IsValid( self ) and not self.Dead then self:EjectShell() end end )
	self:Wait( dur, nil, true )
end

function ENT:CornerGrenade( target )
	local d = COD1.CornerData[ self.CornerKey ]
	self.Grenades = self.Grenades - 1
	self.NextGrenade = CurTime() + math.Rand( 15, 25 )
	self:Say( "grenadeattack", 0.9 )
	self:EmitSound( "COD1.GrenadePin" )
	local dur = self:PlaySeq( self:CornerSeq( "grenade" ) )
	if not self:Wait( d.nade, nil, true ) then return end
	self:LaunchGrenade( target, self.Corner.side == "r" and "anim_attachment_LH" or "anim_attachment_RH" )
	if self:Wait( math.max( 0, dur - d.nade ), nil, true ) and self.Corner then self:CornerPlay( "alert" ) end
end

function ENT:CornerRambo( enemy )
	local cn = self.Corner
	local r = COD1.CornerRambo and COD1.CornerRambo[ cn.side ]
	if not r or not IsValid( enemy ) then return false end
	local home, ang = self:GetPos(), self:GetAngles()
	local out = home + ang:Forward() * r[ 1 ] - ang:Right() * r[ 2 ]
	if not hullClear( out, self ) or blocked( home + Vector( 0, 0, 40 ), out + Vector( 0, 0, 40 ) ) then return false end
	local sfx = "_" .. cn.side
	local w = self.Weapon
	self.Rambo = true
	self:PlayMotion( "cn_rambo_in" .. sfx, out )
	if not self.Dead then self:Wait( self:PlaySeq( "cn_rambo_ready" .. sfx ), nil, true ) end
	if not self.Dead and w.auto then
		self:PlaySeq( "cn_rambo_auto" .. sfx )
		for i = 1, math.random( 5, 9 ) do
			if self.Dead or not self:CornerShot( enemy, 1 ) then break end
			self:Wait( w.delay, nil, true )
		end
	elseif not self.Dead then
		for i = 1, math.random( 2, 4 ) do
			if self.Dead then break end
			self:PlaySeq( "cn_rambo_semi" .. sfx )
			self:CornerShot( enemy, 1 )
			self:Wait( math.max( w.delay, 0.3 ), nil, true )
		end
	end
	if not self.Dead then self:PlayMotion( "cn_rambo_out" .. sfx, home ) end
	self.Rambo = false
	if self.Dead then return true end
	self:SetAngles( ang )
	self:CornerPlay( "alert" )
	return true
end

function ENT:CornerFight( enemy )
	local cn = self.Corner
	local w = self.Weapon
	self:SetAngles( Angle( 0, cn.yaw + COD1.CornerData[ self.CornerKey ].hide, 0 ) )
	self:CornerPlay( "alert" )
	if not self:CornerWait( math.Rand( 0.4, 0.7 ), enemy ) then return end
	local lkp = self.LastKnownPos
	if self:CoverFireRequested() then
		if self:CornerSuppress( enemy, true ) then return end
	end
	if lkp and CurTime() - self.LastSeen < 8 and math.random() < 0.35 and self:CanThrowGrenade( lkp ) then return self:CornerGrenade( lkp ) end
	if self.Mag <= 0 or self.Mag < w.clip * 0.15 then return self:CornerReload() end
	if self.NeedRechamber then self:CornerRechamber() self:CornerPlay( "alert" ) end

	local was = false
	while CurTime() < self.Suppressed and not self.Dead do
		if was then self:Say( "undersuppression", 0.4 ) end
		was = true
		if not self:CornerWait( math.Rand( 0.6, 1.2 ), enemy ) then return end
		if lkp and math.random() < 0.15 and self:CanThrowGrenade( lkp ) then return self:CornerGrenade( lkp ) end
	end
	if self.Dead then return end
	if was and math.random() < 0.5 and self:LookupSequence( self:CornerSeq( "look" ) ) >= 0 then
		self:CornerWait( self:PlaySeq( self:CornerSeq( "look" ) ), enemy )
		if self.Corner then self:CornerPlay( "alert" ) end
		return
	end
	local chance = w.auto and 0.15 or ( w.bolt and 0 or 0.07 )
	if ( self:EnemySide() or self:Fair() ) and cn.set == "a" and cn.pose == "s" and math.random() < chance and self:CornerRambo( enemy ) then return end
	self:CornerAttack( enemy )
end

--finding cover, harder then it sounds
