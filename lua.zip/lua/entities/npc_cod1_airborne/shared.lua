ENT.Base = "base_nextbot"
ENT.PrintName = "Allied Soldier"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true
ENT.IsCOD1Soldier = true

ENT.COD1Team = "allies"
ENT.DefaultVariant = "airborne_summer"
ENT.RunSpeed = 180
ENT.WalkSpeed = 55
ENT.SightRange = 4000
ENT.FOV = 0.25
ENT.Author = "adodser"

--shared soldier stuff
