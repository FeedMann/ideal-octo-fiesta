local U = COD1.AI
local flat, hullClear = U.flat, U.hullClear

local OVER = {
	{ seq = "trav_window", lo = 22, hi = 58, window = true },
	{ seq = "mantle_low", lo = 18, hi = 46 },
	{ seq = "trav_fence", lo = 30, hi = 52 },
	{ seq = "trav_wall", lo = 44, hi = 68 },
	{ seq = "mantle_high", lo = 64, hi = 100, top = 90 },
}
local UP = {
	{ seq = "trav_step_up", lo = 18, hi = 46 },
	{ seq = "trav_climb", lo = 40, hi = 66 },
}
local DOWN = {
	{ seq = "trav_step_down", lo = 21, hi = 46 },
	{ seq = "jump_down_low", lo = 40, hi = 76 },
	{ seq = "jump_down_high", lo = 70, hi = 118 },
}
U.MANTLE_MAX = 100
U.DROP_MAX = 118

local GUN_RUN = {
	stand = { fwd = "run_shoot", back = "run_shoot_back", left = "run_shoot_left", right = "run_shoot_right" },
	crouch = { fwd = "crouch_shoot_run", back = "crouch_shoot_run_back", left = "crouch_shoot_run_left", right = "crouch_shoot_run_right" },
}
local DOORS = { prop_door_rotating = true, func_door = true, func_door_rotating = true }
local PORTAL_MARGIN = 20
local STEP_UP = Vector( 0, 0, 22 )
local PULL_MINS, PULL_MAXS = Vector( -12, -12, 0 ), Vector( 12, 12, 40 )

local function notActor( e ) return not ( e.IsCOD1Soldier or e:IsPlayer() or e:IsNPC() or e:IsNextBot() ) end

local function landClear( pos )
	return not util.TraceHull( { start = pos + Vector( 0, 0, 4 ), endpos = pos + Vector( 0, 0, 4 ),
		mins = Vector( -13, -13, 0 ), maxs = Vector( 13, 13, 68 ), filter = notActor, mask = MASK_PLAYERSOLID } ).Hit
end

local function ray( a, b )
	return util.TraceLine( { start = a, endpos = b, filter = notActor, mask = MASK_PLAYERSOLID } )
end

local function up( z ) return Vector( 0, 0, z ) end

local KEYS = {}

local function keys( seq, top )
	local k = KEYS[ seq ]
	if k ~= nil then return k end
	local m = COD1.Motion and COD1.Motion[ seq ]
	if not m or #m < 3 then
		KEYS[ seq ] = false
		return false
	end
	local o = m[ 1 ]
	local rc, rs = math.cos( math.rad( -o[ 4 ] ) ), math.sin( math.rad( -o[ 4 ] ) )
	k = { n = #m, fps = m.fps, x = {}, z = {}, yaw = {}, top = 0 }
	for i, r in ipairs( m ) do
		local dx, dy = r[ 1 ] - o[ 1 ], r[ 2 ] - o[ 2 ]
		k.x[ i ] = dx * rc - dy * rs
		k.z[ i ] = r[ 3 ] - o[ 3 ]
		k.yaw[ i ] = r[ 4 ] - o[ 4 ]
		k.top = math.max( k.top, k.z[ i ] )
	end
	k.top = top or k.top
	if k.top > 8 then
		for i = 1, k.n do
			if k.z[ i ] >= k.top * 0.85 then
				k.ka = k.ka or i
				k.kb = i
			end
		end
	else
		for i = 2, k.n do
			if k.z[ i ] < -2 then
				k.ke = i - 1
				break
			end
		end
	end
	KEYS[ seq ] = k
	return k
end

local function pick( ent, list, h, test )
	local best, bd, info
	for _, c in ipairs( list ) do
		if h >= c.lo and h <= c.hi and ent:LookupSequence( c.seq ) >= 0 then
			local k = keys( c.seq, c.top )
			local r = k and ( k.ka or k.ke ) and ( not test or test( c, k ) )
			if r then
				local d = math.abs( ( k.top > 8 and k.top or -k.z[ k.n ] ) - h ) + math.random() * 8
				if not bd or d < bd then best, bd, info = c, d, r end
			end
		end
	end
	return best, info
end

function ENT:ProbeOver( from, dir, reach, onlyOver )
	local tr = ray( from + up( 10 ), from + up( 10 ) + dir * reach )
	if not tr.Hit or tr.StartSolid or tr.HitNormal.z > 0.6 then return end
	if IsValid( tr.Entity ) and DOORS[ tr.Entity:GetClass() ] then return end
	local n = flat( tr.HitNormal )
	if n:LengthSqr() < 0.01 then return end
	n:Normalize()
	if n:Dot( dir ) > -0.6 then return end
	local ax = -n
	local side = Vector( -ax.y, ax.x, 0 )
	local face = Vector( tr.HitPos.x, tr.HitPos.y, from.z )
	if ray( from + up( 6 ), face - ax * 6 + up( 6 ) ).Hit then return end
	local near = face - ax * 20
	local z0
	for z = 14, 112, 4 do
		if not ray( near + up( z ), face + ax * 4 + up( z ) ).Hit then
			z0 = z
			break
		end
	end
	if not z0 then return end
	local t = ray( face + ax * 4 + up( z0 + 2 ), face + ax * 4 + up( z0 - 10 ) )
	local h = ( t.Hit and not t.StartSolid and t.HitNormal.z > 0.7 ) and t.HitPos.z - from.z or z0 - 2
	if h < ( onlyOver and 24 or 18 ) then return end
	local lintel
	for z = z0 + 4, z0 + 96, 4 do
		if ray( near + up( z ), face + ax * 4 + up( z ) ).Hit then
			lintel = z
			break
		end
	end
	local opening = lintel and lintel - h
	local window = opening ~= nil and opening < 72
	local slack = 20
	if window then
		if opening < 44 then return end
		local c = face + ax * 4 + up( h + math.min( opening * 0.5, 24 ) )
		local l, r = ray( c, c + side * 64 ), ray( c, c - side * 64 )
		if l.StartSolid or r.StartSolid then return end
		local dl, dr = l.Fraction * 64, r.Fraction * 64
		if dl + dr < 24 then return end
		face = face + side * ( dl - dr ) * 0.5
		slack = math.Clamp( ( dl + dr ) * 0.5 - 13, 3, 20 )
	end
	local thick = 104
	for _, d in ipairs( { 104, 64, 40 } ) do
		local tb = ray( face + ax * d + up( h - 3 ), face + ax * 1 + up( h - 3 ) )
		if not tb.StartSolid then
			thick = tb.Hit and math.max( ( tb.HitPos - face ):Dot( ax ), 1 ) or 1
			break
		end
	end
	local plan = { face = face, axis = ax, side = side, h = h, thick = thick, slack = slack, window = window, from = from }
	if thick > 40 then
		if onlyOver or window then return end
		local c = pick( self, UP, h )
		if not c then return end
		local k = keys( c.seq, c.top )
		local deep = math.Clamp( k.x[ k.n ] - k.x[ k.ka ], 18, math.max( thick - 14, 18 ) )
		local q = face + ax * deep
		local g = ray( q + up( h + 10 ), q + up( h - 10 ) )
		if not g.Hit or g.StartSolid or g.HitNormal.z < 0.7 or not landClear( g.HitPos ) then return end
		plan.kind, plan.seq, plan.top, plan.land = "up", c.seq, c.top, g.HitPos
		plan.start = face - ax * math.Clamp( k.x[ k.ka ] - 6, 14, 26 )
		return plan
	end
	local function lands( c, k )
		if window ~= ( c.window or false ) then return false end
		local off = math.max( 18, k.x[ k.n ] - k.x[ k.kb ] )
		local q = face + ax * ( thick + off )
		local g = ray( q + up( h + 6 ), q + up( h - 140 ) )
		if not g.Hit or g.StartSolid or g.HitNormal.z < 0.7 then return false end
		local dz = g.HitPos.z - from.z
		if dz < -64 or dz > h - 10 or not landClear( g.HitPos ) then return false end
		if util.TraceHull( { start = face - ax * 2 + up( h + 2 ), endpos = q + up( h + 2 ), mins = Vector( -8, -8, 0 ),
			maxs = Vector( 8, 8, window and 20 or 30 ), filter = notActor, mask = MASK_PLAYERSOLID } ).Hit then return false end
		return { land = g.HitPos }
	end
	local c, got = pick( self, OVER, h, lands )
	if not c then return end
	local k = keys( c.seq, c.top )
	plan.kind, plan.seq, plan.top, plan.land = "over", c.seq, c.top, got.land
	plan.start = face - ax * math.Clamp( k.x[ k.ka ] - 6, 14, 26 )
	return plan
end

function ENT:ProbeDown( from, dir, reach )
	local edge
	for s = 8, reach, 8 do
		local p = from + dir * s
		local g = ray( p + up( 24 ), p - up( 20 ) )
		if g.StartSolid then return end
		if not g.Hit then
			edge = s
			break
		end
	end
	if not edge then return end
	local lo, hi = edge - 8, edge
	for _ = 1, 3 do
		local mid = ( lo + hi ) * 0.5
		local p = from + dir * mid
		if ray( p + up( 24 ), p - up( 20 ) ).Hit then lo = mid else hi = mid end
	end
	local face = from + dir * lo
	if ray( from + up( 40 ), face + dir * 40 + up( 40 ) ).Hit then return end
	local side = Vector( -dir.y, dir.x, 0 )
	local function lands( c, k )
		local off = math.max( 20, k.x[ k.n ] - k.x[ k.ke ] )
		local q = face + dir * off
		local g = ray( q + up( 8 ), q - up( 130 ) )
		if not g.Hit or g.StartSolid or g.HitNormal.z < 0.7 then return false end
		local drop = from.z - g.HitPos.z
		if drop < c.lo or drop > c.hi or not landClear( g.HitPos ) then return false end
		return { land = g.HitPos, drop = drop }
	end
	local probe = ray( face + dir * 30 + up( 8 ), face + dir * 30 - up( 130 ) )
	local drop = probe.Hit and from.z - probe.HitPos.z or 130
	local c, got = pick( self, DOWN, drop, lands )
	if not c then return end
	local k = keys( c.seq )
	return { kind = "down", seq = c.seq, face = Vector( face.x, face.y, from.z ), axis = dir, side = side, h = 0, thick = 0, drop = got.drop,
		land = got.land, slack = 30, from = from, start = face - dir * math.min( k.x[ k.ke ], 24 ) }
end

function ENT:PlanTraverse( dir, reach, kind, goal )
	if not self.loco:IsOnGround() then return end
	dir = Vector( dir.x, dir.y, 0 )
	if dir:LengthSqr() < 0.01 then return end
	dir:Normalize()
	local from = self:GetPos()
	local plan
	if kind ~= 1 then plan = self:ProbeOver( from, dir, reach, kind == nil ) end
	if not plan and kind == 1 then plan = self:ProbeDown( from, dir, reach ) end
	if not plan then return end
	if goal then
		local beyond = flat( goal - plan.face ):Dot( plan.axis )
		if beyond < ( kind and plan.kind ~= "up" and -24 or plan.kind == "up" and 8 or plan.thick + 8 ) then return end
		if plan.kind == "up" and goal.z < plan.land.z - 30 then return end
	end
	return plan
end

function ENT:TryMantle( dir, dryRun, goal )
	if not self.loco:IsOnGround() then return false end
	if not dryRun then
		if ( self.NextMantle or 0 ) > CurTime() then return false end
		self.NextMantle = CurTime() + 0.15
	end
	local plan = self:PlanTraverse( dir, 40, 2, goal ) or self:PlanTraverse( dir, 48, 1, goal )
	if not plan then return false end
	if not dryRun then self:Traverse( plan ) end
	return true
end

local function piece( x, x0, x1, y0, y1 )
	if math.abs( x1 - x0 ) < 0.01 then return y1 end
	return y0 + ( x - x0 ) / ( x1 - x0 ) * ( y1 - y0 )
end

function ENT:Traverse( plan )
	local k = keys( plan.seq, plan.top )
	if not k then return false end
	local pos = self:GetPos()
	local ax, side = plan.axis, plan.side
	local rel = pos - plan.face
	local a = math.max( -rel:Dot( ax ), 2 )
	local lat0 = rel:Dot( side )
	local base = plan.face - ax * a
	base.z = pos.z
	local land = plan.land
	local dz = land.z - pos.z
	local reach = a + ( land - plan.face ):Dot( ax )
	local landLat = ( land - plan.face ):Dot( side )
	local k0, rise = 1, k.ka or k.ke
	local path = {}
	if plan.kind == "down" then
		local xe = k.x[ k.ke ]
		if a < xe then
			for i = 1, k.ke do
				if k.x[ i ] >= xe - a then
					k0 = i
					break
				end
			end
		end
		local depth = math.max( -k.z[ k.n ], 1 )
		for i = k0, k.n do
			local along = i <= k.ke and piece( k.x[ i ], k.x[ k0 ], xe, 0, a ) or piece( k.x[ i ], xe, k.x[ k.n ], a, reach )
			local h = i <= k.ke and 0 or k.z[ i ] / depth * -dz
			path[ #path + 1 ] = { along, h, i }
		end
	else
		local hScale = plan.h / k.top
		local A, B = a + 2, a + plan.thick + 2
		if plan.kind == "up" then B = reach end
		if B < A then B = A end
		local zb = k.z[ k.kb ] * hScale
		for i = 1, k.n do
			local along, h
			if i <= k.ka then
				along = piece( k.x[ i ], 0, k.x[ k.ka ], 0, A )
			elseif i <= k.kb then
				along = piece( k.x[ i ], k.x[ k.ka ], k.x[ k.kb ], A, B )
			else
				along = piece( k.x[ i ], k.x[ k.kb ], k.x[ k.n ], B, reach )
			end
			if plan.kind == "up" or i <= k.kb then
				h = k.z[ i ] * hScale
			else
				h = piece( k.z[ i ], k.z[ k.kb ], k.z[ k.n ], zb, dz )
			end
			path[ #path + 1 ] = { along, h, i }
		end
	end
	local topEnd = plan.kind == "down" and k.ke or k.kb
	for j = 2, #path do path[ j ][ 1 ] = math.max( path[ j ][ 1 ], path[ j - 1 ][ 1 ] ) end
	local pts = {}
	for j, p in ipairs( path ) do
		local lat = 0
		if p[ 3 ] <= rise then
			local t = math.Clamp( ( p[ 3 ] - k0 ) / math.max( rise - k0, 1 ), 0, 1 )
			lat = lat0 * ( 1 - t * t * ( 3 - 2 * t ) )
		elseif p[ 3 ] > topEnd then
			lat = landLat * ( p[ 3 ] - topEnd ) / math.max( k.n - topEnd, 1 )
		end
		pts[ j ] = base + ax * p[ 1 ] + side * lat + up( p[ 2 ] )
	end
	pts[ #pts ] = Vector( land.x, land.y, land.z )
	self.Traversing = plan
	self.Moving = false
	self.loco:SetDesiredSpeed( 0 )
	self.loco:SetVelocity( vector_origin )
	self:PlaySeq( plan.seq )
	if k0 > 1 then self:SetCycle( ( k0 - 1 ) / ( k.n - 1 ) ) end
	if plan.kind ~= "down" then self:EmitSound( "COD1.Scrape" ) end
	local grav = self.loco:GetGravity()
	self.loco:SetGravity( 0 )
	self:SetCollisionBounds( Vector( -2, -2, 0 ), Vector( 2, 2, 8 ) )
	local axisYaw = ax:Angle().y
	local turn = math.AngleDifference( axisYaw, self:GetAngles().y )
	local t0 = CurTime()
	local last = #pts
	while not self.Dead do
		local el = CurTime() - t0
		local f = math.min( el * k.fps, last - 1 )
		local i = math.floor( f )
		local frac = f - i
		local p = LerpVector( frac, pts[ i + 1 ], pts[ math.min( i + 2, last ) ] )
		local ki = path[ i + 1 ][ 3 ]
		local yaw = Lerp( frac, k.yaw[ ki ], k.yaw[ math.min( ki + 1, k.n ) ] )
		self:SetPos( p )
		self:SetAngles( Angle( 0, axisYaw + yaw - turn * math.max( 0, 1 - el / 0.15 ), 0 ) )
		self.loco:SetVelocity( vector_origin )
		if f >= last - 1 then break end
		coroutine.yield()
	end
	self:SetCollisionBounds( U.HULL_MINS, U.HULL_MAXS )
	self.loco:SetGravity( grav )
	self.loco:ClearStuck()
	self.Traversing = nil
	if self.Dead then return true end
	self:SetPos( Vector( land.x, land.y, land.z ) )
	self:SetAngles( Angle( 0, axisYaw, 0 ) )
	self:EmitSound( "COD1.Land." .. COD1.SurfaceUnder( self ) )
	self:EmitSound( "COD1.Gear" )
	self.Crouched = false
	self.Hiding = false
	self.LastTraverse = CurTime()
	return true
end

local GLASS = { func_breakable_surf = true, func_breakable = true }

function ENT:SmashGlass( dir )
	if CurTime() < ( self.NextSmash or 0 ) then return false end
	local pos = self:GetPos()
	for _, z in ipairs( { 56, 40 } ) do
		local s = pos + Vector( 0, 0, z )
		local tr = util.TraceLine( { start = s, endpos = s + dir * 48, filter = self, mask = MASK_PLAYERSOLID } )
		local e = tr.Entity
		if IsValid( e ) and GLASS[ e:GetClass() ] then
			self.NextSmash = CurTime() + 1.5
			self.loco:SetVelocity( vector_origin )
			self:TurnTo( tr.HitPos, 0.3 )
			if e:GetClass() == "func_breakable_surf" then e:Fire( "Shatter", "0.5 0.5 96" ) else e:TakeDamage( 500, self, self ) end
			self:EmitSound( "physics/glass/glass_impact_bullet" .. math.random( 1, 4 ) .. ".wav", 75 )
			self:Wait( 0.35, nil, true )
			return true
		end
	end
	return false
end

local KICKABLE = { prop_physics = true, prop_physics_multiplayer = true, prop_physics_respawnable = true }

function ENT:ShoveProp( dir )
	if CurTime() < ( self.NextShove or 0 ) or self.HasFlag or self.Carrying or self.NoGun then return false end
	local pos = self:GetPos()
	local tr = util.TraceHull( { start = pos + Vector( 0, 0, 24 ), endpos = pos + Vector( 0, 0, 24 ) + dir * 44,
		mins = Vector( -10, -10, -14 ), maxs = Vector( 10, 10, 24 ), filter = self, mask = MASK_NPCSOLID } )
	local e = tr.Entity
	if not IsValid( e ) or not KICKABLE[ e:GetClass() ] then return false end
	local phys = e:GetPhysicsObject()
	if not IsValid( phys ) or not phys:IsMoveable() or phys:GetMass() > 250 then return false end
	self.NextShove = CurTime() + 2
	self.loco:SetVelocity( vector_origin )
	self.loco:SetDesiredSpeed( 0 )
	self.Moving = false
	self:TurnTo( e:WorldSpaceCenter(), 0.3 )
	if self.Dead or not IsValid( e ) then return true end
	local dur = self:PlaySeq( "grenade_kick" )
	self:Wait( 5 / 30, nil, true )
	if IsValid( e ) and IsValid( phys ) and not self.Dead then
		local push = flat( e:WorldSpaceCenter() - self:GetPos() )
		if push:LengthSqr() < 1 then push = dir end
		push:Normalize()
		local side = Vector( -dir.y, dir.x, 0 ) * ( ( e:WorldSpaceCenter() - pos ):Dot( Vector( -dir.y, dir.x, 0 ) ) >= 0 and 1 or -1 )
		phys:Wake()
		phys:SetVelocity( ( push + side * 0.8 ):GetNormalized() * math.Clamp( 9000 / math.max( phys:GetMass(), 5 ), 120, 420 ) + Vector( 0, 0, 90 ) )
		e:EmitSound( "physics/wood/wood_box_impact_hard" .. math.random( 1, 3 ) .. ".wav", 70 )
	end
	self:Wait( math.max( dur - 5 / 30, 0.2 ), nil, true )
	return true
end

function ENT:Unwedge( dir )
	local me = self:GetPos()
	local cands = {}
	if navmesh.IsLoaded() then
		local area = navmesh.GetNearestNavArea( me, false, 120, false, true )
		if IsValid( area ) then
			local p = area:GetClosestPointOnArea( me + ( dir or vector_origin ) * 32 )
			if p then cands[ #cands + 1 ] = p end
			cands[ #cands + 1 ] = area:GetCenter()
		end
	end
	for _, r in ipairs( { 24, 44, 64 } ) do
		for i = 0, 7 do
			local a = i * math.pi / 4
			cands[ #cands + 1 ] = me + Vector( math.cos( a ) * r, math.sin( a ) * r, 0 )
		end
	end
	for _, c in ipairs( cands ) do
		local g = U.groundAt( c )
		if g and math.abs( g.z - me.z ) < 24 and g:Distance2D( me ) > 8 and g:Distance2D( me ) < 140 and hullClear( g, self )
			and not U.blocked( me + Vector( 0, 0, 36 ), g + Vector( 0, 0, 36 ) ) then
			self:SetPos( g )
			self.loco:ClearStuck()
			return true
		end
	end
	return false
end

function ENT:Sidestep( dir )
	self.loco:ClearStuck()
	dir = flat( dir or self:GetForward() )
	if dir:LengthSqr() < 0.01 then dir = self:GetForward() end
	dir:Normalize()
	local right = Vector( dir.y, -dir.x, 0 )
	local pos = self:GetPos()
	local best, bestFrac
	for _, v in ipairs( { right, -right, ( right - dir ):GetNormalized(), ( -right - dir ):GetNormalized(), -dir } ) do
		local tr = util.TraceHull( { start = pos + Vector( 0, 0, 20 ), endpos = pos + Vector( 0, 0, 20 ) + v * 60,
			mins = Vector( -11, -11, 0 ), maxs = Vector( 11, 11, 46 ), filter = self, mask = MASK_NPCSOLID } )
		if not bestFrac or tr.Fraction > bestFrac + 0.05 then best, bestFrac = v, tr.Fraction end
	end
	local goal = pos + best * 60 * math.max( bestFrac, 0.3 )
	local t = CurTime() + 0.45
	while CurTime() < t and not self.Dead do
		self.loco:FaceTowards( pos + dir * 100 )
		self.loco:Approach( goal, 1 )
		coroutine.yield()
	end
end

function ENT:OpenToward( dir, dist )
	local pos = self:GetPos()
	return not util.TraceHull( { start = pos + Vector( 0, 0, 20 ), endpos = pos + Vector( 0, 0, 20 ) + dir * dist,
		mins = Vector( -11, -11, 0 ), maxs = Vector( 11, 11, 46 ), filter = self, mask = MASK_NPCSOLID_BRUSHONLY } ).Hit
end

function ENT:CanWalk( a, b )
	if math.abs( b.z - a.z ) > 40 or a:Distance2D( b ) > 500 then return false end
	if util.TraceHull( { start = a + Vector( 0, 0, 20 ), endpos = b + Vector( 0, 0, 20 ), mins = Vector( -15, -15, 0 ),
		maxs = Vector( 15, 15, 40 ), filter = self, mask = MASK_NPCSOLID_BRUSHONLY } ).Hit then return false end
	local mid = ( a + b ) / 2
	return util.TraceLine( { start = mid + Vector( 0, 0, 20 ), endpos = mid - Vector( 0, 0, 60 ), mask = MASK_NPCSOLID_BRUSHONLY } ).Hit
end

function ENT:DirectWalk( a, b )
	if util.TraceHull( { start = a + STEP_UP, endpos = b + STEP_UP, mins = PULL_MINS, maxs = PULL_MAXS,
		filter = notActor, mask = MASK_NPCSOLID } ).Hit then return false end
	local steps = math.floor( a:Distance2D( b ) / 32 )
	for s = 1, steps do
		local p = LerpVector( s / ( steps + 1 ), a, b )
		if not util.TraceLine( { start = p + Vector( 0, 0, 30 ), endpos = p - Vector( 0, 0, 44 ), mask = MASK_NPCSOLID_BRUSHONLY } ).Hit then
			return false
		end
	end
	return true
end

function ENT:Reachable( goal )
	local me = self:GetPos()
	if math.abs( goal.z - me.z ) > 40 then return false end
	if me:Distance2D( goal ) < 24 then return true end
	return self:DirectWalk( me, goal )
end

function ENT:Steer( goal )
	local pos = self:GetPos()
	local to = flat( goal - pos )
	local dist = to:Length()
	if dist < 1 then return goal end
	to:Normalize()
	local probe, look = math.min( dist, 40 ), math.min( dist, 70 )
	local function clear( d )
		local t = { start = pos + Vector( 0, 0, 46 ), endpos = pos + Vector( 0, 0, 46 ) + d * probe,
			mins = Vector( -14, -14, 0 ), maxs = Vector( 14, 14, 20 ), filter = self, mask = MASK_NPCSOLID_BRUSHONLY }
		local tr = util.TraceHull( t )
		if tr.StartSolid then
			t.mins, t.maxs = Vector( -10, -10, 0 ), Vector( 10, 10, 20 )
			tr = util.TraceHull( t )
		end
		return not tr.Hit
	end
	if clear( to ) then
		self.SteerSide = nil
		return goal
	end
	local side = self.SteerSide or ( math.random( 2 ) == 1 and 1 or -1 )
	for _, a in ipairs( { 30, 55, 80, 110, 140 } ) do
		for _, s in ipairs( { side, -side } ) do
			local ang = to:Angle()
			ang.y = ang.y + a * s
			local d = ang:Forward()
			if clear( d ) then
				self.SteerSide = s
				return pos + d * look
			end
		end
	end
	return goal
end

function ENT:NoNavHint()
	if navmesh.IsLoaded() or COD1.ToldNoNav then return end
	COD1.ToldNoNav = true
	for _, ply in ipairs( player.GetAll() ) do
		ply:ChatPrint( "[CoD1] This map has no navmesh, so soldiers can't plan a way round walls or up stairs. Press Build navmesh in Utilities > Call of Duty 1 > Map Tools." )
	end
end

function ENT:MoveSide( dir )
	local f, r = dir:Dot( self:GetForward() ), dir:Dot( self:GetRight() )
	if math.abs( f ) >= math.abs( r ) then return f >= 0 and "fwd" or "back" end
	return r >= 0 and "right" or "left"
end

function ENT:CanGunWhileMoving( enemy )
	local w = self.Weapon
	if self.WeaponType == "pistol" or self.Unarmed or self.HasFlag then return false end
	if self.Mag <= 0 or self:IsHurt() or not IsValid( enemy ) then return false end
	local range = U.RANGES[ self.WeaponType ]
	return self:GetPos():DistToSqr( enemy:GetPos() ) < ( range[ 2 ] * 1.3 ) ^ 2 and self:CanSee( enemy )
end

local edgeCache = {}

local function propBetween( a, b, floor )
	local tr = util.TraceHull( { start = a + Vector( 0, 0, 30 ), endpos = b + Vector( 0, 0, 30 ),
		mins = Vector( -12, -12, 0 ), maxs = Vector( 12, 12, 30 ), ignoreworld = true, mask = MASK_NPCSOLID,
		filter = function( e )
			if e.IsCOD1Soldier or e:IsPlayer() or e:IsNPC() or DOORS[ e:GetClass() ] then return false end
			local _, top = e:WorldSpaceAABB()
			return top.z - floor > U.MANTLE_MAX
		end } )
	return tr.Hit
end

local function ledgeBlocked( fromArea, area )
	local a = fromArea:GetClosestPointOnArea( area:GetCenter() )
	local b = area:GetClosestPointOnArea( fromArea:GetCenter() )
	if not a or not b then return false end
	local s = a + Vector( 0, 0, 30 )
	return util.TraceLine( { start = s, endpos = Vector( b.x, b.y, s.z ), mask = MASK_PLAYERSOLID_BRUSHONLY } ).Hit
end

function ENT:PathCost()
	local loco = self.loco
	local blocked, blockedEdges = self.MyBlocked, self.MyBlockedEdges
	local now = CurTime()
	return function( area, fromArea, ladder, elevator, length )
		if not IsValid( fromArea ) then return 0 end
		if IsValid( ladder ) or not loco:IsAreaTraversable( area ) then return -1 end
		local id = area:GetID()
		if ( blocked[ id ] or 0 ) > now then return -1 end
		if ( blockedEdges[ fromArea:GetID() .. ">" .. id ] or 0 ) > now then return -1 end
		if area:HasAttributes( NAV_MESH_CROUCH ) or area:IsBlocked() then return -1 end
		local key = fromArea:GetID() .. ":" .. id
		local e = edgeCache[ key ]
		if not e or e[ 2 ] < now then
			local from, to = fromArea:GetCenter(), area:GetClosestPointOnArea( fromArea:GetCenter() )
			e = { propBetween( from, to, from.z ) or propBetween( to, area:GetCenter(), from.z ), now + 3 }
			edgeCache[ key ] = e
		end
		if e[ 1 ] then return -1 end
		local dist = length > 0 and length or area:GetCenter():Distance( fromArea:GetCenter() )
		local cost = dist * ( area:HasAttributes( NAV_MESH_AVOID ) and 4 or 1 )
		local dz = fromArea:ComputeAdjacentConnectionHeightChange( area )
		if dz >= loco:GetStepHeight() then
			if dz >= U.MANTLE_MAX then return -1 end
			cost = cost + dist * 4
		elseif dz <= -loco:GetStepHeight() then
			if dz < -U.DROP_MAX then return -1 end
			local dk = "d" .. key
			local d = edgeCache[ dk ]
			if not d or d[ 2 ] < now then
				d = { ledgeBlocked( fromArea, area ), now + 30 }
				edgeCache[ dk ] = d
			end
			if d[ 1 ] then return -1 end
			cost = cost + dist * 3
		end
		return cost + fromArea:GetCostSoFar()
	end
end

local MARGIN = 16
local RADIUS = 15
local LEFT_OF = { [ 0 ] = Vector( 1, 0, 0 ), [ 1 ] = Vector( 0, 1, 0 ), [ 2 ] = Vector( -1, 0, 0 ), [ 3 ] = Vector( 0, -1, 0 ) }

local function portalEnds( seg, prev )
	local how = seg.how
	if not how or how > 3 then return end
	local c, hw = seg.m_portalCenter, seg.m_portalHalfWidth
	local lo, hi, fixed
	if c and hw and hw > 0 then
		if how == 0 or how == 2 then lo, hi, fixed = c.x - hw, c.x + hw, c.y else lo, hi, fixed = c.y - hw, c.y + hw, c.x end
	else
		if not IsValid( prev.area ) or not IsValid( seg.area ) then return end
		local a0, a2 = prev.area:GetCorner( 0 ), prev.area:GetCorner( 2 )
		local b0, b2 = seg.area:GetCorner( 0 ), seg.area:GetCorner( 2 )
		if how == 0 or how == 2 then lo, hi, fixed = math.max( a0.x, b0.x ), math.min( a2.x, b2.x ), seg.pos.y
		else lo, hi, fixed = math.max( a0.y, b0.y ), math.min( a2.y, b2.y ), seg.pos.x end
	end
	if hi - lo < 1 then return end
	local m = math.min( MARGIN, ( hi - lo ) / 2 )
	lo, hi = lo + m, hi - m
	local z = seg.pos.z
	if how == 0 or how == 2 then return Vector( lo, fixed, z ), Vector( hi, fixed, z ) end
	return Vector( fixed, lo, z ), Vector( fixed, hi, z )
end

local function cross( a, b, c ) return ( b.x - a.x ) * ( c.y - a.y ) - ( b.y - a.y ) * ( c.x - a.x ) end
local function same( a, b ) return math.abs( a.x - b.x ) < 0.01 and math.abs( a.y - b.y ) < 0.01 end

local function funnel( portals )
	local out = {}
	local apex, left, right = portals[ 1 ].l, portals[ 1 ].l, portals[ 1 ].r
	local ai, li, ri = 1, 1, 1
	local i, guard = 2, 0
	while i <= #portals and guard < 4000 do
		guard = guard + 1
		local pl, pr = portals[ i ].l, portals[ i ].r
		local restart = false
		if cross( apex, right, pr ) >= 0 then
			if same( apex, right ) or cross( apex, left, pr ) <= 0 then
				right, ri = pr, i
			else
				out[ #out + 1 ] = { pos = portals[ li ].l, area = portals[ li ].area }
				apex, ai = left, li
				left, right, li, ri = apex, apex, ai, ai
				i, restart = ai + 1, true
			end
		end
		if not restart and cross( apex, left, pl ) <= 0 then
			if same( apex, left ) or cross( apex, right, pl ) >= 0 then
				left, li = pl, i
			else
				out[ #out + 1 ] = { pos = portals[ ri ].r, area = portals[ ri ].area }
				apex, ai = right, ri
				left, right, li, ri = apex, apex, ai, ai
				i, restart = ai + 1, true
			end
		end
		if not restart then i = i + 1 end
	end
	return out
end
U.funnel = funnel

function ENT:ComputeRoute( goal, tolerance )
	if not navmesh.IsLoaded() then return nil end
	self.MyBlocked = self.MyBlocked or {}
	self.MyBlockedEdges = self.MyBlockedEdges or {}
	local area = navmesh.GetNearestNavArea( goal, false, 250, false, true )
	if IsValid( area ) then
		local p = area:GetClosestPointOnArea( goal )
		if p then goal = p end
	end
	local path = Path( "Follow" )
	path:SetGoalTolerance( 8 )
	path:SetMinLookAheadDistance( 10 )
	local complete = path:Compute( self, goal, self:PathCost() )
	if not complete and ( next( self.MyBlocked ) or next( self.MyBlockedEdges ) ) then
		self.MyBlocked, self.MyBlockedEdges = {}, {}
		complete = path:Compute( self, goal, self:PathCost() )
	end
	if not path:IsValid() then return nil end
	local segs = path:GetAllSegments()
	if not segs or #segs == 0 then return nil end
	local partial = false
	for k = 2, #segs do
		local a, b = segs[ k - 1 ].area, segs[ k ].area
		if IsValid( a ) and IsValid( b ) and a ~= b and not a:IsConnected( b ) and not b:IsConnected( a ) then
			local cut = {}
			for j = 1, k - 1 do cut[ j ] = segs[ j ] end
			cut[ k ] = { pos = segs[ k - 1 ].pos, area = a, type = 0, how = segs[ k - 1 ].how }
			segs = cut
			break
		end
	end
	local last = segs[ #segs ]
	local endArea = IsValid( last.area ) and last.area or ( #segs > 1 and segs[ #segs - 1 ].area )
	if IsValid( endArea ) then
		local reach = endArea:GetClosestPointOnArea( goal )
		if reach and reach:Distance( goal ) > 48 then
			if reach:Distance2D( self:GetPos() ) < 32 then return nil end
			segs[ #segs ] = { pos = reach, area = endArea, type = 0, how = last.how }
			goal = reach
			partial = true
		end
	elseif complete == false then
		return nil
	end
	local me = self:GetPos()
	local a1 = segs[ 1 ].area
	if IsValid( a1 ) and math.abs( ( a1:GetZ( me ) or me.z ) - me.z ) > 64 then return nil end
	local route = { points = {}, i = 1, start = me, goal = goal, tolerance = tolerance or 20, partial = partial }
	local portals = { { l = me, r = me } }
	local function flush( endPos, endArea )
		portals[ #portals + 1 ] = { l = endPos, r = endPos, area = endArea }
		for _, c in ipairs( funnel( portals ) ) do
			route.points[ #route.points + 1 ] = { pos = c.pos, type = 0, area = c.area }
		end
	end
	for k = 2, #segs do
		local s, prev = segs[ k ], segs[ k - 1 ]
		local t = s.type or 0
		if k == #segs then
			flush( s.pos, s.area )
			route.points[ #route.points + 1 ] = { pos = s.pos, type = 0, area = s.area }
		elseif t ~= 0 then
			flush( s.pos, s.area )
			route.points[ #route.points + 1 ] = { pos = s.pos, type = t, area = s.area }
			portals = { { l = s.pos, r = s.pos } }
		elseif IsValid( s.area ) and IsValid( prev.area ) and s.area ~= prev.area then
			local a, b = portalEnds( s, prev )
			if a then
				local lv = LEFT_OF[ s.how ]
				if lv and ( b - a ):Dot( lv ) < 0 then a, b = b, a end
				portals[ #portals + 1 ] = { l = b, r = a, area = s.area }
			end
		end
	end
	if #route.points == 0 then route.points[ 1 ] = { pos = goal, type = 0, area = area } end
	local first = route.points[ 1 ]
	if first.type == 0 and me:Distance2D( first.pos ) > 24 and not self:DirectWalk( me, first.pos ) then
		local here = navmesh.GetNavArea( me, 64 ) or navmesh.GetNearestNavArea( me, false, 200, false, true )
		if IsValid( here ) then
			local c = here:GetClosestPointOnArea( me )
			local center = here:GetCenter()
			local inward = flat( center - c )
			if inward:LengthSqr() > 1 then c = c + inward:GetNormalized() * math.min( 20, inward:Length() ) end
			if c:Distance2D( me ) > 6 and self:DirectWalk( me, c ) then table.insert( route.points, 1, { pos = c, type = 0, area = here } ) end
		end
	end
	return route
end

function ENT:RouteTarget( route )
	local pts = route.points
	local pos = self:GetPos()
	while route.i <= #pts do
		local wp = pts[ route.i ]
		local d = pos:Distance2D( wp.pos )
		local dz = wp.pos.z - pos.z
		local done
		if route.i == #pts then
			done = d < route.tolerance and math.abs( dz ) < 48
		elseif wp.type == 0 then
			done = d < 22 and math.abs( dz ) < 48
			if not done then
				local prev = route.i > 1 and pts[ route.i - 1 ].pos or route.start
				local seg = flat( wp.pos - prev )
				done = seg:LengthSqr() > 1 and flat( pos - wp.pos ):Dot( seg ) > 0 and math.abs( dz ) < 40
			end
		else
			done = ( d < 24 and math.abs( dz ) < 14 ) or ( wp.type == 1 and dz > 24 and d < 140 ) or ( wp.type >= 2 and dz < 8 and d < 60 )
		end
		if not done then break end
		route.i = route.i + 1
	end
	if route.i > #pts then return nil end
	local wp = pts[ route.i ]
	if wp.type ~= 0 and pos:Distance2D( wp.pos ) < 130 then return wp.pos, wp end
	return wp.pos
end

function ENT:TraverseSpecial( route, wp, dir )
	if CurTime() < ( route.nextSpecial or 0 ) then return false end
	route.nextSpecial = CurTime() + 0.15
	local travel = flat( wp.pos - self:GetPos() )
	local d = travel:LengthSqr() > 1 and travel:GetNormalized() or dir
	if wp.type == 3 and travel:Length() < 60 then
		local land = route.points[ route.i + 1 ]
		if land then
			self.loco:JumpAcrossGap( land.pos, flat( land.pos - wp.pos ):GetNormalized() )
			route.i = route.i + 1
			return true
		end
	end
	return false
end

function ENT:BlockRouteAhead( route, wholeArea )
	local wp = route.points[ route.i ]
	if not wp or not IsValid( wp.area ) then return end
	local here = navmesh.GetNearestNavArea( self:GetPos(), false, 60, false, true )
	if wholeArea or not IsValid( here ) or here == wp.area then
		self.MyBlocked[ wp.area:GetID() ] = CurTime() + 15
	else
		self.MyBlockedEdges[ here:GetID() .. ">" .. wp.area:GetID() ] = CurTime() + 15
	end
end

function ENT:OpenDoor( dir )
	if CurTime() < ( self.NextDoor or 0 ) then return false end
	local pos = self:GetPos() + Vector( 0, 0, 40 )
	local tr = util.TraceHull( { start = pos, endpos = pos + dir * 56, mins = Vector( -6, -6, -6 ), maxs = Vector( 6, 6, 6 ), filter = self } )
	local door = tr.Entity
	if not IsValid( door ) or not DOORS[ door:GetClass() ] then return false end
	self.NextDoor = CurTime() + 2
	if door:GetClass() == "prop_door_rotating" then
		door:Fire( "OpenAwayFrom", "!activator", 0, self, self )
	else
		door:Fire( "Open", "", 0, self, self )
	end
	self.loco:SetVelocity( vector_origin )
	self:Wait( 0.6, nil, true )
	return true
end

function ENT:MakeRoom( other, dir )
	if self.Dead or self.AtCorner or self.Rambo or self.Parachuting or CurTime() < ( self.MakeRoomUntil or 0 ) then return end
	local side = flat( self:GetPos() - other:GetPos() ):Dot( Vector( -dir.y, dir.x, 0 ) ) >= 0 and 1 or -1
	self.MakeRoomDir = Vector( -dir.y, dir.x, 0 ) * side
	self.MakeRoomUntil = CurTime() + 1.5
end

local function neighbours( self )
	local out = {}
	for s in pairs( COD1.Soldiers ) do
		if s ~= self and IsValid( s ) and not s.Dead and not s.Parachuting and not s.Riding and not s.Downed then out[ #out + 1 ] = s end
	end
	for _, p in ipairs( player.GetAll() ) do
		if p:Alive() and p:GetMoveType() ~= MOVETYPE_NOCLIP then out[ #out + 1 ] = p end
	end
	return out
end

function ENT:Outranks( other )
	local mine, theirs = IsValid( self.Enemy ) and 1 or 0, IsValid( other.Enemy ) and 1 or 0
	if mine ~= theirs then return mine > theirs end
	return self:EntIndex() < other:EntIndex()
end

function ENT:Avoid( dir, speed )
	local me = self:GetPos()
	local right = Vector( dir.y, -dir.x, 0 )
	local push = Vector( 0, 0, 0 )
	local myV = dir * speed
	local cap, yield
	local reach = 2 * RADIUS + 6
	for _, o in ipairs( neighbours( self ) ) do
		local op = o:GetPos()
		local r = Vector( op.x - me.x, op.y - me.y, 0 )
		local dist2 = r:LengthSqr()
		if dist2 < 140 * 140 and math.abs( op.z - me.z ) < 56 then
			local dist = math.sqrt( dist2 )
			local ov = o.IsCOD1Soldier and flat( o.loco:GetVelocity() ) or flat( o:GetVelocity() )
			if dist < 2 * RADIUS then
				local away = dist > 0.5 and r / dist or right
				push = push - away * ( ( 2 * RADIUS - dist ) / ( 2 * RADIUS ) ) * 1.6
			end
			local rv = myV - ov
			local a = rv:LengthSqr()
			if a > 100 then
				local t = r:Dot( rv ) / a
				if t > 0 and t < 1.2 then
					local c = r - rv * t
					local cd = c:Length()
					if cd < reach then
						local ospeed = ov:Length()
						local headOn = ospeed > 30 and ov:Dot( dir ) < -0.5 * ospeed
						local still = ospeed < 30
						local side
						if headOn then
							side = right
						elseif still then
							side = r:Dot( right ) > 0 and -right or right
							if not self:OpenToward( side, 36 ) and self:OpenToward( -side, 36 ) then side = -side end
						else
							side = c:Dot( right ) > 0 and -right or right
						end
						push = push + side * ( ( 1 - t / 1.2 ) * ( reach - cd ) / reach * 1.8 )
						if not headOn and not still and r:Dot( dir ) > 0 and math.abs( r:Dot( right ) ) < RADIUS * 1.4 and dist < 70 then
							cap = math.min( cap or speed, math.max( ov:Dot( dir ), 0 ) + 15 )
						end
						if headOn and dist < 90 and o.IsCOD1Soldier and o.COD1Team == self.COD1Team and not self:Outranks( o )
							and ( not self:OpenToward( right, 30 ) or not self:OpenToward( -right, 30 ) ) then
							yield = o
						end
						if still and dist < 56 and r:Dot( dir ) > dist * 0.6 and o.IsCOD1Soldier and o.COD1Team == self.COD1Team and not o.Moving then
							o:MakeRoom( self, dir )
						end
					end
				end
			end
		end
	end
	local now = CurTime()
	if yield and now > ( self.NoYieldUntil or 0 ) then
		self.YieldSince = self.YieldSince or now
		if now - self.YieldSince < 1.6 then
			return self:OpenToward( right, 22 ) and right or dir, self:OpenToward( right, 22 ) and 70 or 0
		end
		self.NoYieldUntil = now + 3
	end
	if not yield then self.YieldSince = nil end
	local steer = dir + push
	if steer:LengthSqr() < 0.01 then steer = dir end
	steer:Normalize()
	if steer:Dot( dir ) < 0.1 then steer = ( steer + dir * 1.5 ):GetNormalized() end
	return steer, cap
end

function ENT:GoalTaken( goal )
	for s in pairs( COD1.Soldiers ) do
		if s ~= self and IsValid( s ) and not s.Dead and not s.Moving and s.COD1Team == self.COD1Team and not s.Downed
			and not s.Surrendered and not s.Treatment and not s.CarriedBy and not s.Carrying then
			local p = s:GetPos()
			if math.abs( p.z - goal.z ) < 40 and ( p.x - goal.x ) ^ 2 + ( p.y - goal.y ) ^ 2 < 22 * 22 then return true end
		end
	end
	return false
end

function ENT:MoveTo( pos, speed, maxTime, stop, crouchrun, noShoot )
	if self.AtCorner then self:LeaveCorner() end
	if self.Prone then self:LeaveProne() end
	if ( self.Crouched or self.Hiding ) and not self.HasFlag then self.Crouched = false self.Hiding = false end
	if self.HasFlag then self.Crouched = false end
	self.MoveBlocked = false
	local running = speed > 100
	local animSpeed = self:StartMoveAnim( running, crouchrun )
	local moveSpeed = ( self:IsHurt() or crouchrun or self.HasFlag or self.NoGun ) and animSpeed or speed
	if moveSpeed <= 0 then moveSpeed = speed end
	local started = CurTime()
	local deadline = started + ( maxTime or 5 )
	self.Moving = true
	self.MoveGoal = pos
	local smooth
	local gunning, nextGunCheck, nextShot, gunSeq = false, 0, CurTime() + math.Rand( 0.1, 0.3 ), nil

	local route = self:ComputeRoute( pos )
	if not route and navmesh.IsLoaded() and self.GetLastKnownArea and not IsValid( self:GetLastKnownArea() ) then
		for i = 1, 6 do coroutine.yield() end
		route = self:ComputeRoute( pos )
	end
	if not route and navmesh.IsLoaded() and not self:Reachable( pos ) then
		self.Moving = false
		self.MoveGoal = nil
		self.MoveBlocked = true
		self.loco:SetDesiredSpeed( 0 )
		coroutine.yield()
		return false
	end
	local reached = false
	local stuck = 0
	local plan, planUntil, nextPlan = nil, 0, 0
	local function progress()
		if route then
			local wp = route.points[ route.i ]
			return route.i * 10000 - ( wp and self:GetPos():Distance( wp.pos ) or 0 )
		end
		return -self:GetPos():Distance2D( pos )
	end
	local lastProgress, nextCheck = progress(), CurTime() + 0.6
	local function replan()
		route = self:ComputeRoute( pos )
		if not route and navmesh.IsLoaded() and not self:Reachable( pos ) then
			self.MoveBlocked = true
			return false
		end
		return true
	end

	while CurTime() < deadline and not self.Dead and not self.PendingPain and not self.GrenadeThreat do
		if stop and stop() then break end
		local mypos = self:GetPos()
		local target, special
		if route then
			target, special = self:RouteTarget( route )
			if not target then
				reached = not route.partial
				if route.partial then self.MoveBlocked = true end
				break
			end
		else
			if mypos:Distance2D( pos ) < 24 and math.abs( mypos.z - pos.z ) < 40 then
				reached = true
				break
			end
			target = self:Steer( pos )
		end
		if mypos:Distance2D( pos ) < 48 and math.abs( mypos.z - pos.z ) < 40 and self:GoalTaken( pos ) then
			reached = true
			break
		end
		local dir = flat( target - mypos )
		if dir:LengthSqr() > 1 then dir:Normalize() else dir = self:GetForward() end

		local went = false
		if special and special.type == 3 then
			went = self:TraverseSpecial( route, special, dir )
		else
			if not plan and CurTime() >= nextPlan then
				nextPlan = CurTime() + 0.1
				local w, j = special, route and route.i
				if not w and route then
					local nx = route.points[ route.i + 1 ]
					if nx and ( nx.type == 1 or nx.type == 2 ) and mypos:Distance2D( nx.pos ) < 130 then w, j = nx, route.i + 1 end
				end
				local kind = w and w.type or nil
				if not route and not kind then
					local rise = pos.z - mypos.z
					kind = rise > 18 and 2 or rise < -18 and 1 or nil
				end
				local aim = w and flat( w.pos - mypos ) or route and dir or flat( pos - mypos )
				if aim:LengthSqr() < 1 then aim = dir end
				local after = w and route.points[ j + 1 ] or route and route.points[ math.min( route.i + 2, #route.points ) ]
				plan = self:PlanTraverse( aim, kind and 110 or 44, kind, after and after.pos or pos )
				if plan then
					plan.go = plan.face:Distance2D( plan.start ) + 6
					planUntil = CurTime() + 3
				end
			end
			if plan then
				local rel = flat( mypos - plan.face )
				local ahead = -rel:Dot( plan.axis )
				if CurTime() > planUntil or ahead < -6 then
					plan, nextPlan = nil, CurTime() + 0.5
				elseif ahead <= plan.go and math.abs( rel:Dot( plan.side ) ) <= plan.slack then
					local p = plan
					plan = nil
					went = self:Traverse( p ) and p
				else
					target = plan.start
					dir = flat( target - mypos )
					if dir:LengthSqr() > 1 then dir:Normalize() else dir = plan.axis end
				end
			end
		end
		if went then
			if self.Dead then break end
			self:StartMoveAnim( running, crouchrun )
			gunSeq, gunning = nil, false
			self.Moving = true
			if istable( went ) then
				self.loco:SetDesiredSpeed( moveSpeed )
				for _ = 1, 2 do
					self.loco:Approach( self:GetPos() + went.axis * 60, 1 )
					coroutine.yield()
				end
				if self.Dead then break end
			end
			if not replan() then break end
			lastProgress, nextCheck = progress(), CurTime() + 0.6
		else
			local wantSpeed = moveSpeed
			local steer, cap = self:Avoid( dir, wantSpeed )
			if cap then wantSpeed = math.min( wantSpeed, cap ) end
			if smooth then
				smooth = smooth * 0.65 + steer * 0.35
				if smooth:LengthSqr() > 0.01 then steer = smooth:GetNormalized() end
			end
			smooth = steer

			local enemy = self.Enemy
			if not noShoot and running and CurTime() >= nextGunCheck then
				nextGunCheck = CurTime() + 0.25
				local was = gunning
				gunning = self:CanGunWhileMoving( enemy )
				if was and not gunning then
					gunSeq = nil
					self:StartMoveAnim( running, crouchrun )
				end
			end
			if gunning and IsValid( enemy ) then
				self.loco:FaceTowards( enemy:GetPos() )
				self:UpdateAim( enemy )
				local want = GUN_RUN[ crouchrun and "crouch" or "stand" ][ self:MoveSide( steer ) ]
				if want ~= gunSeq then
					gunSeq = want
					local seq = self:LookupSequence( want )
					self:StartActivity( ACT_RUN )
					self:ResetSequence( seq )
					wantSpeed = math.min( wantSpeed, self:GetSequenceGroundSpeed( seq ) )
				end
				if CurTime() >= nextShot then
					local w = self.Weapon
					if self.Mag > 0 and self:LineOfFireClear( self:AimPoint( enemy ) ) then
						self:FireShot( enemy )
						if w.bolt then
							timer.Simple( 0.3, function() if IsValid( self ) and not self.Dead then self:EmitSound( "COD1.Rechamber." .. self.WeaponKey ) end end )
							timer.Simple( 0.55, function() if IsValid( self ) and not self.Dead then self:EjectShell() end end )
						end
					end
					nextShot = CurTime() + ( w.bolt and math.Rand( 1.4, 2.2 ) or w.auto and w.delay * math.Rand( 1.3, 2.2 ) or w.delay * math.Rand( 1.4, 2.4 ) )
					if w.auto and math.random() < 0.12 then nextShot = nextShot + math.Rand( 0.3, 0.7 ) end
				end
			else
				self.loco:FaceTowards( mypos + steer * 100 )
				local facing = self:GetForward():Dot( steer )
				if facing < 0.25 then wantSpeed = wantSpeed * 0.3 elseif facing < 0.7 then wantSpeed = wantSpeed * 0.65 end
			end
			self.loco:SetDesiredSpeed( wantSpeed )
			if wantSpeed > 0 then self.loco:Approach( mypos + steer * 60, 1 ) end

			local engineStuck = self.loco:IsStuck()
			if CurTime() >= nextCheck or engineStuck then
				nextCheck = CurTime() + 0.6
				local p = progress()
				local crowded = cap and cap < 40
				if engineStuck or ( p - lastProgress < 8 and not crowded ) then
					self.loco:ClearStuck()
					if self:OpenDoor( dir ) then
						stuck = math.max( stuck - 1, 0 )
					elseif self:SmashGlass( dir ) then
						stuck = math.max( stuck - 1, 0 )
					elseif stuck >= 1 and self:ShoveProp( dir ) then
						self:StartMoveAnim( running, crouchrun )
						gunSeq, gunning = nil, false
						self.Moving = true
						stuck = math.max( stuck - 1, 0 )
					elseif self:TryMantle( route and dir or flat( pos - mypos ), false, route and target or pos ) then
						self:StartMoveAnim( running, crouchrun )
						gunSeq, gunning = nil, false
						self.Moving = true
						stuck = 0
						if route and not replan() then break end
					else
						stuck = stuck + 1
						if stuck >= 5 then
							self.MoveBlocked = true
							self:NoNavHint()
							break
						end
						if stuck == 1 then
							self:Sidestep( dir )
						elseif stuck == 2 and route then
							self:BlockRouteAhead( route, false )
							if not replan() then break end
						elseif stuck == 3 then
							self:Sidestep( -dir )
							if route and not replan() then break end
						elseif self:Unwedge( dir ) then
							if route and not replan() then break end
						end
					end
					p = progress()
				elseif p - lastProgress >= 8 then
					stuck = math.max( stuck - 1, 0 )
				end
				lastProgress = p
			end
		end
		coroutine.yield()
	end
	self.Moving = false
	self.MoveGoal = nil
	self.YieldSince = nil
	self.StoppedAt = CurTime()
	self.loco:SetDesiredSpeed( 0 )
	if CurTime() == started and not self.Dead then coroutine.yield() end
	return reached
end

function ENT:WalkTo( pos, t, speed )
	self:StartMoveAnim( false )
	self.Moving = true
	self.loco:SetDesiredSpeed( speed or self.WalkSpeed )
	local e = CurTime() + ( t or 0.7 )
	while self:GetPos():Distance2D( pos ) > 8 and CurTime() < e and not self.Dead do
		self.loco:Approach( pos, 1 )
		self.loco:FaceTowards( pos )
		coroutine.yield()
	end
	self.Moving = false
	self.StoppedAt = CurTime()
	self.loco:SetDesiredSpeed( 0 )
end


--walking around, climbing through windows, vaulting fences. took ages
