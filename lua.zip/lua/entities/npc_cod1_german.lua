AddCSLuaFile()

ENT.Base = "npc_cod1_airborne"
ENT.PrintName = "German Soldier"
ENT.Author = "adodser"
ENT.Spawnable = false
ENT.COD1Team = "axis"
ENT.DefaultVariant = "german_wehrmacht"

if CLIENT then
	language.Add( "npc_cod1_german", "German Soldier" )
end

--the germans, they just use the same brain as everyone else
