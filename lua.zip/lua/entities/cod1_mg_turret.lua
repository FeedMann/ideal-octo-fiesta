AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Mounted Machine Gun"
ENT.Author = "adodser"
ENT.Spawnable = false
ENT.IsCOD1Turret = true
ENT.RenderGroup = RENDERGROUP_OPAQUE

COD1.TurretTypes = {
	mg42 = { base = "models/cod1/turrets/sandbags.mdl", gun = "mg42_gun", bipod = true, grid = "mg42s", team = "axis",
		variants = { "german_wehrmacht", "german_wehrmacht", "german_fallschirm", "german_waffenss" }, rate = 0.05, damage = 1.0, playerDamage = 30,
		arc = 45, pitch = 18, pitchAnim = -1, shake = 0.7,
		loop = "COD1.MG42Loop", cooldown = "cod1/weapons/mg42/mg42_cooldown.wav", spread = { 0.07, 0.022 } },
	mg42_stand = { gun = "mg42_gun", bipod = true, grid = "mg42s", team = "axis",
		variants = { "german_wehrmacht", "german_wehrmacht", "german_fallschirm", "german_waffenss" }, rate = 0.05, damage = 1.0, playerDamage = 30,
		arc = 45, pitch = 18, pitchAnim = -1, shake = 0.7,
		loop = "COD1.MG42Loop", cooldown = "cod1/weapons/mg42/mg42_cooldown.wav", spread = { 0.07, 0.022 } },
	mg42_prone = { gun = "mg42_gun", bipod = true, grid = "mg42p", team = "axis", prone = true, duck = true,
		variants = { "german_fallschirm", "german_wehrmacht", "german_winter" }, rate = 0.05, damage = 1.0, playerDamage = 30,
		arc = 45, pitch = 18, pitchAnim = -1, shake = 0.7,
		loop = "COD1.MG42Loop", cooldown = "cod1/weapons/mg42/mg42_cooldown.wav", spread = { 0.07, 0.022 } },
	b30cal = { base = "models/cod1/turrets/sandbags.mdl", baseScale = 0.88, gun = "b30cal_gun", grid = "b30s", team = "allies", duck = true,
		variants = { "airborne_summer" }, rate = 0.1, damage = 1.3, playerDamage = 30, arc = 30, pitch = 10, pitchAnim = 0.46, shake = 0.9,
		loop = "COD1.30calLoop", cooldown = "cod1/weapons/mg42/mg42_cooldown.wav", spread = { 0.06, 0.02 } },
}
COD1.TurretTypes.b30cal_free = table.Copy( COD1.TurretTypes.b30cal )
COD1.TurretTypes.b30cal_free.base = nil
COD1.TurretTypes.b30cal_free.baseScale = nil
COD1.TurretTypes.b30cal_prone = table.Copy( COD1.TurretTypes.b30cal_free )
COD1.TurretTypes.b30cal_prone.grid = "mg42p"
COD1.TurretTypes.b30cal_prone.prone = true
COD1.TurretTypes.b30cal_prone.pitchAnim = -1

sound.Add( { name = "COD1.MG42Loop", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 92, 104 }, sound = "cod1/weapons/mg42/mg42_fire_loop.wav" } )
sound.Add( { name = "COD1.30calLoop", channel = CHAN_WEAPON, level = 140, volume = 1, pitch = { 76, 82 }, sound = "cod1/weapons/mg42/mg42_fire_loop.wav" } )

local YAW_SPEED, PITCH_SPEED = 70, 45
local PLAYER_SPEED = 240

function ENT:SetupDataTables()
	self:NetworkVar( "String", 0, "Kind" )
	self:NetworkVar( "Float", 0, "GunYaw" )
	self:NetworkVar( "Float", 1, "GunPitch" )
end

function ENT:KeyValue( k, v )
	if k == "cod1_mg" then self.KindKey = v
	elseif k == "nocrew" then self.NoCrew = v == "1"
	elseif k == "anyteam" then self.AnyTeam = v == "1"
	elseif k == "arc" then self.ArcOverride = tonumber( v )
	elseif k == "cod1_free" then self.FreePlace = v == "1"
	elseif k == "codorigin" then self.FromCoD = v == "1" end
end

function ENT:Def()
	return COD1.TurretTypes[ self:GetKind() ] or COD1.TurretTypes.mg42
end

function ENT:GunAngles()
	if SERVER then return self.Pitch or 0, self.Yaw or 0 end
	return self:GetGunPitch(), self:GetGunYaw()
end

function ENT:Feet()
	local g = COD1.MGGunner and COD1.MGGunner[ self:Def().grid ]
	return g and g.feet or Vector( -12, 6, -47.5 )
end

function ENT:Grip()
	local part = COD1.TurretParts and COD1.TurretParts[ self:Def().gun ]
	return part and part.grip or Vector( -30.6, -0.1, -0.75 )
end

function ENT:PivotLocal()
	return Vector( 0, 0, -( self:Grip().z + self:Feet().z ) )
end

function ENT:PivotWorld()
	return self:LocalToWorld( self:PivotLocal() )
end

function ENT:GripWorld()
	local pitch, yaw = self:GunAngles()
	local o = Vector( self:Grip() )
	o:Rotate( Angle( -pitch, yaw, 0 ) )
	return self:LocalToWorld( self:PivotLocal() + o )
end

function ENT:FeetWorld()
	local _, yaw = self:GunAngles()
	local f = self:Feet()
	local off = Vector( f.x, f.y, 0 )
	off:Rotate( Angle( 0, self:GetAngles().y + yaw, 0 ) )
	local g = self:GripWorld()
	return Vector( g.x + off.x, g.y + off.y, self:GetPos().z )
end

local KEY_FIRE, KEY_USE, KEY_JUMP = IN_BULLRUSH, IN_GRENADE1, IN_GRENADE2

hook.Add( "StartCommand", "COD1Turret", function( ply, cmd )
	local t = ply:GetNWEntity( "COD1UsingMG" )
	if not IsValid( t ) or not t.IsCOD1Turret then return end
	if CLIENT then
		if cmd:KeyDown( IN_ATTACK ) then cmd:AddKey( KEY_FIRE ) end
		if cmd:KeyDown( IN_USE ) then cmd:AddKey( KEY_USE ) end
		if cmd:KeyDown( IN_JUMP ) then cmd:AddKey( KEY_JUMP ) end
	else
		ply.COD1MGFire = cmd:KeyDown( KEY_FIRE ) or cmd:KeyDown( IN_ATTACK )
		if cmd:KeyDown( KEY_JUMP ) or cmd:KeyDown( IN_JUMP ) then ply.COD1MGLeave = true end
		if not ( cmd:KeyDown( KEY_USE ) or cmd:KeyDown( IN_USE ) ) then
			ply.COD1MGUseHeld = false
		elseif not ply.COD1MGUseHeld then
			ply.COD1MGLeave = true
		end
	end
	cmd:RemoveKey( IN_ATTACK )
	cmd:RemoveKey( IN_ATTACK2 )
	cmd:RemoveKey( IN_JUMP )
	cmd:RemoveKey( IN_RELOAD )
	cmd:RemoveKey( IN_USE )
	if t:Def().duck then cmd:AddKey( IN_DUCK ) end
	cmd:ClearMovement()
end )

hook.Add( "SetupMove", "COD1Turret", function( ply, mv )
	local t = ply:GetNWEntity( "COD1UsingMG" )
	if not IsValid( t ) or not t.IsCOD1Turret then return end
	mv:SetOrigin( t:FeetWorld() )
	mv:SetVelocity( vector_origin )
end )

if CLIENT then
	language.Add( "cod1_mg_turret", "Mounted Machine Gun" )
	return
end

function ENT:SpawnFunction( ply, tr, class )
	if not tr.Hit then return end
	local ent = ents.Create( class )
	ent:SetPos( tr.HitPos )
	ent:SetAngles( Angle( 0, ply:EyeAngles().y, 0 ) )
	ent:Spawn()
	ent:Activate()
	return ent
end

function ENT:PlaceFree()
	self.FreePlace = nil
	local pos = self:GetPos()
	local tr = util.TraceLine( { start = pos + Vector( 0, 0, 8 ), endpos = pos - Vector( 0, 0, 48 ), filter = self, mask = MASK_SOLID } )
	if tr.Hit then pos = tr.HitPos end
	self:SetPos( pos )
	local rise = 0
	for d = 20, 100, 10 do
		local back = pos - self:GetForward() * d
		if util.TraceLine( { start = pos + Vector( 0, 0, 8 ), endpos = back + Vector( 0, 0, 8 ), filter = self, mask = MASK_PLAYERSOLID } ).Hit then break end
		local floor = util.TraceLine( { start = back + Vector( 0, 0, 8 ), endpos = back - Vector( 0, 0, 160 ), filter = self, mask = MASK_PLAYERSOLID } )
		if floor.Hit and not floor.StartSolid then rise = math.max( rise, pos.z - floor.HitPos.z ) end
	end
	if rise < 24 then
		if self.KindKey == "mg42_stand" then self.KindKey = "mg42_prone" end
		if self.KindKey == "b30cal_free" then self.KindKey = "b30cal_prone" end
	end
	self.FromCoD = true
end

function ENT:Initialize()
	if self.FreePlace then self:PlaceFree() end
	if self.KindKey and COD1.TurretTypes[ self.KindKey ] then self:SetKind( self.KindKey ) end
	if self:GetKind() == "" then self:SetKind( "mg42" ) end
	local d = self:Def()
	local parts = COD1.TurretParts or {}
	if self.FromCoD then
		local piv = ( parts[ d.gun ] or {} ).pivot or Vector( -3, 0, 12.9 )
		self:SetPos( self:GetPos() - LocalToWorld( self:PivotLocal() - piv, angle_zero, vector_origin, self:GetAngles() ) )
		self.FromCoD = nil
	end
	if d.base then
		self:SetModel( d.base )
		self:PhysicsInit( SOLID_VPHYSICS )
		if d.baseScale then self:ScaleBase( d.baseScale ) end
		self:SetMoveType( MOVETYPE_NONE )
		local phys = self:GetPhysicsObject()
		if IsValid( phys ) then phys:EnableMotion( false ) end
	else
		self:SetModel( "models/cod1/turrets/mg42_bipod.mdl" )
		self:SetMoveType( MOVETYPE_NONE )
		self:SetSolid( SOLID_BBOX )
		local z = self:PivotLocal().z
		self:SetCollisionBounds( Vector( -8, -12, 0 ), Vector( 14, 12, z + 6 ) )
		self:SetCollisionGroup( COLLISION_GROUP_WEAPON )
		self:SetNoDraw( true )
	end
	self:SetUseType( SIMPLE_USE )
	local gunPart = parts[ d.gun ] or {}
	if d.bipod then
		local bp = ents.Create( "prop_dynamic" )
		bp:SetModel( "models/cod1/turrets/mg42_bipod.mdl" )
		bp:SetPos( self:LocalToWorld( self:PivotLocal() - ( gunPart.pivot or Vector( -3, 0, 12.9 ) ) ) )
		bp:SetAngles( self:GetAngles() )
		bp:Spawn()
		bp:SetSolid( SOLID_NONE )
		bp:SetParent( self )
		self.Bipod = bp
	end
	local gun = ents.Create( "prop_dynamic" )
	gun:SetModel( "models/cod1/turrets/" .. d.gun .. ".mdl" )
	gun:SetPos( self:PivotWorld() )
	gun:SetAngles( self:GetAngles() )
	gun:Spawn()
	gun:SetSolid( SOLID_NONE )
	gun:SetParent( self )
	self.Gun = gun
	self.MuzzleAtt = gun:LookupAttachment( "muzzle" )
	self.Yaw, self.Pitch = 0, 0
	self.PauseUntil, self.NextShot, self.NextShake = 0, 0, 0
	self.NextCrew = CurTime() + 0.2
	if self.NoCrew then self.Crewed = true end
	self:CallOnRemove( "COD1Turret", function( t )
		t:StopLoop()
		t:ReleaseUser()
		if IsValid( t.Gunner ) and t.Gunner.Manning == t then t.Gunner:Dismount() end
	end )
end

function ENT:ScaleBase( k )
	local phys = self:GetPhysicsObject()
	local convexes = IsValid( phys ) and phys:GetMeshConvexes()
	self:SetModelScale( k )
	if not convexes then return end
	local mesh = {}
	for i, convex in ipairs( convexes ) do
		local pts = {}
		for j, v in ipairs( convex ) do pts[ j ] = v.pos * k end
		mesh[ i ] = pts
	end
	self:PhysicsInitMultiConvex( mesh )
	self:SetSolid( SOLID_VPHYSICS )
	self:EnableCustomCollisions( true )
end

function ENT:MountSpot()
	local o, f = self:Grip(), self:Feet()
	local p = self:LocalToWorld( Vector( o.x + f.x, o.y + f.y, 0 ) )
	return p, self:GetAngles().y
end

function ENT:Busy( s )
	return s.Dead or s.Manning or s.Riding or s.Parachuting or s.Treatment or s.Role or s.HasFlag
		or s.VariantData.medic or s.VariantData.fixedName or IsValid( s.WantTurret ) or CurTime() < ( s.LeftTurret or 0 )
		or IsValid( s.Enemy ) and not self:InArc( s.Enemy:GetPos() )
end

function ENT:FindCrew()
	local d = self:Def()
	local best, bestDist
	for s in pairs( COD1.Soldiers or {} ) do
		if IsValid( s ) and ( self.AnyTeam or s.COD1Team == d.team ) and not self:Busy( s ) then
			local dist = s:GetPos():DistToSqr( self:GetPos() )
			if dist < 700 * 700 and ( not bestDist or dist < bestDist ) then best, bestDist = s, dist end
		end
	end
	return best
end

function ENT:Manned()
	return IsValid( self.User ) or IsValid( self.Gunner ) and not self.Gunner.Dead and self.Gunner.Manning == self
end

function ENT:Think()
	local now = CurTime()
	if IsValid( self.User ) then
		self:OperatePlayer( self.User )
		self:NextThink( now )
		return true
	end
	if now >= self.NextCrew then
		self.NextCrew = now + 2
		if not IsValid( self.Gunner ) or self.Gunner.Dead or self.Gunner.Manning ~= self then
			self.Gunner = nil
			if not self.Crewed then
				self.Crewed = true
				self:SpawnCrew()
			elseif not IsValid( self.Claimed ) or self.Claimed.Dead or self.Claimed.WantTurret ~= self then
				local s = self:FindCrew()
				if s then
					s.WantTurret = self
					self.Claimed = s
				end
			end
		end
	end
	if not IsValid( self.Gunner ) then self:Idle() end
	self:NextThink( now )
	return true
end

function ENT:SpawnCrew()
	local d = self:Def()
	local pos, yaw = self:MountSpot()
	local s = COD1.SpawnSoldier( d.variants[ math.random( #d.variants ) ], pos, Angle( 0, yaw, 0 ), nil, self.Spawner )
	if IsValid( s ) then s:MountTurret( self ) end
end

function ENT:Use( ply )
	if not IsValid( ply ) or not ply:IsPlayer() or not ply:Alive() or self:Manned() then return end
	if IsValid( ply:GetNWEntity( "COD1UsingMG" ) ) then return end
	self.User = ply
	ply.COD1MGUseHeld = true
	ply.COD1MGLeave = nil
	ply.COD1MGFire = nil
	ply:SetNWEntity( "COD1UsingMG", self )
	ply:DrawViewModel( false )
	ply:DrawWorldModel( false )
	if IsValid( self.Claimed ) then self.Claimed.WantTurret = nil end
	self.Claimed = nil
	self.TargetSince = 0
end

function ENT:ReleaseUser()
	local ply = self.User
	self.User = nil
	if not IsValid( ply ) then return end
	self:StopBurst()
	ply:SetNWEntity( "COD1UsingMG", NULL )
	ply:DrawViewModel( true )
	ply:DrawWorldModel( true )
	ply.COD1MGFire, ply.COD1MGLeave = nil, nil
	self.NextCrew = CurTime() + 3
end

function ENT:OperatePlayer( ply )
	if not ply:Alive() or ply.COD1MGLeave or ply:GetNWEntity( "COD1UsingMG" ) ~= self then
		self:ReleaseUser()
		return
	end
	local d = self:Def()
	local now = CurTime()
	local ea = ply:EyeAngles()
	local arc, lim = self:Arc(), d.pitch or 15
	local step = PLAYER_SPEED * self:StepTime()
	self.Yaw = math.Approach( self.Yaw, math.Clamp( math.NormalizeAngle( ea.y - self:GetAngles().y ), -arc, arc ), step )
	self.Pitch = math.Approach( self.Pitch, math.Clamp( -ea.p, -lim, lim ), step )
	if ply.COD1MGFire then
		self:StartBurst()
	else
		self:StopBurst()
	end
	if self.Firing and now >= self.NextShot then
		self.NextShot = now + d.rate
		self:Shoot( ply, nil, nil, true )
		ply:ViewPunch( Angle( math.Rand( -0.7, -0.2 ), math.Rand( -0.35, 0.35 ), 0 ) )
	end
	self:PoseGun()
end

function ENT:StepTime()
	local now = CurTime()
	local dt = math.Clamp( now - ( self.StepAt or now ), 0, 0.25 )
	self.StepAt = now
	return dt
end

function ENT:Idle()
	local dt = self:StepTime()
	self.Yaw = math.Approach( self.Yaw, 0, YAW_SPEED * 0.3 * dt )
	self.Pitch = math.Approach( self.Pitch, 0, PITCH_SPEED * 0.3 * dt )
	self:StopBurst()
	self:PoseGun()
end

function ENT:PoseGun()
	if not IsValid( self.Gun ) then return end
	self:SetGunYaw( self.Yaw )
	self:SetGunPitch( self.Pitch )
	local ang = Angle( -self.Pitch, self.Yaw, 0 )
	local pos = self:PivotLocal()
	if self.Firing then
		local j = self:Def().shake or 0.7
		pos = pos - ang:Forward() * math.Rand( 0, 0.9 ) + Vector( 0, 0, math.Rand( -0.25, 0.25 ) )
		ang = ang + Angle( math.Rand( -j, j ), math.Rand( -j, j ) * 0.6, math.Rand( -j, j ) * 0.4 )
		if CurTime() >= self.NextShake then
			self.NextShake = CurTime() + 0.15
			util.ScreenShake( self:PivotWorld(), 2.5, 40, 0.2, 280 )
		end
	end
	self.Gun:SetLocalPos( pos )
	self.Gun:SetLocalAngles( ang )
end

function ENT:Arc()
	return self.ArcOverride or self:Def().arc or 45
end

function ENT:Bearing( target )
	local lp = WorldToLocal( target, angle_zero, self:PivotWorld(), Angle( 0, self:GetAngles().y, 0 ) )
	return math.deg( math.atan2( lp.y, lp.x ) ), math.deg( math.atan2( lp.z, math.sqrt( lp.x * lp.x + lp.y * lp.y ) ) ), lp
end

function ENT:InArc( target )
	local yaw, _, lp = self:Bearing( target )
	return lp.x > 0 and math.abs( yaw ) <= self:Arc() + 5
end

function ENT:Aim( target )
	local arc = self:Arc()
	local yaw, pitch = self:Bearing( target )
	if not self:InArc( target ) then return false end
	yaw = math.Clamp( yaw, -arc, arc )
	local lim = self:Def().pitch or 15
	pitch = math.Clamp( pitch, -lim, lim )
	local dt = self:StepTime()
	self.Yaw = math.Approach( self.Yaw, yaw, YAW_SPEED * dt )
	self.Pitch = math.Approach( self.Pitch, pitch, PITCH_SPEED * dt )
	return math.abs( self.Yaw - yaw ) < 4 and math.abs( self.Pitch - pitch ) < 4
end

function ENT:Operate( gunner, enemy )
	local d = self:Def()
	local now = CurTime()
	local target, seen
	if IsValid( enemy ) then
		seen = gunner:CanSee( enemy )
		if seen then
			target = gunner:AimPoint( enemy )
		elseif gunner.LastKnownPos and now - gunner.LastSeen < 3 then
			target = gunner.LastKnownPos + Vector( 0, 0, 36 )
		end
		if enemy ~= self.Target then
			self.Target = enemy
			self.TargetSince = now
			self.PauseUntil = math.max( self.PauseUntil, now + math.Rand( 0.2, 0.5 ) )
		end
	end
	local onTarget = target and self:Aim( target )
	if not target then self:Idle() end
	if onTarget then
		if not self.Firing and now >= self.PauseUntil then
			self:StartBurst()
			self.BurstEnd = now + 0.5 + math.Rand( 0, 1.5 )
		elseif self.Firing and now >= self.BurstEnd then
			self:StopBurst()
			self.PauseUntil = now + 0.1 + math.Rand( 0, 0.5 )
		end
	elseif self.Firing then
		self:StopBurst()
		self.PauseUntil = now + 0.3
	end
	if self.Firing and now >= self.NextShot then
		self.NextShot = now + d.rate
		self:Shoot( gunner, target, enemy, seen )
	end
	self:PoseGun()
	return self.Yaw, self.Pitch, self.Firing
end

function ENT:StartBurst()
	if self.Firing then return end
	self.Firing = true
	self.NextShot = math.max( self.NextShot, CurTime() )
	if not self.Loop and IsValid( self.Gun ) then self.Loop = CreateSound( self.Gun, self:Def().loop ) end
	if self.Loop then
		self.Loop:Stop()
		self.Loop:Play()
	end
end

function ENT:StopLoop()
	if self.Loop then self.Loop:Stop() end
end

function ENT:StopBurst()
	if not self.Firing then return end
	self.Firing = false
	self:StopLoop()
	if self:Def().cooldown then self:EmitSound( self:Def().cooldown, 90, math.random( 95, 105 ), 0.8 ) end
end

function ENT:Shoot( gunner, target, enemy, seen )
	local d = self:Def()
	local gun = self.Gun
	if not IsValid( gun ) then return end
	local att = gun:GetAttachment( self.MuzzleAtt )
	local fwd = gun:GetAngles():Forward()
	local src = att and att.Pos or ( self:PivotWorld() + fwd * 12 )
	local k = math.Clamp( ( CurTime() - ( self.TargetSince or 0 ) ) / 1.5, 0, 1 )
	local spread = Lerp( k, d.spread[ 1 ], d.spread[ 2 ] ) * ( seen and 1 or 1.8 )
	local dir = fwd
	if target then dir = LerpVector( 0.85, fwd, ( target - src ):GetNormalized() ):GetNormalized() end
	local damage = gunner:IsPlayer() and d.playerDamage * GetConVar( "cod1_swep_damage" ):GetFloat() or GetConVar( "cod1_npc_damage" ):GetFloat() * d.damage
	gun:FireBullets( {
		Attacker = gunner, Inflictor = self,
		Damage = damage, Force = 4 * d.damage, Num = 1,
		Src = src, Dir = dir, Spread = Vector( spread, spread, 0 ),
		Tracer = 2, TracerName = "Tracer", IgnoreEntity = gunner,
		Callback = function( _, tr ) return COD1.BulletImpactFX( tr, "mg42" ) end,
	} )
	local ed = EffectData()
	ed:SetEntity( gun )
	ed:SetAttachment( self.MuzzleAtt )
	ed:SetFlags( 1 )
	ed:SetDamageType( COD1.WeaponFXIndex[ string.find( self.KindKey or "", "30cal", 1, true ) and "b30cal" or "mg42" ] or 0 )
	util.Effect( "cod1npc_muzzleflash", ed, true, true )
	if gunner.MarkBattle then gunner:MarkBattle() end
end

hook.Add( "PlayerSpawnedNPC", "COD1Turret", function( ply, ent )
	if IsValid( ent ) and ent.IsCOD1Turret then ent.Spawner = ply end
end )

--turret base, shared between all the mgs
