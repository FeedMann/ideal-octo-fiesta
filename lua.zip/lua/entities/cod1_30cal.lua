AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "cod1_mg_turret"
ENT.PrintName = ".30 cal Nest (Empty)"
ENT.Author = "adodser"
ENT.Category = "Call of Duty 1"
ENT.Spawnable = true
ENT.KindKey = "b30cal"
ENT.NoCrew = true
ENT.AnyTeam = true

--the 30 cal, sit down and hold E
