AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "cod1_mg_turret"
ENT.PrintName = "MG42 Free Placement (Empty)"
ENT.Author = "adodser"
ENT.Category = "Call of Duty 1"
ENT.Spawnable = true
ENT.KindKey = "mg42_stand"
ENT.FreePlace = true
ENT.NoCrew = true
ENT.AnyTeam = true

--free placement mg42, put it on a window sill
