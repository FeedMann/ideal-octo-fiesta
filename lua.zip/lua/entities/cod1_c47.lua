AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "C-47"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true
ENT.Model = "models/cod1/props/c47.mdl"
ENT.Speed = 800
ENT.JumpGap = 0.4

function ENT:Initialize()
	self:SetModel( self.Model )
	self:SetSolid( SOLID_NONE )
	self:SetMoveType( MOVETYPE_NONE )
	if CLIENT then
		self:SetRenderBounds( Vector( -600, -700, -100 ), Vector( 500, 700, 300 ) )
		return
	end
	local seq = self:LookupSequence( "idle" )
	if seq >= 0 then self:ResetSequence( seq ) end
end

if CLIENT then return end

function ENT:Fly( info )
	self.Info = info
	self.Start = self:GetPos()
	self.StartTime = CurTime()
	self.Jumped = 0
	self.Drone = CreateSound( self, "cod1/vehicles/c47_drone_loop.wav" )
	self.Drone:SetSoundLevel( 140 )
	self.Drone:PlayEx( 1, 100 )
	local stick = info.count * self.JumpGap * self.Speed
	self.JumpFrom = -stick / 2 - 150
end

function ENT:SpawnJumper( pos )
	local info = self.Info
	local v = COD1.Variants[ info.variant ] or COD1.Variants.airborne_summer
	local ground = util.TraceLine( { start = pos, endpos = pos - Vector( 0, 0, 16000 ), mask = MASK_SOLID_BRUSHONLY } )
	if not ground.Hit or ground.HitSky then return end
	local npc = ents.Create( v.team == "axis" and "npc_cod1_german" or "npc_cod1_airborne" )
	if not IsValid( npc ) then return end
	npc:SetKeyValue( "cod1_variant", COD1.Variants[ info.variant ] and info.variant or "airborne_summer" )
	npc:SetKeyValue( "cod1_weapon", "random" )
	npc:SetKeyValue( "cod1_parachute", "1" )
	npc:SetKeyValue( "cod1_para_from", tostring( pos.z - 60 ) )
	npc:SetPos( ground.HitPos )
	npc:SetAngles( Angle( 0, info.dir:Angle().y + math.random( -30, 30 ), 0 ) )
	npc:Spawn()
	npc:Activate()
	local ply = info.owner
	if IsValid( ply ) then
		undo.Create( "COD1 Paratrooper" ) undo.AddEntity( npc ) undo.SetPlayer( ply ) undo.Finish()
		ply:AddCleanup( "npcs", npc )
	end
end

function ENT:Think()
	local info = self.Info
	if not info then return end
	local travelled = ( CurTime() - self.StartTime ) * self.Speed
	local pos = self.Start + info.dir * travelled
	self:SetPos( pos )

	local along = ( pos - info.target ):Dot( info.dir )
	if not self.FlybyPlayed and along > -1600 then
		self.FlybyPlayed = true
		self:EmitSound( "COD1.C47Flyby" )
	end
	if self.Jumped < info.count and along >= self.JumpFrom + self.Jumped * self.JumpGap * self.Speed then
		self.Jumped = self.Jumped + 1
		local side = info.dir:Angle():Right() * math.Rand( -40, 40 )
		self:SpawnJumper( pos - info.dir * 160 + side - Vector( 0, 0, 40 ) )
	end
	if travelled >= info.distance then
		if info.done then info.done() end
		self:Remove()
		return
	end
	self:NextThink( CurTime() )
	return true
end

function ENT:OnRemove()
	if self.Drone then self.Drone:Stop() end
end

--the plane, it flies over and drops the boys
