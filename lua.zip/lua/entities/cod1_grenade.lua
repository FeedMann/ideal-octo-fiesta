AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "MK2 Frag Grenade"
ENT.Spawnable = false

ENT.Model = "models/cod1/props/mk2_grenade.mdl"
ENT.Radius = 256
ENT.MaxDamage = 175
ENT.Fuse = 3.5

if CLIENT then
	language.Add( "cod1_grenade", "MK2 Frag Grenade" )
	return
end

function ENT:Initialize()
	if self.Smoke then self.Model = "models/cod1/props/smoke_grenade.mdl" end
	self:SetModel( self.Model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	local phys = self:GetPhysicsObject()
	if IsValid( phys ) then
		phys:SetMass( 2 )
		phys:SetDamping( 0.3, 2 )
		phys:Wake()
	end
	self.DetonateAt = self.DetonateAt or ( CurTime() + self.Fuse )
end

function ENT:SetFuse( seconds )
	self.DetonateAt = CurTime() + seconds
end

function ENT:TimeLeft()
	return ( self.DetonateAt or CurTime() ) - CurTime()
end

function ENT:Think()
	if self.HeldBy then
		local holder = self.HeldBy
		if IsValid( holder ) and not holder.Dead then
			local att = holder:GetAttachment( holder:LookupAttachment( "anim_attachment_RH" ) )
			if att then self:SetPos( att.Pos ) self:SetAngles( att.Ang ) end
		else
			self:Release( vector_origin )
		end
	end
	if CurTime() >= self.DetonateAt and not self.Exploded then
		self:Detonate()
		return
	end
	self:NextThink( CurTime() )
	return true
end

function ENT:PickUp( holder )
	self.HeldBy = holder
	local phys = self:GetPhysicsObject()
	if IsValid( phys ) then phys:EnableMotion( false ) end
	self:SetNotSolid( true )
end

function ENT:Release( velocity )
	self.HeldBy = nil
	self:SetNotSolid( false )
	local phys = self:GetPhysicsObject()
	if IsValid( phys ) then
		phys:EnableMotion( true )
		phys:Wake()
		phys:SetVelocity( velocity )
		phys:AddAngleVelocity( VectorRand() * 600 )
	end
end

function ENT:PhysicsCollide( data )
	if data.Speed > 80 and data.DeltaTime > 0.15 then
		self:EmitSound( "COD1.GrenadeBounce" )
	end
end

function ENT:PopSmoke()
	local pos = self:GetPos() + Vector( 0, 0, 4 )
	sound.Play( "COD1.SmokePop", pos, 90 )
	COD1.FX( "smoke/smoke_grenade", pos, Vector( 0, 0, 1 ) )
	local now = CurTime()
	table.insert( COD1.SmokeClouds, { pos = pos + Vector( 0, 0, 60 ), r = 200, t0 = now + 1.5, t1 = now + 28 } )
	self:SetMoveType( MOVETYPE_NONE )
	SafeRemoveEntityDelayed( self, 30 )
end

function ENT:Detonate()
	if self.Exploded then return end
	self.Exploded = true
	if self.Smoke then return self:PopSmoke() end
	local pos = self:GetPos() + Vector( 0, 0, 4 )
	local attacker = IsValid( self.Thrower ) and self.Thrower or self

	local tr = util.TraceLine( { start = pos, endpos = pos - Vector( 0, 0, 48 ), mask = MASK_SOLID_BRUSHONLY } )
	local wet = bit.band( util.PointContents( pos ), CONTENTS_WATER ) ~= 0
	COD1.FX( COD1.GrenadeFX( tr, wet ), tr.Hit and tr.HitPos or pos, tr.Hit and tr.HitNormal or Vector( 0, 0, 1 ) )
	sound.Play( "COD1.GrenadeExplode", pos, 140, math.random( 95, 105 ) )
	util.ScreenShake( pos, 8, 120, 0.8, self.Radius * 2.5 )
	util.Decal( "Scorch", pos, pos - Vector( 0, 0, 32 ), self )
	util.BlastDamage( self, attacker, pos, self.Radius, self.MaxDamage )
	self:Remove()
end

--GRENADE!
