AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "German Truck"
ENT.Author = "adodser"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true
ENT.RenderGroup = RENDERGROUP_OPAQUE

ENT.Model = "models/cod1/vehicles/opel_truck.mdl"
ENT.IsCOD1Truck = true

local RIDERS = {
	{ tag = "tag_driver", seq = "truck_drive", out = "truck_driver_out", delay = 0.6 },
	{ tag = "tag_guy01", seq = "truck_guy1", out = "truck_guy1", delay = 1.0 },
	{ tag = "tag_guy03", seq = "truck_guy3", out = "truck_guy3", delay = 1.35 },
	{ tag = "tag_guy02", seq = "truck_guy2", out = "truck_guy2", delay = 1.7 },
	{ tag = "tag_guy04", seq = "truck_guy4", out = "truck_guy4", delay = 2.2 },
}
local MAX_RUN, MIN_RUN, SPEED = 1500, 260, 300
local HULL_MINS, HULL_MAXS = Vector( -48, -48, 24 ), Vector( 48, 48, 90 )

if CLIENT then
	language.Add( "cod1_german_truck", "German Truck" )
	local WHEELS = { "tag_wheel_back_left", "tag_wheel_back_right", "tag_wheel_front_left", "tag_wheel_front_right" }
	function ENT:Initialize()
		self:SetRenderBounds( Vector( -160, -60, 0 ), Vector( 140, 60, 110 ) )
		self:SetCustomCollisionCheck( true )
		self.Spin = 0
		self.Wheels = {}
		for _, name in ipairs( WHEELS ) do
			local b = self:LookupBone( name )
			if b then table.insert( self.Wheels, b ) end
		end
	end
	function ENT:Think()
		local pos = self:GetPos()
		if self.LastPos then
			local moved = ( pos - self.LastPos ):Dot( self:GetForward() )
			if moved ~= 0 then
				local d = COD1.VehicleTags and COD1.VehicleTags.opel_truck
				self.Spin = ( self.Spin + moved / ( d and d.wheel or 18 ) * 57.3 ) % 360
				for _, b in ipairs( self.Wheels ) do self:ManipulateBoneAngles( b, Angle( self.Spin, 0, 0 ) ) end
			end
		end
		self.LastPos = pos
		self:SetNextClientThink( CurTime() )
		return true
	end
	return
end

function ENT:KeyValue( k, v )
	if k == "cod1_variant" then self.Variant = v end
end

function ENT:Initialize()
	self:SetModel( self.Model )
	local d = COD1.VehicleTags and COD1.VehicleTags.opel_truck
	self:SetSolid( SOLID_NONE )
	self:SetCustomCollisionCheck( true )
	self:SetMoveType( MOVETYPE_NONE )
	if d then self:SetCollisionBounds( d.mins, d.maxs ) end
	self:PlayAnim( "idle", 0 )
	self.Riders = {}
	self.State = "wait"
	self:CallOnRemove( "COD1TruckRiders", function( truck )
		for _, npc in ipairs( truck.Riders ) do
			if IsValid( npc ) and npc.Riding then npc:Remove() end
		end
		if truck.Engine then truck.Engine:Stop() end
	end )
end

function ENT:PlayAnim( name, rate )
	local seq = self:LookupSequence( name )
	if seq < 0 then return 0 end
	self:ResetSequence( seq )
	self:SetCycle( 0 )
	self:SetPlaybackRate( rate or 1 )
	return self:SequenceDuration( seq )
end

local function ground( p, filter )
	local tr = util.TraceLine( { start = p + Vector( 0, 0, 80 ), endpos = p - Vector( 0, 0, 140 ), filter = filter, mask = MASK_PLAYERSOLID_BRUSHONLY } )
	if tr.Hit and not tr.StartSolid and tr.HitNormal.z > 0.75 then return tr.HitPos end
end

function ENT:ClearRun( stop, yaw )
	local dir = Angle( 0, yaw, 0 ):Forward()
	local samples = { stop }
	local run = 0
	for dist = 120, MAX_RUN + 200, 120 do
		local p = ground( stop - dir * dist, self )
		local prev = samples[ #samples ]
		if not p or math.abs( p.z - prev.z ) > 40 then break end
		local tr = util.TraceHull( { start = prev, endpos = p, mins = HULL_MINS, maxs = HULL_MAXS, filter = self, mask = MASK_PLAYERSOLID } )
		if tr.Hit then break end
		table.insert( samples, p )
		run = dist
	end
	run = math.min( run - 200, MAX_RUN )
	return run, samples
end

function ENT:PlanRoute()
	local stop = self:GetPos()
	local face = self:GetAngles().y
	local best
	for _, yaw in ipairs( { face + 90, face - 90, face + 180 } ) do
		local run, samples = self:ClearRun( stop, yaw )
		if not best or run > best.run then best = { run = run, yaw = yaw, samples = samples } end
		if run >= MAX_RUN then break end
	end
	self.Yaw = best.yaw
	self.Stop = stop
	self.Samples = best.samples
	self.Run = best.run >= MIN_RUN and best.run or 0
	self.DriveTime = self.Run > 0 and math.Clamp( self.Run / SPEED * 1.6, 1.5, 8 ) or 0
end

function ENT:GroundZ( dist )
	local s = self.Samples
	local i = math.Clamp( math.floor( dist / 120 ), 0, #s - 2 )
	local a, b = s[ i + 1 ], s[ math.min( i + 2, #s ) ]
	return Lerp( math.Clamp( dist / 120 - i, 0, 1 ), a.z, b.z )
end

function ENT:PosAt( t )
	if self.Run <= 0 then return self.Stop end
	local k = math.Clamp( t / self.DriveTime, 0, 1 )
	local left = self.Run * ( 1 - ( 1 - ( 1 - k ) ^ 2 ) )
	local dir = Angle( 0, self.Yaw, 0 ):Forward()
	local p = self.Stop - dir * left
	return Vector( p.x, p.y, self:GroundZ( left ) )
end

function ENT:AreaClear()
	local d = COD1.VehicleTags and COD1.VehicleTags.opel_truck
	if not d then return true end
	local lo, hi = d.mins - Vector( 18, 18, 0 ), d.maxs + Vector( 18, 18, 0 )
	for _, e in ipairs( ents.FindInSphere( self:GetPos(), 260 ) ) do
		if e ~= self and ( e:IsPlayer() or e:IsNPC() or e.IsCOD1Soldier ) then
			local p = self:WorldToLocal( e:GetPos() )
			if p.x > lo.x and p.x < hi.x and p.y > lo.y and p.y < hi.y and p.z < hi.z then return false end
		end
	end
	return true
end

function ENT:SpawnRiders()
	local ply = self.Spawner
	for i, r in ipairs( RIDERS ) do
		local npc = ents.Create( "npc_cod1_german" )
		if IsValid( npc ) then
			npc:SetKeyValue( "cod1_variant", "german_wehrmacht" )
			npc:SetKeyValue( "cod1_weapon", "random" )
			if i == 1 and math.random() < 0.5 then npc:SetKeyValue( "cod1_officer", "1" ) end
			npc.TruckRide = { truck = self, tag = r.tag, seq = r.seq, out = r.out }
			npc:SetPos( self:GetPos() + Vector( 0, 0, 60 ) )
			npc:SetAngles( self:GetAngles() )
			npc:Spawn()
			npc:Activate()
			if npc.Riding then
				local pos, yaw = npc:TruckSeat()
				npc:SetPos( pos )
				npc:SetAngles( Angle( 0, yaw, 0 ) )
			end
			if IsValid( ply ) then ply:AddCleanup( "npcs", npc ) end
			table.insert( self.Riders, npc )
		end
	end
	if IsValid( ply ) and #self.Riders > 0 then
		undo.Create( "CoD1 Truck Squad" )
		for _, npc in ipairs( self.Riders ) do undo.AddEntity( npc ) end
		undo.SetPlayer( ply )
		undo.Finish()
	end
end

function ENT:Think()
	local now = CurTime()
	if self.State == "wait" then
		self.State = "drive"
		self.T0 = now
		self:PlanRoute()
		self:SetAngles( Angle( 0, self.Yaw, 0 ) )
		self:SetPos( self:PosAt( 0 ) )
		self:SpawnRiders()
		if self.Run > 0 then
			self.Engine = CreateSound( self, "cod1/vehicles/truck_move.wav" )
			self.Engine:SetSoundLevel( 85 )
			self.Engine:Play()
		end
	elseif self.State == "drive" then
		local t = now - self.T0
		self:SetPos( self:PosAt( t ) )
		for _, npc in ipairs( self.Riders ) do
			if IsValid( npc ) and npc.Riding and npc.TruckRide and not npc.TruckRide.exit then npc:HoldTruckSeat() end
		end
		if not self.Braked and self.Run > 0 and t >= self.DriveTime - 1.2 then
			self.Braked = true
			self:EmitSound( "cod1/vehicles/skids/skid02.wav", 75, 100, 0.6 )
		end
		if t >= self.DriveTime then
			self.State = "unload"
			self.StopAt = now
			if self.Engine then self.Engine:FadeOut( 0.6 ) end
			self:EmitSound( "cod1/vehicles/truck_idle.wav", 75, 100, 0.8 )
			self.DoorAt = now + 0.6
			for i, r in ipairs( RIDERS ) do
				local npc = self.Riders[ i ]
				if IsValid( npc ) and npc.TruckRide then npc.TruckRide.go = now + r.delay end
			end
		end
	elseif self.State == "unload" then
		if self.DoorAt and now >= self.DoorAt then
			self.DoorAt = nil
			self:PlayAnim( "climbout", 1 )
			self:EmitSound( "cod1/vehicles/truck_door_open.wav", 75 )
		end
		local aboard = false
		for _, npc in ipairs( self.Riders ) do
			if IsValid( npc ) and npc.Riding then aboard = true break end
		end
		if not aboard and now - self.StopAt > 3 then
			self.State = "parked"
			self.Riders = {}
		end
	elseif self.State == "parked" and not self.Solid and now >= ( self.NextSolidTry or 0 ) then
		self.NextSolidTry = now + 0.5
		if self:AreaClear() then
			self.Solid = true
			self:SetSolid( SOLID_OBB )
			self:CollisionRulesChanged()
		end
	end
	self:NextThink( now )
	return true
end

hook.Add( "PlayerSpawnedNPC", "COD1Truck", function( ply, ent )
	if IsValid( ent ) and ent:GetClass() == "cod1_german_truck" then ent.Spawner = ply end
end )

--german truck, drives in and drops off a squad. dont stand in front of it
