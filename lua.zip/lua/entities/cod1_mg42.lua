AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "cod1_mg_turret"
ENT.PrintName = "MG42 Nest (Empty)"
ENT.Author = "adodser"
ENT.Category = "Call of Duty 1"
ENT.Spawnable = true
ENT.KindKey = "mg42"
ENT.NoCrew = true
ENT.AnyTeam = true

--mg42 nest, the guys man it themselves
