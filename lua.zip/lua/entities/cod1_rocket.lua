AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Rocket"
ENT.Spawnable = false
ENT.Model = "models/cod1/props/rocket.mdl"
ENT.Radius = 256
ENT.MaxDamage = 200

local TRAIL = { pschreck = "smoke/smoke_trail_panzerschreck", bazooka = "smoke/smoke_trail_bazooka", pfaust = "smoke/smoke_trail_panzerfaust" }

if CLIENT then
	language.Add( "cod1_rocket", "Rocket" )
	function ENT:Initialize()
		self.NextTrail = 0
	end
	function ENT:Think()
		local now = CurTime()
		if now >= self.NextTrail and COD1.PlayEFX then
			self.NextTrail = now + 0.03
			COD1.PlayEFX( TRAIL[ self:GetNWString( "COD1Kind" ) ] or "smoke/smoke_trail_panzerfaust", self:GetPos(), self:GetRight() )
		end
		if GetConVar( "cod1_efx_lights" ):GetBool() then
			local d = DynamicLight( self:EntIndex() )
			if d then
				d.pos = self:GetPos()
				d.r, d.g, d.b = 255, 150, 70
				d.brightness = 2
				d.size = 180
				d.decay = 1200
				d.dietime = now + 0.1
			end
		end
		self:SetNextClientThink( now )
		return true
	end
	return
end

function ENT:Initialize()
	self:SetModel( self.Model )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_NONE )
	self:SetNWString( "COD1Kind", self.Kind or "" )
	self.Vel = self:GetForward() * ( self.Speed or 2800 )
	self.Born = CurTime()
	self.Last = CurTime()
	self:Face()
end

function ENT:Face()
	local ang = self.Vel:Angle()
	ang:RotateAroundAxis( ang:Up(), -90 )
	self:SetAngles( ang )
end

function ENT:Think()
	local now = CurTime()
	local dt = math.min( now - self.Last, 0.1 )
	self.Last = now
	local from = self:GetPos()
	self.Vel = self.Vel - Vector( 0, 0, 160 * dt )
	local to = from + self.Vel * dt
	local tr = util.TraceLine( { start = from, endpos = to, filter = { self, self.Shooter }, mask = MASK_SHOT } )
	if tr.Hit then
		self:Explode( tr )
		return
	end
	self:SetPos( to )
	self:Face()
	if now - self.Born > 5 or bit.band( util.PointContents( to ), CONTENTS_WATER ) ~= 0 then
		self:Explode( { HitPos = to, HitNormal = -self.Vel:GetNormalized(), Hit = false } )
		return
	end
	self:NextThink( now )
	return true
end

function ENT:Explode( tr )
	if self.Done then return end
	self.Done = true
	local normal = tr.HitNormal or Vector( 0, 0, 1 )
	local pos = tr.HitPos + normal * 4
	local attacker = IsValid( self.Shooter ) and self.Shooter or self
	local hit = tr.Entity
	if IsValid( hit ) and hit.IsCOD1Tank and hit.RocketHit then hit:RocketHit( self.TankDamage or 600, attacker, tr.HitPos, self.Vel:GetNormalized() ) end
	if tr.HitSky then self:Remove() return end
	local wet = bit.band( util.PointContents( pos ), CONTENTS_WATER ) ~= 0
	COD1.FX( COD1.ExplosionFX( "rocket", tr, wet ), pos, normal )
	sound.Play( "COD1.RocketExplode", pos, 145, math.random( 95, 105 ) )
	util.ScreenShake( pos, 10, 140, 0.9, self.Radius * 3 )
	util.Decal( "Scorch", pos + normal * 8, pos - normal * 32 )
	util.BlastDamage( self, attacker, pos, self.Radius, self.MaxDamage )
	self:Remove()
end

--rocket goes nose first now, it used to fly sideways lmao
