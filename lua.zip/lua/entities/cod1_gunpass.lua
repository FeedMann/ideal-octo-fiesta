AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Supply Station"
ENT.Author = "adodser"
ENT.Spawnable = false
ENT.IsCOD1GunPass = true

ENT.Model = "models/cod1/props/sov_supply_crates.mdl"

if CLIENT then
	language.Add( "cod1_gunpass", "Supply Station" )
	return
end

local TAGS = {
	[ 0 ] = { 28.5, -70.3, 131, { 1, 3 } }, [ 1 ] = { 16.2, -98.2, 105, { 4, 5 } }, [ 3 ] = { 56.2, -82.8, 151, { 6, 7 } },
	[ 4 ] = { 15.4, -128.6, 104, { 8 } }, [ 5 ] = { 40.9, -115.2, 113.5, { 9 } }, [ 6 ] = { 70.8, -111.0, 139.5, { 10, 11 } },
	[ 7 ] = { 85.9, -86.3, 150, { 12 } }, [ 8 ] = { 24.8, -158.0, 105.5, { 13 } }, [ 9 ] = { 52.4, -143.5, 110.5, { 14 } },
	[ 10 ] = { 82.6, -138.4, 134.5, { 15, 16 } }, [ 11 ] = { 101.5, -115.8, 151, { 17 } }, [ 12 ] = { 116.4, -89.1, -172.5, { 18, 19 } },
	[ 13 ] = { 30.3, -187.2, 102.5, { 20 } }, [ 14 ] = { 58.1, -172.7, 108, { 21 } }, [ 15 ] = { 87.8, -168.5, 123, { 22 } },
	[ 16 ] = { 110.8, -149.8, 148, { 23 } }, [ 17 ] = { 128.4, -125.5, 155.5, { 24, 25 } }, [ 18 ] = { 144.2, -100.2, 157, { 26 } },
	[ 19 ] = { 135.5, -65.1, -171, { 27 } }, [ 20 ] = { 44.8, -214.3, 107.5, {} }, [ 21 ] = { 72.2, -199.8, 112, {} },
	[ 22 ] = { 102.6, -193.8, 116, {} }, [ 23 ] = { 125.4, -176.9, 123, {} }, [ 24 ] = { 142.1, -151.7, 150, {} },
	[ 25 ] = { 159.4, -126.4, 156, {} }, [ 26 ] = { 174.4, -99.7, 174, {} }, [ 27 ] = { 161.5, -73.9, -158.5, {} },
}
local ORDER = { 0, 1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27 }
local PARENT = {}
for n, t in pairs( TAGS ) do
	for _, f in ipairs( t[ 4 ] ) do PARENT[ f ] = n end
end
local GIVERS = { front = { -19.1, -31.7, 43.9, 0 }, back = { -58.2, 14.2, 43.8, -90 }, ammo = { -7.7, 48.4, 0, 0 } }
local ENTRIES = { 20, 21, 22, 13, 14 }
local CROWD = 8

function ENT:KeyValue( k, v )
	if k == "cod1_variant" then self.Variant = v end
end

function ENT:Initialize()
	self:SetModel( self.Model )
	local tr = util.TraceLine( { start = self:GetPos() + Vector( 0, 0, 40 ), endpos = self:GetPos() - Vector( 0, 0, 200 ), filter = self, mask = MASK_PLAYERSOLID } )
	if tr.Hit and not tr.StartSolid then self:SetPos( tr.HitPos ) end
	self:SetAngles( Angle( 0, self:GetAngles().y, 0 ) )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_NONE )
	local phys = self:GetPhysicsObject()
	if IsValid( phys ) then phys:EnableMotion( false ) end
	self.Item = "gun"
	self.GunReadyAt, self.AmmoReadyAt = 0, 0
	self.Pending = {}
	self.Givers = {}
	self.Recruits = {}
	self.Sent = 0
	self.Users = {}
	self.State = "setup"
	self:CallOnRemove( "COD1GunPass", function( st )
		for _, npc in pairs( st.Givers ) do
			if IsValid( npc ) then npc:Remove() end
		end
		for _, npc in ipairs( st.Recruits ) do
			if IsValid( npc ) and npc.GunPass and npc.GunPass.station == st then npc:Remove() end
		end
	end )
end

function ENT:Spot( row )
	return self:LocalToWorld( Vector( row[ 1 ], row[ 2 ], row[ 3 ] or 0 ) )
end

function ENT:GroundSpot( row )
	local p = self:Spot( row )
	return COD1.AI.groundAt( p ) or p
end

function ENT:Place()
	self.PlacedAt = { pos = self:GetPos(), yaw = self:GetAngles().y }
	self.TagSpots = {}
	for n, t in pairs( TAGS ) do
		local p = self:Spot( { t[ 1 ], t[ 2 ], 0 } )
		self.TagSpots[ n ] = { pos = COD1.AI.groundAt( p ) or p, yaw = self:GetAngles().y + t[ 3 ] }
	end
end

function ENT:TagPos( n ) return self.TagSpots[ n ].pos end
function ENT:TagYaw( n ) return self.TagSpots[ n ].yaw end

function ENT:GiverSpot( part )
	local g = GIVERS[ part ]
	local p = self:Spot( g )
	if part == "ammo" then p = COD1.AI.groundAt( p ) or p end
	return { pos = p, yaw = self:GetAngles().y + g[ 4 ] }
end

function ENT:Soldier( variant, pos, yaw, gp, officer )
	local npc = ents.Create( "npc_cod1_airborne" )
	if not IsValid( npc ) then return end
	npc:SetKeyValue( "cod1_variant", variant )
	npc:SetKeyValue( "cod1_weapon", "random" )
	if officer then npc:SetKeyValue( "cod1_officer", "1" ) end
	gp.station = self
	npc.GunPass = gp
	npc:SetPos( pos )
	npc:SetAngles( Angle( 0, yaw, 0 ) )
	npc:Spawn()
	npc:Activate()
	if IsValid( self.Spawner ) then self.Spawner:AddCleanup( "npcs", npc ) end
	return npc
end

function ENT:Variants()
	local winter = self.Variant == "russian_winter"
	return winter and "russian_winter" or "russian", winter and "russian_winter_conscript" or "russian_conscript"
end

function ENT:Setup()
	self:Place()
	local army = self:Variants()
	for part in pairs( GIVERS ) do
		local s = self:GiverSpot( part )
		self.Givers[ part ] = self:Soldier( army, s.pos + Vector( 0, 0, 2 ), s.yaw, { part = part }, true )
	end
	local budget = math.min( CROWD, GetConVar( "cod1_gunpass_recruits" ):GetInt() )
	for i = 1, budget do
		local n = ORDER[ i ]
		self:Recruit( self:TagPos( n ), n )
	end
end

function ENT:Recruit( pos, tag )
	local _, conscript = self:Variants()
	local yaw = tag and self:TagYaw( tag ) or self:GetAngles().y + 180
	local gp = { part = "queue", tag = tag, state = tag and "wait" or "join" }
	local npc = self:Soldier( conscript, pos + Vector( 0, 0, 2 ), yaw, gp )
	if not IsValid( npc ) then return end
	self.Sent = self.Sent + 1
	table.insert( self.Recruits, npc )
	if tag then
		self.Users[ tag ] = npc
	elseif not self:Join( npc ) then
		npc.GunPass = nil
	end
	return npc
end

local function ok( npc ) return IsValid( npc ) and not npc.Dead end

function ENT:Giver( part )
	local g = self.Givers[ part ]
	return ok( g ) and g.GunPass and g.GunPass.station == self and g or nil
end

function ENT:Serves( item )
	if item == "gun" then return self:Giver( "front" ) ~= nil and self:Giver( "back" ) ~= nil end
	return self:Giver( "ammo" ) ~= nil
end

function ENT:IsOpen()
	return self.State == "run" and ( self:Serves( "gun" ) or self:Serves( "ammo" ) )
end

function ENT:Member( npc, n )
	local gp = ok( npc ) and npc.GunPass
	return gp and gp.station == self and gp.part == "queue" and ( n == nil or gp.tag == n ) and gp or nil
end

function ENT:Settled( n )
	local gp = self:Member( self.Users[ n ], n )
	return gp and gp.state == "wait" and not gp.order and not gp.to and self.Users[ n ] or nil
end

function ENT:Join( npc )
	if not self:IsOpen() then return false end
	local best, bd
	for _, n in ipairs( ORDER ) do
		if not self.Users[ n ] then
			local p = PARENT[ n ]
			if p == nil or self.Users[ p ] then
				local d = self:TagPos( n ):DistToSqr( npc:GetPos() )
				if not bd or d < bd - 2500 then best, bd = n, d end
			end
		end
	end
	if not best then return false end
	self.Users[ best ] = npc
	npc.GunPass = { station = self, part = "queue", tag = best, state = "join" }
	npc.IdleUntil = nil
	return true
end

function ENT:Release( npc )
	for n, u in pairs( self.Users ) do
		if u == npc then self.Users[ n ] = nil end
	end
	for item, u in pairs( self.Pending ) do
		if u == npc then self.Pending[ item ] = nil end
	end
end

function ENT:StepDone( npc, from )
	if self.Users[ from ] == npc then self.Users[ from ] = nil end
end

function ENT:Hand( item )
	self.Pending[ item ] = nil
	for _, part in ipairs( item == "gun" and { "front", "back" } or { "ammo" } ) do
		local g = self:Giver( part )
		if g then g.GunPass.give, g.GunPass.busy = true, true end
	end
end

function ENT:CanHand( item )
	if not self:Serves( item ) or ok( self.Pending[ item ] ) then return false end
	if CurTime() < ( item == "gun" and self.GunReadyAt or self.AmmoReadyAt ) then return false end
	for _, part in ipairs( item == "gun" and { "front", "back" } or { "ammo" } ) do
		if self:Giver( part ).GunPass.busy then return false end
	end
	return true
end

function ENT:Feed()
	for n, u in pairs( self.Users ) do
		local gp = self:Member( u )
		if not gp or ( gp.tag ~= n and gp.to ~= n ) then self.Users[ n ] = nil end
	end
	local tags = table.Copy( ORDER )
	for i = #tags, 2, -1 do
		local j = math.random( i )
		tags[ i ], tags[ j ] = tags[ j ], tags[ i ]
	end
	for _, n in ipairs( tags ) do
		if not self.Users[ n ] then
			local feeders = table.Copy( TAGS[ n ][ 4 ] )
			if #feeders == 2 and math.random() < 0.5 then feeders[ 1 ], feeders[ 2 ] = feeders[ 2 ], feeders[ 1 ] end
			for _, f in ipairs( feeders ) do
				local u = self:Settled( f )
				if u then
					self.Users[ n ] = u
					u.GunPass.to = n
					u.GunPass.order = { kind = "step", to = n }
					break
				end
			end
		end
	end
	local head = self:Settled( 0 )
	if not head then return end
	local item = self.Item
	if not self:Serves( item ) then item = item == "gun" and "ammo" or "gun" end
	if not self:CanHand( item ) then return end
	self.Users[ 0 ] = nil
	self.Pending[ item ] = head
	head.GunPass.order = { kind = item }
	self.Item = item == "gun" and "ammo" or "gun"
	if item == "gun" then self.AmmoReadyAt = CurTime() + 2.5 else self.GunReadyAt = CurTime() + 0.5 end
end

function ENT:Reinforce()
	if CurTime() < ( self.NextRecruit or 0 ) then return end
	self.NextRecruit = CurTime() + 1.6
	if self.Sent >= GetConVar( "cod1_gunpass_recruits" ):GetInt() then return end
	local waiting = 0
	for _ in pairs( self.Users ) do waiting = waiting + 1 end
	if waiting >= 12 then return end
	for _, n in ipairs( ENTRIES ) do
		if not self.Users[ n ] then
			local base = self:TagPos( n )
			local back = Angle( 0, self:TagYaw( n ) + 180, 0 ):Forward()
			for _, dist in ipairs( { 260, 180, 100 } ) do
				local p = COD1.AI.groundAt( base + back * dist )
				if p and COD1.AI.hullClear( p ) and not COD1.AI.blocked( p + Vector( 0, 0, 40 ), base + Vector( 0, 0, 40 ) ) then
					self:Recruit( p )
					return
				end
			end
			if COD1.AI.hullClear( base ) then
				self:Recruit( base )
				return
			end
		end
	end
end

function ENT:Think()
	local now = CurTime()
	if self.State == "setup" then
		self.State = "run"
		self:Setup()
	elseif self.State == "run" then
		local at = self.PlacedAt
		if at.pos:DistToSqr( self:GetPos() ) > 1 or math.abs( math.AngleDifference( at.yaw, self:GetAngles().y ) ) > 0.5 then self:Place() end
		if self:IsOpen() then
			self:Feed()
			self:Reinforce()
		else
			self.State = "closed"
			for n, u in pairs( self.Users ) do
				if ok( u ) and u.GunPass and u.GunPass.station == self then u:LeaveGunPass() end
			end
			self.Users = {}
		end
	end
	self:NextThink( now + 0.1 )
	return true
end

hook.Add( "PlayerSpawnedNPC", "COD1GunPass", function( ply, ent )
	if IsValid( ent ) and ent:GetClass() == "cod1_gunpass" then ent.Spawner = ply end
end )

--one gets the rifle, the other gets the ammo. when the one with the rifle gets killed, the one who is following picks up the rifle and shoots
