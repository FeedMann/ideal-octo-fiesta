AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Call of Duty Effect"
ENT.Author = "adodser"
ENT.Spawnable = false
ENT.RenderGroup = RENDERGROUP_OPAQUE

function ENT:SetupDataTables()
	self:NetworkVar( "String", 0, "FX" )
	self:NetworkVar( "Float", 0, "Rate" )
end

function ENT:KeyValue( k, v )
	if k == "cod1_fx" then self.FXName = v
	elseif k == "cod1_fx_rate" then self.FXRate = tonumber( v )
	elseif k == "cod1_fx_life" then self.FXLife = tonumber( v ) end
end

if SERVER then
	function ENT:Initialize()
		self:SetModel( "models/hunter/blocks/cube025x025x025.mdl" )
		self:PhysicsInit( SOLID_VPHYSICS )
		self:SetMoveType( MOVETYPE_NONE )
		self:SetCollisionGroup( COLLISION_GROUP_WORLD )
		local ph = self:GetPhysicsObject()
		if IsValid( ph ) then ph:EnableMotion( false ) end
		self:SetFX( self.FXName or "fire/medfire" )
		self:SetRate( self.FXRate or 0.4 )
		if self.FXLife then SafeRemoveEntityDelayed( self, self.FXLife ) end
	end
	return
end

function ENT:Draw()
	local w = LocalPlayer():GetActiveWeapon()
	if IsValid( w ) and ( w:GetClass() == "weapon_physgun" or w:GetClass() == "gmod_tool" ) then self:DrawModel() end
end

function ENT:Think()
	if CurTime() >= ( self.NextFX or 0 ) then
		self.NextFX = CurTime() + math.max( self:GetRate(), 0.05 )
		if COD1.ViewPos and COD1.ViewPos():DistToSqr( self:GetPos() ) < 9000 * 9000 and COD1.PlayEFX then COD1.PlayEFX( self:GetFX(), self:GetPos(), self:GetUp() ) end
	end
	self:SetNextClientThink( CurTime() )
	return true
end

--place effects around the map, smoke fire etc
