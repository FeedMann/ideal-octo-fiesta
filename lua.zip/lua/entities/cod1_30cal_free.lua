AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "cod1_mg_turret"
ENT.PrintName = ".30 cal Free Placement (Empty)"
ENT.Author = "adodser"
ENT.Category = "Call of Duty 1"
ENT.Spawnable = true
ENT.KindKey = "b30cal_free"
ENT.FreePlace = true
ENT.NoCrew = true
ENT.AnyTeam = true

--put the 30 cal anywhere you want
