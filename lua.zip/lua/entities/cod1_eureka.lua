AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Eureka Beacon (Paradrop)"
ENT.Category = "Call of Duty 1"
ENT.Spawnable = true
ENT.Model = "models/cod1/props/eureka_beacon.mdl"

function ENT:SetupDataTables()
	self:NetworkVar( "Bool", 0, "Active" )
	self:NetworkVar( "Float", 0, "LastBeep" )
end

if CLIENT then
	local glow = Material( "sprites/light_glow02_add" )
	function ENT:Draw()
		self:DrawModel()
		if not self:GetActive() then return end
		local t = CurTime() - self:GetLastBeep()
		if t > 0.35 then return end
		local pos = self:GetPos() + self:GetUp() * ( self:OBBMaxs().z + 2 )
		render.SetMaterial( glow )
		render.DrawSprite( pos, 22, 22, Color( 255, 40, 30, 255 * ( 1 - t / 0.35 ) ) )
	end
	return
end

function ENT:Initialize()
	self:SetModel( self.Model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetUseType( SIMPLE_USE )
	local phys = self:GetPhysicsObject()
	if IsValid( phys ) then phys:Wake() end
	timer.Simple( 1, function() if IsValid( self ) then self:CallDrop() end end )
end

function ENT:Use( activator )
	if not self:GetActive() then self:CallDrop() end
end

function ENT:Notify( msg )
	local ply = self:GetCreator()
	if IsValid( ply ) then ply:ChatPrint( msg ) end
end

function ENT:CallDrop()
	if self:GetActive() then return end
	local pos = self:GetPos()
	local sky = util.TraceLine( { start = pos + Vector( 0, 0, 30 ), endpos = pos + Vector( 0, 0, 16000 ), mask = MASK_SOLID_BRUSHONLY } )
	local alt = math.min( sky.HitPos.z - 220, pos.z + 1700 )
	if alt - pos.z < 500 then
		self:Notify( "Eureka beacon: not enough open sky above the beacon for a drop." )
		return
	end

	local dir = Angle( 0, math.random( 0, 359 ), 0 ):Forward()
	local over = Vector( pos.x, pos.y, alt )
	local function reach( d )
		local tr = util.TraceLine( { start = over, endpos = over + d * 9000, mask = MASK_SOLID_BRUSHONLY } )
		return math.max( tr.Fraction * 9000 - 300, 1200 )
	end
	local back, ahead = reach( -dir ), reach( dir )

	self:SetActive( true )
	self.NextBeep = 0
	timer.Simple( 5, function()
		if not IsValid( self ) then return end
		local plane = ents.Create( "cod1_c47" )
		if not IsValid( plane ) then self:SetActive( false ) return end
		plane:SetPos( over - dir * back )
		plane:SetAngles( dir:Angle() )
		plane:Spawn()
		plane:Fly( {
			target = over, dir = dir, distance = back + ahead,
			variant = GetConVar( "cod1_eureka_variant" ):GetString(),
			count = GetConVar( "cod1_eureka_count" ):GetInt(),
			owner = self:GetCreator(),
			done = function() if IsValid( self ) then self:SetActive( false ) end end,
		} )
	end )
end

function ENT:Think()
	if self:GetActive() and CurTime() >= ( self.NextBeep or 0 ) then
		self.NextBeep = CurTime() + 1.2
		self:SetLastBeep( CurTime() )
		self:EmitSound( "cod1/misc/marker_beep.wav", 75, 100, 0.8 )
	end
	self:NextThink( CurTime() + 0.1 )
	return true
end

--put the beacon down and wait for the C-47
