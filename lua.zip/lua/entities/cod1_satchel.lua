AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Satchel Charge"
ENT.Spawnable = false
ENT.Model = "models/cod1/props/satchel.mdl"
ENT.Radius = 420
ENT.MaxDamage = 230
ENT.TankDamage = 1400
ENT.Fuse = 6

if CLIENT then
	language.Add( "cod1_satchel", "Satchel Charge" )
	return
end

function ENT:Initialize()
	self:SetModel( self.Model )
	self:PhysicsInit( SOLID_VPHYSICS )
	self:SetMoveType( MOVETYPE_VPHYSICS )
	self:SetSolid( SOLID_VPHYSICS )
	self:SetCollisionGroup( COLLISION_GROUP_WEAPON )
	local phys = self:GetPhysicsObject()
	if IsValid( phys ) then
		phys:SetMass( 4 )
		phys:Wake()
	end
	self.DetonateAt = CurTime() + self.Fuse
end

function ENT:Stick( ent )
	if not IsValid( ent ) then return end
	self.StuckTo = ent
	self:SetMoveType( MOVETYPE_NONE )
	self:SetSolid( SOLID_NONE )
	self:SetParent( ent )
end

function ENT:TimeLeft()
	return self.DetonateAt - CurTime()
end

function ENT:PhysicsCollide( data )
	if data.Speed > 60 and data.DeltaTime > 0.2 then self:EmitSound( "COD1.SatchelBounce" ) end
end

function ENT:Think()
	if CurTime() >= self.DetonateAt then
		self:Detonate()
		return
	end
	self:NextThink( CurTime() + 0.05 )
	return true
end

function ENT:Detonate()
	if self.Exploded then return end
	self.Exploded = true
	local pos = self:GetPos() + Vector( 0, 0, 6 )
	local attacker = IsValid( self.Thrower ) and self.Thrower or self
	local tank = self.StuckTo
	if not ( IsValid( tank ) and tank.IsCOD1Tank ) then
		for t in pairs( COD1.Tanks or {} ) do
			if IsValid( t ) and t:NearestPoint( pos ):DistToSqr( pos ) < 90 * 90 then tank = t break end
		end
	end
	self:SetParent( NULL )
	if IsValid( tank ) and tank.IsCOD1Tank and tank.RocketHit then tank:RocketHit( self.TankDamage, attacker, pos, Vector( 0, 0, -1 ) ) end
	local tr = util.TraceLine( { start = pos, endpos = pos - Vector( 0, 0, 64 ), mask = MASK_SOLID_BRUSHONLY } )
	COD1.FX( COD1.ExplosionFX( "rocket", tr, false ), tr.Hit and tr.HitPos or pos, tr.Hit and tr.HitNormal or Vector( 0, 0, 1 ) )
	sound.Play( "COD1.BigExplode", pos, 150, math.random( 95, 105 ) )
	util.ScreenShake( pos, 14, 140, 1.2, self.Radius * 3 )
	util.Decal( "Scorch", pos, pos - Vector( 0, 0, 48 ), self )
	util.BlastDamage( self, attacker, pos, self.Radius, self.MaxDamage )
	self:Remove()
end

--satchel charge, run
