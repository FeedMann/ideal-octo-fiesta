AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Tank"
ENT.Author = "adodser"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true
ENT.RenderGroup = RENDERGROUP_OPAQUE
ENT.IsCOD1Tank = true

COD1.Tanks = COD1.Tanks or {}

local WHEELS = { "tag_wheel_back_left", "tag_wheel_back_right", "tag_wheel_front_left", "tag_wheel_front_right",
	"tag_wheel_middle_left", "tag_wheel_middle_right" }

local function tankType( ent )
	return COD1.TankTypes[ ent:GetNWString( "COD1Tank" ) ] or COD1.TankTypes.tiger
end

local function rotZ( v, deg )
	local r = math.rad( deg )
	local c, s = math.cos( r ), math.sin( r )
	return Vector( v.x * c - v.y * s, v.x * s + v.y * c, v.z )
end

local function rotY( v, deg )
	local r = math.rad( deg )
	local c, s = math.cos( r ), math.sin( r )
	return Vector( v.x * c + v.z * s, v.y, -v.x * s + v.z * c )
end

function ENT:GunPoint( lp, yaw, pitch )
	local tags = tankType( self ).tags
	local T = tags.tag_turret and tags.tag_turret[ 1 ] or vector_origin
	local B = tags.tag_barrel and tags.tag_barrel[ 1 ] or T
	local p = rotY( lp - B, pitch ) + B
	return self:LocalToWorld( rotZ( p - T, yaw ) + T )
end

function ENT:Muzzle()
	local tags = tankType( self ).tags
	local yaw, pitch = self.TurretYaw or 0, self.GunPitch or 0
	local F = tags.tag_flash and tags.tag_flash[ 1 ] or Vector( 200, 0, 100 )
	local dir = rotZ( rotY( Vector( 1, 0, 0 ), pitch ), yaw )
	return self:GunPoint( F, yaw, pitch ), self:LocalToWorld( dir ) - self:GetPos()
end

function ENT:CoaxPoint()
	local tags = tankType( self ).tags
	local lp = tags.tag_coaxel and tags.tag_coaxel[ 1 ]
	if not lp then
		local B = tags.tag_barrel and tags.tag_barrel[ 1 ] or Vector( 40, 0, 90 )
		lp = B + Vector( 30, 14, 2 )
	end
	return self:GunPoint( lp, self.TurretYaw or 0, self.GunPitch or 0 )
end

function ENT:Hull()
	local tags = tankType( self ).tags
	local mins, maxs = tags.mins or Vector( -140, -80, 0 ), tags.maxs or Vector( 160, 80, 130 )
	return Vector( mins.x, mins.y, 6 ), Vector( math.min( maxs.x, -mins.x * 1.25 ), maxs.y, maxs.z * 0.8 )
end

if CLIENT then
	function ENT:Initialize()
		self.Wheels = {}
		local list = tankType( self ).tags.wheels
		if list then
			for _, w in ipairs( list ) do
				local b = self:LookupBone( w[ 1 ] )
				if b then table.insert( self.Wheels, { bone = b, r = w[ 2 ], y = w[ 3 ], spin = 0 } ) end
			end
		else
			for _, name in ipairs( WHEELS ) do
				local b = self:LookupBone( name )
				if b then table.insert( self.Wheels, { bone = b, r = tankType( self ).tags.wheel or 20, y = 0, spin = 0 } ) end
			end
		end
		self.LastYaw = self:GetAngles().y
		self.TurretBone = self:LookupBone( "tag_turret" )
		self.BarrelBone = self:LookupBone( "tag_barrel" )
		self.RecoilBone = self:LookupBone( "barrel_recoil" )
		self.Yaw, self.Pitch = 0, 0
		self.NextSmoke = 0
		local t = tankType( self ).tags
		if t.mins then self:SetRenderBounds( t.mins - Vector( 40, 40, 0 ), t.maxs + Vector( 40, 40, 60 ) ) end
	end

	function ENT:Think()
		local now = CurTime()
		local pos = self:GetPos()
		local dead = self:GetNWBool( "COD1Dead" )
		if self.ModelName ~= self:GetModel() then
			self.ModelName = self:GetModel()
			for i = 0, self:GetBoneCount() - 1 do
				self:ManipulateBoneAngles( i, angle_zero )
				self:ManipulateBonePosition( i, vector_origin )
			end
			self:Initialize()
		end
		if not dead then
			local yaw = self:GetAngles().y
			if self.LastPos then
				local moved = ( pos - self.LastPos ):Dot( self:GetForward() )
				local turned = math.rad( math.AngleDifference( yaw, self.LastYaw or yaw ) )
				if moved ~= 0 or turned ~= 0 then
					for _, w in ipairs( self.Wheels ) do
						w.spin = ( w.spin + ( moved - turned * w.y ) / w.r * 57.3 ) % 360
						self:ManipulateBoneAngles( w.bone, Angle( w.spin, 0, 0 ) )
					end
				end
			end
			self.LastYaw = yaw
			local k = math.min( FrameTime() * 10, 1 )
			self.Yaw = Lerp( k, self.Yaw, self:GetNW2Float( "COD1TurretYaw" ) )
			self.Pitch = Lerp( k, self.Pitch, self:GetNW2Float( "COD1GunPitch" ) )
			if self.TurretBone then self:ManipulateBoneAngles( self.TurretBone, Angle( 0, self.Yaw, 0 ) ) end
			if self.BarrelBone then self:ManipulateBoneAngles( self.BarrelBone, Angle( self.Pitch, 0, 0 ) ) end
			if self.RecoilBone then
				local e = now - self:GetNWFloat( "COD1Fired" )
				local back = e < 0.08 and e / 0.08 or math.max( 1 - ( e - 0.08 ) / 0.9, 0 )
				self:ManipulateBonePosition( self.RecoilBone, Vector( -22 * back, 0, 0 ) )
			end
		end
		self.LastPos = pos
		if self:GetNWBool( "COD1Smoking" ) and not dead and now >= self.NextSmoke and COD1.PlayEFX then
			local t = tankType( self ).tags
			local deck = self:LocalToWorld( Vector( ( t.mins and t.mins.x or -120 ) * 0.6, 0, ( t.maxs and t.maxs.z or 120 ) * 0.7 ) )
			local burning = self:GetNWBool( "COD1Burning" )
			self.NextSmoke = now + ( burning and 0.9 or 0.7 )
			COD1.PlayEFX( burning and "fire/tank_burn" or "smoke/blacksmoke2", deck, Vector( 0, 0, 1 ) )
		end
		self:SetNextClientThink( now )
		return true
	end
	return
end

local MASK_TANK = MASK_SHOT

function ENT:KeyValue( k, v )
	if k == "cod1_tank" then self.TankKey = v end
end

function ENT:Initialize()
	local t = COD1.TankTypes[ self.TankKey or "" ] or COD1.TankTypes.tiger
	self.Type = t
	self:SetNWString( "COD1Tank", t.key )
	self:SetNWString( "COD1Team", t.team )
	self:SetModel( "models/cod1/vehicles/" .. t.model .. ".mdl" )
	self.COD1Team = t.team
	self:SetMaxHealth( t.hp )
	self:SetHealth( t.hp )
	self:SetMoveType( MOVETYPE_NONE )
	self:SetCollisionBounds( self:Hull() )
	self:SetSolid( SOLID_OBB )
	self:ResetSequence( self:LookupSequence( "idle" ) )
	self.Speed = 0
	self.TiltP, self.TiltR = 0, 0
	self.TurretYaw, self.GunPitch = 0, 0
	self.WantYaw, self.WantPitch = 0, 0
	self.NextShot = CurTime() + 2
	self.MGRest = CurTime() + math.Rand( 1, 2.5 )
	self.Grudges = {}
	self.Progress = { at = CurTime(), pos = self:GetPos() }
	COD1.Tanks[ self ] = true
	if COD1.OtherNPCs then COD1.OtherNPCs[ self ] = true end
	self.IdleSnd = CreateSound( self, "COD1.Tank." .. t.engine .. "Idle" )
	self.MoveSnd = CreateSound( self, "COD1.Tank." .. t.engine .. "Move" )
	self.IdleSnd:Play()
	self.MoveSnd:PlayEx( 0, 100 )
	timer.Simple( 0, function() if IsValid( self ) then self:Settle() end end )
end

function ENT:OnRemove()
	COD1.Tanks[ self ] = nil
	if COD1.OtherNPCs then COD1.OtherNPCs[ self ] = nil end
	if self.IdleSnd then self.IdleSnd:Stop() end
	if self.MoveSnd then self.MoveSnd:Stop() end
	if self.MGSnd then self.MGSnd:Stop() end
end

local function solidForTank( e )
	if not IsValid( e ) then return true end
	if e.IsCOD1Tank or e.IsCOD1Soldier or e:IsPlayer() or e:IsNPC() or e:IsNextBot() or e:IsWeapon() then return false end
	local c = e:GetClass()
	if c == "prop_ragdoll" or c == "cod1_grenade" or c == "cod1_satchel" or c == "cod1_rocket" then return false end
	local phys = e:GetPhysicsObject()
	return not ( IsValid( phys ) and phys:IsMoveable() and phys:GetMass() < 400 )
end

function ENT:Feet()
	local mins, maxs = self:Hull()
	return maxs.x * 0.8, mins.x * 0.8, maxs.y * 0.75
end

function ENT:GroundHeight( p, base )
	local tr = util.TraceLine( { start = Vector( p.x, p.y, base + 90 ), endpos = Vector( p.x, p.y, base - 220 ), filter = function( e )
		return e ~= self and solidForTank( e )
	end, mask = MASK_SOLID } )
	if not tr.Hit or tr.StartSolid then return nil end
	return tr.HitPos.z
end

function ENT:GroundAt( pos, yaw )
	local front, back, side = self:Feet()
	local a = Angle( 0, yaw, 0 )
	local f, r = a:Forward(), a:Right()
	local fl = self:GroundHeight( pos + f * front - r * side, pos.z )
	local fr = self:GroundHeight( pos + f * front + r * side, pos.z )
	local bl = self:GroundHeight( pos + f * back - r * side, pos.z )
	local br = self:GroundHeight( pos + f * back + r * side, pos.z )
	if not ( fl and fr and bl and br ) then return nil end
	local hf, hb, hl, hr = ( fl + fr ) / 2, ( bl + br ) / 2, ( fl + bl ) / 2, ( fr + br ) / 2
	local pitch = math.deg( math.atan2( hb - hf, front - back ) )
	local roll = math.deg( math.atan2( hl - hr, side * 2 ) )
	if math.abs( pitch ) > 34 or math.abs( roll ) > 30 then return nil end
	return ( hf + hb ) / 2, pitch, roll
end

function ENT:Settle()
	local pos = self:GetPos()
	local z, p, r = self:GroundAt( pos, self:GetAngles().y )
	if not z then return end
	self.TiltP, self.TiltR = p, r
	self:SetPos( Vector( pos.x, pos.y, z ) )
	self:SetAngles( Angle( p, self:GetAngles().y, r ) )
end

function ENT:PathClear( from, yaw, dist )
	local _, maxs = self:Hull()
	local w = maxs.y * 0.8
	local dir = Angle( 0, yaw, 0 ):Forward()
	local start = from + dir * ( maxs.x - w ) + Vector( 0, 0, 40 )
	local tr = util.TraceHull( { start = start, endpos = start + dir * dist, mins = Vector( -w, -w, 0 ), maxs = Vector( w, w, maxs.z - 40 ),
		filter = function( e ) return e ~= self and solidForTank( e ) end, mask = MASK_SOLID } )
	if tr.StartSolid then return false, 0 end
	return not tr.Hit, tr.Fraction * dist
end

function ENT:Steer( goalYaw, reach )
	local pos = self:GetPos()
	local best, bestScore
	local probe = math.Clamp( reach or 300, 120, 300 )
	for _, off in ipairs( { 0, -25, 25, -50, 50, -80, 80, -115, 115 } ) do
		local yaw = goalYaw + off
		local clear, free = self:PathClear( pos, yaw, off == 0 and probe or 300 )
		local ahead = pos + Angle( 0, yaw, 0 ):Forward() * math.min( free, 200 )
		if clear and self:GroundAt( ahead, yaw ) then
			local score = math.abs( off ) + math.abs( math.AngleDifference( yaw, self:GetAngles().y ) ) * 0.3
			if ( self.SideBias or 0 ) * off < 0 then score = score + 15 end
			if not bestScore or score < bestScore then best, bestScore = yaw, score end
			if off == 0 then break end
		end
	end
	return best
end

function ENT:SetGoal( pos, tolerance )
	self.Goal = pos
	self.GoalTol = tolerance or 150
	self.FaceGoal = nil
end

COD1.TankNav = COD1.TankNav or { fits = {}, edges = {}, bad = {} }
local NAV = COD1.TankNav

function ENT:NavWidth()
	local _, maxs = self:Hull()
	return math.max( maxs.y, 40 )
end

local FIT_SPOTS = { { 0, 0 }, { 1, 1 }, { -1, 1 }, { 1, -1 }, { -1, -1 } }

local function fitPoint( a, w )
	local key = a:GetID() .. ":" .. math.floor( w / 8 )
	local c = NAV.fits[ key ]
	if c == nil then
		c = false
		if not a:IsUnderwater() and not a:HasAttributes( NAV_MESH_CROUCH ) then
			local p = a:GetCenter()
			local sx, sy = a:GetSizeX() * 0.25, a:GetSizeY() * 0.25
			for _, o in ipairs( FIT_SPOTS ) do
				local q = a:GetClosestPointOnArea( p + Vector( o[ 1 ] * sx, o[ 2 ] * sy, 0 ) ) or p
				local tr = util.TraceHull( { start = q + Vector( 0, 0, 30 ), endpos = q + Vector( 0, 0, 31 ),
					mins = Vector( -w - 6, -w - 6, 0 ), maxs = Vector( w + 6, w + 6, 70 ), mask = MASK_SOLID_BRUSHONLY } )
				if not tr.Hit and not tr.StartSolid then
					c = q
					break
				end
			end
		end
		NAV.fits[ key ] = c
	end
	return c
end

local function edgeOpen( a, b, w, pa, pb )
	local key = a:GetID() .. ">" .. b:GetID() .. ":" .. math.floor( w / 8 )
	local c = NAV.edges[ key ]
	if c == nil then
		local dz = a:ComputeAdjacentConnectionHeightChange( b )
		c = dz < 40 and dz > -70
		if c then
			local p, q = pa + Vector( 0, 0, 40 ), pb + Vector( 0, 0, 40 )
			local tr = util.TraceHull( { start = p, endpos = q, mins = Vector( -w * 0.7, -w * 0.7, 0 ), maxs = Vector( w * 0.7, w * 0.7, 50 ),
				mask = MASK_SOLID_BRUSHONLY } )
			c = not tr.Hit
		end
		NAV.edges[ key ] = c
	end
	return c
end

local function heapPush( h, node, f )
	h[ #h + 1 ] = { node, f }
	local i = #h
	while i > 1 do
		local p = math.floor( i / 2 )
		if h[ p ][ 2 ] <= h[ i ][ 2 ] then break end
		h[ p ], h[ i ] = h[ i ], h[ p ]
		i = p
	end
end

local function heapPop( h )
	local top = h[ 1 ]
	local last = table.remove( h )
	if #h > 0 then
		h[ 1 ] = last
		local i = 1
		while true do
			local l, r, s = i * 2, i * 2 + 1, i
			if h[ l ] and h[ l ][ 2 ] < h[ s ][ 2 ] then s = l end
			if h[ r ] and h[ r ][ 2 ] < h[ s ][ 2 ] then s = r end
			if s == i then break end
			h[ s ], h[ i ] = h[ i ], h[ s ]
			i = s
		end
	end
	return top[ 1 ]
end

function ENT:PlanRoute( from, to )
	local w = self:NavWidth()
	local startA
	local bestD
	for _, a in ipairs( navmesh.Find( from, 360, 80, 80 ) ) do
		local fp = fitPoint( a, w )
		if fp then
			local d = fp:DistToSqr( from )
			if not bestD or d < bestD then startA, bestD = a, d end
		end
	end
	startA = startA or navmesh.GetNearestNavArea( from, false, 400, false, true )
	local goalA = navmesh.GetNearestNavArea( to, false, 700, false, true )
	if not IsValid( startA ) or not IsValid( goalA ) then return { failed = true, goal = to, retry = CurTime() + 6 } end
	if startA == goalA then return { pts = { to }, i = 1, goal = to } end
	local now = CurTime()
	local goalC = to
	local spot = { [ startA ] = fitPoint( startA, w ) or from, [ goalA ] = fitPoint( goalA, w ) or to }
	local g, came, closed = { [ startA ] = 0 }, {}, {}
	local open = {}
	heapPush( open, startA, spot[ startA ]:Distance( goalC ) )
	local found, expanded = false, 0
	while #open > 0 and expanded < 1800 do
		local a = heapPop( open )
		if a == goalA then found = true break end
		if not closed[ a ] then
			closed[ a ] = true
			expanded = expanded + 1
			for _, b in ipairs( a:GetAdjacentAreas() ) do
				if not closed[ b ] and ( NAV.bad[ b:GetID() ] or 0 ) < now and not b:IsBlocked() then
					local pb = spot[ b ] or fitPoint( b, w )
					if pb then
						spot[ b ] = pb
						if edgeOpen( a, b, w, spot[ a ], pb ) then
							local ng = g[ a ] + spot[ a ]:Distance( pb ) * ( b:HasAttributes( NAV_MESH_AVOID ) and 3 or 1 )
							if not g[ b ] or ng < g[ b ] then
								g[ b ] = ng
								came[ b ] = a
								heapPush( open, b, ng + pb:Distance( goalC ) )
							end
						end
					end
				end
			end
		end
	end
	if not found then return { failed = true, goal = to, retry = CurTime() + 6 } end
	local chain = {}
	local a = goalA
	while a and a ~= startA do
		table.insert( chain, 1, a )
		a = came[ a ]
	end
	local pts = {}
	for i = 1, #chain - 1 do pts[ #pts + 1 ] = spot[ chain[ i ] ] or chain[ i ]:GetCenter() end
	pts[ #pts + 1 ] = to
	return { pts = pts, areas = chain, i = 1, goal = to }
end

function ENT:RouteAim( pos )
	if not navmesh.IsLoaded() or not self.Goal then return end
	local now = CurTime()
	local r = self.Route
	local stale = not r or r.goal:DistToSqr( self.Goal ) > 300 * 300 or r.failed and now >= r.retry
	if stale and now >= ( self.NextRoute or 0 ) then
		self.NextRoute = now + 2
		if self.Goal:DistToSqr( pos ) < 500 * 500 then
			r = nil
		else
			r = self:PlanRoute( pos, self.Goal )
		end
		self.Route = r
	end
	if not r or r.failed then return end
	local flatPos = Vector( pos.x, pos.y, 0 )
	while r.i < #r.pts do
		local wp, nx = r.pts[ r.i ], r.pts[ r.i + 1 ]
		local w2 = Vector( wp.x, wp.y, 0 )
		local passed = ( flatPos - w2 ):Dot( Vector( nx.x - wp.x, nx.y - wp.y, 0 ) ) > 0 and w2:DistToSqr( flatPos ) < 420 * 420
		if w2:DistToSqr( flatPos ) > 170 * 170 and not passed then break end
		r.i = r.i + 1
	end
	if r.i < #r.pts and now >= ( r.nextSkip or 0 ) then
		r.nextSkip = now + 0.5
		local nxt = r.pts[ r.i + 1 ]
		local to = Vector( nxt.x - pos.x, nxt.y - pos.y, 0 )
		local d = to:Length()
		if d > 1 and d < 900 and self:PathClear( pos, to:Angle().y, d ) then r.i = r.i + 1 end
	end
	return r.pts[ r.i ]
end

function ENT:StartReverse()
	self.ReverseUntil = CurTime() + math.Rand( 1.2, 2 )
	self.SideBias = math.random( 2 ) == 1 and 1 or -1
	self.ReverseTurn = 25 * self.SideBias
	self.SteerYaw = nil
	local r = self.Route
	if r and not r.failed and r.areas then
		local a = r.areas[ math.min( r.i, #r.areas ) ]
		if IsValid( a ) and r.i < #r.pts then NAV.bad[ a:GetID() ] = CurTime() + 12 end
		self.Route = nil
		self.NextRoute = CurTime() + 1
	end
end

function ENT:Drive( dt )
	local t = self.Type
	local pos = self:GetPos()
	local yaw = self:GetAngles().y
	local now = CurTime()
	local wantSpeed, wantYaw = 0, yaw
	if self.ReverseUntil and now < self.ReverseUntil then
		wantSpeed = -t.speed * 0.45
		wantYaw = yaw + self.ReverseTurn
	elseif self.Goal then
		local toGoal = self.Goal - pos
		toGoal.z = 0
		if toGoal:Length() < self.GoalTol then
			self.Goal = nil
			self.Route = nil
		else
			local aim = self:RouteAim( pos ) or self.Goal
			local to = aim - pos
			to.z = 0
			if not self.SteerAt or now >= self.SteerAt then
				self.SteerAt = now + 0.25
				self.SteerYaw = self:Steer( to:Angle().y, to:Length() + 40 )
			end
			if self.SteerYaw then
				wantYaw = self.SteerYaw
				wantSpeed = t.speed * math.Clamp( 1 - math.abs( math.AngleDifference( wantYaw, yaw ) ) / 45, 0, 1 )
				if toGoal:Length() < 400 then wantSpeed = wantSpeed * math.max( toGoal:Length() / 400, 0.35 ) end
			else
				self:StartReverse()
			end
		end
	elseif self.FaceGoal then
		wantYaw = ( self.FaceGoal - pos ):Angle().y
		if math.abs( math.AngleDifference( wantYaw, yaw ) ) < 3 then self.FaceGoal = nil end
	end
	local rate = ( t.turnRate or 30 ) * dt
	yaw = yaw + math.Clamp( math.AngleDifference( wantYaw, yaw ), -rate, rate )
	self.Speed = math.Approach( self.Speed, wantSpeed, ( math.abs( wantSpeed ) > math.abs( self.Speed ) and 110 or 260 ) * dt )
	local np = pos + Angle( 0, yaw, 0 ):Forward() * self.Speed * dt
	if self.Speed ~= 0 and not self:PathClear( pos, self.Speed > 0 and yaw or yaw + 180, math.abs( self.Speed * dt ) + 12 ) then
		np = pos
		local backing = self.Speed < 0
		self.Speed = 0
		if backing then self.ReverseUntil = now elseif not ( self.ReverseUntil and now < self.ReverseUntil ) then self:StartReverse() end
	end
	local z, p, r = self:GroundAt( np, yaw )
	if not z or math.abs( z - pos.z ) > 48 then
		np = pos
		self.Speed = 0
		z, p, r = self:GroundAt( pos, yaw )
		if self.Goal and not ( self.ReverseUntil and now < self.ReverseUntil ) then self:StartReverse() end
	end
	z = z or pos.z
	local k = math.min( dt * 6, 1 )
	self.TiltP = Lerp( k, self.TiltP, p or self.TiltP )
	self.TiltR = Lerp( k, self.TiltR, r or self.TiltR )
	local nz = z > pos.z and math.min( z, pos.z + 260 * dt ) or math.max( z, pos.z - 420 * dt )
	self:SetPos( Vector( np.x, np.y, nz ) )
	self:SetAngles( Angle( self.TiltP, yaw, self.TiltR ) )
	if wantSpeed > 0 and self.Goal then
		if pos:DistToSqr( self.Progress.pos ) > 40 * 40 then
			self.Progress = { at = now, pos = pos }
		elseif now - self.Progress.at > 3 then
			self.Progress = { at = now, pos = pos }
			self:StartReverse()
		end
	else
		self.Progress = { at = now, pos = pos }
	end
	if math.abs( self.Speed ) > 5 then self:PushAside() end
end

function ENT:PushAside()
	local mins, maxs = self:Hull()
	local lo, hi = self:LocalToWorld( mins ), self:LocalToWorld( maxs )
	local wmin = Vector( math.min( lo.x, hi.x ), math.min( lo.y, hi.y ), math.min( lo.z, hi.z ) ) - Vector( 60, 60, 0 )
	local wmax = Vector( math.max( lo.x, hi.x ), math.max( lo.y, hi.y ), math.max( lo.z, hi.z ) ) + Vector( 60, 60, 0 )
	local now = CurTime()
	for _, e in ipairs( ents.FindInBox( wmin, wmax ) ) do
		if e ~= self and ( e:IsPlayer() and e:Alive() or e.IsCOD1Soldier and not e.Dead ) and e:GetGroundEntity() ~= self then
			local lp = self:WorldToLocal( e:GetPos() )
			local ahead = self.Speed >= 0 and lp.x > maxs.x - 8 and lp.x < maxs.x + 16 or self.Speed < 0 and lp.x < mins.x + 8 and lp.x > mins.x - 16
			local inside = lp.x > mins.x and lp.x < maxs.x
			if ( inside or ahead ) and lp.y > mins.y - 6 and lp.y < maxs.y + 6 and lp.z < maxs.z * 0.6 then
				local side = lp.y >= 0 and 1 or -1
				local out = self:GetRight() * -side
				if e:IsPlayer() then
					e:SetVelocity( out * 320 + Vector( 0, 0, 80 ) )
				else
					local edge = side > 0 and maxs.y + 40 or mins.y - 40
					local p = self:LocalToWorld( Vector( lp.x, edge, 0 ) )
					e:SetPos( Vector( p.x, p.y, e:GetPos().z ) )
				end
				if math.abs( self.Speed ) > 40 and now >= ( e.COD1Crushed or 0 ) and e.COD1Team ~= self.COD1Team then
					e.COD1Crushed = now + 0.4
					local dmg = DamageInfo()
					dmg:SetDamage( 25 )
					dmg:SetDamageType( DMG_CRUSH )
					dmg:SetAttacker( self )
					dmg:SetInflictor( self )
					dmg:SetDamageForce( out * 8000 )
					e:TakeDamageInfo( dmg )
				end
			end
		end
	end
end

function ENT:Eye()
	local tags = self.Type.tags
	return self:LocalToWorld( tags.tag_player and tags.tag_player[ 1 ] or Vector( 0, 0, tags.maxs and tags.maxs.z or 120 ) )
end

function ENT:Hostile( e )
	if not IsValid( e ) or e == self then return false end
	if e.IsCOD1Tank then return not e.Dead and e.COD1Team ~= self.COD1Team end
	if e:IsPlayer() then return COD1.HostileToPlayer( self.COD1Team, e ) or ( self.Grudges[ e ] or 0 ) > CurTime() end
	if e.IsCOD1Soldier then return not e.Dead and not e.Downed and not e.Surrendered and e.COD1Team ~= self.COD1Team end
	return false
end

function ENT:Sees( e, from )
	from = from or self:Eye()
	local to = e:WorldSpaceCenter()
	if #COD1.SmokeClouds > 0 and COD1.SmokeBlocks and COD1.SmokeBlocks( from, to, CurTime() ) then return false end
	local tr = util.TraceLine( { start = from, endpos = to, filter = self, mask = MASK_TANK } )
	return tr.Entity == e or tr.Fraction > 0.98
end

function ENT:FindTarget()
	local me = self:GetPos()
	local cands = {}
	local function consider( e, base )
		local d = me:Distance( e:GetPos() )
		if d > 4500 then return end
		local s = base - d / 1200
		if e == self.Target then s = s + 0.8 end
		if e == self.Provoker then s = s + 1 end
		if e.IsCOD1Soldier and e.WeaponType == "rocket" then s = s + 1.2 end
		cands[ #cands + 1 ] = { e, s }
	end
	for t in pairs( COD1.Tanks ) do
		if self:Hostile( t ) then consider( t, 3 ) end
	end
	for _, p in ipairs( player.GetAll() ) do
		if self:Hostile( p ) then consider( p, 1.5 ) end
	end
	for s in pairs( COD1.Soldiers or {} ) do
		if IsValid( s ) and self:Hostile( s ) then consider( s, 1 ) end
	end
	table.sort( cands, function( a, b ) return a[ 2 ] > b[ 2 ] end )
	local eye = self:Eye()
	for i = 1, math.min( #cands, 8 ) do
		if self:Sees( cands[ i ][ 1 ], eye ) then return cands[ i ][ 1 ] end
	end
end

function ENT:AimAt( pos )
	local tags = self.Type.tags
	local T = tags.tag_turret and tags.tag_turret[ 1 ] or vector_origin
	local lt = self:WorldToLocal( pos )
	local yaw = math.deg( math.atan2( lt.y - T.y, lt.x - T.x ) )
	local trav = self.Type.traverse
	if trav then yaw = math.Clamp( yaw, -trav, trav ) end
	local B = tags.tag_barrel and tags.tag_barrel[ 1 ] or T
	local bl = rotZ( B - T, yaw ) + T
	local d = lt - bl
	self.WantYaw = yaw
	self.WantPitch = math.Clamp( -math.deg( math.atan2( d.z, Vector( d.x, d.y, 0 ):Length() ) ), -15, 8 )
end

function ENT:InArc( pos )
	local trav = self.Type.traverse
	if not trav then return true end
	local lt = self:WorldToLocal( pos )
	return math.abs( math.deg( math.atan2( lt.y, lt.x ) ) ) < trav
end

function ENT:Brain()
	local tgt = self:FindTarget()
	self.Target = tgt
	local now = CurTime()
	if IsValid( tgt ) then
		self.LastTargetPos = tgt:GetPos()
		self.LastSeenAt = now
		local d = self:GetPos():Distance( tgt:GetPos() )
		if d > 2600 then
			self:SetGoal( tgt:GetPos(), 2200 )
		elseif not self:InArc( tgt:GetPos() ) then
			self.Goal = nil
			self.FaceGoal = tgt:GetPos()
		else
			self.Goal = nil
		end
	elseif self.LastTargetPos and now - ( self.LastSeenAt or 0 ) < 25 then
		self:SetGoal( self.LastTargetPos, 350 )
		if self:GetPos():Distance( self.LastTargetPos ) < 400 then self.LastTargetPos = nil end
	elseif self:MayAdvance() then
		local goal, radius = self:AdvanceGoal()
		if goal then self:SetGoal( goal, radius ) elseif self.Goal and now - ( self.LastSeenAt or 0 ) > 40 then self.Goal = nil end
	elseif self.Goal and now - ( self.LastSeenAt or 0 ) > 40 then
		self.Goal = nil
	end
end

function ENT:MayAdvance()
	local mode = GetConVar( "cod1_npc_advance" ):GetInt()
	local enemySide = self.COD1Team ~= COD1.PlayerSide()
	return mode == 1 or ( mode == 2 and not enemySide ) or ( mode == 3 and enemySide )
end

function ENT:AdvanceGoal()
	local now, me = CurTime(), self:GetPos()
	local best, bd
	for e, info in pairs( COD1.Intel and COD1.Intel[ self.COD1Team ] or {} ) do
		if IsValid( e ) and now - info.t < 45 then
			local d = me:DistToSqr( info.pos )
			if d < 7000 * 7000 and ( not bd or d < bd ) then best, bd = info.pos, d end
		end
	end
	if best then return best, 1600 end
	if not COD1.PatrolPoint then return end
	local p = COD1.PatrolPoint( self )
	if p and me:DistToSqr( p ) < 600 * 600 and self.Patrol then
		self.Patrol.expires = 0
		p = COD1.PatrolPoint( self )
	end
	return p, 400
end

local function shellImpact( tank, tr, dir )
	local attacker = IsValid( tank ) and tank or game.GetWorld()
	local hit = tr.Entity
	if IsValid( hit ) and hit.IsCOD1Tank and hit ~= tank and hit.RocketHit then hit:RocketHit( 900, attacker, tr.HitPos, dir ) end
	if tr.HitSky then return end
	local n = tr.HitNormal or Vector( 0, 0, 1 )
	local pos = tr.HitPos + n * 6
	COD1.FX( COD1.ExplosionFX( "tank", tr, false ), pos, n )
	sound.Play( "COD1.ShellExplode", pos, 150, math.random( 95, 105 ) )
	util.ScreenShake( pos, 10, 140, 1, 1300 )
	util.Decal( "Scorch", pos + n * 8, pos - n * 32 )
	util.BlastDamage( attacker, attacker, pos, 280, 220 )
end

function ENT:FireCannon( target )
	local src, dir = self:Muzzle()
	local aim = target:WorldSpaceCenter()
	if not target.IsCOD1Tank then aim = aim - Vector( 0, 0, 24 ) end
	local d = src:Distance( aim )
	local chance = target.IsCOD1Tank and math.Clamp( 1 - d / 5000, 0.35, 0.85 ) or math.Clamp( 0.7 - d / 5000, 0.2, 0.55 )
	if math.abs( self.Speed ) > 20 then chance = chance * 0.5 end
	if math.random() > chance * GetConVar( "cod1_npc_accuracy" ):GetFloat() then
		aim = aim + VectorRand():GetNormalized() * math.Rand( 90, 240 ) * ( 1 + d / 3000 )
	end
	local shot = ( aim - src ):GetNormalized()
	if shot:Dot( dir ) < 0.97 then shot = dir end
	local tr = util.TraceLine( { start = src, endpos = src + shot * 12000, filter = self, mask = MASK_TANK } )
	self.NextShot = CurTime() + self.Type.reload * math.Rand( 0.9, 1.25 )
	COD1.FX( "muzzleflashes/flak88", src, shot )
	self:EmitSound( "COD1.Tank.Fire" )
	self:SetNWFloat( "COD1Fired", CurTime() )
	util.ScreenShake( src, 8, 120, 0.7, 1400 )
	COD1.NoteGunfire( self:GetPos() )
	local delay = math.min( tr.Fraction * 12000 / 9000, 1.2 )
	timer.Simple( delay, function() shellImpact( self, tr, shot ) end )
end

function ENT:StopMG()
	if not self.MGOn then return end
	self.MGOn = false
	if self.MGSnd then self.MGSnd:Stop() end
	self:EmitSound( "COD1.Tank.MGStop" )
	self.MGRest = CurTime() + math.Rand( 1, 2.5 )
end

function ENT:UpdateMG( target, aligned )
	local now = CurTime()
	if not IsValid( target ) or target.IsCOD1Tank or not aligned or self:GetPos():Distance( target:GetPos() ) > 1400 then
		self:StopMG()
		return
	end
	if not self.MGOn then
		if now < ( self.MGRest or 0 ) then return end
		self.MGOn = true
		self.MGUntil = now + math.Rand( 0.7, 1.5 )
		self.MGSnd = self.MGSnd or CreateSound( self, "COD1.Tank.MGLoop" )
		self.MGSnd:Play()
	end
	if now > self.MGUntil then
		self:StopMG()
		return
	end
	if now < ( self.NextMGShot or 0 ) then return end
	self.NextMGShot = now + 0.09
	local src = self:CoaxPoint()
	local aim = target:WorldSpaceCenter()
	self:FireBullets( {
		Attacker = self, Inflictor = self, Damage = GetConVar( "cod1_npc_damage" ):GetFloat(), Force = 6, Num = 1,
		Src = src, Dir = ( aim - src ):GetNormalized(), Spread = Vector( 0.05, 0.05, 0 ), Tracer = 2, TracerName = "Tracer",
		IgnoreEntity = self, Callback = function( _, tr ) return COD1.BulletImpactFX( tr, "mg42" ) end,
	} )
	COD1.NoteGunfire( self:GetPos() )
end

function ENT:Guns( dt )
	local tgt = self.Target
	if IsValid( tgt ) and self:Hostile( tgt ) then
		self:AimAt( tgt:WorldSpaceCenter() )
	else
		self.WantYaw = self.Type.traverse and 0 or self.WantYaw
		self.WantPitch = 0
		tgt = nil
	end
	local rate = self.Type.turretRate * dt
	local dy = math.AngleDifference( self.WantYaw, self.TurretYaw )
	local turning = math.abs( dy ) > 0.5
	self.TurretYaw = math.NormalizeAngle( self.TurretYaw + math.Clamp( dy, -rate, rate ) )
	self.GunPitch = math.Approach( self.GunPitch, self.WantPitch, 12 * dt )
	if turning ~= self.Turning then
		self.Turning = turning
		self:EmitSound( turning and "COD1.Tank.Turret" or "COD1.Tank.TurretStop" )
	end
	if math.abs( self:GetNW2Float( "COD1TurretYaw" ) - self.TurretYaw ) > 0.2 then self:SetNW2Float( "COD1TurretYaw", self.TurretYaw ) end
	if math.abs( self:GetNW2Float( "COD1GunPitch" ) - self.GunPitch ) > 0.2 then self:SetNW2Float( "COD1GunPitch", self.GunPitch ) end
	local aligned = tgt and math.abs( math.AngleDifference( self.WantYaw, self.TurretYaw ) ) < 2 and math.abs( self.WantPitch - self.GunPitch ) < 2
	if aligned and CurTime() >= self.NextShot and ( tgt.IsCOD1Tank or self:GetPos():Distance( tgt:GetPos() ) > 350 ) then
		if self:Sees( tgt, self:Muzzle() ) then self:FireCannon( tgt ) end
	end
	self:UpdateMG( tgt, tgt and math.abs( math.AngleDifference( self.WantYaw, self.TurretYaw ) ) < 12 )
	local v = math.Clamp( math.abs( self.Speed ) / self.Type.speed, 0, 1 )
	self.MoveSnd:ChangeVolume( v, 0.3 )
	self.IdleSnd:ChangeVolume( 1 - v * 0.6, 0.3 )
end

function ENT:Think()
	local now = CurTime()
	local dt = math.Clamp( now - ( self.LastThink or now ), 0, 0.1 )
	self.LastThink = now
	if not self.Dead and not GetConVar( "ai_disabled" ):GetBool() then
		if now >= ( self.NextBrain or 0 ) then
			self.NextBrain = now + 0.4
			self:Brain()
		end
		self:Drive( dt )
		self:Guns( dt )
	end
	self:NextThink( now )
	return true
end

function ENT:Chip( amount, attacker )
	if self.Dead or amount <= 0 then return end
	self:SetHealth( self:Health() - amount )
	if IsValid( attacker ) and attacker ~= self then
		if attacker:IsPlayer() then self.Grudges[ attacker ] = CurTime() + 30 end
		if attacker:IsPlayer() or attacker.IsCOD1Soldier or attacker.IsCOD1Tank then self.Provoker = attacker end
	end
	local frac = self:Health() / self:GetMaxHealth()
	if frac < 0.6 then self:SetNWBool( "COD1Smoking", true ) end
	if frac < 0.3 then self:SetNWBool( "COD1Burning", true ) end
	if self:Health() <= 0 then self:Wreck( attacker ) end
end

function ENT:RocketHit( amount, attacker, pos, dir )
	COD1.FX( "impacts/metalhit_large", pos, -dir )
	self:Chip( amount, attacker )
end

function ENT:HatchSpot()
	local tags = self.Type.tags
	local h = tags.tag_hatch or tags.tag_detach or tags.tag_popout or tags.tag_player
	if not h then return nil end
	local lp = h[ 1 ]
	local yaw = 0
	if tags.tag_turret and not self.Type.traverse then
		lp = rotZ( lp - tags.tag_turret[ 1 ], self.TurretYaw or 0 ) + tags.tag_turret[ 1 ]
		yaw = self.TurretYaw or 0
	end
	return { pos = self:LocalToWorld( lp ), yaw = self:GetAngles().y + yaw }
end

function ENT:Wreck( attacker )
	self.Dead = true
	COD1.Tanks[ self ] = nil
	self:SetHealth( 0 )
	self:StopMG()
	self:SetNWBool( "COD1Dead", true )
	self.IdleSnd:Stop()
	self.MoveSnd:Stop()
	self.Speed = 0
	self.TurretYaw = 0
	self.HatchWorld = self:HatchSpot()
	local pos = self:GetPos()
	for i = 0, self:GetBoneCount() - 1 do
		self:ManipulateBoneAngles( i, angle_zero )
		self:ManipulateBonePosition( i, vector_origin )
	end
	self:SetModel( "models/cod1/vehicles/" .. self.Type.dead .. ".mdl" )
	COD1.FX( self.Type.boom, pos, Vector( 0, 0, 1 ) )
	sound.Play( "COD1.Tank.Die", pos, 150 )
	sound.Play( "COD1.BigExplode", pos + Vector( 0, 0, 60 ), 150 )
	util.ScreenShake( pos, 16, 120, 1.6, 2200 )
	local who = IsValid( attacker ) and attacker or self
	util.BlastDamage( self, who, pos + Vector( 0, 0, 60 ), self.Type.blast or 360, 180 )
	hook.Run( "OnNPCKilled", self, who, self )
	timer.Simple( 1.4, function() if IsValid( self ) then self:BailCrew() end end )
end

local CLIMB_ROOT = Vector( 6.58, -0.33, -46.79 )
local JUMP_ROOT = Vector( -22.65, 21.27, -53.82 )
local JUMP_END = Vector( -35.21, 160.92, -137.73 )

function ENT:BailCrew()
	local t = self.Type
	local hatch = self.HatchWorld
	if not hatch then return end
	local a = Angle( 0, hatch.yaw, 0 )
	local function at( v ) return hatch.pos + a:Forward() * v.x - a:Right() * v.y + Vector( 0, 0, v.z ) end
	for i = 1, math.random( 1, t.crewCount ) do
		timer.Simple( ( i - 1 ) * 2.6, function()
			if not IsValid( self ) then return end
			local land = at( JUMP_END )
			local tr = util.TraceLine( { start = land + Vector( 0, 0, 200 ), endpos = land - Vector( 0, 0, 300 ), filter = self,
				mask = MASK_PLAYERSOLID_BRUSHONLY } )
			local npc = ents.Create( t.crewClass )
			if not IsValid( npc ) then return end
			npc:SetKeyValue( "cod1_variant", t.crew )
			npc:SetKeyValue( "cod1_weapon", "random" )
			npc.TankBail = { climb = at( CLIMB_ROOT ), jump = at( JUMP_ROOT ), yaw = hatch.yaw, land = tr.Hit and tr.HitPos or nil,
				burning = i == 1 and math.random() < 0.3 }
			npc:SetPos( at( CLIMB_ROOT ) )
			npc:SetAngles( a )
			npc:Spawn()
			npc:Activate()
			if IsValid( self.Spawner ) then
				self.Spawner:AddCleanup( "npcs", npc )
				undo.Create( "CoD1 Tank Crewman" )
				undo.AddEntity( npc )
				undo.SetPlayer( self.Spawner )
				undo.Finish()
			end
		end )
	end
end

hook.Add( "EntityTakeDamage", "COD1TankArmour", function( target, dmg )
	if not target.IsCOD1Tank then return end
	if not target.Dead and dmg:IsExplosionDamage() then
		local inf = dmg:GetInflictor()
		local cls = IsValid( inf ) and inf:GetClass() or ""
		if cls ~= "cod1_rocket" and cls ~= "cod1_satchel" and inf ~= target and not ( IsValid( inf ) and inf.IsCOD1Tank ) then
			target:Chip( dmg:GetDamage() * ( cls == "cod1_grenade" and 0.1 or 1 ), dmg:GetAttacker() )
		end
	end
	dmg:SetDamage( 0 )
	return true
end )

hook.Add( "PlayerSpawnedNPC", "COD1Tank", function( ply, ent )
	if IsValid( ent ) and ent.IsCOD1Tank then ent.Spawner = ply end
end )

--thanks gmodwiki
