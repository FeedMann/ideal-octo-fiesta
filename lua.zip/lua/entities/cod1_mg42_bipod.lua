AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "cod1_mg_turret"
ENT.PrintName = "MG42 on Bipod (Empty)"
ENT.Author = "adodser"
ENT.Category = "Call of Duty 1"
ENT.Spawnable = true
ENT.KindKey = "mg42_prone"
ENT.NoCrew = true
ENT.AnyTeam = true

--bipod mg42 for laying down on the ground
