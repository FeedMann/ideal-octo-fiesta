AddCSLuaFile()

ENT.Type = "anim"
ENT.Base = "base_anim"
ENT.PrintName = "Parachute"
ENT.Spawnable = false
ENT.AutomaticFrameAdvance = true
ENT.RenderGroup = RENDERGROUP_OPAQUE

ENT.Model = "models/cod1/props/parachute.mdl"

function ENT:Initialize()
	self:SetModel( self.Model )
	self:SetSolid( SOLID_NONE )
	self:SetMoveType( MOVETYPE_NONE )
	self:DrawShadow( false )
	if CLIENT then
		self:SetRenderBounds( Vector( -300, -300, -20 ), Vector( 300, 300, 520 ) )
		return
	end
	self:PlayAnim( "idle" )
end

function ENT:PlayAnim( name )
	local seq = self:LookupSequence( name )
	if seq < 0 then return 0 end
	self:ResetSequence( seq )
	self:SetCycle( 0 )
	self:SetPlaybackRate( 1 )
	return self:SequenceDuration( seq )
end

function ENT:Land()
	if self.Landed then return end
	self.Landed = true
	self:PlayAnim( "land" )
	local t = GetConVar( "cod1_para_chute_time" ):GetFloat()
	if t > 0 then SafeRemoveEntityDelayed( self, t ) end
end

local GEAR = { "tag_gear", "tag_con01", "tag_con02", "tag_hippack", "tag_l_straps", "tag_main_chute", "tag_r_straps",
	"tag_reserve_chute", "backbagrip", "bag2map", "object02", "object03", "object04", "object05", "rip1", "cylinder03" }

function ENT:Deflate()
	if self.Landed then return end
	self.Landed = true
	for _, name in ipairs( GEAR ) do
		local b = self:LookupBone( name )
		if b then self:ManipulateBoneScale( b, vector_origin ) end
	end
	if self:PlayAnim( "hit" ) <= 0 then self:PlayAnim( "land" ) end
	local t = GetConVar( "cod1_para_chute_time" ):GetFloat()
	if t > 0 then SafeRemoveEntityDelayed( self, t ) end
end

function ENT:Think()
	self:NextThink( CurTime() )
	return true
end

--parachutes, sometimes they land in a tree. thats realism
