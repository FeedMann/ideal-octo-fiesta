AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "m1garand"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--garand, listen for the ping
