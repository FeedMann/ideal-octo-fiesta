AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "colt"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--colt 45
