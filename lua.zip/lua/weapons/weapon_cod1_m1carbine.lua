AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "m1carbine"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--m1 carbine
