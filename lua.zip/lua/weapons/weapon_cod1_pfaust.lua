AddCSLuaFile()
SWEP.Base = "weapon_cod1_rocket"
SWEP.CoDKey = "pfaust"
SWEP.Spawnable = true
SWEP.OneShot = true
COD1.SetupSWEP( SWEP )

--panzerfaust, one shot then throw it away
