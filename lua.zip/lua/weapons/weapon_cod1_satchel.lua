AddCSLuaFile()
SWEP.Base = "weapon_cod1_grenade"
SWEP.CoDKey = "satchel"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )

--satchel, plant it and run like hell
