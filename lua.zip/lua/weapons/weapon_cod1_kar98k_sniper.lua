AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "kar98k_sniper"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--scoped kar, hold breath
