AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "ppsh"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--ppsh, spray and pray
