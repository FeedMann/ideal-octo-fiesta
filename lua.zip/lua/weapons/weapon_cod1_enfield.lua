AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "enfield"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--lee enfield, the best bolt action fight me
