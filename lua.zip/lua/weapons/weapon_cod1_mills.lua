AddCSLuaFile()
SWEP.Base = "weapon_cod1_grenade"
SWEP.CoDKey = "mills"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--mills bomb, very british
