AddCSLuaFile()
SWEP.Base = "weapon_cod1_rocket"
SWEP.CoDKey = "bazooka"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )

--bazooka for the tigers
