AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "springfield"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--springfield, the american sniper
