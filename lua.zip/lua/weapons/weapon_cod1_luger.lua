AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "luger"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--luger
