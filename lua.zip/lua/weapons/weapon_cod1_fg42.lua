AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "fg42"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--fg42 is lowkey op
