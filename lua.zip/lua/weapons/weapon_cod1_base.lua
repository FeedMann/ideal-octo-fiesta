AddCSLuaFile()

SWEP.Base = "weapon_base"
SWEP.Category = "Call of Duty 1"
SWEP.Spawnable = false
SWEP.UseHands = false
SWEP.ViewModelFOV = 74
SWEP.DrawCrosshair = false
SWEP.DrawAmmo = true
SWEP.BobScale = 0.5
SWEP.SwayScale = 0.5
SWEP.Secondary = { ClipSize = -1, DefaultClip = -1, Automatic = true, Ammo = "none" }

function SWEP:SetupDataTables()
	self:NetworkVar( "Bool", 0, "ADS" )
	self:NetworkVar( "Bool", 1, "NeedRechamber" )
	self:NetworkVar( "Float", 0, "ADSTime" )
	self:NetworkVar( "Float", 1, "NextIdle" )
	self:NetworkVar( "Float", 2, "ReloadAt" )
	self:NetworkVar( "Float", 3, "RechamberAt" )
	self:NetworkVar( "Float", 4, "Spread" )
	self:NetworkVar( "Int", 0, "ReloadState" )
end

function SWEP:Def() return COD1.WeaponDefs[ self.CoDKey ] end
function SWEP:Has( seq ) return self:Def().anims[ seq ] ~= nil end

function SWEP:Initialize()
	self:SetHoldType( self.HoldType )
end

function SWEP:Seq( name, rate )
	local owner = self:GetOwner()
	if not IsValid( owner ) or not owner:IsPlayer() then return 0 end
	local vm = owner:GetViewModel()
	if not IsValid( vm ) then return 0 end
	local seq = vm:LookupSequence( name )
	if seq < 0 then return 0 end
	vm:SendViewModelMatchingSequence( seq )
	vm:SetPlaybackRate( rate or 1 )
	local dur = vm:SequenceDuration( seq ) / ( rate or 1 )
	self:SetNextIdle( CurTime() + dur )
	return dur
end

function SWEP:Sound( key )
	local alias = self:Def().sounds[ key ]
	if alias then self:EmitSound( "COD1." .. alias:lower() ) return true end
	return false
end

function SWEP:FireLoop()
	local alias = self:Def().sounds.loopFireSound
	if not alias then return end
	self.LoopUntil = CurTime() + ( self:Def().fireTime or 0.1 ) * 2.5
	if self.FireSnd or ( CLIENT and game.SinglePlayer() ) then return end
	if SERVER then
		local rf = RecipientFilter()
		rf:AddPAS( self:GetPos() )
		if not game.SinglePlayer() and IsValid( self:GetOwner() ) then rf:RemovePlayer( self:GetOwner() ) end
		self.FireSnd = CreateSound( self, "COD1." .. alias:lower(), rf )
	elseif IsFirstTimePredicted() then
		self.FireSnd = CreateSound( self, "COD1." .. alias:lower() )
	end
	if self.FireSnd then self.FireSnd:Play() end
end

function SWEP:StopFireLoop()
	if not self.FireSnd then return end
	self.FireSnd:Stop()
	self.FireSnd = nil
	self:Sound( "stopFireSound" )
end

function SWEP:Deploy()
	local d = self:Def()
	self:SetADS( false )
	self:SetReloadState( 0 )
	self:SetNeedRechamber( false )
	self:SetSpread( d.hipSpreadStandMin or 1 )
	self:Seq( "raise" )
	self:SetNextPrimaryFire( CurTime() + ( d.raiseTime or 0.4 ) )
	self:ApplyHands()
	return true
end

function SWEP:Holster()
	self:SetADS( false )
	self:SetReloadState( 0 )
	self:StopFireLoop()
	return true
end

function SWEP:OnRemove()
	self:StopFireLoop()
end

function SWEP:CanPrimaryAttack()
	if self:GetNeedRechamber() then return false end
	if self:Clip1() <= 0 then
		self:EmitSound( "Weapon_Pistol.Empty" )
		self:SetNextPrimaryFire( CurTime() + 0.3 )
		self:Reload()
		return false
	end
	return true
end

function SWEP:PrimaryAttack()
	local d = self:Def()
	local state = self:GetReloadState()
	if state >= 2 then
		if self:Clip1() > 0 and state ~= 4 then self:FinishSegmented() end
		return
	end
	if state == 1 or not self:CanPrimaryAttack() then return end
	local owner = self:GetOwner()
	local last = self:Clip1() == 1
	local ads = self:GetADS() and CurTime() - self:GetADSTime() >= ( d.adsTransInTime or 0.2 )

	self:TakePrimaryAmmo( 1 )
	local spread = math.rad( ads and d.adsSpread or self:GetSpread() )
	owner:LagCompensation( true )
	self:FireBullets( {
		Attacker = owner, Num = 1, Src = owner:GetShootPos(), Dir = owner:GetAimVector(),
		Spread = Vector( math.tan( spread ) * 0.5, math.tan( spread ) * 0.5, 0 ),
		Damage = ( d.damage or 100 ) * GetConVar( "cod1_swep_damage" ):GetFloat(), Force = ( d.damage or 100 ) / 20,
		Tracer = d.class == "smg" and 3 or 1, TracerName = "Tracer", AmmoType = self.Primary.Ammo,
		Callback = function( _, tr )
			return COD1.BulletImpactFX( tr, COD1.SWEPFXKey[ self.CoDKey ] or self.CoDKey, true, not ( SERVER or IsFirstTimePredicted() ) )
		end,
	} )
	owner:LagCompensation( false )
	if not ( last and self:Sound( "lastShotSound" ) ) and not self:Sound( "fireSound" ) then self:FireLoop() end

	local seq = ads and ( last and self:Has( "ads_lastshot" ) and "ads_lastshot" or "ads_fire" )
		or ( last and self:Has( "lastshot" ) and "lastshot" or "fire" )
	if not self:Has( seq ) then seq = ads and "ads_idle" or "fire" end
	self:Seq( seq )
	owner:SetAnimation( PLAYER_ATTACK1 )

	if IsFirstTimePredicted() then
		local ed = EffectData()
		ed:SetEntity( self )
		ed:SetAttachment( 1 )
		ed:SetFlags( d.semiAuto == 0 and 1 or 0 )
		util.Effect( "cod1npc_muzzleflash", ed, true, game.SinglePlayer() )
		local sh = EffectData()
		sh:SetEntity( self )
		sh:SetFlags( d.class == "pistol" and 0 or 1 )
		if d.boltAction ~= 1 then util.Effect( "cod1_vmshell", sh, true, game.SinglePlayer() ) end
	end

	local p = math.Rand( ads and d.adsViewKickPitchMin or d.hipViewKickPitchMin or 50, ads and d.adsViewKickPitchMax or d.hipViewKickPitchMax or 60 ) / 100
	local y = math.Rand( ads and d.adsViewKickYawMin or d.hipViewKickYawMin or -10, ads and d.adsViewKickYawMax or d.hipViewKickYawMax or 10 ) / 100
	owner:ViewPunch( Angle( -p * 1.6, y * 1.6, 0 ) )
	self:SetSpread( math.min( self:GetSpread() + ( d.hipSpreadFireAdd or 0.5 ), d.hipSpreadMax or 6 ) )

	self:SetNextPrimaryFire( CurTime() + ( d.fireTime or 0.1 ) )
	if d.boltAction == 1 and self:Clip1() > 0 then
		self:SetNeedRechamber( true )
		self:SetRechamberAt( CurTime() + ( d.fireTime or 0.33 ) )
	end
end

function SWEP:SecondaryAttack() end

function SWEP:Reload()
	local d = self:Def()
	local owner = self:GetOwner()
	if self:GetReloadState() ~= 0 or self:Clip1() >= d.clipSize or owner:GetAmmoCount( self.Primary.Ammo ) <= 0 then return end
	if CurTime() < self:GetNextPrimaryFire() - 0.05 and not self:GetNeedRechamber() then return end
	self:SetADS( false )
	self:SetNeedRechamber( false )
	owner:SetAnimation( PLAYER_RELOAD )
	if d.segmentedReload == 1 then
		self:SetReloadState( 2 )
		self:Seq( "reload_start" )
		self:Sound( "reloadStartSound" )
		self:SetReloadAt( CurTime() + ( d.reloadStartTime or 1 ) )
		return
	end
	local empty = self:Clip1() == 0
	self:SetReloadState( 1 )
	self:Seq( empty and self:Has( "reload_empty" ) and "reload_empty" or "reload" )
	if not ( empty and self:Sound( "reloadEmptySound" ) ) then self:Sound( "reloadSound" ) end
	self:SetReloadAt( CurTime() + ( empty and d.reloadEmptyTime or d.reloadTime or 2 ) )
end

function SWEP:AddRounds( n )
	local owner = self:GetOwner()
	local take = math.min( n, self:Def().clipSize - self:Clip1(), owner:GetAmmoCount( self.Primary.Ammo ) )
	if take <= 0 then return end
	self:SetClip1( self:Clip1() + take )
	owner:RemoveAmmo( take, self.Primary.Ammo )
end

function SWEP:FinishSegmented()
	local d = self:Def()
	self:SetReloadState( 4 )
	self:Seq( "reload_end" )
	self:Sound( "reloadEndSound" )
	self:SetReloadAt( CurTime() + ( d.reloadEndTime or 0.7 ) )
end

function SWEP:ReloadThink()
	local d = self:Def()
	local state = self:GetReloadState()
	if state == 0 or CurTime() < self:GetReloadAt() then return end
	local owner = self:GetOwner()
	if state == 1 then
		self:AddRounds( d.clipSize )
		self:SetReloadState( 0 )
		self:SetNextPrimaryFire( CurTime() )
	elseif state == 2 or state == 3 then
		self:AddRounds( state == 2 and ( d.reloadStartAdd or 0 ) or math.max( 1, d.reloadAmmoAdd or 1 ) )
		if self:Clip1() >= d.clipSize or owner:GetAmmoCount( self.Primary.Ammo ) <= 0 then
			self:FinishSegmented()
		else
			self:SetReloadState( 3 )
			self:Seq( "reload" )
			self:Sound( "reloadSound" )
			self:SetReloadAt( CurTime() + ( d.reloadTime or 0.6 ) )
		end
	else
		self:SetReloadState( 0 )
		self:SetNextPrimaryFire( CurTime() )
	end
end

function SWEP:ApplyHands()
	local owner = self:GetOwner()
	local vm = IsValid( owner ) and owner:IsPlayer() and owner:GetViewModel()
	if not IsValid( vm ) then return end
	local id = vm:FindBodygroupByName( "hands" )
	if id >= 0 then vm:SetBodygroup( id, COD1.HandSet() ) end
end

function SWEP:Think()
	local d = self:Def()
	local owner = self:GetOwner()
	if not IsValid( owner ) then return end
	if CurTime() >= ( self.NextHandsCheck or 0 ) then
		self.NextHandsCheck = CurTime() + 1
		self:ApplyHands()
	end
	self:ReloadThink()
	if self.FireSnd and CurTime() > ( self.LoopUntil or 0 ) then self:StopFireLoop() end

	if self:GetNeedRechamber() and CurTime() >= self:GetRechamberAt() then
		self:SetNeedRechamber( false )
		local aimed = self:GetADS() and self:Has( "ads_rechamber" )
		if not aimed then
			if self:GetADS() then self:SetADS( false ) self:SetADSTime( CurTime() ) end
			self.NoADSUntil = CurTime() + ( d.rechamberTime or 1 )
		end
		self:Seq( aimed and "ads_rechamber" or "rechamber" )
		self:Sound( "rechamberSound" )
		self:SetNextPrimaryFire( CurTime() + ( d.rechamberTime or 1 ) )
	end

	local want = owner:KeyDown( IN_ATTACK2 ) and self:GetReloadState() == 0 and CurTime() >= ( self.NoADSUntil or 0 )
		and ( not self.CanAim or self:CanAim() )
	if want ~= self:GetADS() then
		self:SetADS( want )
		self:SetADSTime( CurTime() )
		self:Seq( want and "ads_up" or "ads_down" )
		if self.Deployable then self:Sound( want and "deploySound" or "breakdownSound" ) end
	end

	local min = owner:Crouching() and ( d.hipSpreadDuckedMin or 0.9 ) or ( d.hipSpreadStandMin or 1 )
	local speed = owner:GetVelocity():Length2D() / math.max( owner:GetWalkSpeed(), 1 )
	local s = self:GetSpread()
	s = s + speed * ( d.hipSpreadMoveAdd or 8 ) * FrameTime()
	s = s - ( d.hipSpreadDecayRate or 4 ) * FrameTime()
	self:SetSpread( math.Clamp( s, min, d.hipSpreadMax or 6 ) )

	if CurTime() >= self:GetNextIdle() and self:GetReloadState() == 0 then
		local idle = self:GetADS() and "ads_idle" or ( self:Clip1() == 0 and self:Has( "idle_empty" ) and "idle_empty" or "idle" )
		self:Seq( idle )
		self:SetNextIdle( math.huge )
	end
end

function SWEP:Melee()
	local d = self:Def()
	if CurTime() < self:GetNextPrimaryFire() or self:GetReloadState() ~= 0 then return end
	local owner = self:GetOwner()
	self:SetADS( false )
	self:Seq( "melee" )
	owner:SetAnimation( PLAYER_ATTACK1 )
	if COD1.PlayerMeleeAnim then COD1.PlayerMeleeAnim( owner ) end
	self:EmitSound( "COD1.melee_swing_large" )
	self:SetNextPrimaryFire( CurTime() + ( d.meleeTime or 0.7 ) )
	if CLIENT then return end
	timer.Simple( 0.15, function()
		if not IsValid( self ) or not IsValid( owner ) then return end
		owner:LagCompensation( true )
		local tr = util.TraceHull( { start = owner:GetShootPos(), endpos = owner:GetShootPos() + owner:GetAimVector() * 64,
			mins = Vector( -8, -8, -8 ), maxs = Vector( 8, 8, 8 ), filter = owner, mask = MASK_SHOT_HULL } )
		owner:LagCompensation( false )
		if tr.Hit then
			self:EmitSound( "COD1.melee_hit" )
			if IsValid( tr.Entity ) then
				local dmg = DamageInfo()
				dmg:SetAttacker( owner )
				dmg:SetInflictor( self )
				dmg:SetDamage( ( d.meleeDamage or 150 ) * GetConVar( "cod1_swep_damage" ):GetFloat() )
				dmg:SetDamageType( DMG_CLUB )
				dmg:SetDamageForce( owner:GetAimVector() * 4000 )
				dmg:SetDamagePosition( tr.HitPos )
				tr.Entity:TakeDamageInfo( dmg )
			end
		end
	end )
end

function SWEP:ADSFraction()
	local d = self:Def()
	local t = CurTime() - self:GetADSTime()
	if self:GetADS() then return math.Clamp( t / math.max( d.adsTransInTime or 0.2, 0.01 ), 0, 1 ) end
	return 1 - math.Clamp( t / math.max( d.adsTransOutTime or 0.3, 0.01 ), 0, 1 )
end

function SWEP:Scoped()
	return ( self:Def().adsZoomFov or 65 ) <= 25
end

function SWEP:TranslateFOV( fov )
	local f = self:ADSFraction()
	local d = self:Def()
	if d.adsZoomGunFov then
		self.BaseViewModelFOV = self.BaseViewModelFOV or self.ViewModelFOV
		self.ViewModelFOV = Lerp( f, self.BaseViewModelFOV, self.BaseViewModelFOV * d.adsZoomGunFov / 80 )
	end
	return Lerp( f, fov, fov * ( d.adsZoomFov or 65 ) / 80 )
end

function SWEP:AdjustMouseSensitivity()
	if self:ADSFraction() < 0.5 then return nil end
	return ( self:Def().adsZoomFov or 65 ) / 80
end

if CLIENT then
	local SIDE = Material( "cod1/hud/side_skinny" )
	local QUARTER = Material( "cod1/hud/reticle_quarter" )

	function SWEP:DrawWeaponSelection( x, y, w, h, alpha )
		self.SelIcon = self.SelIcon or Material( "cod1/hud/icon_" .. self.CoDKey )
		local iw = w * 0.9
		local ih = iw * self.SelIcon:Height() / math.max( self.SelIcon:Width(), 1 )
		if ih > h * 0.8 then ih = h * 0.8 iw = ih * self.SelIcon:Width() / math.max( self.SelIcon:Height(), 1 ) end
		surface.SetMaterial( self.SelIcon )
		surface.SetDrawColor( 255, 235, 180, alpha )
		surface.DrawTexturedRect( x + ( w - iw ) / 2, y + ( h - ih ) / 2, iw, ih )
	end

	function SWEP:PreDrawViewModel()
		if self:Scoped() and self:ADSFraction() >= 1 then return true end
	end

	function SWEP:GetViewModelPosition( pos, ang )
		if not self.HipPitch then return pos, ang end
		ang:RotateAroundAxis( ang:Right(), self.HipPitch * ( 1 - self:ADSFraction() ) )
		return pos, ang
	end

	function SWEP:DrawHUD()
		local w, h = ScrW(), ScrH()
		local f = self:ADSFraction()
		if self:Scoped() and f >= 1 then
			local size = h * 220 / 480
			local cx, cy = w / 2, h / 2
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawRect( 0, 0, cx - size, h )
			surface.DrawRect( cx + size, 0, w - cx - size, h )
			surface.DrawRect( cx - size, 0, size * 2, cy - size )
			surface.DrawRect( cx - size, cy + size, size * 2, h - cy - size )
			surface.SetMaterial( QUARTER )
			surface.SetDrawColor( 255, 255, 255, 255 )
			surface.DrawTexturedRectUV( cx - size, cy - size, size, size, 0, 0, 1, 1 )
			surface.DrawTexturedRectUV( cx, cy - size, size, size, 1, 0, 0, 1 )
			surface.DrawTexturedRectUV( cx - size, cy, size, size, 0, 1, 1, 0 )
			surface.DrawTexturedRectUV( cx, cy, size, size, 1, 1, 0, 0 )
			surface.SetDrawColor( 0, 0, 0, 255 )
			surface.DrawRect( cx - size, cy - 1, size * 2, 2 )
			surface.DrawRect( cx - 1, cy, 2, size )
			return
		end
		if f > 0.2 then return end
		local fov = LocalPlayer():GetFOV()
		local gap = math.tan( math.rad( self:GetSpread() ) * 0.5 ) / math.tan( math.rad( fov ) * 0.5 ) * w / 2 + 3
		local len = 8 * h / 480
		local a = 255 * ( 1 - f / 0.2 )
		surface.SetMaterial( SIDE )
		surface.SetDrawColor( 255, 255, 255, a )
		local cx, cy = w / 2, h / 2
		surface.DrawTexturedRect( cx + gap, cy - 1, len, 2 )
		surface.DrawTexturedRect( cx - gap - len, cy - 1, len, 2 )
		surface.DrawTexturedRect( cx - 1, cy + gap, 2, len )
		surface.DrawTexturedRect( cx - 1, cy - gap - len, 2, len )
	end
end

--base for every gun, if guns break look here first
