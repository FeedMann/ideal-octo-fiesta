AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "thompson"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--thompson, best weapon
