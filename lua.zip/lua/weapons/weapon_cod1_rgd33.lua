AddCSLuaFile()
SWEP.Base = "weapon_cod1_grenade"
SWEP.CoDKey = "rgd33"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--russian grenade
