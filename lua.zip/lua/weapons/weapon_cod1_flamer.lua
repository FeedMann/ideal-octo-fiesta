AddCSLuaFile()

SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "flamer"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )
SWEP.Primary.Automatic = true

function SWEP:StopFlame()
	if not self.Flaming then return end
	self.Flaming = false
	if self.FlameSnd then self.FlameSnd:Stop() end
	self:EmitSound( "COD1.Flame.Stop" )
	self:Seq( "idle" )
end

function SWEP:Holster()
	self:StopFlame()
	return true
end

function SWEP:OnRemove()
	self:StopFlame()
end

function SWEP:Reload() end

function SWEP:PrimaryAttack()
	local owner = self:GetOwner()
	if self:Clip1() <= 0 then
		self:StopFlame()
		self:EmitSound( "COD1.Flame.Empty" )
		self:SetNextPrimaryFire( CurTime() + 0.6 )
		return
	end
	self:SetNextPrimaryFire( CurTime() + 0.1 )
	self:TakePrimaryAmmo( 1 )
	if not self.Flaming then
		self.Flaming = true
		self:EmitSound( "COD1.Flame.Start" )
		self.FlameSnd = self.FlameSnd or CreateSound( self, "COD1.Flame.Loop" )
		self.FlameSnd:Play()
		self:Seq( "fire" )
	end
	self.FlameUntil = CurTime() + 0.2
	owner:SetAnimation( PLAYER_ATTACK1 )
	local aim = owner:GetAimVector()
	if IsFirstTimePredicted() then
		local ed = EffectData()
		ed:SetEntity( self )
		ed:SetAttachment( 1 )
		ed:SetOrigin( owner:GetShootPos() + aim * 30 )
		ed:SetNormal( aim )
		util.Effect( "cod1_flame", ed, true, game.SinglePlayer() )
	end
	if CLIENT then return end
	local src = owner:GetShootPos()
	for _, e in ipairs( ents.FindInSphere( src, 440 ) ) do
		if e ~= owner and IsValid( e ) and ( e:IsPlayer() or e:IsNPC() or e:IsNextBot() or e:GetClass() == "prop_physics" ) then
			local to = e:WorldSpaceCenter() - src
			local d = to:Length()
			if d > 1 and to:GetNormalized():Dot( aim ) > 0.9 - math.min( d, 200 ) / 1000
				and not util.TraceLine( { start = src, endpos = e:WorldSpaceCenter(), mask = MASK_SOLID_BRUSHONLY } ).Hit then
				local dmg = DamageInfo()
				dmg:SetDamage( 12 * GetConVar( "cod1_swep_damage" ):GetFloat() )
				dmg:SetDamageType( DMG_BURN )
				dmg:SetAttacker( owner )
				dmg:SetInflictor( self )
				dmg:SetDamagePosition( e:WorldSpaceCenter() )
				e:TakeDamageInfo( dmg )
				if IsValid( e ) then COD1.Burn( e, 3, owner ) end
			end
		end
	end
	local tr = util.TraceLine( { start = src, endpos = src + aim * 440, filter = owner, mask = MASK_SOLID_BRUSHONLY } )
	if tr.Hit and math.random() < 0.3 then util.Decal( "Scorch", tr.HitPos + tr.HitNormal, tr.HitPos - tr.HitNormal ) end
end

function SWEP:Think()
	local owner = self:GetOwner()
	if not IsValid( owner ) then return end
	if CurTime() >= ( self.NextHandsCheck or 0 ) then
		self.NextHandsCheck = CurTime() + 1
		self:ApplyHands()
	end
	if self.Flaming and CurTime() > ( self.FlameUntil or 0 ) then self:StopFlame() end
	if CurTime() >= self:GetNextIdle() and not self.Flaming then
		self:Seq( "idle" )
		self:SetNextIdle( math.huge )
	end
end

if CLIENT then
	function SWEP:DrawHUD() end
end

--flamethrower, burn baby burn
