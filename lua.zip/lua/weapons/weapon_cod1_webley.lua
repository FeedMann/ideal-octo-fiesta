AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "webley"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )

--webley revolver, jolly good
