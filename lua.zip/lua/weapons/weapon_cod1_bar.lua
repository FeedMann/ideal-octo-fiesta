AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "bar"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--BAR, heavy but worth it
