AddCSLuaFile()
SWEP.Base = "weapon_cod1_rocket"
SWEP.CoDKey = "pschreck"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )

--panzerschreck, rocket doesnt stick out the back anymore
