AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "bren"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--bren gun, the brits favourite
