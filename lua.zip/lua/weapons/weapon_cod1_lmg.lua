AddCSLuaFile()

SWEP.Base = "weapon_cod1_base"
SWEP.Spawnable = false
SWEP.Deployable = true

local BASE = baseclass.Get( "weapon_cod1_base" )

function SWEP:Prone()
	local owner = self:GetOwner()
	if COD1MV and COD1MV.Active and COD1MV.Active( owner ) then return owner:GetNW2Int( "c1mvStance", 0 ) == 2 end
	return owner:Crouching()
end

function SWEP:Ledge()
	local owner = self:GetOwner()
	local eye = owner:EyePos()
	local fwd = owner:GetAimVector()
	fwd.z = 0
	if fwd:LengthSqr() < 0.01 then return false end
	fwd:Normalize()
	local top = eye + fwd * 30
	if util.TraceLine( { start = eye, endpos = top, filter = owner, mask = MASK_SOLID } ).Hit then return false end
	local tr = util.TraceLine( { start = top, endpos = top - Vector( 0, 0, 34 ), filter = owner, mask = MASK_SOLID } )
	return tr.Hit and not tr.StartSolid and tr.HitNormal.z > 0.7 and eye.z - tr.HitPos.z > 6
end

function SWEP:CanAim()
	local owner = self:GetOwner()
	if not IsValid( owner ) or not owner:IsOnGround() then return false end
	if self:GetADS() and self.DeployedAt and owner:GetPos():DistToSqr( self.DeployedAt ) > 16 * 16 then return false end
	local ok = self:Prone() or self:Ledge()
	if ok and not self:GetADS() then self.DeployedAt = owner:GetPos() end
	return ok
end

function SWEP:Deployed()
	return self:GetADS() and CurTime() - self:GetADSTime() >= math.max( self:Def().anims.ads_up or 0.5, 0.5 ) * 0.85
end

function SWEP:PrimaryAttack()
	if not self:Deployed() then
		self:SetNextPrimaryFire( CurTime() + 0.25 )
		return
	end
	return BASE.PrimaryAttack( self )
end

if CLIENT then
	function SWEP:DrawHUD()
		if self:GetADS() then return end
		local can = self:CanAim()
		local text = can and "Hold aim to deploy the bipod" or "Lie down or rest on a ledge to deploy"
		draw.SimpleTextOutlined( text, "DermaDefault", ScrW() / 2, ScrH() * 0.62, Color( 230, 220, 190, 200 ), TEXT_ALIGN_CENTER,
			TEXT_ALIGN_CENTER, 1, Color( 0, 0, 0, 160 ) )
	end
end

--lmg base, deploy it on something
