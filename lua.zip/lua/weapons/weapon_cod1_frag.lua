AddCSLuaFile()
SWEP.Base = "weapon_cod1_grenade"
SWEP.CoDKey = "frag"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--frag out
