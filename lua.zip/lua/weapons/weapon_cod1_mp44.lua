AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "mp44"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--mp44, the first real assault rifle
