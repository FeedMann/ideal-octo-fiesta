AddCSLuaFile()

SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "binoculars"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )
SWEP.DrawAmmo = false

function SWEP:PrimaryAttack()
	self:SetNextPrimaryFire( CurTime() + 0.5 )
	if CLIENT or self:ADSFraction() < 0.9 then return end
	COD1.CallArtillery( self:GetOwner() )
end

function SWEP:Reload() end

function SWEP:Scoped()
	return true
end

function SWEP:TranslateFOV( fov )
	return Lerp( self:ADSFraction(), fov, fov * 0.25 )
end

function SWEP:AdjustMouseSensitivity()
	if self:ADSFraction() < 0.5 then return nil end
	return 0.25
end

if CLIENT then
	local OVERLAY = Material( "cod1/hud/fieldglasses" )

	function SWEP:DrawHUD()
		if self:ADSFraction() < 1 then return end
		local w, h = ScrW(), ScrH()
		local ow = h * 4 / 3
		local x = ( w - ow ) / 2
		surface.SetDrawColor( 255, 255, 255, 255 )
		surface.SetMaterial( OVERLAY )
		surface.DrawTexturedRect( x, 0, ow, h )
		surface.SetDrawColor( 0, 0, 0, 255 )
		if x > 0 then
			surface.DrawRect( 0, 0, x + 1, h )
			surface.DrawRect( x + ow - 1, 0, x + 1, h )
		end
		if not GetConVar( "cod1_artillery" ):GetBool() then return end
		local left = LocalPlayer():GetNW2Float( "COD1ArtyReady", 0 ) - CurTime()
		local text = left > 0 and ( "Artillery ready in " .. math.ceil( left ) .. "s" ) or "Fire to call artillery"
		COD1.DrawText( text, 320, 440, 0.3, 255, 255, 255, left > 0 and 150 or 220, true, "center" )
	end
end

--binoculars, officers love these. now they can call the big guns too
