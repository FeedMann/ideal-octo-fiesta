AddCSLuaFile()

SWEP.Base = "weapon_cod1_base"
SWEP.Spawnable = false

local TANK_DAMAGE = { pfaust = 800, pschreck = 600, bazooka = 600 }

function SWEP:PrimaryAttack()
	if self:GetReloadState() ~= 0 or not self:CanPrimaryAttack() then return end
	local d = self:Def()
	local owner = self:GetOwner()
	local ads = self:GetADS() and CurTime() - self:GetADSTime() >= ( d.adsTransInTime or 0.2 )
	self:TakePrimaryAmmo( 1 )
	self:Sound( "fireSound" )
	self:Seq( ads and self:Has( "ads_fire" ) and "ads_fire" or "fire" )
	owner:SetAnimation( PLAYER_ATTACK1 )
	owner:ViewPunch( Angle( -5, math.Rand( -1.5, 1.5 ), 0 ) )
	self:SetNextPrimaryFire( CurTime() + math.max( d.fireTime or 1, 0.6 ) )
	if IsFirstTimePredicted() then
		local ed = EffectData()
		ed:SetEntity( self )
		ed:SetAttachment( 1 )
		ed:SetFlags( 0 )
		util.Effect( "cod1npc_muzzleflash", ed, true, game.SinglePlayer() )
	end
	if CLIENT then return end
	local aim = owner:GetAimVector()
	if not ads then
		local s = math.rad( 1.2 )
		aim = ( aim + VectorRand() * math.tan( s ) ):GetNormalized()
	end
	local r = ents.Create( "cod1_rocket" )
	if not IsValid( r ) then return end
	r:SetPos( owner:GetShootPos() + aim * 32 + owner:GetRight() * 5 - Vector( 0, 0, 4 ) )
	r:SetAngles( aim:Angle() )
	r.Shooter = owner
	r.Kind = self.CoDKey
	r.TankDamage = TANK_DAMAGE[ self.CoDKey ] or 600
	r.Speed = d.projectileSpeed or 2800
	r:SetOwner( owner )
	r:Spawn()
	COD1.FX( "smoke/smoke_panzerfaust", owner:GetShootPos() - aim * 40, -aim )
	if self.OneShot and self:Clip1() <= 0 and owner:GetAmmoCount( self.Primary.Ammo ) <= 0 then
		timer.Simple( 0.9, function()
			if IsValid( owner ) and IsValid( self ) and owner:GetActiveWeapon() == self then owner:StripWeapon( self:GetClass() ) end
		end )
	end
end

if CLIENT then
	function SWEP:DrawHUD()
		if self:ADSFraction() > 0.2 then return end
		local cx, cy = ScrW() / 2, ScrH() / 2
		surface.SetDrawColor( 255, 255, 255, 160 )
		surface.DrawRect( cx - 1, cy - 1, 2, 2 )
	end
end

--rocket launcher base
