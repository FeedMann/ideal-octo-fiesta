AddCSLuaFile()

SWEP.Base = "weapon_cod1_base"
SWEP.Spawnable = false
SWEP.DrawAmmo = true

local BASE = baseclass.Get( "weapon_cod1_base" )

local MODELS = { frag = "models/cod1/props/mk2_grenade.mdl", stielhandgranate = "models/cod1/props/stielhandgranate.mdl",
	mills = "models/cod1/props/mills_grenade.mdl", rgd33 = "models/cod1/props/rgd33_grenade.mdl" }

function SWEP:SetupDataTables()
	BASE.SetupDataTables( self )
	self:NetworkVar( "Bool", 2, "Pinned" )
	self:NetworkVar( "Float", 5, "PinAt" )
	self:NetworkVar( "Float", 6, "ThrownAt" )
end

function SWEP:Ammo()
	local owner = self:GetOwner()
	return IsValid( owner ) and owner:GetAmmoCount( self.Primary.Ammo ) or 0
end

function SWEP:Deploy()
	self:SetPinned( false )
	self:SetThrownAt( 0 )
	self:Seq( self:Ammo() > 0 and "raise" or "idle_empty" )
	self:SetNextPrimaryFire( CurTime() + ( self:Def().raiseTime or 0.5 ) )
	self:ApplyHands()
	return true
end

function SWEP:Holster()
	self:SetPinned( false )
	return true
end

function SWEP:PrimaryAttack()
	if self:GetPinned() or self:Ammo() <= 0 or CurTime() < self:GetNextPrimaryFire() then return end
	self:SetPinned( true )
	self:SetPinAt( CurTime() )
	self:Seq( "pullpin" )
	self:Sound( "pullbackSound" )
end

function SWEP:SecondaryAttack() end
function SWEP:Reload() end

function SWEP:Throw()
	local d = self:Def()
	local owner = self:GetOwner()
	self:SetPinned( false )
	self:SetThrownAt( CurTime() )
	self:Seq( self:Ammo() <= 1 and self:Has( "lastshot" ) and "lastshot" or "fire" )
	owner:SetAnimation( PLAYER_ATTACK1 )
	self:SetNextPrimaryFire( CurTime() + ( d.fireTime or 1 ) )
	if CLIENT then return end
	local aim = owner:GetAimVector()
	local src = owner:GetShootPos() + aim * 16 + owner:GetRight() * 6 - Vector( 0, 0, 6 )
	local satchel = self.CoDKey == "satchel"
	local nade = ents.Create( satchel and "cod1_satchel" or "cod1_grenade" )
	if not IsValid( nade ) then return end
	if self.CoDKey == "smoke" then nade.Smoke = true end
	if MODELS[ self.CoDKey ] then nade.Model = MODELS[ self.CoDKey ] end
	nade:SetPos( src )
	nade:SetAngles( aim:Angle() )
	nade.Thrower = owner
	nade.ThrownAt = CurTime()
	nade:SetOwner( owner )
	nade:Spawn()
	if nade.SetFuse then nade:SetFuse( d.fuseTime or 4 ) end
	local phys = nade:GetPhysicsObject()
	if IsValid( phys ) then
		phys:SetVelocity( aim * ( d.projectileSpeed or 900 ) + Vector( 0, 0, d.projectileSpeedUp or 120 ) + owner:GetVelocity() * 0.5 )
		phys:AddAngleVelocity( VectorRand() * 600 )
	end
	timer.Simple( 0.25, function() if IsValid( nade ) then nade:SetOwner( NULL ) end end )
	owner:RemoveAmmo( 1, self.Primary.Ammo )
	nade:EmitSound( "COD1.GrenadeThrow" )
end

function SWEP:Think()
	local owner = self:GetOwner()
	if not IsValid( owner ) then return end
	if CurTime() >= ( self.NextHandsCheck or 0 ) then
		self.NextHandsCheck = CurTime() + 1
		self:ApplyHands()
	end
	local d = self:Def()
	if self:GetPinned() and not owner:KeyDown( IN_ATTACK ) and CurTime() >= self:GetPinAt() + ( d.holdFireTime or 0.5 ) then
		self:Throw()
	end
	local thrown = self:GetThrownAt()
	if thrown > 0 and CurTime() >= self:GetNextPrimaryFire() then
		self:SetThrownAt( 0 )
		if self:Ammo() > 0 then
			self:Seq( "raise" )
		elseif SERVER then
			owner:StripWeapon( self:GetClass() )
			return
		end
	end
	if CurTime() >= self:GetNextIdle() and not self:GetPinned() then
		self:Seq( self:Ammo() > 0 and "idle" or "idle_empty" )
		self:SetNextIdle( math.huge )
	end
end

if CLIENT then
	function SWEP:DrawHUD() end
end

--grenade base, cook it if you dare
