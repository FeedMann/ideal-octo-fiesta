AddCSLuaFile()
SWEP.Base = "weapon_cod1_lmg"
SWEP.CoDKey = "mg34"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )

--mg34
