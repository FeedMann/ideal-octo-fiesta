AddCSLuaFile()
SWEP.Base = "weapon_cod1_grenade"
SWEP.CoDKey = "stielhandgranate"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--potato masher
