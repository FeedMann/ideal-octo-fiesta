AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "mosin_nagant_sniper"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--scoped mosin, pavlov would be proud
