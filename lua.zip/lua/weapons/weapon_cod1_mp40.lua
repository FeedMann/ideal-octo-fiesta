AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "mp40"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--mp40
