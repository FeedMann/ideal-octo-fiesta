AddCSLuaFile()
SWEP.Base = "weapon_cod1_lmg"
SWEP.CoDKey = "dp28"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )

--dp28, the pancake gun
