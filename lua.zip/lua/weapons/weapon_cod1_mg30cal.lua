AddCSLuaFile()
SWEP.Base = "weapon_cod1_lmg"
SWEP.CoDKey = "mg30cal"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )

--30 cal you can carry, your arms will hate you
