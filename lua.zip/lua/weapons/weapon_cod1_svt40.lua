AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "svt40"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )

--svt40
