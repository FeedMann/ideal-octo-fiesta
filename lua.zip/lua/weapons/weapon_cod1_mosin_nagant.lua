AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "mosin_nagant"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--mosin, the texture is fixed now i promise
