AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "kar98k"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--kar98k, one shot one kill
