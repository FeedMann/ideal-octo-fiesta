AddCSLuaFile()
SWEP.Base = "weapon_cod1_grenade"
SWEP.CoDKey = "smoke"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )

--smoke grenade, pop smoke
