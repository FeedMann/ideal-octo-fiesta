AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "stensd"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP, "Call of Duty: United Offensive" )
SWEP.Quiet = true

--silenced sten for the sas, very sneaky
