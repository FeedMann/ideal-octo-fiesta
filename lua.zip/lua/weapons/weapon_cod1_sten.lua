AddCSLuaFile()
SWEP.Base = "weapon_cod1_base"
SWEP.CoDKey = "sten"
SWEP.Spawnable = true
COD1.SetupSWEP( SWEP )

--sten, rattles like a sewing machine
