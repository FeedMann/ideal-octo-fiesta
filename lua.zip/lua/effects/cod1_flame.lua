local FRAMES = 43
local TEXTURE = "cod1/efx/flamethrower/flame"
local MATS = {}
local PUFFS = {}
local WHITE = Color( 255, 255, 255 )

local function frameMat( i )
	local m = MATS[ i ]
	if not m then
		m = CreateMaterial( "cod1_flame_f" .. i, "UnlitGeneric", { [ "$basetexture" ] = TEXTURE, [ "$frame" ] = i,
			[ "$additive" ] = 1, [ "$vertexcolor" ] = 1, [ "$vertexalpha" ] = 1, [ "$nocull" ] = 1 } )
		MATS[ i ] = m
	end
	return m
end

function EFFECT:Init( data )
	local ent = data:GetEntity()
	local pos, dir = data:GetOrigin(), data:GetNormal()
	local src, idx = ent, data:GetAttachment()
	if IsValid( ent ) and ent:IsWeapon() and ent:IsCarriedByLocalPlayer() and not LocalPlayer():ShouldDrawLocalPlayer() then
		src = LocalPlayer():GetViewModel()
		idx = IsValid( src ) and src:LookupAttachment( "muzzle" ) or 0
	end
	if IsValid( src ) and idx > 0 then
		local att = src:GetAttachment( idx )
		if att then pos = att.Pos end
	end
	local now = CurTime()
	local base = IsValid( ent ) and ent:GetVelocity() or vector_origin
	for i = 0, #PUFFS < 600 and 5 or -1 do
		local age = i * 0.016
		local v = ( dir + VectorRand() * 0.035 ):GetNormalized() * math.Rand( 950, 1100 ) + base
		PUFFS[ #PUFFS + 1 ] = {
			pos = pos + dir * math.Rand( 2, 8 ) + v * age, vel = v, born = now - age, life = math.Rand( 0.55, 0.78 ),
			s0 = math.Rand( 4, 8 ), s1 = math.Rand( 75, 115 ), roll = math.Rand( 0, 360 ), spin = math.Rand( -70, 70 ),
			lift = math.Rand( 40, 110 ), smoke = math.random() < 0.3
		}
	end
	if GetConVar( "cod1_efx_lights" ):GetBool() then
		local d = DynamicLight( IsValid( ent ) and ent:EntIndex() or 0 )
		if d then
			d.pos = pos + dir * 140
			d.r, d.g, d.b = 255, 140, 50
			d.brightness = 3
			d.size = 320
			d.decay = 900
			d.dietime = now + 0.15
		end
	end
end

function EFFECT:Think() return false end
function EFFECT:Render() end

hook.Add( "Think", "COD1NPCFlame", function()
	local n = #PUFFS
	if n == 0 then return end
	local now, dt = CurTime(), FrameTime()
	local drag = math.max( 1 - 1.9 * dt, 0 )
	for i = n, 1, -1 do
		local p = PUFFS[ i ]
		local t = now - p.born
		if t > p.life then
			if p.smoke and COD1 and COD1.PlayEFX then COD1.PlayEFX( "smoke/smoke_flamethrower", p.pos, Vector( 0, 0, 1 ) ) end
			table.remove( PUFFS, i )
		else
			p.vel = p.vel * drag
			p.vel.z = p.vel.z + p.lift * dt
			local to = p.pos + p.vel * dt
			local tr = util.TraceLine( { start = p.pos, endpos = to, mask = MASK_SOLID_BRUSHONLY } )
			if tr.Hit then
				local n2 = tr.HitNormal
				p.pos = tr.HitPos + n2 * 4
				p.vel = ( p.vel - n2 * p.vel:Dot( n2 ) ) * 0.45
				if not p.hit then
					p.hit = true
					p.s1 = p.s1 * 1.25
					if math.random() < 0.15 and COD1 and COD1.PlayEFX then COD1.PlayEFX( "smoke/smoke_flamethrower_lg", p.pos, n2 ) end
				end
			else
				p.pos = to
			end
		end
	end
end )

hook.Add( "PostDrawTranslucentRenderables", "COD1NPCFlame", function( depth, sky )
	if depth or sky or #PUFFS == 0 then return end
	local now, eye = CurTime(), EyePos()
	for _, p in ipairs( PUFFS ) do
		local f = math.Clamp( ( now - p.born ) / p.life, 0, 1 )
		local size = Lerp( f ^ 0.55, p.s0, p.s1 )
		render.SetMaterial( frameMat( math.min( math.floor( f ^ 0.8 * FRAMES ), FRAMES - 1 ) ) )
		render.DrawQuadEasy( p.pos, ( eye - p.pos ):GetNormalized(), size, size, WHITE, p.roll + p.spin * ( now - p.born ) )
	end
end )

--hans get the flammenwerfer
