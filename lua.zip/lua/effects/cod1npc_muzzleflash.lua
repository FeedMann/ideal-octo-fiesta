function EFFECT:Init( data )
	local ent = data:GetEntity()
	if not IsValid( ent ) or not COD1.PlayEFX then return end
	local idx = data:GetAttachment()
	local key, view
	if ent:IsWeapon() then
		key = COD1.SWEPFXKey[ ent.CoDKey or "" ] or ent.CoDKey
		if ent:IsCarriedByLocalPlayer() and not LocalPlayer():ShouldDrawLocalPlayer() then
			ent = LocalPlayer():GetViewModel()
			if not IsValid( ent ) then return end
			idx = ent:LookupAttachment( "muzzle" )
			view = true
		end
	else
		key = COD1.WeaponFXKeys[ data:GetDamageType() ]
	end
	local fx = COD1.WeaponFX[ key or "" ] or COD1.WeaponFX.garand
	local att = ent:GetAttachment( idx )
	if not att then return end
	COD1.PlayEFX( view and fx[ 2 ] or fx[ 1 ], att.Pos, att.Ang:Forward(), ent, idx )
end

function EFFECT:Think() return false end
function EFFECT:Render() end

--muzzle flashes look exactly like the game, i checked like 50 times
