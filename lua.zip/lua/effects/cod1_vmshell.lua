function EFFECT:Init( data )
	local wep = data:GetEntity()
	if not IsValid( wep ) or not COD1.PlayEFX then return end
	local ent = wep
	if wep:IsCarriedByLocalPlayer() and not LocalPlayer():ShouldDrawLocalPlayer() then ent = LocalPlayer():GetViewModel() end
	if not IsValid( ent ) then return end
	local idx = ent:LookupAttachment( "brass" )
	local att = ent:GetAttachment( idx )
	if not att then return end
	COD1.PlayEFX( data:GetFlags() == 1 and "shellejects/rifle" or "shellejects/pistol", att.Pos, att.Ang:Forward(), ent, idx )
end

function EFFECT:Think() return false end
function EFFECT:Render() end

--shell casings flying everywhere
