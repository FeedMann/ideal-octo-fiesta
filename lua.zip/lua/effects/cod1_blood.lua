local RED = { { 0.4275, 0.04706, 0.04706 }, { 0.7255, 0.08235, 0.1961 } }

local function spray( p )
	return table.Merge( { mat = "cod1/fx/flesh_hit1", rgb = RED, randomStart = true, rot = { -264, 123 } }, p )
end
local function mist( p )
	return table.Merge( { mat = "cod1/fx/whitesmoke", rot = { -256, 128 }, spin = { -2, 1 } }, p )
end

local EFX = {
	[ 0 ] = {
		spray( { count = { 6, 8 }, life = { 0.2, 0.2 }, height = { 14, 23 }, radius = { 1, 10 }, vel = { -220, 220 }, gravity = 200,
			alpha = { 0.7, 1 }, size = { 2, 2, 15, 26 } } ),
		spray( { count = { 2, 3 }, life = { 0.2, 0.2 }, origin = { 0, 13 }, radius = { 1, 3 }, height = { 1, 3 }, vel = { -220, -90 },
			spin = { -44, 22 }, alpha = { 0.7, 0.8 }, size = { 12, 12, 46, 57 } } ),
		mist( { count = { 3, 3 }, life = { 0.5, 0.5 }, vel = { 2, 33 }, rgb = { { 0.7569, 0.6627, 0.5922 }, { 0.7255, 0.08235, 0.1961 } },
			alpha = { 0.6, 0.7 }, size = { 2, 2, 6, 16 } } ),
		mist( { count = { 4, 6 }, life = { 0.2, 0.3 }, vel = { 23, 59 }, rgb = { { 1, 1, 1 }, { 0.7608, 0.4353, 0.2392 }, { 0.4863, 0.06275, 0.06275 } },
			alpha = { 0.7, 0.7 }, size = { 2, 2, 17, 26 } } ),
	},
	[ 1 ] = {
		spray( { count = { 6, 8 }, life = { 0.1, 0.4 }, origin = { 12, 23 }, height = { 14, 133 }, radius = { 1, 20 }, vel = { -420, 420 },
			gravity = 200, alpha = { 0.7, 1 }, size = { 2, 2, 36, 120 } } ),
		spray( { count = { 2, 3 }, life = { 0.3, 0.3 }, origin = { 0, 33 }, radius = { 1, 13 }, height = { 1, 13 }, vel = { -220, -90 },
			spin = { -44, 22 }, alpha = { 0.7, 0.8 }, size = { 12, 12, 46, 57 } } ),
		mist( { count = { 4, 6 }, life = { 0.4, 0.6 }, vel = { 113, 139 }, rgb = { { 0.7569, 0.6627, 0.5922 }, { 0.8706, 0.6941, 0.5882 } },
			alpha = { 0.3, 0.7 }, size = { 2, 2, 67, 86 } } ),
		mist( { count = { 3, 3 }, life = { 0.5, 0.5 }, vel = { 2, 33 }, rgb = { { 0.7569, 0.6627, 0.5922 }, { 0.7255, 0.08235, 0.1961 } },
			alpha = { 0.6, 0.7 }, size = { 2, 2, 6, 16 } } ),
		mist( { count = { 4, 6 }, life = { 0.2, 0.3 }, vel = { 23, 59 }, rgb = { { 1, 1, 1 }, { 0.7608, 0.4353, 0.2392 }, { 0.4863, 0.06275, 0.06275 } },
			alpha = { 0.7, 0.7 }, size = { 2, 2, 17, 26 } } ),
	},
}

local function rand( r ) return math.Rand( r[ 1 ], r[ 2 ] ) end

local function mix( a, b, t )
	return { Lerp( t, a[ 1 ], b[ 1 ] ), Lerp( t, a[ 2 ], b[ 2 ] ), Lerp( t, a[ 3 ], b[ 3 ] ) }
end

local function fader( c0, c1 )
	return function( p )
		local t = math.Clamp( p:GetLifeTime() / p:GetDieTime(), 0, 1 )
		local c = mix( c0, c1, t )
		p:SetColor( math.min( c[ 1 ] * 330, 255 ), math.min( c[ 2 ] * 330, 255 ), math.min( c[ 3 ] * 330, 255 ) )
		p:SetNextThink( CurTime() )
	end
end

function EFFECT:Init( data )
	local pos, axis = data:GetOrigin(), data:GetNormal()
	if axis:LengthSqr() < 0.01 then axis = VectorRand() end
	axis:Normalize()
	local ang = axis:Angle()
	local right, up = ang:Right(), ang:Up()
	local em = ParticleEmitter( pos )
	if not em then return end
	for _, g in ipairs( EFX[ data:GetFlags() ] or EFX[ 0 ] ) do
		for i = 1, math.random( g.count[ 1 ], g.count[ 2 ] ) do
			local spawn = pos
			if g.origin then spawn = spawn + axis * rand( g.origin ) end
			if g.radius then
				local a = math.Rand( 0, math.pi * 2 )
				spawn = spawn + ( right * math.cos( a ) + up * math.sin( a ) ) * rand( g.radius ) + axis * rand( g.height )
			end
			local out = spawn - pos
			out = out:LengthSqr() > 0.01 and out:GetNormalized() or VectorRand():GetNormalized()
			local p = em:Add( g.mat, spawn )
			if p then
				p:SetVelocity( out * rand( g.vel ) )
				p:SetDieTime( rand( g.life ) )
				p:SetStartAlpha( rand( g.alpha ) * 255 )
				p:SetEndAlpha( 0 )
				p:SetStartSize( math.Rand( g.size[ 1 ], g.size[ 2 ] ) / 2 )
				p:SetEndSize( math.Rand( g.size[ 3 ], g.size[ 4 ] ) / 2 )
				p:SetRoll( math.rad( rand( g.rot ) ) )
				if g.spin then p:SetRollDelta( math.rad( rand( g.spin ) ) * 20 ) end
				if g.gravity then p:SetGravity( Vector( 0, 0, -g.gravity ) ) end
				p:SetLighting( false )
				local fade = fader( g.randomStart and mix( g.rgb[ 1 ], g.rgb[ 2 ], math.random() ) or g.rgb[ 1 ],
					#g.rgb > 2 and mix( g.rgb[ 2 ], g.rgb[ 3 ], math.random() ) or g.rgb[ 2 ] )
				p:SetThinkFunction( fade )
				fade( p )
			end
		end
	end
	em:Finish()
end

function EFFECT:Think() return false end
function EFFECT:Render() end

--red stuff
